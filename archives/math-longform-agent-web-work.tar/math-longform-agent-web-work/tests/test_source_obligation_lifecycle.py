from __future__ import annotations

from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from unittest.mock import patch
import hashlib
import json
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "skills" / "math-longform-publisher" / "scripts"
sys.path.insert(0, str(SCRIPTS))

from content_functions import stage_function_reviews  # noqa: E402
from source_obligations import (  # noqa: E402
    obligation_identity_sha256,
    source_obligation_contracts,
)
import validate_author_question_obligations  # noqa: E402


SOURCE = "The author asks why this construction works and keeps the question as part of the learning route."
FUNCTIONS = ["SUBSTANTIVE_CONTENT", "QUESTION_OR_DOUBT"]


def write_jsonl(path: Path, rows: list[dict[str, object]]) -> None:
    path.write_text(
        "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows),
        encoding="utf-8",
    )


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def aq_row(status: str = "CONFIRMED_ACTIVE_OBLIGATION") -> dict[str, object]:
    return {
        "question_id": "AQ0001",
        "source_span": f"0-{len(SOURCE.encode('utf-8'))}",
        "source_excerpt": SOURCE,
        "obligation_type": "UNDERSTANDING_CHECK",
        "required_action": "Keep the motivating question explicit and answer it without deleting the learning route.",
        "destination_file": "publication_final.md",
        "destination_anchor": "construction-question",
        "resolution_status": status,
        "response_trace": "P03 confirmed this source obligation and routed it forward.",
        "verification_note": "Whole-source semantic review confirmed an independent question duty.",
    }


def scan_row() -> dict[str, object]:
    return {
        "question_id": "AQ0002",
        "source_span": "none",
        "source_excerpt": "none",
        "obligation_type": "SOURCE_WIDE_SEMANTIC_SCAN",
        "required_action": "Review the complete source for missed intellectual obligations.",
        "destination_file": "P03_SOURCE_REVIEW",
        "destination_anchor": "whole-source",
        "resolution_status": "SEMANTIC_SCAN_COMPLETE",
        "response_trace": "P03 reviewed the complete canonical source.",
        "verification_note": "The scan is complete and AQ0001 remains active.",
    }


def atom() -> dict[str, object]:
    return {
        "atom_id": "A0001",
        "source_revision_id": "R0001",
        "source_byte_start": "0",
        "source_byte_end": str(len(SOURCE.encode("utf-8"))),
        "raw_excerpt": SOURCE,
        "required_functions": FUNCTIONS,
        "content_type": "PROSE",
        "p02_surface_mode": "CONTENT_PRESERVE",
        "surface_mode": "CONTENT_PRESERVE",
    }


def atom_contract() -> dict[str, object]:
    return {
        "atom_id": "A0001",
        "required_functions": FUNCTIONS,
        "source_evidence": SOURCE,
        "reason": "This Atom independently carries mathematical content and the author's motivating question.",
        "content_type": "PROSE",
        "local_context_role": "asks why the construction works",
        "global_context_role": "preserves the author's learning route",
        "content_invariant": {"summary": "retain the result and motivating question"},
        "surface_contract": {
            "decision": "CONTENT_PRESERVE",
            "output_operation": "REORGANIZE_CONTENT",
            "prelock_disposition": "NO_PRELOCK",
            "basis": ["ORDINARY_SEMANTIC_CONTENT"],
            "source_cues": [],
            "rationale": "Formalization is allowed only while the motivating question remains explicit.",
            "confidence": "HIGH",
            "allowed_completion": "formalize the wording and answer the question",
            "forbidden_change": "do not keep only the mathematical conclusion",
        },
    }


def obligation_contract(row: dict[str, object]) -> dict[str, object]:
    return {
        "obligation_id": "AQ0001",
        "obligation_kind": "AUTHOR_QUESTION",
        "source_ledger": "author_question_obligation_ledger.jsonl",
        "obligation_identity_sha256": obligation_identity_sha256("AUTHOR_QUESTION", row),
        "source_evidence": SOURCE,
        "source_atom_ids": ["A0001"],
        "required_functions": ["QUESTION_OR_DOUBT"],
        "function_bindings": [
            {"atom_id": "A0001", "function": "QUESTION_OR_DOUBT"}
        ],
        "fulfillment_mode": "ANSWER_IN_EXPLANATION",
        "implementation_requirement": "Keep the motivating question visible and answer why the construction works.",
        "reason": "P03 identified an author question whose function is independent from the mathematical conclusion.",
    }


def prepare_root(root: Path) -> tuple[dict[str, object], dict[str, object]]:
    (root / "source_canonical.txt").write_text(SOURCE, encoding="utf-8")
    active = aq_row()
    write_jsonl(root / "author_question_obligation_ledger.jsonl", [active, scan_row()])
    write_jsonl(
        root / "source_formula_block_ledger.jsonl",
        [
            {
                "formula_block_id": "FB0001",
                "source_span": "none",
                "canonicalization_status": "NO_FRAGMENTED_FORMULA_BLOCKS",
            }
        ],
    )
    write_jsonl(
        root / "source_math_risk_ledger.jsonl",
        [
            {
                "risk_id": "MR0001",
                "source_revision_id": "R0001",
                "source_sha256": hashlib.sha256(SOURCE.encode("utf-8")).hexdigest(),
                "source_span": f"0-{len(SOURCE.encode('utf-8'))}",
                "risk_type": "SOURCE_WIDE_MATH_SEMANTIC_SCAN",
                "claim_excerpt": "WHOLE_SOURCE",
                "reason": "A complete semantic mathematics review was performed over the current source.",
                "required_review": "Review every mathematical claim, condition, and proof dependency in the complete source.",
                "resolution_status": "MATH_SEMANTIC_SCAN_COMPLETE",
                "resolution_note": "P03 reviewed the complete source and found no independent mathematical hazard.",
            },
            {
                "risk_id": "MR0002",
                "source_revision_id": "R0001",
                "source_sha256": hashlib.sha256(SOURCE.encode("utf-8")).hexdigest(),
                "source_span": f"0-{len(SOURCE.encode('utf-8'))}",
                "risk_type": "NO_MATHEMATICAL_RISKS",
                "claim_excerpt": "WHOLE_SOURCE",
                "reason": "The source-wide semantic review found no material mathematical risk that requires article realization.",
                "required_review": "Continue ordinary claim-level and proof-level review at every article boundary.",
                "resolution_status": "NO_MATHEMATICAL_RISKS",
                "resolution_note": "P03 completed a full-source mathematical review rather than relying on token absence.",
            }
        ],
    )
    source_atom = atom()
    write_jsonl(root / "source_atom_ledger.jsonl", [source_atom])
    blueprint = {
        "atom_function_contracts": [atom_contract()],
        "source_obligation_contracts": [obligation_contract(active)],
        "function_preservation_reviews": [],
    }
    return blueprint, active


def write_plan(root: Path) -> None:
    realizations = [
        {
            "realization_id": "RZ00001",
            "atom_id": "A0001",
            "function": "SUBSTANTIVE_CONTENT",
            "source_evidence": SOURCE,
            "writing_instruction": "State the mathematical content explicitly.",
            "realization_group_id": "RG00001",
            "merge_justification": "",
            "source_obligation_ids": [],
        },
        {
            "realization_id": "RZ00002",
            "atom_id": "A0001",
            "function": "QUESTION_OR_DOUBT",
            "source_evidence": SOURCE,
            "writing_instruction": "Keep and answer the motivating author question explicitly.",
            "realization_group_id": "RG00002",
            "merge_justification": "",
            "source_obligation_ids": ["AQ0001"],
        },
    ]
    write_jsonl(
        root / "section_execution_plan.jsonl",
        [{"function_realization_plan_json": json.dumps(realizations)}],
    )


def stage_review(target: Path, *, include_obligation_result: bool) -> dict[str, object]:
    question_unit = "The motivating question remains explicit, and the explanation answers why the construction works."
    question_result: dict[str, object] = {
        "realization_id": "RZ00002",
        "status": "REASONABLE_TRANSFORM",
        "source_evidence": SOURCE,
        "target_evidence": question_unit,
        "source_obligation_ids": ["AQ0001"],
        "source_obligation_results": {},
        "reason": "The target keeps the author's motivating question independent from the conclusion.",
    }
    if include_obligation_result:
        active = aq_row()
        question_result["source_obligation_results"] = {
            "AQ0001": {
                "status": "REASONABLE_TRANSFORM",
                "obligation_identity_sha256": obligation_identity_sha256(
                    "AUTHOR_QUESTION", active
                ),
                "fulfillment_mode": "ANSWER_IN_EXPLANATION",
                "source_evidence": SOURCE,
                "target_evidence": question_unit,
                "reason": "The question is still visible and the requested explanation is delivered in the same unit.",
            }
        }
    return {
        "stage_id": "P06_DRAFT",
        "target_file": "draft.md",
        "target_sha256": sha(target),
        "atom_id": "A0001",
        "function_results": {
            "SUBSTANTIVE_CONTENT": {
                "realization_id": "RZ00001",
                "status": "PRESERVED",
                "source_evidence": SOURCE,
                "target_evidence": "The construction proves the result.",
                "source_obligation_ids": [],
                "source_obligation_results": {},
                "reason": "The mathematical conclusion is present as its own complete sentence.",
            },
            "QUESTION_OR_DOUBT": question_result,
        },
        "verdict": "PASS",
    }


class SourceObligationLifecycleTests(unittest.TestCase):
    def test_p03_cannot_claim_article_fulfillment_before_article_exists(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "source_canonical.txt").write_text(SOURCE, encoding="utf-8")
            premature = aq_row("RESOLVED_IN_ARTICLE")
            write_jsonl(
                root / "author_question_obligation_ledger.jsonl",
                [premature, scan_row()],
            )
            output = StringIO()
            with patch.object(
                sys,
                "argv",
                ["validate_author_question_obligations.py", str(root)],
            ):
                with redirect_stdout(output):
                    code = validate_author_question_obligations.main()
            self.assertEqual(code, 1)
            self.assertIn("before publication_final.md exists", output.getvalue())

    def test_p04_must_bind_every_confirmed_p03_obligation(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            blueprint, _active = prepare_root(root)
            blueprint["source_obligation_contracts"] = []
            _contracts, errors = source_obligation_contracts(
                root, blueprint, [atom()], require_ledgers=True
            )
            self.assertIn("AQ0001", "\n".join(errors))

    def test_p04_cannot_bind_understanding_check_as_plain_content_only(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            blueprint, active = prepare_root(root)
            bad = obligation_contract(active)
            bad["required_functions"] = ["SUBSTANTIVE_CONTENT"]
            bad["function_bindings"] = [
                {"atom_id": "A0001", "function": "SUBSTANTIVE_CONTENT"}
            ]
            blueprint["source_obligation_contracts"] = [bad]
            _contracts, errors = source_obligation_contracts(
                root, blueprint, [atom()], require_ledgers=True
            )
            self.assertIn("requires functions: QUESTION_OR_DOUBT", "\n".join(errors))

    def test_topic_and_function_result_without_obligation_fulfillment_fails(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            blueprint, _active = prepare_root(root)
            write_plan(root)
            target = root / "draft.md"
            target.write_text(
                "The construction proves the result.\n"
                "The motivating question remains explicit, and the explanation answers why the construction works.\n",
                encoding="utf-8",
            )
            blueprint["function_preservation_reviews"] = [
                stage_review(target, include_obligation_result=False)
            ]
            _reviews, errors = stage_function_reviews(
                root,
                blueprint,
                [atom()],
                "P06_DRAFT",
                "draft.md",
                require_all_atoms=True,
            )
            self.assertIn("source_obligation_results", "\n".join(errors))

    def test_formal_rewrite_with_bound_obligation_fulfillment_passes(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            blueprint, _active = prepare_root(root)
            write_plan(root)
            target = root / "draft.md"
            target.write_text(
                "The construction proves the result.\n"
                "The motivating question remains explicit, and the explanation answers why the construction works.\n",
                encoding="utf-8",
            )
            blueprint["function_preservation_reviews"] = [
                stage_review(target, include_obligation_result=True)
            ]
            _reviews, errors = stage_function_reviews(
                root,
                blueprint,
                [atom()],
                "P06_DRAFT",
                "draft.md",
                require_all_atoms=True,
            )
            self.assertEqual(errors, [])


if __name__ == "__main__":
    unittest.main()
