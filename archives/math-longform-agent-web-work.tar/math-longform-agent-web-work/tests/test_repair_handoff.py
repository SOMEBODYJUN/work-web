from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import agent_runtime  # noqa: E402
from phase_registry import get_phase  # noqa: E402
from repair_handoff import validate_claim  # noqa: E402
from runtime_support import validate_json_schema  # noqa: E402


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class RepairHandoffTests(unittest.TestCase):
    def _action_response(self, *, actions: list[dict[str, object]], ready: bool = False) -> dict[str, object]:
        return {
            "status": "ACTION_PROPOSED" if actions else "BLOCKER_FOUND",
            "phase_id": "P06",
            "context_pack_sha256": "a" * 64,
            "summary": "The current turn records a bounded phase result.",
            "actions": actions,
            "phase_completion_claim": {
                "ready": ready,
                "review_mode": "NATIVE_SUBAGENT_REVIEW",
                "verdict": "PASS" if ready else "PARTIAL",
                "evidence": [],
                "unresolved_items": [] if ready else ["The current semantic boundary remains unresolved."],
                "first_loss_boundary": None if ready else "P06 draft boundary",
            },
        }

    def test_incremental_partial_action_does_not_require_handoff(self) -> None:
        response = self._action_response(
            actions=[
                {
                    "action_id": "A1",
                    "action_type": "READ_REGISTERED_FILE",
                    "phase_id": "P06",
                    "target": "source_canonical.txt",
                    "source_basis": [],
                    "rule_basis": [],
                    "reason": "Continue the ordinary incremental phase work.",
                }
            ]
        )
        # Ordinary writer progress is intentionally distinct from a completed
        # semantic review that opens a repair transaction.
        validate_json_schema(response, "action-response.schema.json")
        agent_runtime.validate_serial_completion_claim({}, {}, response)

    def test_empty_partial_without_handoff_is_rejected_by_schema(self) -> None:
        response = self._action_response(actions=[])
        with self.assertRaisesRegex(ValueError, "repair_handoff"):
            validate_json_schema(response, "action-response.schema.json")

    def test_repair_handoff_cannot_be_mixed_with_a_write_action(self) -> None:
        response = self._action_response(
            actions=[
                {
                    "action_id": "A1",
                    "action_type": "READ_REGISTERED_FILE",
                    "phase_id": "P06",
                    "target": "source_canonical.txt",
                    "source_basis": [],
                    "rule_basis": [],
                    "reason": "This action must not be mixed with a repair diagnosis.",
                }
            ]
        )
        response["phase_completion_claim"]["repair_handoff"] = {
            "handoff_id": "RH-TEST0001",
            "return_to_phase": "P06",
            "failure_class": "CONTENT_FUNCTION_LOSS",
            "failure_class_note": "A structured diagnosis is required before any retry.",
            "defects": [{}],
        }
        with self.assertRaisesRegex(ValueError, "empty action"):
            agent_runtime.validate_action_semantics(
                {"cursor": {"current_phase": "P06"}, "active": {"context_pack_sha256": "a" * 64}},
                response,
            )

    def test_claim_binds_exact_source_and_target_and_rejects_stale_target(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "source_canonical.txt"
            target = root / "draft.md"
            source.write_text("The author asks why this construction works.\n", encoding="utf-8")
            target.write_text("The draft currently states only the conclusion.\n", encoding="utf-8")
            state = {
                "identity": {"job_id": "JOB-1", "run_id": "RUN-1"},
                "route": {
                    "phase_plan_revision": 1,
                    "ordered_phase_ids": ["P03", "P04", "P05", "P06", "P07"],
                },
                "cursor": {"attempt": 1, "recovery_epoch": 0},
                "state_revision": 4,
                "active": {"context_pack_sha256": "a" * 64, "repair_handoff": None},
            }
            envelope = {
                "required_reads": [
                    {
                        "relative_path": "source_canonical.txt",
                        "path": str(source),
                        "sha256": digest(source),
                    },
                    {
                        "relative_path": "draft.md",
                        "path": str(target),
                        "sha256": digest(target),
                        "binding_role": "PHASE_OUTPUT_CANDIDATE",
                    },
                ]
            }
            defect = {
                "defect_id": "RHI-TEST0001",
                "responsibility": {
                    "atom_id": "A0001",
                    "function": "QUESTION_OR_DOUBT",
                    "realization_id": "RZ00001",
                    "source_obligation_ids": [],
                },
                "source_evidence": {
                    "path": "source_canonical.txt",
                    "sha256": digest(source),
                    "excerpt": "asks why this construction works",
                },
                "target_evidence": {
                    "path": "draft.md",
                    "sha256": digest(target),
                    "excerpt": "states only the conclusion",
                    "exists": True,
                },
                "first_loss_phase": "P06",
                "classification": "PARTIAL",
                "observed_problem": "The target contains the topic but drops the author's explicit question.",
                "root_cause": "The completion check treated topic coverage as complete semantic consumption.",
                "required_repair": "Restore the question function in a separately identifiable target unit.",
                "forbidden_shortcut": "Do not replace the missing question with a generic topic sentence.",
                "acceptance_condition": "The repaired draft must visibly preserve the question and its motivating role.",
            }
            claim = {
                "ready": False,
                "review_mode": "NATIVE_SUBAGENT_REVIEW",
                "verdict": "PARTIAL",
                "evidence": [],
                "unresolved_items": ["The question function is not demonstrated in the draft."],
                "first_loss_boundary": "P06 draft boundary",
                "repair_handoff": {
                    "handoff_id": "RH-TEST0001",
                    "return_to_phase": "P06",
                    "failure_class": "CONTENT_FUNCTION_LOSS",
                    "failure_class_note": "The draft preserves a topic but not the independent question function.",
                    "first_loss_boundary": "P06 draft boundary",
                    "defects": [defect],
                },
            }
            handoff = validate_claim(
                claim,
                state=state,
                envelope=envelope,
                phase_id="P06",
                ordered_phase_ids=state["route"]["ordered_phase_ids"],
                phase_outputs=get_phase("P06").agent_writes,
                response_sha256="b" * 64,
            )
            self.assertEqual(handoff["defects"][0]["source_evidence"]["sha256"], digest(source))
            self.assertEqual(handoff["created_from"]["failed_phase"], "P06")
            target.write_text("The draft changed after the review.\n", encoding="utf-8")
            stale_envelope = json.loads(json.dumps(envelope))
            with self.assertRaisesRegex(ValueError, "target hash is stale"):
                validate_claim(
                    claim,
                    state=state,
                    envelope=stale_envelope,
                    phase_id="P06",
                    ordered_phase_ids=state["route"]["ordered_phase_ids"],
                    phase_outputs=get_phase("P06").agent_writes,
                    response_sha256="b" * 64,
                )

    def test_context_projection_contains_diagnosis_and_acceptance(self) -> None:
        handoff = {
            "created_from": {"failed_phase": "P06"},
            "return_to_phase": "P06",
            "repair_attempt": 1,
            "first_loss_boundary": "P06 draft boundary",
            "failure_class": "CONTENT_FUNCTION_LOSS",
            "failure_class_note": "The reviewer found a concrete function loss.",
            "unresolved_items": ["Question function is missing."],
            "defects": [
                {
                    "defect_id": "RHI-TEST0001",
                    "responsibility": {"atom_id": "A0001", "function": "QUESTION_OR_DOUBT"},
                    "first_loss_phase": "P06",
                    "classification": "PARTIAL",
                    "observed_problem": "A concrete target function is absent from the candidate.",
                    "root_cause": "The old check counted topic coverage as complete consumption.",
                    "required_repair": "Restore the question as an explicit target responsibility.",
                    "forbidden_shortcut": "Do not substitute a generic topic sentence for the question.",
                    "acceptance_condition": "The next review must find the question function in target bytes.",
                    "source_evidence": {"path": "source_canonical.txt", "excerpt": "question"},
                    "target_evidence": {"path": "draft.md", "excerpt": "conclusion", "exists": True},
                }
            ],
        }
        projection = agent_runtime.repair_handoff_context_payload(
            handoff, {"relative_path": "recovery/handoffs/RH-TEST0001.json", "sha256": "c" * 64}
        )
        self.assertEqual(projection["handoff_payload"], handoff)
        self.assertIn("root_cause", projection["defect_instructions"][0])
        self.assertIn("acceptance_condition", projection["defect_instructions"][0])
        self.assertIn("required_repair", projection["defect_instructions"][0])

    def test_emit_turn_is_idempotent_for_an_active_context(self) -> None:
        state = {
            "cursor": {"current_phase": "P06", "attempt": 1},
            "active": {
                "status": "AWAITING_ACTION",
                "context_pack_sha256": "a" * 64,
            },
            "state_revision": 46,
        }
        envelope = {"context_pack_sha256": "a" * 64, "current_phase": "P06"}
        args = SimpleNamespace(runtime_root="C:/runtime")
        with patch.object(agent_runtime, "load_state", return_value=state), \
            patch.object(agent_runtime, "repair_recovery"), \
            patch.object(agent_runtime, "require_phase"), \
            patch.object(agent_runtime, "validate_bound_context", return_value=envelope) as validate, \
            patch.object(agent_runtime, "commit_context_envelope") as commit, \
            patch.object(agent_runtime, "emit_json") as emit:
            self.assertEqual(agent_runtime.cmd_emit_turn(args), 0)
        validate.assert_called_once()
        commit.assert_not_called()
        emit.assert_called_once_with(envelope)
        self.assertEqual(state["state_revision"], 46)

    def test_repeated_emit_turns_reuse_one_active_binding(self) -> None:
        state = {
            "cursor": {"current_phase": "P06", "attempt": 1},
            "active": {
                "status": "AWAITING_ACTION",
                "context_pack_sha256": "a" * 64,
            },
            "state_revision": 46,
        }
        envelope = {"context_pack_sha256": "a" * 64, "current_phase": "P06"}
        args = SimpleNamespace(runtime_root="C:/runtime")
        with patch.object(agent_runtime, "load_state", return_value=state), \
             patch.object(agent_runtime, "repair_recovery"), \
             patch.object(agent_runtime, "require_phase"), \
             patch.object(agent_runtime, "validate_bound_context", return_value=envelope) as validate, \
             patch.object(agent_runtime, "commit_context_envelope") as commit, \
             patch.object(agent_runtime, "emit_json") as emit:
            self.assertEqual(agent_runtime.cmd_emit_turn(args), 0)
            self.assertEqual(agent_runtime.cmd_emit_turn(args), 0)
        self.assertEqual(validate.call_count, 2)
        commit.assert_not_called()
        self.assertEqual(emit.call_count, 2)
        self.assertEqual(state["active"]["context_pack_sha256"], "a" * 64)
        self.assertEqual(state["state_revision"], 46)

    def test_emit_turn_cannot_invalidate_an_unexecuted_receipt(self) -> None:
        state = {
            "cursor": {"current_phase": "P06", "attempt": 1},
            "active": {
                "status": "ACTION_VALIDATED",
                "context_pack_sha256": "a" * 64,
            },
        }
        args = SimpleNamespace(runtime_root="C:/runtime")
        with patch.object(agent_runtime, "load_state", return_value=state), \
            patch.object(agent_runtime, "repair_recovery"), \
            patch.object(agent_runtime, "require_phase"):
            with self.assertRaisesRegex(ValueError, "after validation"):
                agent_runtime.cmd_emit_turn(args)

    def test_validate_action_cannot_start_a_second_validation_cycle(self) -> None:
        state = {
            "cursor": {"current_phase": "P06", "attempt": 1},
            "active": {"status": "ACTION_VALIDATED", "context_pack_sha256": "a" * 64},
        }
        args = SimpleNamespace(runtime_root="C:/runtime", response="C:/response.json")
        with patch.object(agent_runtime, "load_state", return_value=state), \
            patch.object(agent_runtime, "repair_recovery"), \
            patch.object(agent_runtime, "require_phase"):
            with self.assertRaisesRegex(ValueError, "AWAITING_ACTION"):
                agent_runtime.cmd_validate_action(args)


if __name__ == "__main__":
    unittest.main()
