from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import hashlib
import json
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import agent_runtime  # noqa: E402
from phase_registry import get_phase, phase_brief_for  # noqa: E402
from runtime_support import validate_json_schema  # noqa: E402


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class DesktopRuntimeContractTests(unittest.TestCase):
    def test_runtime_state_can_store_every_accepted_completion_evidence_field(self) -> None:
        action_schema = json.loads(
            (ROOT / "schemas" / "action-response.schema.json").read_text(encoding="utf-8")
        )
        state_schema = json.loads(
            (ROOT / "schemas" / "runtime-state-v2.schema.json").read_text(encoding="utf-8")
        )
        action_evidence = action_schema["properties"]["phase_completion_claim"]["properties"]["evidence"]["items"]
        state_evidence = state_schema["properties"]["execution"]["properties"]["semantic_completion_evidence"]["items"]
        self.assertEqual(state_evidence["required"], action_evidence["required"])
        self.assertEqual(state_evidence["properties"], action_evidence["properties"])

    def test_every_supervised_semantic_phase_has_an_explicit_brief(self) -> None:
        for phase_id in sorted(agent_runtime.SUPERVISED_SEMANTIC_PHASES):
            with self.subTest(phase_id=phase_id):
                brief = phase_brief_for(phase_id)
                self.assertIsNotNone(brief)
                assert brief is not None
                self.assertEqual(brief["phase_id"], phase_id)
                self.assertTrue(brief["mission"])
                self.assertTrue(brief["objective"])
                self.assertGreaterEqual(len(brief["success_conditions"]), 3)
                self.assertGreaterEqual(len(brief["prohibitions"]), 3)
                self.assertTrue(brief["handoff"])

    def test_p05_and_p09_are_real_nonempty_output_contracts(self) -> None:
        self.assertGreaterEqual(len(get_phase("P05").agent_writes), 8)
        self.assertGreaterEqual(len(get_phase("P09").agent_writes), 8)
        self.assertIn("section_execution_plan.jsonl", get_phase("P05").agent_writes)
        self.assertIn("final_trace_map.md", get_phase("P09").agent_writes)

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            phase = get_phase("P05")
            for rel in phase.agent_writes[:-1]:
                (root / rel).write_text("current run evidence\n", encoding="utf-8")
            state = {"roots": {"business_root": str(root)}}
            self.assertEqual(
                agent_runtime.require_phase_outputs(state, "P05"),
                [phase.agent_writes[-1]],
            )

    def test_agent_outputs_do_not_conflict_with_machine_evidence_ownership(self) -> None:
        for phase_id in agent_runtime.SUPERVISED_SEMANTIC_PHASES:
            phase = get_phase(phase_id)
            self.assertFalse(
                set(phase.agent_writes) & agent_runtime.MACHINE_EVIDENCE_TARGETS,
                phase_id,
            )

    def test_completion_review_covers_every_output_and_invalidates_on_change(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "source_canonical.txt"
            plan = root / "section_execution_plan.jsonl"
            draft = root / "draft.md"
            blueprint = root / "publication_blueprint.json"
            source.write_text("exact source question and method\n", encoding="utf-8")
            plan.write_text(
                json.dumps(
                    {
                        "function_realization_plan_json": [
                            {
                                "atom_id": "A0001",
                                "function": "METHOD_OBSERVATION",
                                "realization_id": "RZ00001",
                            }
                        ]
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            draft.write_text("# Draft\n\nThe question and method remain explicit.\n", encoding="utf-8")
            blueprint.write_text('{"review":"current"}\n', encoding="utf-8")
            state = {
                "cursor": {"current_phase": "P06", "attempt": 1},
                "roots": {"business_root": str(root)},
                "phase_records": {
                    "P06": {"written_targets": list(get_phase("P06").agent_writes)}
                },
            }
            envelope = {
                "required_reads": [
                    {
                        "relative_path": "source_canonical.txt",
                        "path": str(source),
                        "sha256": digest(source),
                    },
                    {
                        "relative_path": "section_execution_plan.jsonl",
                        "path": str(plan),
                        "sha256": digest(plan),
                    },
                    {
                        "relative_path": "draft.md",
                        "path": str(draft),
                        "sha256": digest(draft),
                        "binding_role": "PHASE_OUTPUT_CANDIDATE",
                    },
                    {
                        "relative_path": "publication_blueprint.json",
                        "path": str(blueprint),
                        "sha256": digest(blueprint),
                        "binding_role": "PHASE_OUTPUT_CANDIDATE",
                    },
                ]
            }

            def evidence(
                target: Path, excerpt: str, source_file: Path = source, source_excerpt: str = "source question"
            ) -> dict[str, object]:
                result: dict[str, object] = {
                    "source_path": source_file.name,
                    "source_sha256": digest(source_file),
                    "source_excerpt": source_excerpt,
                    "target_path": target.name,
                    "target_sha256": digest(target),
                    "target_excerpt": excerpt,
                    "judgment": "The exact target preserves the bound source responsibility in this phase.",
                }
                if target == draft and source_file == source and source_excerpt == "source question":
                    result.update(
                        {
                            "atom_id": "A0001",
                            "function": "METHOD_OBSERVATION",
                            "realization_id": "RZ00001",
                            "source_obligation_ids": [],
                        }
                    )
                return result

            response = {
                "actions": [],
                "phase_completion_claim": {
                    "ready": True,
                    "review_mode": "NATIVE_SUBAGENT_REVIEW",
                    "verdict": "PASS",
                    "evidence": [
                        evidence(draft, "question and method"),
                        evidence(draft, "question and method", plan, "RZ00001"),
                        evidence(blueprint, '"review":"current"'),
                    ],
                    "unresolved_items": [],
                    "first_loss_boundary": None,
                },
            }
            agent_runtime.validate_serial_completion_claim(state, envelope, response)
            draft.write_text("# Draft\n\nChanged after review.\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "target hash is stale"):
                agent_runtime.validate_serial_completion_claim(state, envelope, response)

    def test_representative_file_evidence_cannot_replace_every_atom_function_review(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "source_canonical.txt"
            plan = root / "section_execution_plan.jsonl"
            draft = root / "draft.md"
            blueprint = root / "publication_blueprint.json"
            source.write_text("two independent source responsibilities\n", encoding="utf-8")
            plan.write_text(
                json.dumps(
                    {
                        "function_realization_plan_json": [
                            {
                                "atom_id": "A0001",
                                "function": "SUBSTANTIVE_CONTENT",
                                "realization_id": "RZ00001",
                                "source_obligation_ids": [],
                            },
                            {
                                "atom_id": "A0001",
                                "function": "METHOD_OBSERVATION",
                                "realization_id": "RZ00002",
                                "source_obligation_ids": [],
                            },
                        ]
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            draft.write_text("# Draft\n\nBoth responsibilities appear.\n", encoding="utf-8")
            blueprint.write_text('{"review":"current"}\n', encoding="utf-8")
            state = {
                "cursor": {"current_phase": "P06", "attempt": 1},
                "roots": {"business_root": str(root)},
                "phase_records": {
                    "P06": {"written_targets": list(get_phase("P06").agent_writes)}
                },
            }
            envelope = {
                "required_reads": [
                    {
                        "relative_path": "source_canonical.txt",
                        "path": str(source),
                        "sha256": digest(source),
                    },
                    {
                        "relative_path": "section_execution_plan.jsonl",
                        "path": str(plan),
                        "sha256": digest(plan),
                    },
                    {
                        "relative_path": "draft.md",
                        "path": str(draft),
                        "sha256": digest(draft),
                        "binding_role": "PHASE_OUTPUT_CANDIDATE",
                    },
                    {
                        "relative_path": "publication_blueprint.json",
                        "path": str(blueprint),
                        "sha256": digest(blueprint),
                        "binding_role": "PHASE_OUTPUT_CANDIDATE",
                    },
                ]
            }
            common = {
                "source_path": "source_canonical.txt",
                "source_sha256": digest(source),
                "source_excerpt": "two independent source responsibilities",
                "target_path": "draft.md",
                "target_sha256": digest(draft),
                "target_excerpt": "Both responsibilities appear.",
                "atom_id": "A0001",
                "function": "SUBSTANTIVE_CONTENT",
                "realization_id": "RZ00001",
                "source_obligation_ids": [],
                "judgment": "The source content has a concrete realization in the exact draft bytes.",
            }
            response = {
                "actions": [],
                "phase_completion_claim": {
                    "ready": True,
                    "review_mode": "NATIVE_SUBAGENT_REVIEW",
                    "verdict": "PASS",
                    "evidence": [
                        common,
                        {
                            **common,
                            "source_path": "section_execution_plan.jsonl",
                            "source_sha256": digest(plan),
                            "source_excerpt": "RZ00001",
                            "atom_id": None,
                            "function": None,
                            "realization_id": None,
                        },
                        {
                            **common,
                            "target_path": "publication_blueprint.json",
                            "target_sha256": digest(blueprint),
                            "target_excerpt": '"review":"current"',
                            "atom_id": None,
                            "function": None,
                            "realization_id": None,
                        },
                    ],
                    "unresolved_items": [],
                    "first_loss_boundary": None,
                },
            }
            with self.assertRaisesRegex(ValueError, "METHOD_OBSERVATION/RZ00002"):
                agent_runtime.validate_serial_completion_claim(state, envelope, response)

    def test_p04_completion_review_cannot_sample_only_one_atom_function(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "source_canonical.txt"
            blueprint = root / "publication_blueprint.json"
            source.write_text("one atom carries a result and a question\n", encoding="utf-8")
            (root / "source_atom_ledger.jsonl").write_text(
                json.dumps(
                    {
                        "atom_id": "A0001",
                        "raw_excerpt": "one atom carries a result and a question",
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            blueprint.write_text(
                json.dumps(
                    {
                        "atom_function_contracts": [
                            {
                                "atom_id": "A0001",
                                "required_functions": [
                                    "SUBSTANTIVE_CONTENT",
                                    "QUESTION_OR_DOUBT",
                                ],
                                "function_matrix": {
                                    function: {
                                        "status": "REQUIRED"
                                        if function in {"SUBSTANTIVE_CONTENT", "QUESTION_OR_DOUBT"}
                                        else "NOT_REQUIRED",
                                        "source_evidence": "one atom carries a result and a question",
                                        "semantic_reason": "The native reviewer must decide this dimension from the exact source span.",
                                    }
                                    for function in (
                                        "SUBSTANTIVE_CONTENT",
                                        "QUESTION_OR_DOUBT",
                                        "EXPLANATION_CHAIN",
                                        "METHOD_OBSERVATION",
                                        "AUTHOR_PERSPECTIVE",
                                        "INTUITION_OR_ANALOGY",
                                        "PROOF_DEPENDENCY",
                                        "FOLLOWUP_REQUEST",
                                        "WARNING_OR_CONTRAST",
                                    )
                                },
                            }
                        ],
                        "source_obligation_contracts": [],
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            state = {
                "cursor": {"current_phase": "P04", "attempt": 1},
                "roots": {"business_root": str(root)},
                "phase_records": {
                    "P04": {"written_targets": list(get_phase("P04").agent_writes)}
                },
            }
            envelope = {
                "required_reads": [
                    {
                        "relative_path": "source_canonical.txt",
                        "path": str(source),
                        "sha256": digest(source),
                    },
                    {
                        "relative_path": "publication_blueprint.json",
                        "path": str(blueprint),
                        "sha256": digest(blueprint),
                        "binding_role": "PHASE_OUTPUT_CANDIDATE",
                    },
                ]
            }
            response = {
                "actions": [],
                "phase_completion_claim": {
                    "ready": True,
                    "review_mode": "NATIVE_SUBAGENT_REVIEW",
                    "verdict": "PASS",
                    "evidence": [
                        {
                            "source_path": "source_canonical.txt",
                            "source_sha256": digest(source),
                            "source_excerpt": "one atom carries a result and a question",
                            "target_path": "publication_blueprint.json",
                            "target_sha256": digest(blueprint),
                            "target_excerpt": '"SUBSTANTIVE_CONTENT"',
                            "atom_id": "A0001",
                            "function": "SUBSTANTIVE_CONTENT",
                            "function_decision": "REQUIRED",
                            "realization_id": None,
                            "source_obligation_ids": [],
                            "judgment": "The reviewer checked only the substantive result function of this Atom.",
                        }
                    ],
                    "unresolved_items": [],
                    "first_loss_boundary": None,
                },
            }
            with self.assertRaisesRegex(ValueError, "QUESTION_OR_DOUBT"):
                agent_runtime.validate_serial_completion_claim(state, envelope, response)

    def test_p06_rejects_a_stale_p05_context_pack_member(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            business = root / "business"
            runtime = root / "runtime"
            business.mkdir()
            runtime.mkdir()
            phase = get_phase("P06")
            for rel in phase.required_reads:
                path = business / rel
                path.parent.mkdir(parents=True, exist_ok=True)
                if rel != "context_pack_manifest.json":
                    path.write_text(f"current {rel}\n", encoding="utf-8")

            plan = business / "section_execution_plan.jsonl"
            stale_plan_sha = hashlib.sha256(b"reviewed P05 plan\n").hexdigest()
            plan.write_text("replaced after P05 review\n", encoding="utf-8")
            context_rows = [
                {
                    "path": rel,
                    "sha256": (
                        stale_plan_sha
                        if rel == "section_execution_plan.jsonl"
                        else digest(business / rel)
                    ),
                }
                for rel in phase.required_reads
                if rel != "context_pack_manifest.json"
            ]
            (business / "context_pack_manifest.json").write_text(
                json.dumps(
                    {
                        "schema_version": "context-pack-manifest-v2",
                        "prepared_before_writing": True,
                        "context_files": context_rows,
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            state = {
                "identity": {"job_id": "J", "run_id": "R", "thread_id": "T"},
                "versions": {"skill_package_version": "test"},
                "roots": {"business_root": str(business), "runtime_root": str(runtime)},
                "route": {"phase_plan_revision": 1},
                "cursor": {"current_phase": "P06", "attempt": 1},
                "state_revision": 1,
                "source": {
                    "global_goal": "test",
                    "source_revision_id": "R0001",
                    "source_sha256": "a" * 64,
                },
                "execution": {"run_mode": "full_publication"},
                "blockers": [],
            }
            with self.assertRaisesRegex(ValueError, "context-pack member hash is stale"):
                agent_runtime.build_context_envelope(state)

    def test_p06_rejects_an_incomplete_context_pack_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            business = root / "business"
            runtime = root / "runtime"
            business.mkdir()
            runtime.mkdir()
            phase = get_phase("P06")
            for rel in phase.required_reads:
                path = business / rel
                path.parent.mkdir(parents=True, exist_ok=True)
                if rel != "context_pack_manifest.json":
                    path.write_text(f"current {rel}\n", encoding="utf-8")
            (business / "context_pack_manifest.json").write_text(
                json.dumps(
                    {
                        "schema_version": "context-pack-manifest-v2",
                        "prepared_before_writing": True,
                        "context_files": [],
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            state = {
                "identity": {"job_id": "J", "run_id": "R", "thread_id": "T"},
                "versions": {"skill_package_version": "test"},
                "roots": {"business_root": str(business), "runtime_root": str(runtime)},
                "route": {"phase_plan_revision": 1},
                "cursor": {"current_phase": "P06", "attempt": 1},
                "state_revision": 1,
                "source": {
                    "global_goal": "test",
                    "source_revision_id": "R0001",
                    "source_sha256": "a" * 64,
                },
                "execution": {"run_mode": "full_publication"},
                "blockers": [],
            }
            with self.assertRaisesRegex(ValueError, "omits required P06 inputs"):
                agent_runtime.build_context_envelope(state)

    def test_completion_review_cannot_use_an_output_as_its_own_source(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "source_canonical.txt"
            draft = root / "draft.md"
            blueprint = root / "publication_blueprint.json"
            plan = root / "section_execution_plan.jsonl"
            source.write_text("source responsibility\n", encoding="utf-8")
            draft.write_text("draft responsibility\n", encoding="utf-8")
            blueprint.write_text('{"review":"current"}\n', encoding="utf-8")
            plan.write_text('{"realization_id":"RZ00001"}\n', encoding="utf-8")
            envelope = {
                "required_reads": [
                    {
                        "relative_path": "source_canonical.txt",
                        "path": str(source),
                        "sha256": digest(source),
                    },
                    {
                        "relative_path": "section_execution_plan.jsonl",
                        "path": str(plan),
                        "sha256": digest(plan),
                    },
                    {
                        "relative_path": "draft.md",
                        "path": str(draft),
                        "sha256": digest(draft),
                        "binding_role": "PHASE_OUTPUT_CANDIDATE",
                    },
                    {
                        "relative_path": "publication_blueprint.json",
                        "path": str(blueprint),
                        "sha256": digest(blueprint),
                        "binding_role": "PHASE_OUTPUT_CANDIDATE",
                    },
                ]
            }
            self_review = {
                "source_path": "draft.md",
                "source_sha256": digest(draft),
                "source_excerpt": "draft responsibility",
                "target_path": "draft.md",
                "target_sha256": digest(draft),
                "target_excerpt": "draft responsibility",
                "judgment": "The draft certifies itself without reopening an upstream authority.",
            }
            response = {
                "actions": [],
                "phase_completion_claim": {
                    "ready": True,
                    "review_mode": "NATIVE_SUBAGENT_REVIEW",
                    "verdict": "PASS",
                    "evidence": [self_review],
                    "unresolved_items": [],
                    "first_loss_boundary": None,
                },
            }
            state = {
                "cursor": {"current_phase": "P06", "attempt": 1},
                "roots": {"business_root": str(root)},
                "phase_records": {
                    "P06": {"written_targets": list(get_phase("P06").agent_writes)}
                },
            }
            with self.assertRaisesRegex(ValueError, "not a bound phase input"):
                agent_runtime.validate_serial_completion_claim(state, envelope, response)

    def test_advance_revalidates_the_reviewed_context_bytes(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            state = {
                "cursor": {"current_phase": "P05"},
                "roots": {"business_root": str(root)},
                "active": {"status": "VALIDATION_REQUESTED"},
                "workflow": {"status": "RUNNING"},
            }
            args = SimpleNamespace(runtime_root=str(root))
            with patch.object(agent_runtime, "load_state", return_value=state), patch.object(
                agent_runtime,
                "validate_bound_context",
                side_effect=ValueError("reviewed context changed"),
            ):
                with self.assertRaisesRegex(ValueError, "reviewed context changed"):
                    agent_runtime._cmd_advance_locked(args)

    def test_semantic_advance_requires_current_epoch_output_actions(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            state = {
                "cursor": {"current_phase": "P05"},
                "roots": {"business_root": str(root)},
                "active": {"status": "VALIDATION_REQUESTED"},
                "workflow": {"status": "RUNNING"},
                "phase_records": {"P05": {"written_targets": []}},
            }
            args = SimpleNamespace(runtime_root=str(root))
            with patch.object(agent_runtime, "load_state", return_value=state), patch.object(
                agent_runtime, "validate_bound_context", return_value={}
            ):
                with self.assertRaisesRegex(ValueError, "lack current-epoch Action provenance"):
                    agent_runtime._cmd_advance_locked(args)

    def test_recovered_p13_old_outputs_cannot_request_completion(self) -> None:
        state = {
            "cursor": {"current_phase": "P13", "attempt": 2},
            "roots": {"business_root": "."},
            "phase_records": {"P13": {"written_targets": []}},
        }
        response = {
            "actions": [],
            "phase_completion_claim": {
                "ready": True,
                "review_mode": "NATIVE_SUBAGENT_REVIEW",
                "verdict": "PASS",
                "evidence": [],
                "unresolved_items": [],
                "first_loss_boundary": None,
            },
        }
        with self.assertRaisesRegex(ValueError, "lack current-epoch Action provenance"):
            agent_runtime.validate_serial_completion_claim(state, {"required_reads": []}, response)

    def test_shallow_string_evidence_is_not_schema_valid(self) -> None:
        response = {
            "status": "PHASE_READY",
            "phase_id": "P06",
            "context_pack_sha256": "a" * 64,
            "summary": "ready",
            "actions": [],
            "phase_completion_claim": {
                "ready": True,
                "review_mode": "NATIVE_SUBAGENT_REVIEW",
                "verdict": "PASS",
                "evidence": ["source and candidate checked"],
                "unresolved_items": [],
                "first_loss_boundary": None,
            },
        }
        with self.assertRaises(Exception):
            validate_json_schema(response, "action-response.schema.json")

    def test_runtime_contains_no_nested_codex_transport(self) -> None:
        text = (ROOT / "scripts" / "agent_runtime.py").read_text(encoding="utf-8")
        self.assertNotIn("codex-propose", text)
        self.assertNotIn('"codex", "exec"', text)
        self.assertNotIn("materialize_single_section_plan", text)
        self.assertNotIn("CORE_PHASE_OUTPUTS", text)


if __name__ == "__main__":
    unittest.main()
