from __future__ import annotations

from pathlib import Path
import hashlib
import json
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SKILL_SCRIPTS = ROOT / "skills" / "math-longform-publisher" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from content_functions import CONTENT_FUNCTION_ORDER, INTERMEDIATE_STAGE_TARGETS  # noqa: E402
from finalize_atom_consumption import finalize  # noqa: E402
from publication_assembler import ARTICLE_HISTORY, assemble, read_jsonl, write_jsonl  # noqa: E402
from quality_contract import compile_quality_contract  # noqa: E402


ARTICLE = (
    "# Topic\n\n"
    "The motivating question remains explicit.\n\n"
    "The construction method explains the result.\n"
)
SOURCE_EXCERPT = "The motivating question remains explicit, and the construction method explains the result."
FUNCTIONS = ["SUBSTANTIVE_CONTENT", "QUESTION_OR_DOUBT", "METHOD_OBSERVATION"]


def realization_id(function: str) -> str:
    return f"RZ{FUNCTIONS.index(function) + 1:05d}"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False) + "\n", encoding="utf-8")


class PublicationOwnershipTests(unittest.TestCase):
    def make_fixture(self, root: Path) -> tuple[Path, Path]:
        for name in ARTICLE_HISTORY:
            (root / name).write_text(ARTICLE, encoding="utf-8")
        source = root / "source_canonical.txt"
        source_text = "Topic\n" + SOURCE_EXCERPT + "\n"
        source.write_text(source_text, encoding="utf-8")
        source_bytes = source.read_bytes()
        source_hash = hashlib.sha256(source_bytes).hexdigest()
        (root / "source_original.txt").write_bytes(source_bytes)
        write_json(
            root / "source_revision.json",
            {
                "schema_version": "content-authority-source-revision-v2",
                "source_revision_id": "R0001",
                "parent_revision_id": "none",
                "original_source_file": "source_original.txt",
                "original_source_sha256": source_hash,
                "canonical_source_file": "source_canonical.txt",
                "canonical_source_sha256": source_hash,
                "canonical_source_length_bytes": len(source_bytes),
                "canonical_transformation": "IDENTITY",
                "span_unit": "utf8_byte_offset",
                "authority": "CURRENT_CANONICAL_SOURCE_ONLY",
                "applied_patch_ids": "",
                "downstream_state": "CURRENT",
                "created_by": "test_publication_ownership fixture",
            },
        )
        write_jsonl(
            root / "source_chunk_index.jsonl",
            [
                {
                    "chunk_id": "C001",
                    "char_span": f"0-{len(source_text)}",
                    "start_sentence_id": "T0001",
                    "end_sentence_id": "T0002",
                    "semantic_unit_hint": "one ownership test topic",
                    "target_atom_budget": "1",
                    "context_left": "none",
                    "context_right": "none",
                    "ledger_file": "chunk_ledger/chunk_C001_atom_ledger.md",
                    "status": "complete",
                }
            ],
        )
        write_json(
            root / "author_task_contract.json",
            {
                "schema_version": "author-task-contract-v1",
                "task_id": "TASK-OWNERSHIP001",
                "author_request": (
                    "Reorganize the source into a publication article without summarizing "
                    "or dropping its question, result, or reusable method."
                ),
                "task_mode": "PRESERVE_REORGANIZE",
                "author_confirmation": {
                    "status": "DIRECT_REQUEST_SUFFICIENT",
                    "evidence": "The fixture explicitly forbids summarization and function loss.",
                },
                "source_preservation": {
                    "summary_authorized": False,
                    "minimum_source_cjk_ratio": 1.0,
                    "minimum_substantive_atom_cjk_ratio": 0.7,
                    "minimum_atom_source_cjk": 1,
                    "maximum_atoms_per_target_unit": 3,
                    "omission_policy": "NONE",
                },
                "article_volume": {
                    "minimum_total_cjk_ratio": 1.0,
                    "count_headings_as_explanation": False,
                    "count_math_as_explanation": False,
                },
                "expansion_directives": [],
                "structure_requirements": [
                    "Retain one source-grounded Topic section."
                ],
                "non_negotiable_requirements": [
                    "Preserve the question, substantive result, and reusable method independently."
                ],
                "unresolved_author_choices": [],
            },
        )
        atom = {
            "schema_version": "content-authority-atom-v3",
            "atom_id": "A0001",
            "source_revision_id": "R0001",
            "source_byte_start": "6",
            "source_byte_end": str(6 + len(SOURCE_EXCERPT.encode("utf-8"))),
            "source_excerpt_sha256": hashlib.sha256(SOURCE_EXCERPT.encode("utf-8")).hexdigest(),
            "raw_excerpt": SOURCE_EXCERPT,
            "content_lock_state": "CONTENT_LOCKED",
            "content_type": "PROSE",
            "required_functions": FUNCTIONS,
            "local_context_role": "question, method, and result",
            "global_context_role": "article explanation",
            "content_invariant_json": json.dumps(
                {"summary": SOURCE_EXCERPT, "required_functions": FUNCTIONS},
                separators=(",", ":"),
            ),
            "p02_surface_mode": "CONTENT_PRESERVE",
            "surface_mode": "CONTENT_PRESERVE",
            "output_operation": "REORGANIZE_CONTENT",
            "allowed_completion": "formalize without dropping functions",
            "forbidden_change": "do not collapse the question or method into a result",
            "consumption_status": "PLANNED",
            "duplicate_of": "",
            "surface_decision_json": "{}",
            "surface_group_id": "",
            "surface_group_mode": "NONE",
            "chunk_id": "C001",
        }
        write_jsonl(root / "source_atom_ledger.jsonl", [atom])
        (root / "source_atom_ledger.md").write_text("A0001\n", encoding="utf-8")
        realization_rows = [
            {
                "realization_id": realization_id(function),
                "atom_id": "A0001",
                "function": function,
                "source_evidence": SOURCE_EXCERPT,
                "writing_instruction": f"Preserve the independent {function} responsibility explicitly.",
                "realization_group_id": (
                    "RG00002" if function == "QUESTION_OR_DOUBT" else "RG00001"
                ),
                "merge_justification": (
                    "One sentence states the result through the source-selected construction method."
                    if function != "QUESTION_OR_DOUBT"
                    else ""
                ),
            }
            for index, function in enumerate(FUNCTIONS, 1)
        ]
        write_jsonl(
            root / "section_execution_plan.jsonl",
            [
                {
                    "schema_version": "content-authority-section-plan-v4",
                    "plan_id": "SEP0001",
                    "section_id": "SEC001",
                    "section_order": 1,
                    "section_title": "Topic",
                    "source_revision_id": "R0001",
                    "source_atom_ids": "A0001",
                    "atom_contract_sha256": "fixture-owned-by-current-atom-ledger",
                    "required_invariants_json": json.dumps(
                        {"A0001": "fixture-invariant-bound-in-blueprint"}
                    ),
                    "transformation_contract_json": json.dumps(
                        {"A0001": ["CONTENT_PRESERVING_REWRITE"]}
                    ),
                    "forbidden_changes_json": json.dumps(
                        {"A0001": atom["forbidden_change"]}
                    ),
                    "function_realization_plan_json": json.dumps(realization_rows),
                    "expansion_directive_ids": "",
                    "status": "READY_FOR_DRAFT",
                }
            ],
        )

        reviews = []
        target_evidence = {
            "SUBSTANTIVE_CONTENT": "The construction method explains the result.",
            "QUESTION_OR_DOUBT": "The motivating question remains explicit.",
            "METHOD_OBSERVATION": "The construction method explains the result.",
        }
        for stage_id, target_file, _all_atoms in INTERMEDIATE_STAGE_TARGETS:
            target = root / target_file
            reviews.append(
                {
                    "stage_id": stage_id,
                    "target_file": target_file,
                    "target_sha256": sha(target),
                    "atom_id": "A0001",
                    "function_results": {
                        function: {
                            "realization_id": realization_id(function),
                            "status": "PRESERVED",
                            "source_evidence": SOURCE_EXCERPT,
                            "target_evidence": evidence,
                            "reason": f"The exact current article still carries the {function} responsibility.",
                        }
                        for function, evidence in target_evidence.items()
                    },
                    "verdict": "PASS",
                }
            )
        blueprint = {
            "schema_version": "publication-blueprint-v1",
            "voices": [{"voice_id": "V0001", "source_atoms": "A0001"}],
            "symbols": [{"symbol_id": "SYM0001", "source_atoms": "A0001"}],
            "chains": [{"chain_id": "CH0001", "source_atoms": "A0001"}],
            "statements": [{"statement_id": "S0001", "source_atoms": "A0001"}],
            "proofs": [{"proof_id": "PR0001", "source_atoms": "A0001"}],
            "atom_function_contracts": [
                {
                    "atom_id": "A0001",
                    "required_functions": FUNCTIONS,
                    "source_evidence": SOURCE_EXCERPT,
                    "function_matrix": {
                        function: {
                            "status": "REQUIRED" if function in FUNCTIONS else "NOT_REQUIRED",
                            "source_evidence": SOURCE_EXCERPT,
                            "semantic_reason": (
                                f"The source span independently performs {function}."
                                if function in FUNCTIONS
                                else f"The source span has no independent {function} duty in this fixture."
                            ),
                        }
                        for function in CONTENT_FUNCTION_ORDER
                    },
                    "reason": "The source independently contains a result, an open question, and a reusable method.",
                    "content_type": "PROSE",
                    "local_context_role": "keeps the question and construction attached to the result",
                    "global_context_role": "preserves the article's motivating and methodological route",
                    "content_invariant": {
                        "summary": "retain the result, motivating question, and reusable construction"
                    },
                    "surface_contract": {
                        "decision": "CONTENT_PRESERVE",
                        "output_operation": "REORGANIZE_CONTENT",
                        "prelock_disposition": "NO_PRELOCK",
                        "basis": ["ORDINARY_SEMANTIC_CONTENT"],
                        "source_cues": [],
                        "rationale": "Formal wording is allowed because the distinctive source surface is not independently required.",
                        "confidence": "HIGH",
                        "allowed_completion": "reorganize while retaining the question, result, and method",
                        "forbidden_change": "do not collapse the question and method into the result alone",
                    },
                }
            ],
            "function_preservation_reviews": reviews,
            "task_requirement_reviews": [],
            "claims": [
                {
                    "claim_excerpt": "The motivating question remains explicit",
                    "claim_type": "claim",
                    "source_atoms": "A0001",
                    "statement_ids": "S0001",
                    "proof_ids": "PR0001",
                    "support_type": "DIRECT_SOURCE",
                    "source_ownership": "SOURCE_LOCAL_REPHRASE",
                    "transformation_scope": "content_preserving",
                    "verdict": "SUPPORTED",
                    "allowed_new_reason": "source_supported",
                    "verification_note": "The exact claim is bound to A0001 and its reviewed function evidence.",
                }
            ],
            "heading_authorizations": [
                {
                    "heading_text": "Topic",
                    "source_atoms": "A0001",
                    "segments": [{"text": "Topic", "basis": "SOURCE_TERM"}],
                }
            ],
        }
        blueprint_path = root / "publication_blueprint.json"
        write_json(blueprint_path, blueprint)
        write_json(root / "quality_contract.json", compile_quality_contract(root))
        return root / "aigc_rewritten_final.md", blueprint_path

    def test_p12_writes_only_mechanical_pending_candidates(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            article, blueprint = self.make_fixture(root)
            protected = {
                name: sha(root / name)
                for name in (*ARTICLE_HISTORY, "source_atom_ledger.jsonl", "publication_blueprint.json")
            }
            assemble(root, article, blueprint, overwrite=False)
            self.assertEqual(
                protected,
                {name: sha(root / name) for name in protected},
            )
            atoms = read_jsonl(root / "source_atom_ledger.jsonl")
            self.assertEqual(atoms[0]["consumption_status"], "PLANNED")
            candidates = read_jsonl(root / "atom_consumption_candidates.jsonl")
            self.assertEqual(candidates[0]["consumption_status"], "NOT_YET_CONSUMED")
            headings = read_jsonl(root / "heading_authorization.jsonl")
            fragments = read_jsonl(root / "publication_fragment_authorization.jsonl")
            self.assertTrue(all(row["review_status"] == "PENDING_P13_REVIEW" for row in headings))
            self.assertTrue(all(row["review_status"] == "PENDING_P13_REVIEW" for row in fragments))
            for forbidden in (
                "publication_content_review.json",
                "mathematical_review.json",
                "PUBLICATION_AUDIT_REPORT.md",
            ):
                self.assertFalse((root / forbidden).exists())

    def test_p13_is_the_only_consumption_authority_and_stale_bytes_block(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            article, blueprint_path = self.make_fixture(root)
            assemble(root, article, blueprint_path, overwrite=False)
            blueprint = json.loads(blueprint_path.read_text(encoding="utf-8"))
            target = root / "publication_final.md"
            blueprint["function_preservation_reviews"].append(
                {
                    "stage_id": "P13_PUBLICATION",
                    "target_file": "publication_final.md",
                    "target_sha256": sha(target),
                    "atom_id": "A0001",
                    "function_results": {
                        "SUBSTANTIVE_CONTENT": {
                            "realization_id": realization_id("SUBSTANTIVE_CONTENT"),
                            "status": "PRESERVED",
                            "source_evidence": SOURCE_EXCERPT,
                            "target_evidence": "The construction method explains the result.",
                            "reason": "The final bytes retain the substantive result rather than only a topic label.",
                        },
                        "QUESTION_OR_DOUBT": {
                            "realization_id": realization_id("QUESTION_OR_DOUBT"),
                            "status": "PRESERVED",
                            "source_evidence": SOURCE_EXCERPT,
                            "target_evidence": "The motivating question remains explicit.",
                            "reason": "The final bytes keep the motivating question explicit as a question function.",
                        },
                        "METHOD_OBSERVATION": {
                            "realization_id": realization_id("METHOD_OBSERVATION"),
                            "status": "PRESERVED",
                            "source_evidence": SOURCE_EXCERPT,
                            "target_evidence": "The construction method explains the result.",
                            "reason": "The final bytes preserve the selected construction as a reusable method.",
                        },
                    },
                    "verdict": "PASS",
                }
            )
            write_json(blueprint_path, blueprint)
            source_sha = sha(root / "source_canonical.txt")
            publication_sha = sha(target)
            write_json(
                root / "publication_content_review.json",
                {
                    "schema_version": "publication-content-review-v1",
                    "source_sha256": source_sha,
                    "publication_sha256": publication_sha,
                    "verdict": "PASS",
                },
            )
            write_json(
                root / "mathematical_review.json",
                {
                    "schema_version": "publication-mathematical-review-v1",
                    "source_sha256": source_sha,
                    "publication_sha256": publication_sha,
                    "verdict": "PASS",
                },
            )
            for name in (
                "heading_authorization.jsonl",
                "publication_fragment_authorization.jsonl",
            ):
                rows = read_jsonl(root / name)
                for row in rows:
                    row["review_status"] = "APPROVED"
                write_jsonl(root / name, rows)

            target.write_text(ARTICLE + "Changed after review.\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "no longer match"):
                finalize(root)
            self.assertEqual(
                read_jsonl(root / "source_atom_ledger.jsonl")[0]["consumption_status"],
                "PLANNED",
            )
            target.write_text(ARTICLE, encoding="utf-8")
            finalize(root)
            atom = read_jsonl(root / "source_atom_ledger.jsonl")[0]
            self.assertEqual(atom["consumption_status"], "CONSUMED")
            self.assertEqual(atom["consumption_review_stage"], "P13_PUBLICATION")

    def test_p12_rejects_premature_p13_semantic_approval(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            article, blueprint_path = self.make_fixture(root)
            blueprint = json.loads(blueprint_path.read_text(encoding="utf-8"))
            blueprint["function_preservation_reviews"].append(
                {
                    "stage_id": "P13_PUBLICATION",
                    "target_file": "publication_final.md",
                    "target_sha256": "0" * 64,
                    "atom_id": "A0001",
                    "function_results": {},
                    "verdict": "PASS",
                }
            )
            write_json(blueprint_path, blueprint)
            with self.assertRaisesRegex(ValueError, "cannot exist before P12"):
                assemble(root, article, blueprint_path, overwrite=False)


if __name__ == "__main__":
    unittest.main()
