from __future__ import annotations

from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from unittest.mock import patch
import hashlib
import json
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SKILL_SCRIPTS = ROOT / "skills" / "math-longform-publisher" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from content_authority import atom_contract_sha256, canonical_json, sha256_bytes  # noqa: E402
from quality_contract import write_quality_contract  # noqa: E402
import validate_section_execution_plan  # noqa: E402


SOURCE = "The construction proves the result and records a reusable method."
FUNCTIONS = ["SUBSTANTIVE_CONTENT", "METHOD_OBSERVATION"]


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False) + "\n", encoding="utf-8")


def write_jsonl(path: Path, rows: list[dict[str, object]]) -> None:
    path.write_text(
        "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows),
        encoding="utf-8",
    )


def write_author_task_contract(root: Path) -> None:
    write_json(
        root / "author_task_contract.json",
        {
            "schema_version": "author-task-contract-v1",
            "task_id": "TASK-TEST01",
            "author_request": "Preserve and reorganize the complete source without summarizing it.",
            "task_mode": "PRESERVE_REORGANIZE",
            "author_confirmation": {
                "status": "DIRECT_REQUEST_SUFFICIENT",
                "evidence": "The fixture explicitly requires complete preservation and reorganization.",
            },
            "source_preservation": {
                "summary_authorized": False,
                "minimum_source_cjk_ratio": 1.0,
                "minimum_substantive_atom_cjk_ratio": 0.7,
                "minimum_atom_source_cjk": 1,
                "maximum_atoms_per_target_unit": 3,
                "omission_policy": "NONE",
            },
            "article_volume": {
                "minimum_total_cjk_ratio": 1.0,
                "count_headings_as_explanation": False,
                "count_math_as_explanation": False,
            },
            "expansion_directives": [],
            "structure_requirements": ["Retain the planned section order."],
            "non_negotiable_requirements": [
                "Preserve every source Atom and each of its required functions."
            ],
            "unresolved_author_choices": [],
        },
    )


def atom() -> dict[str, object]:
    invariant = {"summary": SOURCE, "required_functions": FUNCTIONS}
    return {
        "schema_version": "content-authority-atom-v3",
        "atom_id": "A0001",
        "source_revision_id": "R0001",
        "source_byte_start": "0",
        "source_byte_end": str(len(SOURCE.encode("utf-8"))),
        "source_excerpt_sha256": hashlib.sha256(SOURCE.encode("utf-8")).hexdigest(),
        "raw_excerpt": SOURCE,
        "content_lock_state": "CONTENT_LOCKED",
        "content_type": "PROSE",
        "required_functions": FUNCTIONS,
        "local_context_role": "states the result through the selected construction",
        "global_context_role": "retains the reusable reasoning route",
        "content_invariant_json": canonical_json(invariant),
        "p02_surface_mode": "CONTENT_PRESERVE",
        "surface_mode": "CONTENT_PRESERVE",
        "output_operation": "REORGANIZE_CONTENT",
        "allowed_completion": "formalize while retaining the selected construction",
        "forbidden_change": "do not replace the method with only its conclusion",
        "consumption_status": "PLANNED",
        "duplicate_of": "",
        "surface_decision_json": "{}",
        "surface_group_id": "",
        "surface_group_mode": "NONE",
    }


def realization(function: str, index: int) -> dict[str, str]:
    return {
        "realization_id": f"RZ{index:05d}",
        "atom_id": "A0001",
        "function": function,
        "source_evidence": SOURCE,
        "writing_instruction": f"Write the independent {function} responsibility explicitly.",
        "realization_group_id": f"RG{index:05d}",
        "merge_justification": "",
    }


def fixture(root: Path, *, functions: list[str] | None = None, chunks: int = 1) -> None:
    source_atom = atom()
    (root / "source_canonical.txt").write_text(SOURCE, encoding="utf-8")
    write_json(root / "source_revision.json", {"source_revision_id": "R0001"})
    write_jsonl(root / "source_atom_ledger.jsonl", [source_atom])
    write_jsonl(
        root / "source_chunk_index.jsonl",
        [
            {"chunk_id": f"C{index:03d}", "char_span": "0-1"}
            for index in range(1, chunks + 1)
        ],
    )
    write_author_task_contract(root)
    invariant = json.loads(str(source_atom["content_invariant_json"]))
    invariant_hash = sha256_bytes(canonical_json(invariant).encode("utf-8"))
    planned_functions = FUNCTIONS if functions is None else functions
    plan = {
        "schema_version": "content-authority-section-plan-v4",
        "plan_id": "SEP0001",
        "section_id": "SEC001",
        "section_order": 1,
        "section_title": "Construction and reusable method",
        "source_revision_id": "R0001",
        "source_atom_ids": "A0001",
        "atom_contract_sha256": atom_contract_sha256([source_atom]),
        "required_invariants_json": json.dumps({"A0001": invariant_hash}),
        "transformation_contract_json": json.dumps(
            {"A0001": ["CONTENT_PRESERVING_REWRITE"]}
        ),
        "forbidden_changes_json": json.dumps(
            {"A0001": source_atom["forbidden_change"]}
        ),
        "function_realization_plan_json": json.dumps(
            [realization(function, index) for index, function in enumerate(planned_functions, 1)]
        ),
        "expansion_directive_ids": "",
        "status": "READY_FOR_DRAFT",
    }
    write_jsonl(root / "section_execution_plan.jsonl", [plan])
    write_quality_contract(root)


def run_validator(root: Path) -> tuple[int, str]:
    output = StringIO()
    with patch.object(sys, "argv", ["validate_section_execution_plan.py", str(root)]):
        with redirect_stdout(output):
            code = validate_section_execution_plan.main()
    return code, output.getvalue()


class SectionRealizationPlanTests(unittest.TestCase):
    def test_complete_atom_function_plan_passes(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            fixture(root)
            code, output = run_validator(root)
            self.assertEqual(code, 0, output)
            self.assertIn("planned_atom_functions=2", output)

    def test_topic_route_without_method_obligation_fails(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            fixture(root, functions=["SUBSTANTIVE_CONTENT"])
            code, output = run_validator(root)
            self.assertEqual(code, 1)
            self.assertIn("A0001/METHOD_OBSERVATION", output)

    def test_partial_atom_excerpt_cannot_be_used_as_source_evidence(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            fixture(root)
            plan = json.loads((root / "section_execution_plan.jsonl").read_text(encoding="utf-8"))
            realizations = json.loads(plan["function_realization_plan_json"])
            realizations[0]["source_evidence"] = "construction"
            plan["function_realization_plan_json"] = json.dumps(realizations)
            write_jsonl(root / "section_execution_plan.jsonl", [plan])
            code, output = run_validator(root)
            self.assertEqual(code, 1)
            self.assertIn("complete exact Atom slice", output)

    def test_functions_of_one_atom_may_share_one_realization_unit(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            fixture(root)
            plan = json.loads((root / "section_execution_plan.jsonl").read_text(encoding="utf-8"))
            realizations = json.loads(plan["function_realization_plan_json"])
            for row in realizations:
                row["realization_group_id"] = "RG00001"
                row["merge_justification"] = (
                    "The source states the result through this same reusable construction."
                )
            plan["function_realization_plan_json"] = json.dumps(realizations)
            write_jsonl(root / "section_execution_plan.jsonl", [plan])
            code, output = run_validator(root)
            self.assertEqual(code, 0, output)

    def test_responsibilities_from_different_atoms_cannot_share_one_unit(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            second_source = "The converse uses a separate contradiction route."
            full_source = SOURCE + "\n" + second_source
            first = atom()
            second = dict(first)
            second_start = len((SOURCE + "\n").encode("utf-8"))
            second_functions = ["PROOF_DEPENDENCY"]
            second.update(
                {
                    "atom_id": "A0002",
                    "source_byte_start": str(second_start),
                    "source_byte_end": str(second_start + len(second_source.encode("utf-8"))),
                    "source_excerpt_sha256": hashlib.sha256(second_source.encode("utf-8")).hexdigest(),
                    "raw_excerpt": second_source,
                    "required_functions": second_functions,
                    "content_invariant_json": canonical_json(
                        {"summary": second_source, "required_functions": second_functions}
                    ),
                }
            )
            (root / "source_canonical.txt").write_text(full_source, encoding="utf-8")
            write_json(root / "source_revision.json", {"source_revision_id": "R0001"})
            write_jsonl(root / "source_atom_ledger.jsonl", [first, second])
            write_jsonl(root / "source_chunk_index.jsonl", [{"chunk_id": "C001"}])
            write_author_task_contract(root)

            invariant_hashes = {
                row["atom_id"]: sha256_bytes(
                    canonical_json(json.loads(str(row["content_invariant_json"]))).encode("utf-8")
                )
                for row in (first, second)
            }
            realizations = [
                realization("SUBSTANTIVE_CONTENT", 1),
                realization("METHOD_OBSERVATION", 2),
                {
                    "realization_id": "RZ00003",
                    "atom_id": "A0002",
                    "function": "PROOF_DEPENDENCY",
                    "source_evidence": second_source,
                    "writing_instruction": "Preserve the independent converse contradiction route.",
                    "realization_group_id": "RG00001",
                    "merge_justification": (
                        "The result and converse route concern one theorem in this section."
                    ),
                },
            ]
            realizations[0]["realization_group_id"] = "RG00001"
            realizations[0]["merge_justification"] = realizations[2]["merge_justification"]
            plan = {
                "schema_version": "content-authority-section-plan-v4",
                "plan_id": "SEP0001",
                "section_id": "SEC001",
                "section_order": 1,
                "section_title": "Result and converse route",
                "source_revision_id": "R0001",
                "source_atom_ids": "A0001 A0002",
                "atom_contract_sha256": atom_contract_sha256([first, second]),
                "required_invariants_json": json.dumps(invariant_hashes),
                "transformation_contract_json": json.dumps(
                    {
                        "A0001": ["CONTENT_PRESERVING_REWRITE"],
                        "A0002": ["CONTENT_PRESERVING_REWRITE"],
                    }
                ),
                "forbidden_changes_json": json.dumps(
                    {
                        "A0001": first["forbidden_change"],
                        "A0002": second["forbidden_change"],
                    }
                ),
                "function_realization_plan_json": json.dumps(realizations),
                "expansion_directive_ids": "",
                "status": "READY_FOR_DRAFT",
            }
            write_jsonl(root / "section_execution_plan.jsonl", [plan])
            write_quality_contract(root)
            code, output = run_validator(root)
            self.assertEqual(code, 1)
            self.assertIn("different Atoms", output)

    def test_multi_chunk_source_cannot_use_one_aggregate_section(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            fixture(root, chunks=2)
            code, output = run_validator(root)
            self.assertEqual(code, 1)
            self.assertIn("cannot be collapsed into one section", output)


if __name__ == "__main__":
    unittest.main()
