from __future__ import annotations

from pathlib import Path
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "skills" / "math-longform-publisher" / "scripts"))

from validate_active_state_feedback import transcribed_source_obligation_ids  # noqa: E402


class ActiveStateAuthorityTests(unittest.TestCase):
    def test_generic_resume_and_user_feedback_ids_do_not_trigger(self) -> None:
        active = {
            "resume_point": "complete source review before planning",
            "resume_instruction": "Read the current source ledgers directly.",
            "hard_constraints": [
                "load user_feedback_ledger.jsonl before writing",
                "carry active feedback UF0001 until verified",
            ],
        }
        self.assertEqual(transcribed_source_obligation_ids(active), [])

    def test_handwritten_source_obligation_inventory_is_rejected(self) -> None:
        active = {
            "resume_point": "continue after AQ0012",
            "resume_instruction": "Carry FB0003 into P04.",
            "hard_constraints": ["carry MR0002-MR0008 through P13"],
        }
        self.assertEqual(
            transcribed_source_obligation_ids(active),
            ["AQ0012", "FB0003", "MR0002", "MR0008"],
        )


if __name__ == "__main__":
    unittest.main()
