from __future__ import annotations

from pathlib import Path
import hashlib
import json
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SKILL_SCRIPTS = ROOT / "skills" / "math-longform-publisher" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))

from build_source_model import atom_rows_for, question_rows_for, surface_reviews_for  # noqa: E402
from content_functions import (  # noqa: E402
    CONTENT_FUNCTION_ORDER,
    atom_function_contracts,
    stage_function_reviews,
)
from materialize_atom_function_contracts import materialize  # noqa: E402


FUNCTIONS = [
    "SUBSTANTIVE_CONTENT",
    "QUESTION_OR_DOUBT",
    "METHOD_OBSERVATION",
    "INTUITION_OR_ANALOGY",
]
SOURCE = "I am asking why this construction works and whether the method generalizes; the picture explains the choice."


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def atom() -> dict[str, object]:
    return {
        "atom_id": "A0001",
        "raw_excerpt": SOURCE,
        "required_functions": FUNCTIONS,
        "content_type": "PROSE",
        "p02_surface_mode": "CONTENT_PRESERVE",
        "surface_mode": "CONTENT_PRESERVE",
    }


def realization_id(function: str) -> str:
    return f"RZ{FUNCTIONS.index(function) + 1:05d}"


def write_realization_plan(root: Path) -> None:
    realizations = [
        {
            "realization_id": realization_id(function),
            "atom_id": "A0001",
            "function": function,
            "source_evidence": SOURCE,
            "writing_instruction": f"Preserve the independent {function} responsibility explicitly.",
            "realization_group_id": f"RG{index:05d}",
            "merge_justification": "",
        }
        for index, function in enumerate(FUNCTIONS, 1)
    ]
    (root / "section_execution_plan.jsonl").write_text(
        json.dumps({"function_realization_plan_json": json.dumps(realizations)}) + "\n",
        encoding="utf-8",
    )


def merge_realization_plan(root: Path) -> None:
    plan = json.loads((root / "section_execution_plan.jsonl").read_text(encoding="utf-8"))
    realizations = json.loads(plan["function_realization_plan_json"])
    justification = (
        "This one source sentence intentionally carries the result, question, method, and picture together."
    )
    for row in realizations:
        row["realization_group_id"] = "RG00001"
        row["merge_justification"] = justification
    plan["function_realization_plan_json"] = json.dumps(realizations)
    (root / "section_execution_plan.jsonl").write_text(
        json.dumps(plan) + "\n", encoding="utf-8"
    )


def contract() -> dict[str, object]:
    matrix = {
        function: {
            "status": "REQUIRED" if function in FUNCTIONS else "NOT_REQUIRED",
            "source_evidence": SOURCE,
            "semantic_reason": (
                f"The exact source span independently performs the {function} responsibility."
                if function in FUNCTIONS
                else f"The exact source span does not independently perform {function}; no such duty is present in this fixture."
            ),
        }
        for function in CONTENT_FUNCTION_ORDER
    }
    return {
        "atom_id": "A0001",
        "required_functions": FUNCTIONS,
        "source_evidence": SOURCE,
        "function_matrix": matrix,
        "reason": "This atom independently carries a result, question, method, and explanatory picture.",
        "content_type": "PROSE",
        "local_context_role": "states a result while preserving its motivating question and method",
        "global_context_role": "connects the article's result to its reusable reasoning route",
        "content_invariant": {
            "summary": "retain the result, motivating question, method, and explanatory picture"
        },
        "surface_contract": {
            "decision": "CONTENT_PRESERVE",
            "output_operation": "REORGANIZE_CONTENT",
            "prelock_disposition": "NO_PRELOCK",
            "basis": ["ORDINARY_SEMANTIC_CONTENT"],
            "source_cues": [],
            "rationale": "The wording may be formalized, but every independent source responsibility must survive.",
            "confidence": "HIGH",
            "allowed_completion": "formalize the wording while retaining every source responsibility",
            "forbidden_change": "do not replace the question, method, or picture with only the result",
        },
    }


def review(stage: str, target: str, target_sha: str, evidence: dict[str, str]) -> dict[str, object]:
    return {
        "stage_id": stage,
        "target_file": target,
        "target_sha256": target_sha,
        "atom_id": "A0001",
        "function_results": {
            function: {
                "realization_id": realization_id(function),
                "status": "REASONABLE_TRANSFORM",
                "source_evidence": SOURCE,
                "target_evidence": target_evidence,
                "reason": f"The formal target still performs the independent {function} responsibility.",
            }
            for function, target_evidence in evidence.items()
        },
        "verdict": "PASS",
    }


class ContentPreservationContractTests(unittest.TestCase):
    def test_p02_does_not_classify_functions_from_keywords(self) -> None:
        source = "我想问为什么这个方法成立；下面的直观解释也许还能推广。"
        rows = atom_rows_for(source, [(0, len(source), False)], "R0001")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["required_functions"], "SUBSTANTIVE_CONTENT")
        self.assertNotIn("candidate_functions", rows[0])
        self.assertEqual(rows[0]["voice_role"], "P04 semantic review pending")

    def test_p02_surface_rules_prelock_but_do_not_approve(self) -> None:
        source = "我操，这个证明把我绕晕了。"
        atoms = atom_rows_for(source, [(0, len(source), False)], "R0001")
        self.assertEqual(atoms[0]["surface_mode"], "BYTE_EXACT")
        decision = json.loads(str(atoms[0]["surface_decision_json"]))
        self.assertEqual(decision["review_status"], "BLOCKED_REVIEW")
        reviews = surface_reviews_for(atoms, "R0001")
        self.assertEqual(len(reviews), 1)
        self.assertEqual(reviews[0]["reviewer_role"], "P02_DETERMINISTIC_CANDIDATE_SCAN")
        self.assertEqual(reviews[0]["reviewer_verdict"], "PENDING_P04_REVIEW")

    def test_p02_question_words_create_candidates_not_semantic_truth(self) -> None:
        rows = question_rows_for("我想问这个理解是否成立。")
        self.assertEqual(rows[0]["obligation_type"], "P02_SEMANTIC_CANDIDATE")
        self.assertEqual(rows[-1]["obligation_type"], "SOURCE_WIDE_SEMANTIC_SCAN")
        self.assertFalse(any(row["obligation_type"] == "UNDERSTANDING_CHECK" for row in rows))

        no_match_rows = question_rows_for("这里记录一个没有问号的陈述。")
        self.assertEqual(len(no_match_rows), 1)
        self.assertEqual(no_match_rows[0]["obligation_type"], "SOURCE_WIDE_SEMANTIC_SCAN")
        self.assertFalse(any(row["obligation_type"] == "NO_AUTHOR_QUESTIONS" for row in no_match_rows))

    def test_p04_must_disposition_the_p02_prelock(self) -> None:
        prelocked_atom = atom()
        prelocked_atom["p02_surface_mode"] = "BYTE_EXACT"
        prelocked_atom["surface_mode"] = "BYTE_EXACT"
        reviewed = contract()
        reviewed["surface_contract"] = {
            "decision": "BYTE_EXACT",
            "output_operation": "COPY_SOURCE_SLICE",
            "prelock_disposition": "CONFIRMED_PRELOCK",
            "basis": ["DISTINCTIVE_AUTHOR_VOICE"],
            "source_cues": ["why this construction works"],
            "rationale": "Changing this exact source wording would alter its authorial and explanatory function.",
            "confidence": "HIGH",
            "allowed_completion": "",
            "forbidden_change": "",
        }
        _contracts, errors = atom_function_contracts(
            {"atom_function_contracts": [reviewed]}, [prelocked_atom]
        )
        self.assertEqual(errors, [])

        reviewed["surface_contract"]["prelock_disposition"] = "NO_PRELOCK"
        _contracts, errors = atom_function_contracts(
            {"atom_function_contracts": [reviewed]}, [prelocked_atom]
        )
        self.assertIn("must be CONFIRMED_PRELOCK", "\n".join(errors))

        reviewed = contract()
        reviewed["surface_contract"]["prelock_disposition"] = "DOWNGRADED_FALSE_POSITIVE"
        reviewed["surface_contract"]["rationale"] = (
            "The P02 lexical prelock is a demonstrated false positive; the wording adds no independent function."
        )
        materialized_atom = dict(prelocked_atom)
        materialized_atom["surface_mode"] = "CONTENT_PRESERVE"
        _contracts, errors = atom_function_contracts(
            {"atom_function_contracts": [reviewed]}, [materialized_atom]
        )
        self.assertEqual(errors, [])

    def test_p04_contract_requires_the_complete_exact_atom(self) -> None:
        reviewed = contract()
        reviewed["source_evidence"] = "why this construction works"
        _contracts, errors = atom_function_contracts({"atom_function_contracts": [reviewed]}, [atom()])
        self.assertIn("complete exact Atom slice", "\n".join(errors))

    def test_production_p04_contract_rejects_required_only_under_declaration(self) -> None:
        reviewed = contract()
        reviewed.pop("function_matrix")
        _contracts, errors = atom_function_contracts(
            {"atom_function_contracts": [reviewed]},
            [atom()],
            require_function_matrix=True,
        )
        self.assertIn("function_matrix is required", "\n".join(errors))

    def test_function_matrix_must_equal_required_functions(self) -> None:
        reviewed = contract()
        reviewed["function_matrix"]["METHOD_OBSERVATION"]["status"] = "NOT_REQUIRED"  # type: ignore[index]
        _contracts, errors = atom_function_contracts(
            {"atom_function_contracts": [reviewed]},
            [atom()],
            require_function_matrix=True,
        )
        self.assertIn("required_functions must equal the REQUIRED matrix set", "\n".join(errors))

    def test_p04_materializes_semantic_surface_review_without_self_certifying_p02(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            prelocked_atom = atom()
            prelocked_atom.update(
                {
                    "source_revision_id": "R0001",
                    "p02_surface_mode": "BYTE_EXACT",
                    "surface_mode": "BYTE_EXACT",
                    "surface_group_id": "",
                    "surface_group_mode": "NONE",
                    "chunk_id": "C001",
                    "content_invariant_json": json.dumps(
                        {"summary": SOURCE, "required_functions": FUNCTIONS}
                    ),
                }
            )
            (root / "source_atom_ledger.jsonl").write_text(
                json.dumps(prelocked_atom) + "\n", encoding="utf-8"
            )
            reviewed = contract()
            reviewed["surface_contract"] = {
                "decision": "BYTE_EXACT",
                "output_operation": "COPY_SOURCE_SLICE",
                "prelock_disposition": "CONFIRMED_PRELOCK",
                "basis": ["DISTINCTIVE_AUTHOR_VOICE"],
                "source_cues": ["why this construction works"],
                "rationale": "Changing this exact wording would alter its authorial and explanatory function.",
                "confidence": "HIGH",
                "allowed_completion": "",
                "forbidden_change": "",
            }
            (root / "publication_blueprint.json").write_text(
                json.dumps({"atom_function_contracts": [reviewed]}), encoding="utf-8"
            )

            materialize(root)

            updated = json.loads(
                (root / "source_atom_ledger.jsonl").read_text(encoding="utf-8")
            )
            self.assertEqual(updated["surface_mode"], "BYTE_EXACT")
            self.assertEqual(updated["function_contract_stage"], "P04_MATH_LOCKS")
            review = json.loads(
                (root / "surface_decision_review.jsonl").read_text(encoding="utf-8")
            )
            self.assertEqual(review["reviewer_role"], "P04_SEMANTIC_CONTRACT_REVIEW")
            self.assertEqual(review["prelock_disposition"], "CONFIRMED_PRELOCK")

    def test_destination_or_topic_coverage_is_not_consumption(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            write_realization_plan(root)
            target = root / "draft.md"
            target.write_text("The construction gives the stated result.\n", encoding="utf-8")
            blueprint = {
                "atom_function_contracts": [contract()],
                "function_preservation_reviews": [
                    review(
                        "P06_DRAFT",
                        "draft.md",
                        sha(target),
                        {"SUBSTANTIVE_CONTENT": "The construction gives the stated result."},
                    )
                ],
            }
            _rows, errors = stage_function_reviews(
                root, blueprint, [atom()], "P06_DRAFT", "draft.md", require_all_atoms=True
            )
            joined = "\n".join(errors)
            self.assertIn("functions not consumed", joined)
            self.assertIn("QUESTION_OR_DOUBT", joined)
            self.assertIn("METHOD_OBSERVATION", joined)

    def test_first_rewrite_boundary_with_loss_is_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            write_realization_plan(root)
            draft = root / "draft.md"
            final = root / "final.md"
            complete = (
                "The result holds.\n"
                "We still ask why it works.\n"
                "The construction is the method.\n"
                "The geometric picture explains the choice.\n"
            )
            draft.write_text(complete, encoding="utf-8")
            final.write_text("The construction gives the result.\n", encoding="utf-8")
            complete_evidence = {
                "SUBSTANTIVE_CONTENT": "The result holds.",
                "QUESTION_OR_DOUBT": "We still ask why it works.",
                "METHOD_OBSERVATION": "The construction is the method.",
                "INTUITION_OR_ANALOGY": "The geometric picture explains the choice.",
            }
            blueprint = {
                "atom_function_contracts": [contract()],
                "function_preservation_reviews": [
                    review("P06_DRAFT", "draft.md", sha(draft), complete_evidence),
                    review(
                        "P07_FINAL",
                        "final.md",
                        sha(final),
                        {"SUBSTANTIVE_CONTENT": "The construction gives the result."},
                    ),
                ],
            }
            _rows, draft_errors = stage_function_reviews(
                root, blueprint, [atom()], "P06_DRAFT", "draft.md", require_all_atoms=True
            )
            _rows, final_errors = stage_function_reviews(
                root, blueprint, [atom()], "P07_FINAL", "final.md", require_all_atoms=True
            )
            self.assertEqual(draft_errors, [])
            self.assertTrue(final_errors)
            self.assertIn("P07_FINAL", "\n".join(final_errors))

    def test_formalization_with_all_functions_is_allowed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            write_realization_plan(root)
            target = root / "standardized_final.md"
            target.write_text(
                "The proposition holds.\n"
                "The motivating question is why the construction works.\n"
                "Its reusable method is to encode the constraint before choosing the object.\n"
                "Geometrically, the picture records that constraint.\n",
                encoding="utf-8",
            )
            evidence = {
                "SUBSTANTIVE_CONTENT": "The proposition holds.",
                "QUESTION_OR_DOUBT": "The motivating question is why the construction works.",
                "METHOD_OBSERVATION": "Its reusable method is to encode the constraint before choosing the object.",
                "INTUITION_OR_ANALOGY": "Geometrically, the picture records that constraint.",
            }
            blueprint = {
                "atom_function_contracts": [contract()],
                "function_preservation_reviews": [
                    review("P08_STANDARDIZED", "standardized_final.md", sha(target), evidence)
                ],
            }
            _rows, errors = stage_function_reviews(
                root,
                blueprint,
                [atom()],
                "P08_STANDARDIZED",
                "standardized_final.md",
                require_all_atoms=True,
            )
            self.assertEqual(errors, [])

    def test_one_passage_cannot_cover_unmerged_responsibilities(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            write_realization_plan(root)
            target = root / "draft.md"
            target.write_text(
                "The construction method proves the result. We still ask why it works. "
                "The geometric picture explains the choice.\n",
                encoding="utf-8",
            )
            shared_unit = target.read_text(encoding="utf-8").strip()
            evidence = {
                "SUBSTANTIVE_CONTENT": shared_unit,
                "QUESTION_OR_DOUBT": shared_unit,
                "METHOD_OBSERVATION": shared_unit,
                "INTUITION_OR_ANALOGY": shared_unit,
            }
            blueprint = {
                "atom_function_contracts": [contract()],
                "function_preservation_reviews": [
                    review("P06_DRAFT", "draft.md", sha(target), evidence)
                ],
            }
            _rows, errors = stage_function_reviews(
                root, blueprint, [atom()], "P06_DRAFT", "draft.md", require_all_atoms=True
            )
            self.assertIn("overlapping target evidence", "\n".join(errors))

    def test_target_evidence_must_be_a_complete_output_unit(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            write_realization_plan(root)
            target = root / "draft.md"
            target.write_text(
                "The proposition holds.\n"
                "The motivating question remains explicit.\n"
                "The construction is reusable.\n"
                "The geometric picture explains the choice.\n",
                encoding="utf-8",
            )
            evidence = {
                "SUBSTANTIVE_CONTENT": "proposition holds",
                "QUESTION_OR_DOUBT": "The motivating question remains explicit.",
                "METHOD_OBSERVATION": "The construction is reusable.",
                "INTUITION_OR_ANALOGY": "The geometric picture explains the choice.",
            }
            blueprint = {
                "atom_function_contracts": [contract()],
                "function_preservation_reviews": [
                    review("P06_DRAFT", "draft.md", sha(target), evidence)
                ],
            }
            _rows, errors = stage_function_reviews(
                root, blueprint, [atom()], "P06_DRAFT", "draft.md", require_all_atoms=True
            )
            self.assertIn("complete output unit", "\n".join(errors))

    def test_one_atom_may_realize_several_functions_in_one_complete_unit(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            write_realization_plan(root)
            merge_realization_plan(root)
            target = root / "draft.md"
            unit = (
                "The result remains tied to the motivating question, the reusable construction, "
                "and its geometric picture."
            )
            target.write_text(unit + "\n", encoding="utf-8")
            evidence = {function: unit for function in FUNCTIONS}
            blueprint = {
                "atom_function_contracts": [contract()],
                "function_preservation_reviews": [
                    review("P06_DRAFT", "draft.md", sha(target), evidence)
                ],
            }
            _rows, errors = stage_function_reviews(
                root, blueprint, [atom()], "P06_DRAFT", "draft.md", require_all_atoms=True
            )
            self.assertEqual(errors, [])


if __name__ == "__main__":
    unittest.main()
