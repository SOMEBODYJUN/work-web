from __future__ import annotations

from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from unittest.mock import patch
import hashlib
import json
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "skills" / "math-longform-publisher" / "scripts"
sys.path.insert(0, str(SCRIPTS))

from content_authority import atom_contract_sha256, canonical_json  # noqa: E402
from content_functions import CONTENT_FUNCTION_ORDER  # noqa: E402
from quality_contract import cjk_count, evaluate_quality_stage, write_quality_contract  # noqa: E402
import validate_quality_gate  # noqa: E402


STAGE = "P06_DRAFT"
TARGET = "draft.md"


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False) + "\n", encoding="utf-8")


def write_jsonl(path: Path, rows: list[dict[str, object]]) -> None:
    path.write_text(
        "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows),
        encoding="utf-8",
    )


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def exact_cjk(prefix: str, count: int, fill: str) -> str:
    """Create one readable-enough sentence with an exact CJK count."""
    if cjk_count(prefix) > count:
        raise ValueError("prefix exceeds requested CJK length")
    return prefix + fill * (count - cjk_count(prefix)) + "。"


class QualityFixture:
    def __init__(
        self,
        root: Path,
        source_units: list[str],
        target_units: list[str],
        *,
        atom_floor: int = 1,
        extra_markdown: str = "",
        functions: list[list[str]] | None = None,
    ) -> None:
        if len(source_units) != len(target_units):
            raise ValueError("source and target units must have equal length")
        self.root = root
        self.source_units = source_units
        self.target_units = target_units
        self.functions = functions or [
            ["SUBSTANTIVE_CONTENT", "QUESTION_OR_DOUBT", "EXPLANATION_CHAIN"],
            ["SUBSTANTIVE_CONTENT", "METHOD_OBSERVATION"],
        ][: len(source_units)]
        self._write(atom_floor=atom_floor, extra_markdown=extra_markdown)

    def _write(self, *, atom_floor: int, extra_markdown: str) -> None:
        source_text = "\n".join(self.source_units) + "\n"
        source_path = self.root / "source_canonical.txt"
        source_path.write_text(source_text, encoding="utf-8")
        write_json(self.root / "source_revision.json", {"source_revision_id": "R0001"})
        write_json(
            self.root / "author_task_contract.json",
            {
                "schema_version": "author-task-contract-v1",
                "task_id": "TASK-QUALITY01",
                "author_request": "完整保留来源的内容功能和解释量，只允许正式化与重组，不允许摘要。",
                "task_mode": "PRESERVE_REORGANIZE",
                "author_confirmation": {
                    "status": "DIRECT_REQUEST_SUFFICIENT",
                    "evidence": "测试任务明确要求完整保留来源内容并禁止摘要。",
                },
                "source_preservation": {
                    "summary_authorized": False,
                    "minimum_source_cjk_ratio": 1.0,
                    "minimum_substantive_atom_cjk_ratio": 0.7,
                    "minimum_atom_source_cjk": atom_floor,
                    "maximum_atoms_per_target_unit": 3,
                    "omission_policy": "NONE",
                },
                "article_volume": {
                    "minimum_total_cjk_ratio": 1.0,
                    "count_headings_as_explanation": False,
                    "count_math_as_explanation": False,
                },
                "expansion_directives": [],
                "structure_requirements": ["保持两个来源部分的顺序和独立标题。"],
                "non_negotiable_requirements": ["每个来源 Atom 的全部功能必须独立保留。"],
                "unresolved_author_choices": [],
            },
        )

        atoms: list[dict[str, object]] = []
        byte_cursor = 0
        for index, (source, required) in enumerate(zip(self.source_units, self.functions), 1):
            atom_id = f"A{index:04d}"
            raw = source.encode("utf-8")
            invariant = {"summary": source, "required_functions": required}
            atoms.append(
                {
                    "schema_version": "content-authority-atom-v3",
                    "atom_id": atom_id,
                    "source_revision_id": "R0001",
                    "source_byte_start": str(byte_cursor),
                    "source_byte_end": str(byte_cursor + len(raw)),
                    "source_excerpt_sha256": hashlib.sha256(raw).hexdigest(),
                    "raw_excerpt": source,
                    "content_lock_state": "CONTENT_LOCKED",
                    "content_type": "PROSE",
                    "required_functions": required,
                    "local_context_role": "保留该段独立承担的问题、解释或方法作用",
                    "global_context_role": "维持整篇文章的推理路线和认知结构",
                    "content_invariant_json": canonical_json(invariant),
                    "p02_surface_mode": "CONTENT_PRESERVE",
                    "surface_mode": "CONTENT_PRESERVE",
                    "output_operation": "REORGANIZE_CONTENT",
                    "allowed_completion": "可以正式化措辞但必须保留全部功能",
                    "forbidden_change": "不得只留下共同知识点或最终结论",
                    "consumption_status": "PLANNED",
                    "duplicate_of": "",
                    "surface_decision_json": "{}",
                    "surface_group_id": "",
                    "surface_group_mode": "NONE",
                }
            )
            byte_cursor += len(raw) + 1
        write_jsonl(self.root / "source_atom_ledger.jsonl", atoms)

        plans: list[dict[str, object]] = []
        for index, (atom, required) in enumerate(zip(atoms, self.functions), 1):
            atom_id = str(atom["atom_id"])
            group_id = f"RG{index:05d}"
            realizations = [
                {
                    "realization_id": f"RZ{index:02d}{function_index:03d}",
                    "atom_id": atom_id,
                    "function": function,
                    "source_evidence": atom["raw_excerpt"],
                    "writing_instruction": f"在目标正文中明确实现 {function} 的独立作用。",
                    "realization_group_id": group_id,
                    "merge_justification": "同一 Atom 的这些功能由同一完整句段共同承担。",
                }
                for function_index, function in enumerate(required, 1)
            ]
            plans.append(
                {
                    "schema_version": "content-authority-section-plan-v4",
                    "plan_id": f"SEP{index:04d}",
                    "section_id": f"SEC{index:03d}",
                    "section_order": index,
                    "section_title": f"第{index}部分",
                    "source_revision_id": "R0001",
                    "source_atom_ids": atom_id,
                    "atom_contract_sha256": atom_contract_sha256(atoms),
                    "required_invariants_json": json.dumps({atom_id: "bound-by-blueprint"}),
                    "transformation_contract_json": json.dumps(
                        {atom_id: ["CONTENT_PRESERVING_REWRITE"]}
                    ),
                    "forbidden_changes_json": json.dumps(
                        {atom_id: atom["forbidden_change"]}, ensure_ascii=False
                    ),
                    "function_realization_plan_json": json.dumps(realizations, ensure_ascii=False),
                    "expansion_directive_ids": "",
                    "status": "READY_FOR_DRAFT",
                }
            )
        write_jsonl(self.root / "section_execution_plan.jsonl", plans)
        write_quality_contract(self.root)

        article = "\n\n".join(
            f"## 第{index}部分\n\n{target}"
            for index, target in enumerate(self.target_units, 1)
        )
        if extra_markdown:
            article += "\n\n" + extra_markdown
        article += "\n"
        (self.root / TARGET).write_text(article, encoding="utf-8")
        target_hash = sha256(self.root / TARGET)

        contracts: list[dict[str, object]] = []
        reviews: list[dict[str, object]] = []
        for index, (atom, required, target) in enumerate(
            zip(atoms, self.functions, self.target_units), 1
        ):
            atom_id = str(atom["atom_id"])
            function_matrix = {
                function: {
                    "status": "REQUIRED" if function in required else "NOT_REQUIRED",
                    "source_evidence": atom["raw_excerpt"],
                    "semantic_reason": (
                        f"The source span independently performs {function}."
                        if function in required
                        else f"The source span has no independent {function} duty in this fixture."
                    ),
                }
                for function in CONTENT_FUNCTION_ORDER
            }
            contracts.append(
                {
                    "atom_id": atom_id,
                    "required_functions": required,
                    "source_evidence": atom["raw_excerpt"],
                    "function_matrix": function_matrix,
                    "reason": "语义审查确认该 Atom 同时承担列出的独立内容功能。",
                    "content_type": "PROSE",
                    "local_context_role": "在局部保留问题、解释、方法等完整作用",
                    "global_context_role": "在全篇保留作者的推理过程和方法路线",
                    "content_invariant": {"summary": atom["raw_excerpt"]},
                    "surface_contract": {
                        "decision": "CONTENT_PRESERVE",
                        "output_operation": "REORGANIZE_CONTENT",
                        "prelock_disposition": "NO_PRELOCK",
                        "basis": ["ORDINARY_SEMANTIC_CONTENT"],
                        "source_cues": [],
                        "rationale": "允许正式改写表面措辞，但内容功能和解释链必须完整保留。",
                        "confidence": "HIGH",
                        "allowed_completion": "正式化并重组措辞，同时保留全部内容功能",
                        "forbidden_change": "不得压缩成主题标签或孤立结论",
                    },
                }
            )
            reviews.append(
                {
                    "stage_id": STAGE,
                    "target_file": TARGET,
                    "target_sha256": target_hash,
                    "atom_id": atom_id,
                    "function_results": {
                        function: {
                            "realization_id": f"RZ{index:02d}{function_index:03d}",
                            "status": "REASONABLE_TRANSFORM",
                            "source_evidence": atom["raw_excerpt"],
                            "target_evidence": target,
                            "reason": "当前完整目标句段仍然实现这一独立功能，且不是只覆盖相同主题。",
                        }
                        for function_index, function in enumerate(required, 1)
                    },
                    "verdict": "PASS",
                }
            )
        write_json(
            self.root / "publication_blueprint.json",
            {
                "schema_version": "publication-blueprint-v1",
                "atom_function_contracts": contracts,
                "function_preservation_reviews": reviews,
                "task_requirement_reviews": [],
            },
        )


def run_cli(root: Path) -> tuple[int, str]:
    output = StringIO()
    argv = [
        "validate_quality_gate.py",
        str(root),
        "--stage",
        STAGE,
        "--target",
        TARGET,
    ]
    with patch.object(sys, "argv", argv), redirect_stdout(output):
        code = validate_quality_gate.main()
    return code, output.getvalue()


class QualityContractGateTests(unittest.TestCase):
    def test_deleting_about_thirty_percent_of_chinese_explanation_fails(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            source = exact_cjk("来源解释先记录问题再展开理由", 100, "理")
            target = exact_cjk("目标保留部分解释", 70, "述")
            QualityFixture(Path(tmp), [source], [target])

            report, errors = evaluate_quality_stage(Path(tmp), STAGE, TARGET)

            self.assertEqual(report["source_prose_cjk"], 100)
            self.assertEqual(report["target_measurements"]["prose_cjk"], 70)
            self.assertEqual(report["verdict"], "MEASURED_FAIL")
            self.assertTrue(any("source-realization CJK 70 below" in error for error in errors))
            code, output = run_cli(Path(tmp))
            self.assertEqual(code, 1)
            self.assertIn("article prose CJK 70 below contract minimum 100", output)

    def test_latex_growth_cannot_offset_chinese_explanation_loss(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            source = exact_cjk("来源解释完整说明推理和方法", 100, "明")
            target = exact_cjk("目标只剩少量说明", 60, "简")
            latex = "$$" + r"\sum_{i=1}^{5000} x_i^2 + \prod_{j=1}^{5000} y_j" * 20 + "$$"
            QualityFixture(Path(tmp), [source], [target], extra_markdown=latex)

            report, errors = evaluate_quality_stage(Path(tmp), STAGE, TARGET)

            self.assertGreater(report["target_measurements"]["math_nonspace_chars"], 500)
            self.assertEqual(report["target_measurements"]["prose_cjk"], 60)
            self.assertTrue(any("article prose CJK 60 below contract minimum 100" in e for e in errors))

    def test_substantive_atom_below_seventy_percent_fails_even_if_article_is_long(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            sources = [
                exact_cjk("第一来源解释", 100, "甲"),
                exact_cjk("第二来源解释", 100, "乙"),
            ]
            targets = [
                exact_cjk("第一目标缩水", 69, "丙"),
                exact_cjk("第二目标充分扩写", 150, "丁"),
            ]
            QualityFixture(Path(tmp), sources, targets)

            report, errors = evaluate_quality_stage(Path(tmp), STAGE, TARGET)

            self.assertGreaterEqual(report["target_measurements"]["prose_cjk"], 200)
            first = report["atom_results"][0]
            self.assertEqual(first["minimum_target_cjk"], 70)
            self.assertEqual(first["actual_target_cjk"], 69)
            self.assertEqual(first["status"], "MEASURED_FAIL")
            self.assertTrue(any("P06_DRAFT:A0001" in error for error in errors))

    def test_one_severely_shrunken_section_fails_even_if_other_section_compensates(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            sources = [
                exact_cjk("第一章节来源", 100, "甲"),
                exact_cjk("第二章节来源", 100, "乙"),
            ]
            targets = [
                exact_cjk("第一章节扩写", 160, "丙"),
                exact_cjk("第二章节缩水", 40, "丁"),
            ]
            # A high Atom floor isolates the section budget: whole-article volume
            # passes, while the second section must still fail independently.
            QualityFixture(Path(tmp), sources, targets, atom_floor=1000)

            report, errors = evaluate_quality_stage(Path(tmp), STAGE, TARGET)

            self.assertEqual(report["target_measurements"]["prose_cjk"], 200)
            self.assertEqual(report["actual_source_realization_cjk"], 200)
            self.assertEqual(report["section_results"][0]["status"], "MEASURED_PASS")
            self.assertEqual(report["section_results"][1]["status"], "MEASURED_FAIL")
            self.assertTrue(
                any("P06_DRAFT:SEC002: source-realization CJK 40 below section minimum 100" in e for e in errors)
            )

    def test_formal_rewrite_with_complete_functions_and_explanation_volume_passes(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            sources = [
                exact_cjk("作者先提出疑问再沿着条件逐步解释其中缘由", 80, "理"),
                exact_cjk("作者随后总结可复用的方法并说明每一步的依赖", 80, "法"),
            ]
            targets = [
                exact_cjk("正式表述仍先明确原有疑问并依次展开条件与理由", 86, "释"),
                exact_cjk("正式表述继续保留可复用方法以及各步骤依赖关系", 86, "证"),
            ]
            QualityFixture(Path(tmp), sources, targets)

            report, errors = evaluate_quality_stage(Path(tmp), STAGE, TARGET)
            code, output = run_cli(Path(tmp))

            self.assertEqual(errors, [])
            self.assertEqual(report["verdict"], "MEASURED_PASS")
            self.assertTrue(all(row["status"] == "MEASURED_PASS" for row in report["atom_results"]))
            self.assertTrue(all(row["status"] == "MEASURED_PASS" for row in report["section_results"]))
            self.assertEqual(code, 0, output)
            self.assertIn('"verdict": "MEASURED_PASS"', output)


if __name__ == "__main__":
    unittest.main()
