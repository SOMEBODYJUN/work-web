from __future__ import annotations

import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from source_atom_resegmentation import prepare_resegmentation  # noqa: E402
from runtime_transitions import _apply_artifacts  # noqa: E402
from runtime_support import RuntimeCliError, sha256_bytes, sha256_file  # noqa: E402
import agent_runtime  # noqa: E402


def copy_fixture(target: Path) -> None:
    """Create a small in-package fixture without shipping manuscript data."""
    import hashlib
    source = "".join(f"Atom {index:04d}: preserve this exact source responsibility.\n" for index in range(1, 49))
    source_bytes = source.encode("utf-8")
    (target / "source_canonical.txt").write_bytes(source_bytes)
    atoms = []
    sentences = []
    for index in range(1, 49):
        atom_id = f"A{index:04d}"
        start = (index - 1) * len(f"Atom {index:04d}: preserve this exact source responsibility.\n".encode())
        end = start + len(f"Atom {index:04d}: preserve this exact source responsibility.\n".encode())
        excerpt = source_bytes[start:end].decode("utf-8")
        atoms.append({
            "atom_id": atom_id, "source_byte_start": str(start), "source_byte_end": str(end),
            "source_excerpt_sha256": hashlib.sha256(source_bytes[start:end]).hexdigest(),
            "raw_excerpt": excerpt, "source_excerpt": excerpt, "char_span": f"{start}-{end}",
            "chunk_id": "C001", "sentence_id": f"T{index:04d}", "content_type": "PROSE",
            "content_invariant_json": json.dumps({"summary": excerpt}, ensure_ascii=False),
            "consumption_status": "PLANNED",
        })
        sentences.append({"sentence_id": f"T{index:04d}", "chunk_id": "C001", "char_span": f"{start}-{end}", "exact_sentence_or_line": excerpt, "sentence_role": "prose", "atom_ids": atom_id, "coverage_status": "covered", "notes": "fixture"})
    (target / "source_atom_ledger.jsonl").write_text("".join(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n" for row in atoms), encoding="utf-8")
    (target / "source_sentence_index.jsonl").write_text("".join(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n" for row in sentences), encoding="utf-8")
    chunk = {"chunk_id": "C001", "char_span": f"0-{len(source_bytes)}", "source_excerpt": source, "start_sentence_id": "T0001", "end_sentence_id": "T0048", "semantic_unit_hint": "48", "status": "complete"}
    (target / "source_chunk_index.jsonl").write_text(json.dumps(chunk, ensure_ascii=False) + "\n", encoding="utf-8")
    # Include the three P03 source-obligation ledgers so the transaction test
    # also exercises their exact Atom-overlap rebinding.
    for filename, key in (("source_formula_block_ledger.jsonl", "formula_block_id"), ("author_question_obligation_ledger.jsonl", "question_id"), ("source_math_risk_ledger.jsonl", "risk_id")):
        row = {key: "OBL0001", "source_span": f"0-{len(source_bytes)}", "atom_ids": "A0001-A0048", "status": "OPEN"}
        (target / filename).write_text(json.dumps(row, ensure_ascii=False) + "\n", encoding="utf-8")
    chunk_dir = target / "chunk_ledger"
    chunk_dir.mkdir()
    (chunk_dir / "chunk_C001_atom_ledger.jsonl").write_text("".join(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n" for row in atoms), encoding="utf-8")
    blueprint = {
        "atom_function_contracts": [{"atom_id": row["atom_id"], "required_functions": ["SUBSTANTIVE_CONTENT"], "source_evidence": row["raw_excerpt"], "function_matrix": {"SUBSTANTIVE_CONTENT": "REQUIRED"}} for row in atoms],
        "voices": [{"voice_id": "V001", "source_atoms": "A0001-A0048", "description": "fixture voice"}],
    }
    (target / "publication_blueprint.json").write_text(json.dumps(blueprint, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def valid_midpoint(root: Path, start: int, end: int) -> int:
    source = (root / "source_canonical.txt").read_bytes()
    midpoint = start + max(1, (end - start) // 2)
    while midpoint < end and (source[midpoint] & 0xC0) == 0x80:
        midpoint += 1
    return midpoint


class SourceAtomResegmentationTests(unittest.TestCase):
    def declaration(self, root: Path, *, split_id: str = "A0048") -> dict:
        blueprint = json.loads((root / "publication_blueprint.json").read_text(encoding="utf-8"))
        atoms = [
            json.loads(line)
            for line in (root / "source_atom_ledger.jsonl").read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        parent = next(row for row in atoms if row["atom_id"] == split_id)
        start, end = int(parent["source_byte_start"]), int(parent["source_byte_end"])
        midpoint = valid_midpoint(root, start, end)
        blueprint["source_atom_resegmentation"] = [{
            "source_atom_id": split_id,
            "children": [
                {"atom_id": "A0101", "source_byte_start": start, "source_byte_end": midpoint},
                {"atom_id": "A0102", "source_byte_start": midpoint, "source_byte_end": end},
            ],
        }]
        return blueprint

    def test_lossless_split_rebuilds_all_authoritative_mirrors(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_fixture(root)
            blueprint = self.declaration(root)
            outputs = prepare_resegmentation(root, blueprint)
            source = (root / "source_canonical.txt").read_bytes()
            atoms = [json.loads(line) for line in outputs["source_atom_ledger.jsonl"].splitlines()]
            self.assertEqual(len(atoms), 49)
            spans = sorted((int(row["source_byte_start"]), int(row["source_byte_end"])) for row in atoms)
            self.assertEqual(spans[0][0], 0)
            self.assertEqual(spans[-1][1], len(source))
            for left, right in zip(spans, spans[1:]):
                self.assertEqual(left[1], right[0])
            children = {row["atom_id"]: row for row in atoms if row["atom_id"].startswith("A010")}
            self.assertEqual(
                children["A0101"]["source_excerpt_sha256"],
                __import__("hashlib").sha256(source[int(children["A0101"]["source_byte_start"]):int(children["A0101"]["source_byte_end"])]).hexdigest(),
            )
            transformed = json.loads(outputs["publication_blueprint.json"])
            child_contracts = {
                row["atom_id"]: row for row in transformed["atom_function_contracts"]
                if row["atom_id"] in children
            }
            self.assertEqual(set(child_contracts), set(children))
            self.assertTrue(all(row.get("resegmentation_inherited") for row in child_contracts.values()))
            self.assertEqual(transformed["source_atom_resegmentation"]["status"], "APPLIED")

    def test_blueprint_without_split_is_a_true_noop(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_fixture(root)
            blueprint = json.loads((root / "publication_blueprint.json").read_text(encoding="utf-8"))
            before = {
                path.name: path.read_bytes()
                for path in root.iterdir()
                if path.is_file()
            }
            self.assertEqual(prepare_resegmentation(root, blueprint), {})
            after = {
                path.name: path.read_bytes()
                for path in root.iterdir()
                if path.is_file()
            }
            self.assertEqual(before, after)

    def test_explicit_child_contracts_and_atom_ranges_are_rebound(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_fixture(root)
            blueprint = self.declaration(root)
            operation = blueprint["source_atom_resegmentation"][0]
            parent_contract = next(
                row for row in blueprint["atom_function_contracts"] if row["atom_id"] == "A0048"
            )
            for child in operation["children"]:
                child["contract"] = {
                    **parent_contract,
                    "atom_id": child["atom_id"],
                    "required_functions": ["SUBSTANTIVE_CONTENT"],
                    "source_evidence": "placeholder",
                }
            # A top-level semantic row uses a bounded range containing the
            # split parent; the transformed blueprint must expose both child IDs.
            blueprint["voices"][0]["source_atoms"] = "A0046-A0048"
            outputs = prepare_resegmentation(root, blueprint)
            transformed = json.loads(outputs["publication_blueprint.json"])
            children = [
                row for row in transformed["atom_function_contracts"]
                if row["atom_id"] in {"A0101", "A0102"}
            ]
            self.assertEqual(len(children), 2)
            self.assertTrue(all("resegmentation_inherited" not in row for row in children))
            self.assertEqual(
                set(transformed["voices"][0]["source_atoms"].split(",")),
                {"A0046", "A0047", "A0101", "A0102"},
            )

    def test_gap_overlap_and_utf8_boundary_are_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_fixture(root)
            base = self.declaration(root)
            operation = base["source_atom_resegmentation"][0]
            parent = next(
                json.loads(line)
                for line in (root / "source_atom_ledger.jsonl").read_text(encoding="utf-8").splitlines()
                if json.loads(line)["atom_id"] == "A0048"
            )
            start, end = int(parent["source_byte_start"]), int(parent["source_byte_end"])
            # A gap.
            midpoint = int(operation["children"][0]["source_byte_end"])
            gap_end = midpoint - 1
            source = (root / "source_canonical.txt").read_bytes()
            while gap_end > start and (source[gap_end] & 0xC0) == 0x80:
                gap_end -= 1
            operation["children"][0]["source_byte_end"] = gap_end
            with self.assertRaisesRegex(ValueError, "contiguous"):
                prepare_resegmentation(root, base)
            # An overlap.
            base = self.declaration(root)
            operation = base["source_atom_resegmentation"][0]
            overlap_start = midpoint + 1
            while overlap_start < end and (source[overlap_start] & 0xC0) == 0x80:
                overlap_start += 1
            operation["children"][1]["source_byte_start"] = overlap_start
            with self.assertRaisesRegex(ValueError, "contiguous"):
                prepare_resegmentation(root, base)
            # A deliberately invalid UTF-8 boundary.
            base = self.declaration(root)
            operation = base["source_atom_resegmentation"][0]
            boundary = start + 1
            while boundary < end and (root / "source_canonical.txt").read_bytes()[boundary] & 0xC0 == 0x80:
                boundary += 1
            if boundary > start + 1:
                operation["children"][0]["source_byte_end"] = boundary - 1
                operation["children"][1]["source_byte_start"] = boundary - 1
                with self.assertRaisesRegex(ValueError, "UTF-8"):
                    prepare_resegmentation(root, base)

    def test_applied_declaration_is_idempotent(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            copy_fixture(root)
            blueprint = self.declaration(root)
            outputs = prepare_resegmentation(root, blueprint)
            for rel, content in outputs.items():
                path = root / rel
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(content, encoding="utf-8")
            applied = json.loads(outputs["publication_blueprint.json"])
            self.assertEqual(prepare_resegmentation(root, applied), {})

    def test_artifact_preflight_rejects_late_conflict_before_any_write(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            first = root / "first.txt"
            second = root / "second.txt"
            first.write_text("before", encoding="utf-8")
            second.write_text("unexpected", encoding="utf-8")
            writes = [
                {
                    "target_path": str(first),
                    "expected_absent": False,
                    "expected_before_sha256": sha256_file(first),
                    "target_precondition": "FILE_HASH_MATCH",
                    "planned_after_sha256": sha256_bytes(b"after"),
                    "payload_base64": __import__("base64").b64encode(b"after").decode(),
                },
                {
                    "target_path": str(second),
                    "expected_absent": True,
                    "expected_before_sha256": None,
                    "target_precondition": "PATH_MUST_NOT_EXIST",
                    "planned_after_sha256": sha256_bytes(b"new"),
                    "payload_base64": __import__("base64").b64encode(b"new").decode(),
                },
            ]
            with self.assertRaises(RuntimeCliError):
                _apply_artifacts({"transition_id": "TX-TEST", "artifact_writes": writes})
            self.assertEqual(first.read_text(encoding="utf-8"), "before")

    def test_p04_execute_action_binds_resegmentation_to_one_transition(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            business = root / "business"
            business.mkdir()
            copy_fixture(business)
            blueprint = self.declaration(business)
            response_path = root / "response.json"
            response = {
                "status": "ACTION_PROPOSED",
                "phase_id": "P04",
                "context_pack_sha256": "c" * 64,
                "summary": "controlled source split",
                "actions": [{
                    "action_id": "P04-SPLIT-001",
                    "action_type": "UPDATE_PHASE_ARTIFACT",
                    "phase_id": "P04",
                    "target": "publication_blueprint.json",
                    "source_basis": ["source_canonical.txt#bytes=0-6868"],
                    "rule_basis": ["SOURCE_MICRO_ATOMIZATION_PROTOCOL.md"],
                    "payload": {
                        "content": json.dumps(blueprint, ensure_ascii=False, indent=2),
                        "content_format": "json",
                        "expected_target_sha256": sha256_file(business / "publication_blueprint.json"),
                    },
                }],
                "phase_completion_claim": {
                    "ready": False,
                    "review_mode": "NATIVE_SUBAGENT_REVIEW",
                    "verdict": "BLOCK",
                    "evidence": [],
                    "unresolved_items": ["resegmentation requires a fresh P04 review"],
                    "first_loss_boundary": None,
                },
            }
            response_path.write_text(json.dumps(response, ensure_ascii=False), encoding="utf-8")
            state = {
                "state_revision": 4,
                "cursor": {"current_phase": "P04", "attempt": 2},
                "route": {"phase_plan_revision": 1},
                "active": {
                    "validation_receipt_id": "RCT-TEST",
                    "status": "ACTION_VALIDATED",
                },
                "roots": {"business_root": str(business), "runtime_root": str(root / "runtime")},
                "domain_states": {"BUSINESS": {"access_state": "READ_WRITE"}},
                "phase_records": {"P04": {"written_targets": []}},
            }
            receipt = {
                "receipt_id": "RCT-TEST",
                "response_sha256": sha256_file(response_path),
                "state_revision": 4,
                "phase_plan_revision": 1,
                "phase_id": "P04",
                "phase_attempt": 2,
                "context_pack_sha256": "c" * 64,
                "artifact_contract_sha256": "a" * 64,
            }
            captured: dict[str, object] = {}

            def fake_transition(_runtime, current, **kwargs):
                captured["artifact_writes"] = kwargs["artifact_writes"]
                result = json.loads(json.dumps(current))
                kwargs["mutate"](result)
                return {**result, "state_revision": current["state_revision"] + 1}

            args = SimpleNamespace(
                runtime_root=str(root / "runtime"),
                response=str(response_path),
                receipt_id="RCT-TEST",
            )
            with patch.object(agent_runtime, "load_state", return_value=state), \
                patch.object(agent_runtime, "require_phase"), \
                patch.object(agent_runtime, "validate_bound_context"), \
                patch.object(agent_runtime, "load_valid_receipt", return_value=receipt), \
                patch.object(agent_runtime, "validate_json_schema"), \
                patch.object(agent_runtime, "current_context_hash", return_value="c" * 64), \
                patch.object(agent_runtime, "artifact_contract_sha", return_value="a" * 64), \
                patch.object(agent_runtime, "apply_transition", side_effect=fake_transition), \
                patch.object(agent_runtime, "emit_json"):
                self.assertEqual(agent_runtime.cmd_execute_action(args), 0)
            writes = captured["artifact_writes"]
            assert isinstance(writes, list)
            targets = {Path(item["target_path"]).name for item in writes}
            self.assertIn("publication_blueprint.json", targets)
            self.assertIn("source_atom_ledger.jsonl", targets)
            self.assertIn("source_sentence_index.jsonl", targets)
            self.assertIn("source_chunk_index.jsonl", targets)
            self.assertGreaterEqual(len(writes), 10)


if __name__ == "__main__":
    unittest.main()
