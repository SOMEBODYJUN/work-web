from __future__ import annotations

from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from unittest.mock import patch
import hashlib
import json
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "skills" / "math-longform-publisher" / "scripts"
sys.path.insert(0, str(SCRIPTS))

from build_source_model import math_risk_rows_for  # noqa: E402
from source_obligations import obligation_identity_sha256, source_obligation_contracts  # noqa: E402
import validate_source_math_risks  # noqa: E402


SOURCE = "Let a map have the stated property. The conclusion follows in the next paragraph."


def sha(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def write_jsonl(path: Path, rows: list[dict[str, object]]) -> None:
    path.write_text(
        "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows),
        encoding="utf-8",
    )


def write_mirror(path: Path, rows: list[dict[str, object]]) -> None:
    columns = list(rows[0])
    lines = [
        "# Source Math Risk Ledger",
        "",
        "| " + " | ".join(columns) + " |",
        "|" + "|".join("---" for _ in columns) + "|",
    ]
    for row in rows:
        values = [str(row.get(column, "")).replace("|", "\\|") for column in columns]
        lines.append("| " + " | ".join(values) + " |")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def scan(status: str) -> dict[str, object]:
    return {
        "risk_id": "MR0001",
        "source_revision_id": "R0001",
        "source_sha256": sha(SOURCE),
        "source_span": f"0-{len(SOURCE.encode('utf-8'))}",
        "risk_type": "SOURCE_WIDE_MATH_SEMANTIC_SCAN",
        "claim_excerpt": "WHOLE_SOURCE",
        "reason": "The complete source requires semantic review of its mathematical claims and dependencies.",
        "required_review": "Read the complete source and check every condition, implication, and proof dependency.",
        "resolution_status": status,
        "resolution_note": "P03 reviewed the entire source in context and recorded the result independently of keywords.",
    }


def no_risk() -> dict[str, object]:
    row = dict(scan("MATH_SEMANTIC_SCAN_COMPLETE"))
    row.update(
        {
            "risk_id": "MR0002",
            "risk_type": "NO_MATHEMATICAL_RISKS",
            "reason": "The completed semantic review found no material mathematical risk in the current source.",
            "required_review": "Continue claim-level and proof-level checking at each later article boundary.",
            "resolution_status": "NO_MATHEMATICAL_RISKS",
            "resolution_note": "No-risk is an explicit full-source AI conclusion, not a zero-keyword inference.",
        }
    )
    return row


def concrete_risk() -> dict[str, object]:
    return {
        "risk_id": "MR0002",
        "source_revision_id": "R0001",
        "source_sha256": sha(SOURCE),
        "source_span": f"0-{len(SOURCE.encode('utf-8'))}",
        "risk_type": "UNSTATED_HYPOTHESIS",
        "claim_excerpt": SOURCE,
        "reason": "The conclusion uses a property whose required hypothesis is not stated in the source.",
        "required_review": "State and justify the missing hypothesis before accepting the conclusion in the article.",
        "resolution_status": "RESOLVED_WITH_JUSTIFICATION",
        "resolution_note": "P03 determined that the article must make the missing hypothesis explicit and justify its use.",
    }


def prepare(root: Path, rows: list[dict[str, object]]) -> None:
    (root / "source_canonical.txt").write_text(SOURCE, encoding="utf-8")
    (root / "source_revision.json").write_text(
        json.dumps({"source_revision_id": "R0001"}), encoding="utf-8"
    )
    write_jsonl(root / "source_math_risk_ledger.jsonl", rows)
    write_mirror(root / "source_math_risk_ledger.md", rows)


def run_validator(root: Path) -> tuple[int, str]:
    output = StringIO()
    with patch.object(sys, "argv", ["validate_source_math_risks.py", str(root)]):
        with redirect_stdout(output):
            code = validate_source_math_risks.main()
    return code, output.getvalue()


class MathRiskSemanticLifecycleTests(unittest.TestCase):
    def test_p02_always_creates_a_whole_source_blocker_without_keyword_guessing(self) -> None:
        rows = math_risk_rows_for(SOURCE, "R0001")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["risk_type"], "SOURCE_WIDE_MATH_SEMANTIC_SCAN")
        self.assertEqual(rows[0]["resolution_status"], "BLOCKED_NEEDS_MATHEMATICAL_REVIEW")
        self.assertEqual(rows[0]["source_span"], f"0-{len(SOURCE.encode('utf-8'))}")
        self.assertEqual(rows[0]["source_sha256"], sha(SOURCE))

    def test_p03_cannot_complete_scan_without_risk_or_explicit_no_risk(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            prepare(root, [scan("MATH_SEMANTIC_SCAN_COMPLETE")])
            code, output = run_validator(root)
            self.assertEqual(code, 1)
            self.assertIn("requires exactly one NO_MATHEMATICAL_RISKS", output)

    def test_zero_keyword_source_can_carry_a_concrete_ai_identified_risk(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            prepare(root, [scan("MATH_SEMANTIC_SCAN_COMPLETE"), concrete_risk()])
            code, output = run_validator(root)
            self.assertEqual(code, 0, output)

    def test_complete_ai_scan_with_explicit_no_risk_passes(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            prepare(root, [scan("MATH_SEMANTIC_SCAN_COMPLETE"), no_risk()])
            code, output = run_validator(root)
            self.assertEqual(code, 0, output)

    def test_p04_must_bind_concrete_math_risk_to_atom_functions(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            prepare(root, [scan("MATH_SEMANTIC_SCAN_COMPLETE"), concrete_risk()])
            write_jsonl(root / "author_question_obligation_ledger.jsonl", [{
                "question_id": "AQ0001", "obligation_type": "NO_AUTHOR_QUESTIONS",
                "resolution_status": "NO_AUTHOR_QUESTIONS",
            }])
            write_jsonl(root / "source_formula_block_ledger.jsonl", [{
                "formula_block_id": "FB0001",
                "canonicalization_status": "NO_FRAGMENTED_FORMULA_BLOCKS",
            }])
            atom = {
                "atom_id": "A0001",
                "content_type": "PROSE",
                "source_byte_start": "0",
                "source_byte_end": str(len(SOURCE.encode("utf-8"))),
            }
            blueprint = {
                "atom_function_contracts": [{
                    "atom_id": "A0001",
                    "required_functions": ["SUBSTANTIVE_CONTENT"],
                }],
                "source_obligation_contracts": [],
            }
            _contracts, errors = source_obligation_contracts(
                root, blueprint, [atom], require_ledgers=True
            )
            self.assertIn("MR0002", "\n".join(errors))

    def test_rendering_only_contract_cannot_discharge_mathematical_conditions(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            risk = concrete_risk()
            prepare(root, [scan("MATH_SEMANTIC_SCAN_COMPLETE"), risk])
            write_jsonl(root / "author_question_obligation_ledger.jsonl", [{
                "question_id": "AQ0001", "obligation_type": "NO_AUTHOR_QUESTIONS",
                "resolution_status": "NO_AUTHOR_QUESTIONS",
            }])
            write_jsonl(root / "source_formula_block_ledger.jsonl", [{
                "formula_block_id": "FB0001",
                "canonicalization_status": "NO_FRAGMENTED_FORMULA_BLOCKS",
            }])
            atom = {
                "atom_id": "A0001",
                "content_type": "PROSE",
                "source_byte_start": "0",
                "source_byte_end": str(len(SOURCE.encode("utf-8"))),
            }
            blueprint = {
                "atom_function_contracts": [{
                    "atom_id": "A0001",
                    "required_functions": ["SUBSTANTIVE_CONTENT"],
                }],
                "source_obligation_contracts": [{
                    "obligation_id": "MR0002",
                    "obligation_kind": "MATH_RISK",
                    "source_ledger": "source_math_risk_ledger.jsonl",
                    "obligation_identity_sha256": obligation_identity_sha256("MATH_RISK", risk),
                    "source_evidence": SOURCE,
                    "source_atom_ids": ["A0001"],
                    "required_functions": ["SUBSTANTIVE_CONTENT"],
                    "function_bindings": [{"atom_id": "A0001", "function": "SUBSTANTIVE_CONTENT"}],
                    "fulfillment_mode": "FORMULA_NORMALIZATION",
                    "implementation_requirement": "Only restore the visual rendering of the expression.",
                    "reason": "The expression is displayed clearly but the missing hypothesis is not addressed.",
                }],
            }
            _contracts, errors = source_obligation_contracts(
                root, blueprint, [atom], require_ledgers=True
            )
            self.assertIn("invalid fulfillment_mode", "\n".join(errors))


if __name__ == "__main__":
    unittest.main()
