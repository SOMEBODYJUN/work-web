from __future__ import annotations

from argparse import Namespace
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from unittest.mock import patch
import json
import sys
import tempfile
import unittest
import zipfile


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import web_work  # noqa: E402
import obsidian_copy_first  # noqa: E402
import agent_runtime  # noqa: E402


class WebWorkTests(unittest.TestCase):
    def test_active_state_json_has_transactional_markdown_mirror(self) -> None:
        value = {
            "run_id": "RUN-TEST", "run_mode": "PRESERVE_REORGANIZE",
            "current_stage": "source_review", "resume_point": "review",
            "feedback_ledger_sha256": "a" * 64,
            "active_feedback_ids": [], "hard_constraints": ["read current source"],
            "resume_instruction": "Continue from the current source review.",
        }
        mirror = agent_runtime.render_active_state_mirror_content(json.dumps(value))
        self.assertIn("CURRENT_STAGE: source_review", mirror)
        self.assertIn("Continue from the current source review.", mirror)
        self.assertIn("- read current source", mirror)

    def test_p21_snapshot_verdict_is_export_not_import(self) -> None:
        with tempfile.TemporaryDirectory(dir=ROOT.parent) as temp:
            root = Path(temp)
            vault = root / "vault"
            vault.mkdir()
            candidate = root / "candidate.md"
            candidate.write_text("# Page\n", encoding="utf-8")
            delivered = root / "delivery" / "02-Obsidian导入包" / "Page.md"
            delivered.parent.mkdir(parents=True)
            delivered.write_bytes(candidate.read_bytes())
            seed = {"page_id": "PAGE1", "operation_id": "OP1", "target_path": "Page.md", "operation_kind": "CREATE", "tag_classification": []}
            (root / "page_seed_manifest.json").write_text(json.dumps({"pages": [seed]}), encoding="utf-8")
            (root / "page_patch_application.json").write_text(json.dumps({"pages": [{"page_id": "PAGE1", "candidate_sha256": web_work._sha(candidate)}]}), encoding="utf-8")
            staging = {
                "vault_binding_id": "SNAPSHOT1", "vault_root_fingerprint": "0" * 64,
                "page_seed_manifest_sha256": web_work._sha(root / "page_seed_manifest.json"),
                "patch_application_sha256": web_work._sha(root / "page_patch_application.json"),
                "generation_id": "GEN1", "new_tag_proposals": [],
                "operations": [{"operation_id": "OP1", "target_path": "Page.md", "operation_kind": "CREATE", "candidate_relative_path": "candidate.md", "before_sha256": None, "after_sha256": web_work._sha(candidate), "tag_classification": []}],
            }
            path = root / "staging" / "staging_manifest.json"
            path.parent.mkdir()
            path.write_text(json.dumps(staging), encoding="utf-8")
            binding = {"binding_id": "SNAPSHOT1", "root_fingerprint": "0" * 64, "config": {"mode": "STAGING_ONLY"}}
            with patch.object(obsidian_copy_first, "_root", return_value=root), patch.object(obsidian_copy_first, "_staging", return_value=(path, staging)), patch.object(obsidian_copy_first.legacy, "load_binding", return_value=(binding, vault)), patch.object(obsidian_copy_first, "_schema"):
                result = obsidian_copy_first.validate_staging({})
            self.assertEqual(result["outcome"], "READY_FOR_EXPORT")
            report = json.loads((root / "validation" / "obsidian_validation_report.json").read_text(encoding="utf-8"))
            self.assertEqual(report["verdict"], "READY_FOR_EXPORT")
            self.assertFalse((vault / "Page.md").exists())

    def test_rejects_traversal_symlink_and_case_collision_in_vault_upload(self) -> None:
        with tempfile.TemporaryDirectory(dir=ROOT.parent) as temp:
            root = Path(temp)
            for name in ("../escape.md", "A/./note.md", "A//note.md", "/absolute.md"):
                source = root / "vault.zip"
                with zipfile.ZipFile(source, "w") as archive:
                    archive.writestr(name, "unsafe")
                with self.subTest(name=name), self.assertRaises(ValueError):
                    web_work.extract_vault_snapshot(source, root / "snapshot")
            with zipfile.ZipFile(root / "vault.zip", "w") as archive:
                archive.writestr("Notes/A.md", "first")
                archive.writestr("notes/a.md", "second")
            with self.assertRaisesRegex(ValueError, "case-colliding"):
                web_work.extract_vault_snapshot(root / "vault.zip", root / "snapshot")
            with zipfile.ZipFile(root / "vault.zip", "w") as archive:
                link = zipfile.ZipInfo("link.md")
                link.create_system = 3
                link.external_attr = (0o120777 << 16)
                archive.writestr(link, "target")
            with self.assertRaisesRegex(ValueError, "link or special"):
                web_work.extract_vault_snapshot(root / "vault.zip", root / "snapshot")

    def test_init_freezes_source_and_contract_before_original_runtime(self) -> None:
        with tempfile.TemporaryDirectory(dir=ROOT.parent) as temp:
            root = Path(temp)
            source = root / "uploaded.txt"
            source.write_text("为什么保留证明路线？\n", encoding="utf-8")
            workspace = root / "run"
            state = {
                "state": {
                    "identity": {"run_id": "RUN-TEST"},
                    "cursor": {"current_phase": "P03"},
                    "workflow": {"status": "RUNNING"},
                    "outputs": {"obsidian": {"status": "NOT_REQUESTED"}},
                    "execution": {"committed_phase_ids": ["P00", "P01", "P02"]},
                }
            }
            args = Namespace(workspace_root=str(workspace), source=str(source), request="保留证明路线", task_contract=None, obsidian=False, vault_zip=None)
            with patch.object(web_work, "_ensure_dependencies"), patch.object(web_work, "_run_runtime", side_effect=[{}, {}, {}, state]) as run, redirect_stdout(StringIO()):
                web_work.init(args)
            commands = [call.args[0] for call in run.call_args_list]
            self.assertEqual(commands, ["bootstrap", "source-authority", "source-model", "status"])
            self.assertIn("--skip-obsidian", run.call_args_list[0].args)
            contract = json.loads((workspace / "inputs" / "author-task-contract.json").read_text(encoding="utf-8"))
            self.assertEqual(contract["author_request"], args.request)
            self.assertEqual(contract["expansion_directives"], [])
            self.assertEqual((workspace / "inputs" / "source.txt").read_bytes(), source.read_bytes())

    def test_init_accepts_work_attachment_without_filename_extension(self) -> None:
        with tempfile.TemporaryDirectory(dir=ROOT.parent) as temp:
            root = Path(temp)
            source = root / "01-txt"
            source.write_text("原稿附件\n", encoding="utf-8")
            workspace = root / "run"
            state = {"state": {"identity": {"run_id": "RUN-TEST"}, "cursor": {"current_phase": "P03"}, "workflow": {"status": "RUNNING"}, "outputs": {"obsidian": {"status": "NOT_REQUESTED"}}, "execution": {"committed_phase_ids": ["P00", "P01", "P02"]}}}
            args = Namespace(workspace_root=str(workspace), source=str(source), request=None, task_contract=None, obsidian=False, vault_zip=None)
            with patch.object(web_work, "_ensure_dependencies"), patch.object(web_work, "_run_runtime", side_effect=[{}, {}, {}, state]), redirect_stdout(StringIO()):
                web_work.init(args)
            self.assertEqual((workspace / "inputs" / "source.txt").read_text(encoding="utf-8"), "原稿附件\n")

    def test_snapshot_route_is_staging_only_and_cannot_be_selected_implicitly(self) -> None:
        with tempfile.TemporaryDirectory(dir=ROOT.parent) as temp:
            root = Path(temp)
            source = root / "uploaded.txt"
            source.write_text("原稿\n", encoding="utf-8")
            vault_zip = root / "vault.zip"
            with zipfile.ZipFile(vault_zip, "w") as archive:
                archive.writestr("Notes/old.md", "# Old\n")
            args = Namespace(workspace_root=str(root / "run"), source=str(source), request="整理原稿", task_contract=None, obsidian=False, vault_zip=str(vault_zip))
            with self.assertRaisesRegex(ValueError, "explicit"):
                web_work.init(args)
            args.obsidian = True
            state = {"state": {"identity": {"run_id": "RUN-TEST"}, "cursor": {"current_phase": "P03"}, "workflow": {"status": "RUNNING"}, "outputs": {"obsidian": {"status": "INDEX_PENDING"}}, "execution": {"committed_phase_ids": ["P00", "P01", "P02"]}}}
            with patch.object(web_work, "_ensure_dependencies"), patch.object(web_work, "_run_runtime", side_effect=[{}, {}, {}, state]), redirect_stdout(StringIO()):
                web_work.init(args)
            config = json.loads((root / "run" / "inputs" / "obsidian-target-config.json").read_text(encoding="utf-8"))
            self.assertEqual(config["mode"], "STAGING_ONLY")
            self.assertIs(config["human_review"]["vault_commit"], False)
            self.assertTrue((root / "run" / "vault-snapshot" / "Notes" / "old.md").is_file())
            web_work._verify_snapshot(root / "run")
            (root / "run" / "vault-snapshot" / "Notes" / "old.md").write_text("changed\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "changed after upload"):
                web_work._verify_snapshot(root / "run")


if __name__ == "__main__":
    unittest.main()
