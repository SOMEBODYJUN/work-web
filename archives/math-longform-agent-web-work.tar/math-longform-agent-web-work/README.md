# Math Longform Agent for Web Work 1.0.0

把本包和数学原稿上传到 ChatGPT Work。Work 会解压本包，先读根目录 `AGENTS.md`、Skill `SKILL.md`、`SUPERVISOR_KERNEL.md` 与 `SINGLE_THREAD_RUNTIME_PROTOCOL.md`，然后在云端工作区直接启动；如果没有附加整理说明，入口使用保真整理默认合同。原稿按 UTF-8 内容校验，Work 附件即使暂时没有 `.txt` 扩展名也能启动。

可以直接使用这句：

> 请按附件中的 Math Longform Agent 直接启动。解压包并完整读取根 AGENTS.md 的必读文件；用 scripts/web_work.py init 冻结当前数学原稿和默认保真合同，然后从 P03 起按 Runtime 一步一步运行。主 Agent 调度工作子 Agent 产出阶段文件，再调度独立只读子 Agent 审查全部 Atom/功能和当前字节；不要跳阶段。

若明确要求 Obsidian，再上传 Vault 的 ZIP 快照并在请求中指明“制作 Obsidian 导入包”。此快照仅用于学习既有笔记、文件夹、标签、链接与生成差异预览；网页端不会写入电脑上的正式 Vault。

## 云端启动

主 Work 任务负责图编排和 Runtime 提交；每个语义阶段由独立工作子 Agent 读取 Context Envelope 并产出声明文件，另由独立只读子 Agent 复核。原有 Python Runtime 负责哈希、许可动作、恢复与提交。启动命令由主 Work 任务执行：

```bash
python scripts/web_work.py init \
  --workspace-root <agent目录之外的新工作目录> \
  --source <已上传的原稿.txt> \
  --request-file <保存作者本次请求原文的UTF-8文件>
```

若作者明确要求 Obsidian，并上传了 ZIP 快照，增加 `--obsidian --vault-zip <快照.zip>`；若作者要求 Obsidian 但尚无快照，只加 `--obsidian`，流程在 P16 等待真实输入。届时使用 `python scripts/web_work.py attach-vault --workspace-root <工作目录> --vault-zip <后来上传的快照.zip>` 恢复。明确授权扩写时，Work 应从 `config/author-task-contract.preserve-reorganize.json` 建立本次合同，填入具体扩写指令，再加 `--task-contract <本次合同.json>`。默认不授权概述、省略或扩写。入口会在云端工作目录加载 `requirements-web-lock.txt` 中的 Python 依赖；若策略阻止必要的安装，它会报错而不会绕开 schema 校验。

入口先使用包内 Linux x86_64/Python 3.12 或 3.14 的依赖包，若环境不匹配再尝试按锁定版本安装；无法加载时阻断。它冻结原稿和合同，依次完成 P00 bootstrap、P01 source authority 与 P02 deterministic source model，并输出当前阶段、run_id 和路径。之后继续用原 Runtime：

```bash
python scripts/web_work.py runtime --workspace-root <工作目录> -- emit-turn
python scripts/web_work.py runtime --workspace-root <工作目录> -- validate-action --response <response.json>
python scripts/web_work.py runtime --workspace-root <工作目录> -- execute-action --response <response.json> --receipt-id <receipt-id>
python scripts/web_work.py runtime --workspace-root <工作目录> -- advance
python scripts/web_work.py status --workspace-root <工作目录>
```

以上是阶段循环的命令名称，不是允许跳过中间动作的脚本。每次写入后重新 `emit-turn`；完成全部声明输出后才启动新的只读子代理，对本阶段的每个 Atom/功能、源义务及每个输出提供当前哈希和精确摘录。没有可用的原生子代理时停为 `BLOCKED`，不提交自我审查伪装的 PASS。遇到 `PARTIAL`/`BLOCK`，保存结构化 repair handoff，修复首个丢失边界，再重新审查。

## 原流程与交付

- P00–P14 顺序与原包相同。P12 只机械组装，P13 才能逐 Atom 验收并写 `CONSUMED`，P14 独占机器发布证据。最终文章在 `<工作目录>/business/publication_final.md`。
- P16–P21 仅在明确请求 Obsidian 时进入，仍按作者取舍、Copy-first page plan、精确 seed、局部 patch、实际页面/diff、导入前校验逐步推进。Vault ZIP 绑定为 `STAGING_ONLY`，P21 成功后状态为 `READY_FOR_EXPORT`；干净交付在 `<工作目录>/runtime/obsidian/delivery/`，工程证据留在工作目录。`apply-obsidian` 对该模式直接拒绝。真实 Vault 的导入不在网页端宣称完成。
- 完成每阶段后可运行 `python scripts/web_work.py checkpoint --workspace-root <工作目录> --output <工作目录之外的检查点.zip>`，保存 Runtime、business、附件副本及哈希清单，再把文件交付保存。此版本的 Runtime 在状态中使用绝对路径；**不可把检查点解压到另一条路径后直接运行旧收据或旧 Context Envelope**。在相同云端工作区可继续；如果工作区已重置，应停下并使用显式的路径迁移流程，不能手工改 JSON 或凭对话记忆接续。本包目前未提供跨工作区自动迁移。

本包完整保留 `schemas/`、业务 `templates/`、机器校验器和测试。历史 pytest/pyc 缓存已从交付包移除。运行中的附件、状态、diff、审查报告与备份都放在 Agent 目录之外，不混入最终文章或导入包。
