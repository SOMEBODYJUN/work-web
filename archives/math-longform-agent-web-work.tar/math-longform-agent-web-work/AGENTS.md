# Math Longform Agent Web Work

This folder is a complete uploaded Agent, not a prompt-only skill. The current
ChatGPT Work task is the **main orchestrator**. It delegates each semantic
phase's source reading and artifact production to a fresh work sub-agent, then
delegates completion checking to a different fresh native read-only reviewer.
The main task alone calls Runtime `validate-action`, `execute-action`, and
`advance`; neither sub-agent may commit state. Extract the package into the
cloud task workspace, then read this file. Do not launch another Codex task,
`codex exec`, a CLI worker, or a CLI supervisor.

The work sub-agent receives only the current Context Envelope, required source
and rule files, and its phase brief. It returns schema-conforming artifact
actions. The reviewer starts without the worker's rationale and rereads the
source and every declared output. If native sub-agents are unavailable, stop as
`BLOCKED`; never simulate either role in the main task or Runtime.

## Mandatory Authorities

Before starting or resuming a run, read these files completely:

1. `skills/math-longform-publisher/SKILL.md`
2. `skills/math-longform-publisher/AGENTS.md`
3. `skills/math-longform-publisher/references/SUPERVISOR_KERNEL.md`
4. `skills/math-longform-publisher/references/SINGLE_THREAD_RUNTIME_PROTOCOL.md`

The Runtime state, phase registry, canonical source, JSONL ledgers, and exact
artifact hashes are authoritative. Conversation memory is not evidence.
After each committed phase, archive the complete run with `web_work.py checkpoint`
and make that file available to the author. This is an evidence backup, not
authorization to replay a run at a new absolute path; fail closed on workspace
loss until an explicit relocation migration exists.

## Web Work Execution Loop

Keep one logical run and drive it only through `scripts/agent_runtime.py`; in
Web Work, invoke its commands using `scripts/web_work.py runtime --workspace-root
<run> -- <command> ...` so the run's Python dependencies are available.

For a new source, use the uploaded UTF-8 `.txt` manuscript and the current
author request. Save the exact request to a UTF-8 file with file tools, then run
`python scripts/web_work.py init --workspace-root <new-root> --source
<uploaded-source.txt> --request-file <exact-current-author-request.txt>`.
The launcher creates a fresh, disjoint run outside this Agent folder, replaces
the task-contract placeholders, bootstraps P00, and runs deterministic P01-P02.
Preserve/reorganize is the default; never infer summary authorization. If the
author explicitly requested expansion, build a schema-valid run-specific
contract from the template and pass `--task-contract`. The launcher refuses a
contract containing placeholders or a different request.

Only when the author explicitly requests Obsidian, pass `--obsidian`. If the
author also uploaded a Vault ZIP, pass `--vault-zip <uploaded-snapshot.zip>`;
the launcher binds it as a read-only `STAGING_ONLY` snapshot. Without the
snapshot, P16 suspends for configuration. Never invent Vault knowledge, local
access, or permission to write it.

1. Bootstrap, run P01 source authority, and run P02 source modeling.
2. At a semantic phase, run `emit-turn` and inspect every bound
   `required_reads` and `required_rule_reads` file.
3. Produce at most one allowed artifact action. Save the schema-conforming
   response under the Runtime's `model-responses/` directory, then run
   `validate-action` and `execute-action`.
4. Re-run `emit-turn` after each write so the next action binds current bytes.
5. When every declared output exists, stop generating. Start a fresh native
   read-only review sub-agent with no inherited drafting rationale. Give it the
   Supervisor Kernel, current Context Envelope, canonical source, exact current
   inputs, and every phase output. Do not give it an expected answer, a prior
   failure report, or the worker's explanation.
6. Submit an empty-action completion response with
   `review_mode=NATIVE_SUBAGENT_REVIEW`. Its evidence must come from the fresh
   review and bind an exact source file/hash/excerpt and target
   file/hash/excerpt for every declared phase output. At P04, review every Atom;
   at rewrite boundaries, review every Atom/function realization. Use PASS only
   with no unresolved item.
7. Run `validate-action`, `execute-action`, then `advance`. If any check fails,
   repair the nearest upstream artifact and repeat the review. Never jump to a
   later phase.

If the fresh reviewer returns `PARTIAL` or `BLOCK`, do not submit a vague
reason or rerun the writer blindly. Submit an empty-action
`status=BLOCKER_FOUND` response with `ready=false` and a complete
`repair_handoff`. Runtime persists that handoff atomically with State. Run
`recover` using the active handoff; the returned phase Context Envelope will
contain the exact immutable handoff and its acceptance conditions. A free-form
`--reason` can add context but cannot replace the handoff.

Deterministic phases are executed by `advance`; they never grant a semantic
PASS. Runtime validation and release evidence remain machine-owned.

The review sub-agent is read-only. It returns `PASS`, `PARTIAL`, or `BLOCK` and
the first loss boundary; it never edits ledgers or prose. On `PARTIAL` or
`BLOCK`, the outer task repairs the nearest upstream artifact and launches a
new fresh review against the new hashes.

## Semantic Rules

- P02 does not infer prose functions from keywords. Its universal
  `SUBSTANTIVE_CONTENT` value is only an incomplete intake floor.
- P04 rereads every exact Atom in local and whole-source context, decides what
  the Atom is actually doing, and writes its complete multi-function contract.
- Each P04 contract must also contain a complete `function_matrix`: all nine
  named functions are explicitly marked `REQUIRED` or `NOT_REQUIRED`, each with
  exact source evidence and a concrete semantic reason. `required_functions`
  is exactly the REQUIRED subset; a required-only list is not a complete review.
- The named function dimensions are review questions for the Agent, not word
  triggers. Their absence from the wording never proves that a function is absent.
- P02 surface-word rules are a conservative prelock safety net. P04 must review
  every Atom, confirm or extend exact locks, and retain a prelock when uncertain.
- If any deletion or surface change alters content, attitude, force, rhythm,
  author identity, narrative timing, or discourse function, use `BYTE_EXACT`.
  Similar meaning or similar strength is not sufficient.
- A destination, related heading, similar theorem, or topic match is not
  consumption.
- At every rewrite boundary, check mathematics, questions, explanation chains,
  methods, author perspective, intuition, proof dependencies, follow-up
  requests, warnings, and deliberately preserved voice separately.
- P05 compiles every Atom/function pair into one source-grounded realization
  obligation carrying the complete exact Atom slice. P06 and every later rewrite
  boundary must bind one complete target output unit to that obligation. Only
  functions of the same Atom may intentionally share a unit; different Atoms need
  separately identifiable realizations even when they discuss one topic.
- P04 also binds every P03 AQ/FB/MR source obligation into those exact
  Atom/functions. P05 carries the IDs, and every rewrite boundary records a
  separate obligation result; ordinary topic or Atom coverage cannot erase the
  obligation identity.
- P02 always leaves mathematical semantics unresolved. P03 reads the complete
  source and records either concrete source-bound risks or one explicit no-risk
  conclusion. Never infer mathematical safety or risk from keywords, formula
  tokens, topics, or historical test manuscripts.
- Stop at the first boundary that loses a required function. Repair that file;
  do not compensate in a later report.
- A `PARTIAL`/`BLOCK` review must identify the first loss boundary and carry
  source/target hashes, the affected responsibility, root cause, repair scope,
  forbidden shortcut, and acceptance condition in `repair-handoff-v1`. Returning
  to a phase without this object is invalid; the next worker must read the
  handoff before writing.
- P12 copies exact P11 article bytes and produces only pending mechanical
  candidates. It cannot write review PASS files or `CONSUMED`.
- P13 reopens every Atom and every required function against the actual
  `publication_final.md`. Only the deterministic P13 finalizer can write
  `CONSUMED` after complete current-hash acceptance. P13 writes the semantic body
  of `PUBLICATION_AUDIT_REPORT.md`; P14 alone replaces its validator hashes and
  command evidence with machine-generated values.
- P16-P21 retain the author-directed Obsidian Copy-first workflow. A web-uploaded
  snapshot is read-only evidence for clean export, not the formal Vault. P21
  reaches `READY_FOR_EXPORT`; do not run `apply-obsidian` on the snapshot.

## Failure Rule

Do not invent missing evidence, fill reports with representative examples, or
declare completion because validators are structurally green. Record the first
loss boundary and repair upstream. Stop as BLOCKED only when the same blocking
condition survives three consecutive repair attempts without meaningful
progress. A newly discovered independent omission, or a strictly shrinking
blocker set, is not the same failed repair; continue the bounded upstream repair
and fresh review. Never spend repair attempts synchronizing a handwritten copy
of an authoritative ledger.
