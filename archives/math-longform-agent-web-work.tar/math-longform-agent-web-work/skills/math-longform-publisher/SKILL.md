---
name: math-longform-publisher
description: canonical-source-locked workflow for turning rough Chinese mathematical notes into validated WeChat/mdnice longform articles. Use when ChatGPT or Codex must preserve the author's mathematical content, proof route, notation, questions, voice, and exact surface passages while producing publication_final.md with semantic atom coverage, formula repair, reverse trace, mathematical review, byte-level output authorization, and deterministic release evidence.
---

# Math Longform Publisher

The package version is recorded only in `VERSION`. Do not introduce package-version
headings into runtime protocols or script names.

## Single-Thread Agent Runtime

When this Skill is supplied by the `math-longform-agent` plugin, read
`references/SINGLE_THREAD_RUNTIME_PROTOCOL.md` before starting. Let the external
runtime own phase transitions, context envelopes, and action authorization; this
Skill remains the sole business authority. Do not present deferred runtime phases
as implemented or claim a release from a runtime status message.

Every semantic run must also read `references/SUPERVISOR_KERNEL.md`. The kernel
is the persistent project-level supervision contract: it carries the semantic
model across phases and fresh Codex sessions, while the runtime binds its hash
into the current context envelope. In this Agent, each semantic phase is
authorized by a fresh native read-only review sub-agent informed by the kernel
and current source; fresh context does not mean an uninformed blank reviewer.

For the uploaded Web Work package, read the package root `AGENTS.md` and use
the `web_work.py` launcher under the package root's scripts directory with the
uploaded source and current author request.
The cloud workspace is temporary; save released files and an archival run
checkpoint after phase commits when the task supports it. A Vault ZIP is a
read-only snapshot: P21 `READY_FOR_EXPORT` does not mean the author's real Vault
was changed. Never run `apply-obsidian` against that snapshot.

## Quick Start

Initialize a legitimate run instead of copying every template:

```bash
python scripts/pipeline.py init <source.txt> <output_dir> --mode source_atomization
python scripts/pipeline.py prepare-source <output_dir>
python scripts/pipeline.py validate <output_dir> --mode source_atomization
python scripts/pipeline.py evidence <output_dir> --mode source_atomization
python scripts/pipeline.py status <output_dir>
```

`prepare-source` performs deterministic, lossless intake. It creates semantic-size
atoms, bounded chunks, exact mirrors, formula-damage rows, author-question
obligations, and conservative surface-review evidence. A
`BLOCKED_NEEDS_HUMAN_REVIEW` formula remains blocked for drafting even though the
source-intake package itself is structurally valid.

For a full article run, first resolve every formula, author-question, and
mathematical-risk obligation. Then write the reviewed article and a
`publication-blueprint-v1` JSON file containing semantic locks and independent
review evidence. Compile the mechanical publication package from those two
reviewed inputs:

```bash
python scripts/pipeline.py set-mode <output_dir> --mode full_publication
python scripts/pipeline.py prepare-publication \
  <output_dir> <reviewed_article.md> <publication_blueprint.json>
python scripts/pipeline.py validate <output_dir> --mode full_publication
python scripts/pipeline.py release <output_dir> --mode full_publication
```

`prepare-publication` is the supported mechanical assembler for the publication
stage. It generates exact output-unit traces, paragraph indexes, claim ledgers,
and pending heading, fragment, and Atom-consumption candidates. It does not write
content review, mathematical review, audit PASS, or `CONSUMED`. P13 supplies the
semantic judgments against the compiled bytes; P14 alone replaces the audit
report's validator hashes and command evidence with machine-generated values.

For WeChat delivery, use `wechat_publication`. Never authenticate, upload, or publish
unless the user explicitly requests that external action.

## Control Plane

`scripts/pipeline_registry.py` is the single source of truth for:

- supported run modes;
- required files;
- structured JSONL files;
- stage artifacts;
- validator order and invocation arguments.

Do not duplicate those lists in another script or protocol. Source intake is implemented by
`scripts/build_source_model.py` and invoked only through `pipeline.py prepare-source`.
Use `scripts/pipeline.py status` to determine the next incomplete stage.

The runtime control plane and the semantic Supervisor have different duties.
The runtime controls hashes, file boundaries, action authorization, and phase
commits. The outer task controls work, and a fresh native read-only reviewer
controls the final semantic verdict and blocking. A worker cannot advance from
its own completion claim without the supervised review loop defined in the
kernel.

## Source Authority

The source flow is:

```text
uploaded UTF-8 TXT
→ source_original.txt
→ source_canonical.txt
→ source_revision.json
→ semantic CONTENT_LOCKED atoms
→ section execution plan
→ article output units
→ deterministic reverse validation
```

`source_original.txt` is immutable. Under the initial `IDENTITY` transformation,
`source_canonical.txt`, `canonical_source.txt`, and `source.txt` are byte-identical.
Only `source_canonical.txt` has writing authority.

If the user authorizes a source correction, use `scripts/apply_source_patch.py`.
Never silently normalize mathematical symbols, punctuation, Unicode, or formulas.

## Semantic Atom Contract

Every current non-duplicate source atom must:

- bind the active `source_revision_id`;
- cover an exact UTF-8 byte span and hash;
- use `content_lock_state=CONTENT_LOCKED`;
- identify a specific `content_type`;
- record every independent semantic responsibility in `required_functions`; at
  P04 also record a complete nine-dimension `function_matrix` with explicit
  `REQUIRED`/`NOT_REQUIRED` decisions, exact source evidence, and reasons;
- state local and global context roles;
- encode a source-grounded invariant;
- define finite legal transformation and forbidden change;
- record consumption status;
- resolve to its sentence and chunk.

P02 supplies only an incomplete universal content floor. Do not use keyword or
regular-expression matches to decide whether an atom carries a question,
explanation, method, perspective, intuition, proof dependency, follow-up, or
warning. At P04, reread the exact atom in local and whole-source context and make
that semantic decision explicitly. Function names are review dimensions; the
source-specific `source_evidence` and `reason` state the actual responsibility.

Atomize by semantic responsibility. Do not force one atom per comma, OCR line, or
individual mathematical symbol. Split when mathematical role, proof role, voice,
warning, question, or destination changes. Reject both paragraph summaries and
one-symbol administrative fragmentation.

Load:

- `references/CONTENT_AUTHORITY_PROTOCOL.md`
- `references/CONTENT_FUNCTION_PRESERVATION_PROTOCOL.md`
- `references/SOURCE_MICRO_ATOMIZATION_PROTOCOL.md`
- `references/CHUNKED_ATOMIZATION_RUN_PROTOCOL.md`

Run:

```bash
python scripts/validate_source_revision.py <output_dir>
python scripts/validate_atom_semantics.py <output_dir>
python scripts/validate_source_atom_granularity.py <output_dir>
python scripts/validate_chunk_batching.py <output_dir>
```

## Exact Surface Decisions

Use `surface_mode=BYTE_EXACT` when the source form itself carries content: quotation,
distinctive voice, abrasive wording, repetition, rhythm, punctuation, wordplay,
fixed expression, title/signature language, or direct address.

P02 may conservatively prelock likely cases, but only P04 supplies semantic
approval after reading every atom in context. Apply the deletion-and-change
counterfactual: if any change alters content, attitude, force, rhythm, author
identity, narrative timing, or discourse function, keep the original bytes.
`CONTENT_PRESERVE` requires a concrete explanation that surface changes leave
all of those functions unchanged; uncertainty retains the prelock.

A `BYTE_EXACT` atom has one legal operation:

```text
output_operation=COPY_SOURCE_SLICE
```

Do not add editable completion or forbidden-change fields to that atom. Re-slice the
bytes from the current canonical source with
`scripts/materialize_exact_source_slice.py`. Group adjacent exact atoms with
`CONTIGUOUS_BYTE_EXACT` when they form one uninterrupted passage.

Load `references/SURFACE_DECISION_PROTOCOL.md` and run:

```bash
python scripts/validate_surface_decisions.py <output_dir>
```

## Formula and Question Intake

Before atomization:

1. inspect vertical OCR/math runs;
2. create `source_formula_block_ledger.jsonl` and its Markdown mirror;
3. reconstruct mathematical objects only when source support is sufficient;
4. use `BLOCKED_NEEDS_HUMAN_REVIEW` when it is not;
5. convert author doubts, requests, and questions into
   `author_question_obligation_ledger.jsonl`.

Formula block and atom spans use UTF-8 byte offsets. Do not create one fake atom for
each vertically copied symbol.

Load:

- `references/FORMULA_BLOCK_CANONICALIZATION_PROTOCOL.md`
- `references/AUTHOR_QUESTION_OBLIGATION_PROTOCOL.md`
- `references/MATHEMATICAL_RISK_REVIEW_PROTOCOL.md`

P02 also creates one unresolved whole-source mathematical semantic scan. It
does not use mathematical keywords or formula patterns to declare a risk or
declare safety. At P03, read the complete source, complete that scan, and write
either source-bound material risks or one explicit no-risk conclusion. Carry
every resolved concrete MR through the same P04-P13 obligation chain; formula
surface repair alone never proves that its mathematical conditions are met.
Treat the three P03 ledgers as the only `AQ`/`FB`/`MR` identity authority. Never
copy their IDs or ranges into `active_state.*`; that state holds only resume
metadata and actual user feedback, while P04 and Runtime read the live ledgers.

## Long-Source Context

For long or dense sources, create bounded contiguous chunks and per-chunk atom
ledgers. Later sections must reopen upstream definitions, symbols, proof premises,
warnings, voice turns, and explanation chains through:

```text
cross_chunk_dependency_map.jsonl
section_context_prefetch_plan.jsonl
context_pack_manifest.json
```

JSONL is machine-authoritative. Markdown is a mirror. Malformed JSONL never falls
back to Markdown.

Load:

- `references/CROSS_CHUNK_DEPENDENCY_PROTOCOL.md`
- `references/LEDGER_CONTEXT_LOCK.md`
- `references/STRUCTURED_LEDGER_PROTOCOL.md`

## Article Construction

Before writing, reopen the current source revision, atom ledger, user feedback,
dependency rows, mathematical locks, and section execution plan. Do not treat a file
as consumed merely because it exists.

At P05, compile every Atom/function pair into one source-grounded realization
obligation carrying the complete exact Atom slice. At P06, execute those
obligations section by section and cite a complete sentence/formula output unit.
Only functions of the same Atom may intentionally share one realization unit, with
an explicit group and justification. Different Atoms remain separately identifiable;
shared subject matter is not a merge reason.

Before P05, bind every actionable P03 `AQ`, canonicalized formula `FB`, and
resolved mathematical-risk `MR` row to its overlapping Atom/functions in
`source_obligation_contracts`. Carry the exact IDs into P05 and write a separate
`source_obligation_results` judgment at each rewrite boundary. Do not let an
Atom/function PASS, destination, or matching theorem silently discharge the P03
required action.

The internal version chain is:

```text
draft.md
→ final.md
→ optimized_final.md
→ standardized_final.md
→ revised_final.md
→ aigc_rewritten_final.md
→ publication_final.md
```

Only `publication_final.md` is releasable. Intermediate files are evidence and repair
boundaries, not alternative final outputs.

Preserve the author's proof route, notation, examples, warnings, questions,
explanatory movement, and distinctive voice. Complete missing mathematics only when
the current source creates a finite obligation and the completion is independently
reviewed. Do not replace an author's method with a generic textbook route.

At every rewrite boundary, review every Atom/function pair against the complete
source Atom, a complete target output unit, and its P05 `realization_id`. A destination or occurrence
of the same topic is not `CONSUMED`; P12 may use only reviewed evidence to map an
atom to concrete output units.

## Output Authorization

Sentence trace alone does not authorize every word. Before release:

- deterministically split `publication_final.md`;
- write exact output byte spans and hashes to
  `publication_sentence_trace.jsonl`;
- partition every output byte in
  `publication_fragment_authorization.jsonl`;
- authorize every heading in `heading_authorization.jsonl`.

Allowed fragment categories are:

```text
SOURCE_EXACT
SOURCE_REORGANIZATION
MATHEMATICAL_COMPLETION
FORMULA_NORMALIZATION
STRUCTURAL_LABEL
MINIMAL_CONNECTIVE
USER_REQUESTED
FORMAT_SYNTAX
```

There is no releasable `UNAUTHORIZED_EDITORIAL` category. Delete unsupported
narration, dramatization, marketing language, synthetic informality, and process
commentary.

Load:

- `references/OUTPUT_FRAGMENT_AUTHORIZATION_PROTOCOL.md`
- `references/HEADING_AUTHORIZATION_PROTOCOL.md`

Run:

```bash
python scripts/validate_publication_sentence_trace.py <output_dir>
python scripts/validate_content_function_preservation.py <output_dir> --release-chain
python scripts/validate_output_fragment_authorization.py <output_dir>
python scripts/validate_heading_authorization.py <output_dir>
```

## Mathematical and Content Acceptance

Provenance cannot prove correctness. Reopen the actual final article and create
current-hash-bound:

```text
publication_content_review.json
mathematical_review.json
```

Check theorem hypotheses, contour orientation, singularities on paths, domains,
symbols, signs, proof dependencies, examples, and unsupported generalizations.
A consistent ledger around a false statement remains a blocking failure.

Load `references/PUBLICATION_CONTENT_ACCEPTANCE_PROTOCOL.md` and run:

```bash
python scripts/validate_publication_content_acceptance.py <output_dir>
```

## Feedback and Recovery

Real user corrections belong in `user_feedback_ledger.jsonl` and `active_state.*`.
Stable quality rules belong in this Skill, protocols, schemas, and validators.
Unresolved feedback blocks release.

On failure:

1. identify the failed layer;
2. record it in `failure_recovery_log.md`;
3. rebuild the nearest upstream artifact;
4. rerun the failed validator;
5. mark `BLOCKED` after three unsuccessful repairs rather than silently patching.

Load `references/FAILURE_RECOVERY_PROTOCOL.md` when a gate fails.

## Run Modes

- `source_atomization`: source lock and source-model work; never publishable.
- `diagnostic_backtest`: staged diagnosis; never publishable.
- `full_publication`: strict article release.
- `wechat_publication`: strict release plus WeChat mirror checks.

A package-supplied `run_mode.json` may record intent, but a trusted caller must pass
`--mode` to a release entry point. Package content cannot lower release strength.

`VERSION` is the only package release version. Values such as
`source-identity-v3` or `validator-result-v2` are independent file-schema
identifiers, not old Skill releases. `run_mode.json.package_version` must match
`VERSION`; after upgrading the Skill, rerun `pipeline.py set-mode` before
validation so stale evidence is invalidated and context bindings are refreshed.

## Release Evidence

Do not hand-write validator evidence. `scripts/pipeline.py release` runs the
canonical registry, creates per-validator logs, writes hashes, and verifies the
result and audit report.

Validator command arguments are recorded with the portable `<output_dir>` token.
Moving or unpacking a completed run into another directory must not invalidate
otherwise unchanged evidence.

Machine-generated evidence includes:

```text
validator_result.json
validator_result.sha256
validator_result.txt
validator_evidence/
release_manifest.json
release_manifest.sha256
```

`PUBLICATION_AUDIT_REPORT.md` is the only artifact allowed to declare the final
release decision.

## Reference Loading

Always read:

- `AGENTS.md`
- this file
- `references/NO_RUNTIME_EXAMPLES_POLICY.md`
- `references/CANONICAL_SOURCE_PROTOCOL.md`
- `references/CONTENT_AUTHORITY_PROTOCOL.md`
- `references/RUN_MODE_PROTOCOL.md`
- `references/ACTIVE_STATE_AND_USER_FEEDBACK_PROTOCOL.md`
- `references/SECURITY_BOUNDARY.md`

Read `references/DETAILED_WORKFLOW_PROTOCOL.md` only for a full run, package
maintenance, or validator failure. Load other references only when their named
condition applies.

## Runtime Isolation

The production Skill contains protocols, blocked templates, and deterministic tools.
It must not contain manuscript fixtures, previous articles, expected answers,
regression corpora, maintenance history, credentials, or hidden publishing actions.

After changing the Skill, run:

```bash
python scripts/validate_skill_package_integrity.py .
python scripts/validate_control_plane_consistency.py .
```
