# Omission Ledger

| omission_id | source_atoms | source_excerpt | allowed_reason | where_intent_preserved | note |
|---|---|---|---|---|---|
| O001 |  |  | exact_duplicate / ocr_artifact / page_header / unrecoverable_fragment / future_preview_preserved_elsewhere |  |  |
