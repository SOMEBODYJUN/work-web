# AIGC Source Type Ledger

Headings count as sentences for this ledger.

| sentence_id | file | location | sentence_or_heading | source_type | source_atoms | statement_ids | proof_ids | generated_by_assistant | function | aigc_risk | required_action | status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| AS001 | revised_final.md | heading / paragraph |  | A/B/C/D | A0001 | S001 | PR001 | yes/no | definition/explanation/transition/summary/proof/heading | low/medium/high | keep/delete/compress/replace | pending / done |
