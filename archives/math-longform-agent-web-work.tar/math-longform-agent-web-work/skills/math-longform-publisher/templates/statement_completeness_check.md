# Statement Completeness Check

| check_id | statement_id | assumptions_complete | conclusion_complete | proof_obligation_linked | symbols_defined | scope_clear | result | fix |
|---|---|---|---|---|---|---|---|---|
| SC001 | S001 | yes/no | yes/no | yes/no | yes/no | yes/no | PASS / FIX_REQUIRED |  |
