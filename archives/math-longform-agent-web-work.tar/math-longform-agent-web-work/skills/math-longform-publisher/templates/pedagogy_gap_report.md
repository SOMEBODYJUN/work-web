# Pedagogy Gap Report

| gap_id | source_atoms | location | gap_type | dependency_or_example_needed | allowed_repair | forbidden_repair | final_destination |
|---|---|---|---|---|---|---|---|
| PG001 |  |  | dependency / proof_anatomy / hypothesis_stress / minimal_example / route_map |  |  |  |  |

## Decision

NO_ACTION / LOCAL_REPAIR / REBUILD_SECTION
