# independent_review.md

## Supervisor Binding

- supervisor kernel: `references/SUPERVISOR_KERNEL.md`
- supervisor kernel sha256:
- source revision id:
- source canonical sha256:
- candidate sha256:
- review context: fresh native read-only sub-agent
- worker interpretation treated as authority? must be no

The reviewer must load the bound Supervisor Kernel, current canonical source,
current-source ledgers, and the exact candidate output before recording a
verdict. A fresh reviewer is independent from the worker's assumptions, not
blank about the project's preservation model.

## Scope

- source:
- draft reviewed:
- second-version target:
- reviewer stance: independent / skeptical / source-first
- conversation assumptions ignored? yes/no

## Semantic Reconstruction Before Findings

- source responsibilities reconstructed from current source/ledgers:
- preservation-sensitive functions present:
- questions, explanation chains, proof routes, methods, perspectives, voice,
  warnings, and future previews identified separately? yes/no
- first candidate boundary checked against source? yes/no

## Findings

| severity | location | issue | lost function | source evidence | rewrite action |
|---|---|---|---|---|---|
| high |  |  |  |  |

## Non-Current-Source Leak Check

| non-current-source influence | useful rule if user-provided | unsupported move that must not be imported |
|---|---|---|
|  |  |  |

## Required Rewrite Actions

- 

## Checks

- Source asides or live comments washed out? yes/no
- Source questions/doubts preserved as article value? yes/no
- Non-current-source/example/fixture content imported without current-source support? yes/no
- Current-scope material falsely labeled future preview? yes/no
- Proof ideas replaced by shorter standard proof? yes/no
- Ledger or coverage claims too optimistic? yes/no
- Validator pass treated as enough? must be no
- Review written before final rewrite? must be yes

## Rewrite Decision

- patch draft / global rewrite:
- reason:

## Supervisor Verdict

- semantic verdict: `PASS` / `PARTIAL` / `BLOCK`
- first unacceptable loss boundary:
- evidence for every required function reviewed? yes/no
- deterministic validators also pass? yes/no
- phase may advance? yes/no
