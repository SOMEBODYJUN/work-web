# source_destination_ledger.md

| source_id | source_excerpt | author_intent | math_role | voice_role | scope_role | needed_action | final_destination |
|---|---|---|---|---|---|---|---|
| S001 |  |  |  |  |  |  |  |
