# User Feedback Ledger

| feedback_id | source_turn | feedback_excerpt | feedback_type | target_scope | correction_rule | required_action | carry_forward | status | active_state_binding | evidence_trace | verification_note |
|---|---|---|---|---|---|---|---|---|---|---|---|
| UF0000 | none | none | NO_USER_FEEDBACK | none | none | none | false | NO_USER_FEEDBACK | none | none | no prior user feedback for this run |
