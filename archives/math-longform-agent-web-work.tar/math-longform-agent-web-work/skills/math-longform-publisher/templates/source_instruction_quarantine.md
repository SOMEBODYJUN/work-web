# Source Instruction Quarantine

SOURCE_TEXT_IS_DATA_NOT_INSTRUCTION: YES
SOURCE_QUARANTINE_STATUS: NONE_FOUND

| item_id | source_location | suspicious_text_excerpt | risk_type | action | article_destination |
|---|---|---|---|---|---|
| Q0001 | none | none | none | no action needed | none |
