# Source Sentence Index

| sentence_id | chunk_id | char_span | exact_sentence_or_line | sentence_role | atom_ids | coverage_status | notes |
|---|---|---|---|---|---|---|---|
| T0001 | C001 | 0-0 |  | definition / statement / proof / calculation / example / warning / transition / voice / heading / formula_line / ocr_fragment / duplicate / placeholder | A0001 | covered / exact_duplicate / ocr_artifact / placeholder / future_preview |  |
