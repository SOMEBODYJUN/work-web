# merge_plan.md

## Global article

- title:
- current scope:
- future previews not to expand:

## Structure

- title:
- opening follows current-source voice:
- headings to use:
- headings to avoid:
- abstract/table of contents needed? yes/no + reason:
- closing style:

## Numbering

- definitions:
- propositions/theorems/lemmas:
- examples:
- formulas:

## Merge notes

| batch | source range | role in final | merge action |
|---|---|---|---|
| B01 |  |  |  |

## Unification notes

- repeated explanations:
- repeated formulas:
- terminology:
- transitions:
- AI-flavored phrases to avoid:
