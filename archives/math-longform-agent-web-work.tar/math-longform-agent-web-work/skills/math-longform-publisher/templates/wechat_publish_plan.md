# WeChat Publish Plan

| item | value |
|---|---|
| source_file | publication_final.md |
| target_platform | mdnice / WeChat public account |
| publishing_tool | md2wechat / manual / other |
| tool_available | yes / no / not_checked |
| requested_action | preview / convert / draft_upload / publish |
| theme |  |
| image_handling |  |
| formula_status | pass / fail / not_checked |
| auth_required | yes / no / unknown |

## Capability Check

```text
paste `python scripts/check_md2wechat_cli.py` output here when relevant
```

## Publication Boundary

- No article text rewrite during export.
- No upload, auth, or publish unless explicitly requested.
- Re-run formula and clean gates after any export transformation.
