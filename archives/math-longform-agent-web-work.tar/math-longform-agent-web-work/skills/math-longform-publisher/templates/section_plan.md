# Section Plan

| section_id | title | source_atoms | statement_ids | explanation_chain_ids | voice_atoms | notes |
|---|---|---|---|---|---|---|
| SEC01 |  |  |  |  |  |  |
