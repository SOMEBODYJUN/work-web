# Standardized Final

Math block normalized candidate before attack/revision.
