# Symbol Lock Report

| symbol_id | preferred_final_symbol | banned_replacement | final_result | evidence |
|---|---|---|---|---|
| SYM001 |  |  | ok / failed |  |
