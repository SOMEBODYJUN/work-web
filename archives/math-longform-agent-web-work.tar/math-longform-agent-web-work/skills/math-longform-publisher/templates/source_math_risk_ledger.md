# Source Math Risk Ledger

| risk_id | source_revision_id | source_sha256 | source_span | risk_type | claim_excerpt | reason | required_review | resolution_status | resolution_note |
|---|---|---|---|---|---|---|---|---|---|
| MR0001 | R0001 | REPLACE_WITH_CURRENT_SOURCE_SHA256 | 0-1 | SOURCE_WIDE_MATH_SEMANTIC_SCAN | WHOLE_SOURCE | Deterministic intake cannot decide the source's mathematical correctness or completeness. | Read the complete canonical source and record every material risk or an explicit no-risk conclusion. | BLOCKED_NEEDS_MATHEMATICAL_REVIEW | Replace through pipeline.py prepare-source; P03 must complete the semantic review. |
