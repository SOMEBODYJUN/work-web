# Pre-Final Plan

This is a construction plan written before article generation. It is not a post-hoc trace map.

| plan_id | planned_location | planned_function | source_atoms | statement_ids | proof_ids | voice_ids | symbol_ids | chain_ids | allowed_new_material | writing_instruction |
|---|---|---|---|---|---|---|---|---|---|---|
| PLAN001 | opening / section / proof / example |  | A0001 | S001 | PR001 | V001 | SYM001 | CH001 | none / math_completion / local_bridge |  |
