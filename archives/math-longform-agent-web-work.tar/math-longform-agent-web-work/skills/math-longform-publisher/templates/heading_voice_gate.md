# Heading Voice Gate

## Heading Audit

| heading_id | heading_level | heading_text | source_atoms | source_phrase | heading_source_type | invented_words | risk | required_fix | status |
|---|---:|---|---|---|---|---|---|---|---|
| H001 | 2 |  | A0001 |  | source_exact / source_repair / plain_local / invented_C |  | low / medium / high | keep / shorten / replace_with_source_phrase / replace_with_plain_label | pending |

## Heading Rules

Heading priority:

1. exact or lightly repaired source phrase;
2. local noun phrase supported by nearby atoms;
3. shortest mathematical label.

Assistant-invented headings are C-class AIGC material until cleared.

Forbidden process-heading phrases unless exact source wording is explicitly allowed with `ALLOW_SOURCE_EXACT`:

```text
先说
先把
先来
先看
然后
接下来
最后
再说
这里先
先别
先记
先写
先给
一波
收尾
说完
看一下
也可以这么看
```

Forbidden slogan/marketing heading words unless locally source-supported:

```text
偷偷
真正
核心
底层逻辑
完整闭环
系统梳理
全面解析
```

Do not put `$...$` math delimiters in headings.

## H2/H3 Repetition Check

- No adjacent H2/H3 pair may repeat the same text.
- Do not create a H2 title and then immediately repeat it as H3.
- Do not make headings narrate the process of writing; make them name the local mathematical object.

## Decision

PASS / FIX_REQUIRED / REBUILD_HEADINGS
