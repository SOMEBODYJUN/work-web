# Chunk Processing Log

| run_id | chunk_id | stage | command | exit_code | status | evidence |
|---|---|---|---|---:|---|---|
| R0001 | C001 | atomize_validate | python scripts/validate_source_atom_granularity.py <output_dir> | 0 | PASS | chunk ledger rebuilt and included in aggregate |
| R0002 | ALL | batching_validate | python scripts/validate_chunk_batching.py <output_dir> | 0 | PASS | source_atom_manifest.md and merged ledger verified |
