# Publication Trace Map

Post-hoc map for `publication_final.md`. Generate after AIGC rewrite and publication assembly.

| para_id | file | publication_location | heading_context | paragraph_or_block_excerpt | source_atoms | statement_ids | proof_ids | voice_ids | symbol_ids | chain_ids | aigc_sentence_ids | source_type_mix | allowed_new_reason | verification_note |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| PP0001 | publication_final.md |  |  |  | A0001 | S001 | PR001 | V001 | SYM001 | CH001 | AS001 | A/B/D | none / math_required |  |
