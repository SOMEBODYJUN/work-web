# Attack Report

The attacker finds failures only. It does not rewrite正文.

## Files Reopened

| file | reopened | notes |
|---|---|---|
| source.txt | yes/no |  |
| source_atom_ledger.md | yes/no |  |
| chunk ledgers | yes/no/not_applicable |  |
| math_statement_ledger.md | yes/no |  |
| proof_obligations.md | yes/no |  |
| voice_expression_ledger.md | yes/no |  |
| symbol_ledger.md | yes/no |  |
| explanation_chain_ledger.md | yes/no |  |
| section_plan.md | yes/no |  |
| standardized_final.md | yes/no |  |
| final_trace_map.md | yes/no |  |
| final_claim_ledger.md | yes/no |  |

## Findings

| finding_id | source_atoms_or_chain_id | statement_ids | proof_ids | target_file | target_location | issue_type | severity | evidence | decision |
|---|---|---|---|---|---|---|---|---|---|
| ATK001 | A0001 | S001 | PR001 | standardized_final.md |  |  | minor / publish_risk / blocker / rebuild |  | fix / rebuild / no_action |

## Rebuild Triggers

- ledger consumption:
- chunk coverage:
- trace/index:
- math statement lock:
- proof obligations:
- explanation chains:
- symbol lock:
- voice lock:
- headings:
- AIGC surface:
- formula:

## Decision

PUBLISHABLE / PUBLISHABLE_AFTER_MINOR_FIXES / REVISE_BEFORE_PUBLISH / REBUILD_BEFORE_PUBLISH
