# AIGC Rewrite Tasks

| task_id | sentence_ids | source_type | target_location | original_text | action | replacement_or_deletion | math_safety_check | voice_safety_check | status |
|---|---|---|---|---|---|---|---|---|---|
| AR001 | AS001 | C/D |  |  | delete / compress / replace / keep_with_reason |  | no_math_change / checked_statement_ids | no_voice_loss / checked_voice_ids | pending / done |
