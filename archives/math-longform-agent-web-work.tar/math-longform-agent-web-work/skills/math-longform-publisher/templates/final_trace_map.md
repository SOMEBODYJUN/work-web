# Final Trace Map

Post-hoc map for `standardized_final.md`. Generate only after `standardized_final.md` exists.

| para_id | file | final_location | heading_context | paragraph_or_block_excerpt | source_atoms | statement_ids | proof_ids | voice_ids | symbol_ids | chain_ids | source_type_mix | added_material_class | allowed_new_reason | verification_note |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| P0001 | standardized_final.md |  |  |  | A0001 | S001 | PR001 | V001 | SYM001 | CH001 | A/B/C/D | none / math_required / bridge / heading |  |  |
