# Symbol Ledger

| symbol_id | source_symbol | meaning | source_context | preferred_final_symbol | banned_replacement | reason | where_used |
|---|---|---|---|---|---|---|---|
| SYM001 |  |  |  |  |  |  |  |
