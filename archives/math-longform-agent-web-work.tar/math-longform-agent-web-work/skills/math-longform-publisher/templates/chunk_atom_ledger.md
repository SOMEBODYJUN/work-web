# Chunk Atom Ledger

Each chunk ledger uses the same global atom ids as `source_atom_ledger.md`.

| atom_id | sentence_id | chunk_id | char_span | source_excerpt | atom_level | atom_type | author_intent | math_role | voice_role | symbol_role | punctuation_boundary | ocr_state | needed_action | destination_status | final_destination |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| A0001 | T0001 | C001 | 0-0 |  | sentence / small_clause / comma_pause / formula / symbol_definition / voice_fragment / author_method / proof_route / insight / exact_surface / ocr_fragment / duplicate / placeholder | definition / statement / proof_step / calculation / formula / example / warning / voice / author_method / proof_route / insight / transition / future_preview / exact_surface / ocr_fragment / duplicate / placeholder |  |  |  |  | original punctuation or line break | clear / damaged / uncertain |  | preserved / formula_restored / voice_preserved / exact_duplicate / ocr_artifact / omitted_with_reason |  |
