# Publication Audit Report

## Final State

FINAL_STATE: BLOCKED

## Source Identity

| field | value |
|---|---|
| source_file | source.txt |
| source_length |  |
| output_dir |  |
| article_target | publication_final.md |

## Ledger Consumption

| gate | status | evidence |
|---|---|---|
| source atoms consumed | PENDING |  |
| voice/symbol/chains consumed | PENDING |  |
| section/pre-final plan consumed | PENDING |  |

## Math And Proof Locks

| gate | status | evidence |
|---|---|---|
| math_statement_ledger | PENDING |  |
| proof_obligations | PENDING |  |
| symbol_lock | PENDING |  |

## Claim Source Obligation

| gate | status | evidence |
|---|---|---|
| final_claim_ledger | PENDING |  |
| publication_claim_ledger | PENDING |  |
| blocked claims | PENDING |  |

## Reverse Trace

| gate | status | evidence |
|---|---|---|
| final_trace_map | PENDING |  |
| publication_trace_map | PENDING |  |
| paragraph coverage | PENDING |  |

## AIGC Regression

| gate | status | evidence |
|---|---|---|
| C-class material resolved | PENDING |  |
| math unchanged | PENDING |  |
| headings checked | PENDING |  |

## Security Boundary

| gate | status | evidence |
|---|---|---|
| source_instruction_quarantine | PENDING |  |
| security_boundary_report | PENDING |  |

## Failure Recovery

| gate | status | evidence |
|---|---|---|
| failure_recovery_log | PENDING |  |
| unresolved validator failure | PENDING |  |

## Validator Evidence Lock

VALIDATOR_RESULT_FILE: validator_result.json
VALIDATOR_RESULT_SHA256: REPLACE_WITH_ACTUAL_SHA256
VALIDATOR_RESULT_GENERATED_BY: scripts/run_publication_validators.py
TARGET_SNAPSHOT_SHA256: REPLACE_WITH_TARGET_SNAPSHOT

## Command Evidence

| command | target | exit_code | verdict | evidence_note |
|---|---|---:|---|---|
| python scripts/run_publication_validators.py | output_dir | 1 | BLOCKED | replace with machine-generated validator_result.json before release |

## Release Decision

RELEASE_DECISION: blocked_do_not_publish
