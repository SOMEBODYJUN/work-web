# Post-AIGC Trace Check

| check | result | evidence |
|---|---|---|
| all surviving paragraphs trace to source atoms or approved B-class rewrites |  |  |
| deleted C-class sentences did not break explanation chains |  |  |
| compressed C-class sentences remain source-supported |  |  |
| no new untraced paragraph was introduced |  |  |

## Decision

PASS / FIX_REQUIRED / REBUILD_REQUIRED
