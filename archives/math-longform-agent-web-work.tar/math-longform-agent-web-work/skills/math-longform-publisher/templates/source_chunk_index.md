# Source Chunk Index

| chunk_id | source_start | source_end | char_start | char_end | rough_topic | required_chunk_ledger | status |
|---|---|---:|---:|---:|---|---|---|
| C001 | first source phrase | last source phrase | 0 | 0 |  | chunk_ledger/chunk_C001_atom_ledger.md | pending / complete |
