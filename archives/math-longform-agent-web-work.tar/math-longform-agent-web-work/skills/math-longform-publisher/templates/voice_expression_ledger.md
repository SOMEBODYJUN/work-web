# Voice Expression Ledger

| voice_id | source_atoms | source_excerpt | expression_function | preservation_requirement | allowed_transform | forbidden_transform | final_destination |
|---|---|---|---|---|---|---|---|
| V001 |  |  | joke / doubt / warning / pressure / transition / emphasis / author_term / follower_talk / rough_phrase | exact / preserve_rhythm / local_compress / relocate_as_note |  | neutralize / textbook_paraphrase / delete_as_informal / replace_with_AIGC_phrase |  |
