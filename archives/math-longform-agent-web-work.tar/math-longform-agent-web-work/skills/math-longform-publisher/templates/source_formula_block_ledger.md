# Source Formula Block Ledger

| formula_block_id | source_span | line_span | fragment_count | raw_fragment_hash | canonical_formula | canonicalization_status | atom_ids | review_status | verification_note |
|---|---|---|---:|---|---|---|---|---|---|
| FB0001 | none | none | 0 | none | none | NO_FRAGMENTED_FORMULA_BLOCKS | none | REVIEWED | No fragmented formula blocks detected in the current source. |

<!-- If a raw formula contains pipes or many line breaks, place it below in a fenced block labeled FORMULA_BLOCK FBxxxx instead of inside the table. -->
