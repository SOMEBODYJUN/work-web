# Clean Final Gate

| check | result | evidence |
|---|---|---|
| no hard banned text in final |  |  |
| source-allowed phrases have source support |  |  |
| no patch section |  |  |
| reports may contain process language but final cannot |  |  |
