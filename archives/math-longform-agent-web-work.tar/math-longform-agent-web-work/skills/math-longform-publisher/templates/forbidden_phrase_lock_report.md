# Forbidden Phrase Lock Report

| check_id | target_files | forbidden_phrases | status | evidence |
|---|---|---|---|---|
| FPL0001 | publication surface files | exact hard-banned phrase list | PASS | no banned phrase in article surface |
