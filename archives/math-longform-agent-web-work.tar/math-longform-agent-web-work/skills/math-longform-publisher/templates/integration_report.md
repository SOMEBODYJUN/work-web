# Integration Report

| item_id | source_atoms_or_chain_id | content_name | expected_section | expected_anchor | actual_section | actual_anchor | status |
|---|---|---|---|---|---|---|---|
| I001 |  |  |  |  |  |  | ok / misplaced / patch_section |
