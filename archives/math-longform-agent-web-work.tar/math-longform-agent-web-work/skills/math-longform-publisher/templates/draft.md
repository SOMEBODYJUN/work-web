# draft.md

This file is the first complete best-effort article. It must be publishable in intent, but provisional in workflow.

Do not leave outlines, TODOs, placeholders, source IDs, ledger rows, or workflow commentary here.
