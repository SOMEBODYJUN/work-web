# Explanation Chain Ledger

| chain_id | source_atoms | topic | required_order | required_symbols | forbidden_collapse | final_destination |
|---|---|---|---|---|---|---|
| CH001 |  |  | 1. ...<br>2. ... |  |  |  |
