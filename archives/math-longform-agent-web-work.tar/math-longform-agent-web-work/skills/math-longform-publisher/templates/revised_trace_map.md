# Revised Trace Map

Post-hoc map for `revised_final.md`. Regenerate after revision.

| para_id | file | revised_location | paragraph_or_block_excerpt | source_atoms | statement_ids | proof_ids | voice_ids | symbol_ids | chain_ids | revision_task_ids | changed_from_standardized | verification_note |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| RP0001 | revised_final.md |  |  | A0001 | S001 | PR001 | V001 | SYM001 | CH001 | R001 | no / yes |  |
