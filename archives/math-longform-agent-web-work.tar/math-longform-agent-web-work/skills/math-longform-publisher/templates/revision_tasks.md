# Revision Tasks

| task_id | finding_ids | source_atoms | statement_ids | proof_ids | chain_ids | symbol_ids | target_file | target_location | problem_type | severity | problem_sentence | allowed_action | forbidden_action | max_change_scope | verification_method | status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| R001 | ATK001 | A0001 | S001 | PR001 | CH001 | SYM001 | standardized_final.md |  |  | minor / publish_risk / blocker / rebuild |  |  |  | one sentence / one paragraph / one proof block / one formula block |  | pending / done |
