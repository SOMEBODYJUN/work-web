# Section Execution Plan

```json
{
  "schema_version": "content-authority-section-plan-v3",
  "plan_id": "SEP0001",
  "section_id": "SEC001",
  "source_revision_id": "R0001",
  "source_atom_ids": "A0001",
  "atom_contract_sha256": "RECOMPUTE_FROM_CURRENT_ATOMS",
  "required_invariants_json": "{\"A0001\":\"RECOMPUTE_INVARIANT_HASH\"}",
  "transformation_contract_json": "{\"A0001\":[\"BLOCKED_REVIEW\"]}",
  "forbidden_changes_json": "{\"A0001\":\"COPY_FROM_CURRENT_NONEXACT_ATOM_FORBIDDEN_CHANGE\"}",
  "function_realization_plan_json": "[{\"realization_id\":\"RZ00001\",\"atom_id\":\"A0001\",\"function\":\"SUBSTANTIVE_CONTENT\",\"source_evidence\":\"COPY_COMPLETE_EXACT_ATOM_SLICE\",\"writing_instruction\":\"State this Atom's independent source responsibility explicitly in the section.\",\"realization_group_id\":\"RG00001\",\"merge_justification\":\"\",\"source_obligation_ids\":[]}]",
  "status": "READY_FOR_DRAFT"
}
```
