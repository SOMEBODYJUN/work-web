# Author Question Obligation Ledger

| question_id | source_span | source_excerpt | obligation_type | required_action | destination_file | destination_anchor | resolution_status | response_trace | verification_note |
|---|---|---|---|---|---|---|---|---|---|
| AQ0001 | none | none | NO_AUTHOR_QUESTIONS | none | none | none | NO_AUTHOR_QUESTIONS | none | No author-facing question or request detected in the current source. |
