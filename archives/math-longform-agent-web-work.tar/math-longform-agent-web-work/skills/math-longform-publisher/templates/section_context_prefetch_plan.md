# Section Context Prefetch Plan

| prefetch_id | section_id | article_target | consumer_chunks | must_open_chunks | must_open_dependency_ids | must_open_files | covered_dependency_ids | status | verification_note |
|---|---|---|---|---|---|---|---|---|---|
| PF001 | SEC00 | publication_final.md | C002 | C001,C002 | D001 | cross_chunk_dependency_map.md; source_atom_manifest.md; chunk_ledger/chunk_C001_atom_ledger.md; chunk_ledger/chunk_C002_atom_ledger.md; source_atom_ledger.md; voice_expression_ledger.md; symbol_ledger.md; math_statement_ledger.md; proof_obligations.md | D001 | READY / PASS / VERIFIED / NO_EXTERNAL_DEPENDENCY | read this pack before writing SEC00 |
