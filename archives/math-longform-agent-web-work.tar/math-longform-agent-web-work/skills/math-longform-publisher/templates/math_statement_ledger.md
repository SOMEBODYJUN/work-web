# Math Statement Ledger

| statement_id | type | source_atoms | object | assumptions | conclusion | symbols_used | local_or_global_scope | proof_source_atoms | proof_obligation_ids | destination_section | status |
|---|---|---|---|---|---|---|---|---|---|---|---|
| S001 | definition / proposition / lemma / theorem / example / calculation_claim | A0001 |  | none / local hypotheses |  | SYM001 | local / global / along_curve / coordinate_patch | A0002 | PR001 |  | complete / preview_only / blocked |
