# Ledger Integrity Check

| check_id | file | question | evidence | verdict | required_fix |
|---|---|---|---|---|---|
| LIC001 | source_sentence_index.md | Does every source sentence-like unit have a `T` id? |  | PASS / FIX_REQUIRED |  |
| LIC002 | source_atom_ledger.md | Does every non-duplicate statement, proof step, formula object, warning, example, author question, method, insight, and voice turn have an `A` id? |  | PASS / FIX_REQUIRED |  |
| LIC003 | source_atom_ledger.md | Does every atom have `sentence_id`, `chunk_id`, `char_span`, literal `source_excerpt`, and `punctuation_boundary`? |  | PASS / FIX_REQUIRED |  |
| LIC004 | source_atom_ledger.md | Are there paragraph/topic summary atoms or one-symbol atoms created only by OCR line breaks? |  | PASS / FIX_REQUIRED |  |
| LIC005 | chunk_ledger/ | Are all chunks represented and using the same global A ids? |  | PASS / FIX_REQUIRED |  |
| LIC006 | voice_expression_ledger.md | Are voice-bearing asides locked instead of deleted? |  | PASS / FIX_REQUIRED |  |
| LIC007 | explanation_chain_ledger.md | Are explanation chains, author methods, and proof routes preserved instead of collapsed into a generic summary? |  | PASS / FIX_REQUIRED |  |
| LIC008 | source_formula_block_ledger.md | Are OCR or oral formula fragments canonicalized before atomization? |  | PASS / FIX_REQUIRED |  |
| LIC009 | author_question_obligation_ledger.md | Are author questions, doubts, and requests tracked instead of polished away? |  | PASS / FIX_REQUIRED |  |
| LIC010 | source_atom_ledger.md | Are source atoms treated as next-round understanding input rather than post-hoc trace only? |  | PASS / FIX_REQUIRED |  |
| LIC011 | omission_ledger.md | Are OCR artifacts, exact duplicates, placeholders, and future previews explicitly classified? |  | PASS / FIX_REQUIRED |  |
| LIC012 | scripts/validate_source_atom_granularity.py | Did the semantic atom granularity validator pass? |  | PASS / FIX_REQUIRED |  |
