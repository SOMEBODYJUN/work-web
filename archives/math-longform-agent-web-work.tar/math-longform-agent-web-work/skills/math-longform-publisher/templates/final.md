# Final

Content-final rewrite after `independent_review.md`.
