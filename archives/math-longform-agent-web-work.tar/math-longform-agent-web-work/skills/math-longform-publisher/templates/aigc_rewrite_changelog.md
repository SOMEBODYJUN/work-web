# AIGC Rewrite Changelog

| change_id | task_id | sentence_ids | before | after | action | changed_math_object | changed_assumption | changed_conclusion | changed_proof_dependency | changed_author_voice | verification |
|---|---|---|---|---|---|---|---|---|---|---|---|
| ARC001 | AR001 | AS001 |  |  | delete / compress / replace / keep | no/yes | no/yes | no/yes | no/yes | no/yes |  |
