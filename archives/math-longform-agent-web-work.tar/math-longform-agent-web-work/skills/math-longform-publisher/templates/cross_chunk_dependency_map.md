# Cross-Chunk Dependency Map

| dep_id | consumer_chunk | consumer_ids | dependency_type | provider_chunk | provider_ids | required_for_sections | prefetch_files | status | verification_note |
|---|---|---|---|---|---|---|---|---|---|
| D001 | C002 | T0000/A0000/S000 | DEFINITION / SYMBOL / VOICE / PROOF_PREREQ / ASSUMPTION / EXAMPLE / WARNING / NOTATION / EXPLANATION_CHAIN / STRUCTURE / FUTURE_PREVIEW / NO_EXTERNAL_DEPENDENCY | C001 / none | A0000,S000,PR000,V000,SYM000,CH000 / none | SEC00 | source_atom_manifest.md; chunk_ledger/chunk_C001_atom_ledger.md; chunk_ledger/chunk_C002_atom_ledger.md; relevant lock ledgers | VERIFIED / NO_EXTERNAL_DEPENDENCY / BLOCKED | exact reason this dependency is needed before writing |
