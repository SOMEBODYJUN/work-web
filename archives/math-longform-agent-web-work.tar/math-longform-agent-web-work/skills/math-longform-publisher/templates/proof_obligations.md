# Proof Obligations

| proof_id | statement_ids | source_atoms | claim_or_formula | obligation_type | source_state | required_completion | allowed_methods_or_source_support | forbidden_expansion | final_destination | completion_status |
|---|---|---|---|---|---|---|---|---|---|---|
| PR001 | S001 | A0001 |  | PRESERVE / COMPLETE_SUPPORTED / DO_NOT_EXPAND / NO_PROOF_NEEDED | complete / sketch / gap / preview / definition |  |  |  |  | satisfied / preview_preserved / not_needed / blocked |
