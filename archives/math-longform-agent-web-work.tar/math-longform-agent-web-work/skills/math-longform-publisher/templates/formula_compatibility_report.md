# Formula Compatibility Report

## Target

- publication file:
- target platform: mdnice / 微信公众号 / 知乎
- formula rules source: `references/mdnice_formula_rules.md`

## Checks

- [ ] 行内公式使用 `$...$`
- [ ] 块级公式使用 `$$...$$`
- [ ] 未使用 `\( ... \)` 或 `\[ ... \]`
- [ ] 公式中的 `<` 后面有空格，例如 `$a < b$`
- [ ] 多行公式使用 `aligned`
- [ ] Markdown 原生表格中没有 MathJax 公式
- [ ] 没有依赖 MathJax 不支持的 LaTeX 宏包
- [ ] 中文说明没有塞进公式环境；能放正文就放正文

## Fixes Made

| location | issue | fix | content_changed? |
|---|---|---|---|

## Validator Result

```text
paste validator output here
```

## Decision

PASS / FIXED_AND_PASS / REVISE_REQUIRED
