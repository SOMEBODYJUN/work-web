# Active State

RUN_ID: RUN0000
RUN_MODE: full_publication
CURRENT_STAGE: stage_0_source_setup
RESUME_POINT: before atomization
FEEDBACK_LEDGER_SHA256: d647970467608f24a6b95ebc5c43661e553de6eb5103ec8ad5b589ff3c462841
ACTIVE_FEEDBACK_IDS: none

## Resume Instruction

No carry-forward user feedback is active. Start from canonical source lock and current-source ledgers.

## Hard Constraints

- Load user_feedback_ledger.jsonl before writing.
- Load context_pack_manifest.json before writing.
- Use current source and current-source ledgers only.
