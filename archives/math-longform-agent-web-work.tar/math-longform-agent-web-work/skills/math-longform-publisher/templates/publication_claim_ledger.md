# Publication Claim Ledger

Reverse coverage map for `publication_final.md`: every nontrivial publication claim must have source ownership and support.

| claim_id | file | location | claim_excerpt | claim_type | source_atoms | statement_ids | proof_ids | support_type | source_ownership | transformation_scope | verdict | allowed_new_reason | verification_note |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| PCL0001 | publication_final.md |  |  | definition / theorem / proof_step / example / warning / transition / heading / formula / method / insight | A0001 | S001 | PR001 | DIRECT_SOURCE / DERIVED_MATH / SUPPORTED_COMPLETION / VOICE_PRESERVATION / AUTHOR_METHOD_PRESERVATION / INSIGHT_PRESERVATION / PROOF_ROUTE_PRESERVATION / FORMULA_CANONICALIZATION / EXACT_SURFACE_PRESERVATION / EXPLANATORY_BRIDGE / HEADING_LABEL / PLATFORM_FORMATTING | SOURCE_EXACT / SOURCE_LOCAL_REPHRASE / SOURCE_DERIVED / AUTHOR_VOICE / AUTHOR_METHOD / AUTHOR_INSIGHT / SOURCE_FORMULA_OBJECT / FORMAT_ONLY | none / local_rephrase / supported_completion / format_only | SUPPORTED / DERIVED_SUPPORTED / VOICE_SUPPORTED / METHOD_SUPPORTED / INSIGHT_SUPPORTED / ROUTE_SUPPORTED / FORMULA_SUPPORTED / EXACT_SURFACE_SUPPORTED / FORMAT_ONLY / BLOCKED_UNSUPPORTED / BLOCKED_SOURCE_MISMATCH / BLOCKED_SCOPE_EXPANSION | none |  |
