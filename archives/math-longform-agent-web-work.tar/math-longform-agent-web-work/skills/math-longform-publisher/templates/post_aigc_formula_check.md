# Post-AIGC Formula Check

| check | result | evidence |
|---|---|---|
| mdnice inline formulas use `$...$` |  |  |
| display formulas use `$$...$$` |  |  |
| no Chinese prose inside math environments |  |  |
| no Markdown table contains MathJax formulas |  |  |
| no unsupported LaTeX package/environment syntax |  |  |

## Validator Output

```text
paste `python scripts/validate_mdnice_math.py publication_final.md` output here
```

## Decision

PASS / FIX_REQUIRED
