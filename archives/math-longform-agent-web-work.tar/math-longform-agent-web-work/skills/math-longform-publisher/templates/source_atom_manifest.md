# Source Atom Manifest

| chunk_id | char_span | sentence_range | atom_range | atom_count | semantic_unit_hint | chunk_ledger_file | validation_status | checksum_or_lock | notes |
|---|---|---|---|---:|---:|---|---|---|---|
| C001 | 0-0 | T0001-T0001 | A0001-A0001 | 1 | 1 | chunk_ledger/chunk_C001_atom_ledger.md | PASS | fill_after_validation | example row |
