# Publication Sentence Trace

```json
{
  "schema_version": "content-authority-output-trace-v2",
  "output_unit_id": "OU0001",
  "file": "publication_final.md",
  "output_byte_start": "0",
  "output_byte_end": "0",
  "output_text_sha256": "REPLACE_WITH_SHA256",
  "output_text": "",
  "unit_type": "sentence",
  "source_atom_ids": "A0001",
  "transformation_kind": "CONTENT_PRESERVING_REWRITE",
  "preserved_invariants": "A0001",
  "new_content_basis": "NONE",
  "verdict": "SUPPORTED",
  "verification_note": "exact span/hash must be regenerated from publication_final.md",
  "sentence_trace_id": "PS0001",
  "location": "body",
  "sentence_or_heading": "",
  "source_atoms": "A0001",
  "statement_ids": "",
  "proof_ids": "",
  "voice_ids": "",
  "symbol_ids": "",
  "chain_ids": "",
  "source_type": "A_SOURCE",
  "allowed_new_reason": "none"
}
```
