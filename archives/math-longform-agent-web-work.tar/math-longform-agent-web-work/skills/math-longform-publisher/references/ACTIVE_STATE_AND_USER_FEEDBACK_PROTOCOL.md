# Active State And User Feedback Protocol

This file is the authoritative runtime contract for active state and actual user corrections. Older feedback-state protocols are maintenance history and must not be loaded during a current run.

## Core invariant

User corrections are runtime constraints. If the user says a previous output changed wording, lost voice, omitted a source unit, used a banned process phrase, or ignored an earlier correction, the next run must capture that correction in `user_feedback_ledger.jsonl` and bind it in `active_state.json` before writing again.

Applied feedback is not complete until the feedback id is visible in a concrete trace/evidence file named by `evidence_trace`.

`user_feedback_ledger.*` is not the place for permanent quality architecture. Stable rules such as "source atoms are next-round understanding input", "do not sanitize source voice", "preserve author method", or "canonicalize OCR formulas" belong in `SKILL.md`, protocol references, source/atom/voice/method/proof/formula ledgers, and validators. Use the feedback ledger only for actual user corrections or run-specific carry-forward constraints.

`active_state.*` is likewise not a second source-obligation ledger. The current
`source_formula_block_ledger.jsonl`, `author_question_obligation_ledger.jsonl`,
and `source_math_risk_ledger.jsonl` are the sole identity authority for
`FB`/`AQ`/`MR` obligations. Never copy their IDs, ranges, or a prose inventory
into `hard_constraints`, `resume_point`, or `resume_instruction`. P04 and the
Runtime enumerate the live ledgers directly, so adding or removing an obligation
cannot leave a stale handwritten carry-forward list.

## Required files

```text
active_state.json
active_state.md
user_feedback_ledger.jsonl
user_feedback_ledger.md
```

## user_feedback_ledger.jsonl schema

Each row must be flat JSON with:

```text
feedback_id
source_turn
feedback_excerpt
feedback_type
target_scope
correction_rule
required_action
carry_forward
status
active_state_binding
evidence_trace
verification_note
```

Use one sentinel row when there is no prior feedback:

```text
feedback_id: UF0000
status: NO_USER_FEEDBACK
carry_forward: false
```

Release-blocking statuses are:

```text
OPEN
ACTIVE
BLOCKED
```

A `full_publication` or `wechat_publication` package may not publish while release-blocking feedback remains active.

## active_state.json schema

`active_state.json` must include:

```text
schema_version
run_id
run_mode
source_identity_sha256
current_stage
resume_point
feedback_ledger_sha256
active_feedback_ids
hard_constraints
resume_instruction
```

`feedback_ledger_sha256` must equal the SHA-256 of `user_feedback_ledger.jsonl`.

## Required validator

Run:

```bash
python scripts/validate_active_state_feedback.py <output_dir>
python scripts/validate_feedback_ingestion.py <output_dir>
```

This validator is part of `run_publication_validators.py` and `validate_publication_package.py`.
