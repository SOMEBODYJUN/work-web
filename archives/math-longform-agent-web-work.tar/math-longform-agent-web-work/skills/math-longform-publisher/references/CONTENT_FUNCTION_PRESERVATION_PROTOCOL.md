# Content Function Preservation Protocol

Use this protocol when one source atom can do more than state a knowledge point.
Its purpose is to prevent topic coverage from being mistaken for full atom
consumption.

## One atom, multiple functions

`content_type` remains a primary routing label. It is not a complete semantic
description. P02 assigns only the universal `SUBSTANTIVE_CONTENT` intake floor;
it does not guess prose functions from keywords. P04 must reread the exact atom,
its local context, and its role in the whole source, then write the complete
`required_functions` contract in `publication_blueprint.json` under
`atom_function_contracts`. The contract's `source_evidence` equals the complete
exact Atom slice; a cue or representative clause is not all-Atom review.

Allowed functions are:

```text
SUBSTANTIVE_CONTENT
QUESTION_OR_DOUBT
EXPLANATION_CHAIN
METHOD_OBSERVATION
AUTHOR_PERSPECTIVE
INTUITION_OR_ANALOGY
PROOF_DEPENDENCY
FOLLOWUP_REQUEST
WARNING_OR_CONTRAST
```

These names are semantic review dimensions, not lexical triggers. Do not add or
omit a function because a particular word appears or is absent. Judge what the
exact atom is doing in the source. Record that source-specific responsibility in
`source_evidence` and `reason`; the label alone is never the contract. In
particular, a formal answer does not by itself preserve the author's question,
and a standard proof does not preserve an author-selected construction method.

## Blueprint contracts

`atom_function_contracts` has exactly one row per source atom:

```json
{
  "atom_id": "A0009",
  "required_functions": ["SUBSTANTIVE_CONTENT", "QUESTION_OR_DOUBT", "METHOD_OBSERVATION"],
  "source_evidence": "complete exact text of this atom",
  "reason": "why these are independent source responsibilities",
  "content_type": "AUTHOR_METHOD",
  "local_context_role": "what this span does in its immediate argument",
  "global_context_role": "what would disappear from the whole article if this span were flattened",
  "content_invariant": {
    "summary": "source-grounded responsibility that must survive"
  },
  "surface_contract": {
    "decision": "BYTE_EXACT",
    "output_operation": "COPY_SOURCE_SLICE",
    "prelock_disposition": "CONFIRMED_PRELOCK",
    "basis": ["DISTINCTIVE_AUTHOR_VOICE"],
    "source_cues": ["exact substring whose form carries content"],
    "rationale": "changing these bytes changes the span's authorial or explanatory function",
    "confidence": "HIGH",
    "allowed_completion": "",
    "forbidden_change": ""
  }
}
```

In this Agent, every P04 row must also contain a `function_matrix` with
one entry for **each** of the nine functions above.  Each entry has
`status: REQUIRED` or `status: NOT_REQUIRED`, an exact `source_evidence`
substring, and a source-grounded `semantic_reason`.  `required_functions` is
the set of matrix entries marked `REQUIRED`; it is not an independent shortcut.
The `NOT_REQUIRED` decisions are part of the review evidence as well.  A
review that lists only the retained functions is incomplete because it cannot
show that the omitted dimensions were considered.  The native P04 reviewer
must therefore submit one decision evidence item for every Atom/function pair,
including the explicit `function_decision` field for both statuses.

The reviewed contract replaces P02's incomplete function floor with the P04
semantic judgment. P04 may not reuse the primary `content_type` or the presence
of familiar words as its reasoning. It also resolves P02's conservative surface
prelock for every atom. Valid `prelock_disposition` values are:

```text
CONFIRMED_PRELOCK
DOWNGRADED_FALSE_POSITIVE
ADDED_BY_P04
NO_PRELOCK
```

`DOWNGRADED_FALSE_POSITIVE` requires a concrete explanation that changing the
surface leaves every content and expression function unchanged. Uncertainty is
not a false positive and must retain the prelock.

## P03 source-obligation binding

`atom_function_contracts` says what each Atom does. It does not by itself retain
the identity of a P03 author-question, formula, or mathematical-risk obligation.
P04 therefore also writes `source_obligation_contracts` with exactly one row per
actionable `AQ`, canonicalized `FB`, and resolved `MR` row. Each row contains:

```text
obligation_id
obligation_kind
source_ledger
obligation_identity_sha256
source_evidence
source_atom_ids
required_functions
function_bindings
fulfillment_mode
implementation_requirement
reason
```

`source_evidence` is the complete exact P03 source span. `source_atom_ids` equals
all current Atoms overlapping that span. Every overlapping Atom receives at least
one appropriate function binding. An understanding question cannot bind only to
`SUBSTANTIVE_CONTENT`; a request for a better method cannot be satisfied by a
standard conclusion; a formula/risk obligation must retain its mathematical
conditions through `SUBSTANTIVE_CONTENT` and the applicable proof/explanation
functions.

## Rewrite-boundary review

After each text-producing phase, append atom-specific rows to
`function_preservation_reviews` in the same blueprint. Use these stage IDs:

```text
P06_DRAFT          -> draft.md
P07_FINAL          -> final.md
P08_OPTIMIZED      -> optimized_final.md
P08_STANDARDIZED   -> standardized_final.md
P10_REVISED        -> revised_final.md
P11_AIGC           -> aigc_rewritten_final.md
P13_PUBLICATION    -> publication_final.md
```

A row is bound to the current target hash and contains one result per required
function:

```json
{
  "stage_id": "P08_OPTIMIZED",
  "target_file": "optimized_final.md",
  "target_sha256": "...",
  "atom_id": "A0009",
  "function_results": {
      "QUESTION_OR_DOUBT": {
      "realization_id": "RZ00009",
      "status": "REASONABLE_TRANSFORM",
      "source_evidence": "complete exact text of A0009",
      "target_evidence": "exact substring in optimized_final.md",
      "reason": "the formal wording still makes the author's open question explicit"
    }
  },
  "verdict": "PASS"
}
```

Every function result also carries the exact P05 `source_obligation_ids` list.
For each ID it adds a `source_obligation_results` entry with the P04 identity hash,
fulfillment mode, complete obligation source evidence, current target evidence,
passing status, and a specific semantic reason. An empty object is required when
the function has no source obligation. This makes the first loss of a question,
method request, formula condition, or risk independently visible even when the
Atom's mathematical topic remains present.

`target_evidence` may be a list when one function is realized across several
output units. `PRESERVED` and `REASONABLE_TRANSFORM` are the only passing
statuses. If any function becomes `PARTIAL` or `LOST`, repair that current file
before advancing. Do not wait for publication.

Every text-producing phase reviews every Atom and every required function. The
result's `realization_id` must match the P05 obligation for that Atom/function.
Source evidence is the complete exact Atom slice, not a convenient word or clause.
Target evidence must equal one complete, uniquely occurring non-heading output unit
(a sentence, formula block, or comparable unit), not a fragment selected from a
generic sentence. Several functions of the same Atom may cite one unit only when
they belong to the same explicitly justified P05 realization group. Different Atoms
must cite separately identifiable units even when they are written in one paragraph.
P11 also covers every non-heading output unit;
those exact evidence fragments become P12's atom-to-output mapping. P13 rechecks
every Atom against the compiled publication.

## Consumption rule

A destination is only a location candidate. It never proves consumption.

P12 may only write a pending consumption candidate when:

1. P11 has a passing result for every required function of that atom;
2. the cited target evidence lands in concrete output units;
3. P12 copies `aigc_rewritten_final.md` byte-for-byte into
   `publication_final.md`;
4. the trace records the required function set and its P11 review basis.

Only P13 may authorize the deterministic finalizer to write `CONSUMED`, after
reopening every exact atom and every current publication function result.

P13 can still block publication when the semantic judgment is wrong. Category
PASS rows and a single representative author-voice example cannot replace the
atom-level review.

Formalizing oral language is allowed. The test is functional equivalence, not
word-for-word identity.
