# Mathematical Risk Review Protocol

## Purpose

Mathematical correctness cannot be decided by a keyword list. A formula may be
perfectly typeset and still use a theorem outside its hypotheses; prose with no
special token may hide a reversed implication or a missing case. Separate
deterministic source intake from semantic mathematical review.

## P02 universal blocker

P02 writes exactly one `SOURCE_WIDE_MATH_SEMANTIC_SCAN` row bound to the current
`source_revision_id`, the SHA-256 of `source_canonical.txt`, and its complete UTF-8
byte span. Its status is `BLOCKED_NEEDS_MATHEMATICAL_REVIEW`.

P02 never writes `NO_MATHEMATICAL_RISKS` and never creates a concrete risk from a
formula, word, topic, regular expression, or historical manuscript pattern.

## P03 semantic review

Read all of `source_canonical.txt` in context and check, as applicable:

- definitions, domains, hypotheses, and quantifiers;
- theorem applicability and proof dependencies;
- signs, orientations, indices, boundary cases, and exceptional cases;
- formula reconstruction and the mathematical conditions behind the formula;
- logical direction, unsupported generalization, and circular reasoning;
- consistency between examples, claims, calculations, and later conclusions.

These are review dimensions, not a finite checklist and not keyword triggers.

After review:

1. mark the one scan row `MATH_SEMANTIC_SCAN_COMPLETE` and record a concrete
   source-wide review note;
2. if no material risk remains, add exactly one `NO_MATHEMATICAL_RISKS` row bound
   to the same complete source identity;
3. otherwise add one narrowly source-bound row per independent material risk;
4. keep an unresolved risk `BLOCKED_NEEDS_MATHEMATICAL_REVIEW`;
5. use `RESOLVED_WITH_JUSTIFICATION` only when the mathematical conditions and
   downstream article duty are explicit and source-supported.

Do not use an article-fulfillment status in P03. A corrected canonical source
requires the authorized source-patch path and a fresh P02/P03 review; do not keep
an obsolete corrected row attached to old bytes.

## Downstream identity

Every concrete `RESOLVED_WITH_JUSTIFICATION` MR is an article obligation. P04
binds its exact identity, source span, required review, and applicable
Atom/functions. P05 carries the MR ID into each realization. P06-P11 and P13
separately judge that MR against the current article boundary.

A canonicalized formula block, matching topic, correctly rendered expression,
or ordinary Atom/function PASS cannot discharge the MR. If the formula surface is
fixed but a hypothesis, domain, proof dependency, or exceptional case remains
unsatisfied, the MR remains unresolved and the phase is blocked.

## Validator boundary

`validate_source_math_risks.py` verifies current source identity, exact spans,
the scan lifecycle, and structural consistency. It does not decide whether the
mathematics is correct. That judgment belongs to the P03 worker and fresh native
reviewer, and is rechecked against `publication_final.md` at P13.
