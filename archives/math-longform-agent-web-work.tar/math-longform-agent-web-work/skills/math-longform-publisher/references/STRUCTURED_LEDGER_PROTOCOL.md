# Structured Ledger Protocol

## Authority Rule

For every dual-track ledger:

```text
*.jsonl = machine authority
*.md    = human-readable mirror
```

In any mode that requires JSONL, an existing malformed or empty JSONL file is a hard failure. Never fall back to Markdown after a JSONL parse error.

## Strict JSONL Contract

Each nonblank line must be one strict UTF-8 JSON object. Reject:

- duplicate JSON keys;
- NaN, Infinity, or other non-standard constants;
- nested objects/arrays where a scalar field is required;
- malformed or guessed Markdown rows;
- missing/empty required fields;
- duplicate or invalid primary ids;
- duplicate ownership across chunk ledgers.

Machine ids must come from the schema-defined id field, not from substring searches across arbitrary values.

## Mirror Contract

Markdown mirrors must preserve the authoritative row count, order, ids, and required field values. Duplicate ids, reordering, omitted rows, or extra rows are failures. Regenerate a mirror from JSONL rather than “fixing” JSONL to match a table.

Before writing, reopen JSONL first. Markdown is for review only.
