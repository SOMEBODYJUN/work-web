# Output Fragment Authorization Protocol

## Purpose

Every byte of `publication_final.md` must have a current-run authorization. A sentence-level source ID is not enough: a source-supported mathematical sentence may still contain an unsupported editorial preface, invented metaphor, or model-authored stance.

The final article therefore requires `publication_fragment_authorization.jsonl`. Its rows partition the UTF-8 bytes of `publication_final.md` exactly, without gaps or overlaps.

## Allowed authorization types

- `SOURCE_EXACT`: exact current-source bytes. Requires `source_slice` and current atom IDs.
- `SOURCE_REORGANIZATION`: source meanings reorganized without a new claim or stance. Requires current atom IDs and preserved invariants.
- `MATHEMATICAL_COMPLETION`: a logically necessary completion of the source proof route. Requires `completion_basis=SOURCE_ROUTE_COMPLETION`, current atom IDs, preserved invariants, and a concrete necessity statement.
- `FORMULA_NORMALIZATION`: OCR/format repair of the same mathematical object. Requires `completion_basis=FORMULA_NORMALIZATION`.
- `STRUCTURAL_LABEL`: a heading or local mathematical label authorized through `heading_authorization.jsonl` or a finite structural-label function.
- `MINIMAL_CONNECTIVE`: at most 12 non-space characters, used only for a grammatical or local logical link. It must declare a finite `connective_function` and a concrete deletion impact. It cannot express editorial stance.
- `USER_REQUESTED`: wording explicitly requested in current feedback. Requires feedback IDs.
- `FORMAT_SYNTAX`: whitespace and Markdown/LaTeX delimiters only.

`UNAUTHORIZED_EDITORIAL` is not a releasable type. If a fragment cannot be assigned one of the allowed types without stretching the schema, delete it or block release.

## Necessity rule

For any text not copied from the current source, ask:

> If this fragment is removed, is source content, mathematical correctness, formula readability, document structure, or grammar actually damaged?

If the answer is no, the fragment has no publication authority. Phrases that merely announce, dramatize, summarize, elevate, or imitate an informal author voice are not necessary.

A broad atom citation does not authorize every word in a paragraph. Split fragments finely enough that unsupported prefaces and conclusions cannot hide inside source-supported mathematics.

## Granularity

- `SOURCE_REORGANIZATION` rows must be below 480 UTF-8 bytes.
- `MATHEMATICAL_COMPLETION` rows must be below 720 UTF-8 bytes.
- `BYTE_EXACT` source slices may remain larger because they are deterministically copied.
- Split at headings, sentences, formula blocks, direct author voice, and changes of authorization type.

## Release

Run:

```text
python scripts/validate_output_fragment_authorization.py <output_dir>
```

Any gap, overlap, stale hash, unknown atom, unsupported authorization, broad hidden editorial text, or altered exact source slice blocks release.
