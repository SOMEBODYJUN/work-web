# Surface Decision Protocol

## Responsibility split

P02 performs a conservative lexical candidate scan and may prelock likely
surface-bearing material. That first layer is a safety net, not semantic
approval. P04 rereads every atom, including atoms with no candidate cue, and
decides whether the surface form itself is author content. The deterministic
runtime executes the P04 decision.

```text
Agent semantic decision: BYTE_EXACT
-> runtime operation: COPY_SOURCE_SLICE
-> validator: exact byte comparison
```

User designation has highest priority but is not required. The Agent must identify
distinctive wording, roughness, punctuation, repetition, rhythm, quotation, nickname,
meme language, direct address, and other surface-bearing content.

The P02 candidate scan cannot unlock text, certify a decision, or claim independent
review. P04 may confirm a prelock, add a missed lock, or downgrade a genuine false
positive. A downgrade requires a concrete semantic explanation; uncertainty keeps
the prelock.

## Decision procedure

1. Split mixed proof/formula and author-voice material.
2. Apply the deletion-and-change counterfactual: would any deletion, paraphrase,
   cleanup, punctuation repair, or reordering change mathematical content,
   explanation, attitude, force, rhythm, author identity, narrative timing, or
   discourse function?
3. If any answer is yes, set:
   ```text
   surface_mode = BYTE_EXACT
   output_operation = COPY_SOURCE_SLICE
   ```
4. Do not attach allowed or forbidden editing rules. There is no editing permission.
5. If adjacent exact atoms form one uninterrupted performance, assign one
   `CONTIGUOUS_BYTE_EXACT` group.
6. Use `CONTENT_PRESERVE` only when the Agent can explain why changing the surface
   leaves every content and expression function unchanged. "The meaning is roughly
   similar" is insufficient.
7. If uncertainty remains after splitting, retain the prelock or block review
   rather than silently downgrading.

## Decision evidence

`surface_decision_json` records why the Agent classified the source. It does not
authorize a transformation.

```json
{
  "decision": "BYTE_EXACT",
  "basis": [
    "DISTINCTIVE_AUTHOR_VOICE",
    "ABRASIVE_OR_TABOO_WORDING",
    "PUNCTUATION_OR_SPACING_IS_CONTENT"
  ],
  "source_cues": ["exact substring from this atom"],
  "rationale": "Paraphrase would change author identity and force.",
  "confidence": "HIGH",
  "review_status": "APPROVED"
}
```

All cues must occur literally in the atom's current-source slice.

## Continuous group

Group members share:

```text
surface_group_id = SG0001
surface_group_mode = CONTIGUOUS_BYTE_EXACT
output_operation = COPY_SOURCE_SLICE
```

The runtime copies from the first member start to the last member end. The final
article must contain that entire byte sequence once and continuously.

## P04 semantic review

Before P04, `surface_decision_review.jsonl` contains pending P02 candidate-scan
rows for every atom. After P04, Runtime replaces them with semantic review rows
that check missed exact material, candidate false positives, mixed-content
segmentation, group boundaries, and evidence consistency. A fresh native
read-only sub-agent authorizes the phase against every exact Atom. The reviewer
cannot create exact text; it only approves or blocks the Agent's decision.
