# Validator Evidence Lock Protocol

## Machine Authority

Generate release evidence only with:

```bash
python scripts/run_publication_validators.py <output_dir>
```

Required evidence:

```text
validator_result.json
validator_result.sha256
validator_result.txt
validator_evidence/*.stdout.txt
validator_evidence/*.stderr.txt
release_manifest.json
release_manifest.sha256
PUBLICATION_AUDIT_REPORT.md
```

`validator_result.json` records ordered invocations, exact arguments, script hashes, exit codes, warning counts, and hashes/paths for complete stdout and stderr logs. Tails are diagnostic conveniences and are not evidence authority.

Arguments for files inside the run are encoded with `<output_dir>` rather than
an absolute machine path. Evidence therefore remains verifiable after the whole
run directory is moved or unpacked elsewhere, provided no bound file changes.

`release_manifest.json` binds the non-evidence target snapshot, current validator result, audit report, publication surface, optional WeChat surface, and every complete validator log. `release_manifest.sha256` binds the manifest bytes.

## Release Rule

A release passes only when:

1. Every required validator ran in the exact mode-specific order and passed.
2. No release-mode validator emitted an unresolved line beginning `WARNING:`.
3. Full logs exist at safe local paths and match their recorded hashes.
4. The non-evidence package snapshot has not changed.
5. The audit and final reader surfaces match the release manifest.
6. `scripts/validate_validator_result_integrity.py` and `scripts/validate_publication_audit_report.py` pass after evidence generation.

Any artifact modification after evidence generation makes the lock stale. Rerun the complete release runner; never hand-edit hashes or PASS claims.
