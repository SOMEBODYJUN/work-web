# Content Authority Protocol

## Single authority chain

```text
source_original.txt
-> source_canonical.txt + source_revision.json
-> 100% CONTENT_LOCKED atoms
-> section execution plan
-> publication output units
-> deterministic reverse validation
```

Historical output, old ledgers, fixtures, model drafts, and maintenance reports cannot
create manuscript authority.

## Atom contract

Every atom binds a current source revision and exact UTF-8 byte slice:

```text
schema_version
atom_id
source_revision_id
source_byte_start
source_byte_end
source_excerpt_sha256
raw_excerpt
content_lock_state
content_type
required_functions
local_context_role
global_context_role
content_invariant_json
surface_mode
output_operation
consumption_status
duplicate_of
surface_decision_json
surface_group_id
surface_group_mode
```

Every non-duplicate source atom is `CONTENT_LOCKED`.

P04 reviews each Atom in local and whole-source context. Its semantic contract
must carry the complete exact Atom slice as `source_evidence`; selecting a short
phrase cannot prove that every independent responsibility was considered.

## Conditional transformation contract

### CONTENT_PRESERVE

A non-exact atom must also contain specific:

```text
allowed_completion
forbidden_change
```

Its `output_operation` must be one of the finite semantic operations, such as:

```text
REORGANIZE_CONTENT
EXPLAIN_CONTENT
FORMALIZE_SOURCE_PROOF
NORMALIZE_SOURCE_FORMULA
DEFINE_SOURCE_TERM
RETAIN_SOURCE_ASIDE
RETAIN_SOURCE_CONTEXT
OMIT_CONFIRMED_DUPLICATE
BLOCK_UNRESOLVED
BLOCKED_REVIEW
```

### BYTE_EXACT

A byte-exact atom has exactly one output operation:

```text
output_operation = COPY_SOURCE_SLICE
```

It must not contain `content_output_mode`, `allowed_completion`, or
`forbidden_change`. Once the Agent has semantically decided `BYTE_EXACT`, it has no
editing permission. The program slices bytes from `source_canonical.txt`; no
handwritten exact text is accepted.

Materialize an exact atom or group with:

```bash
python scripts/materialize_exact_source_slice.py <output_dir> \
  --atom-id A0004 --output-file exact_blocks/A0004.txt

python scripts/materialize_exact_source_slice.py <output_dir> \
  --group-id SG0001 --output-file exact_blocks/SG0001.txt
```

## Section plan

`section_execution_plan.jsonl` hashes the current atom contracts. For a
`BYTE_EXACT` atom, its transformation list must be exactly:

```json
["COPY_SOURCE_SLICE"]
```

`forbidden_changes_json` contains only non-exact atoms. Exact atoms do not use an
editable forbidden-change contract.

P05 must also compile every `(atom_id, required_function)` pair into exactly one
row inside `function_realization_plan_json`. Each row contains a unique
`realization_id`, the complete exact Atom slice as `source_evidence`, a concrete
`writing_instruction`, and a `realization_group_id`. A realization group may join
several functions of the same Atom when one output unit genuinely performs all of
them. It cannot join different Atoms. Different Atoms may remain in one paragraph,
but each needs a separately identifiable output unit. Every multi-function group
uses one shared, source-grounded `merge_justification`; a common topic or
destination is not sufficient.

`content_type` is one primary routing label. `required_functions` is the
multi-value semantic responsibility. A destination or a matching topic never
satisfies the latter. See `CONTENT_FUNCTION_PRESERVATION_PROTOCOL.md`.

## Output trace

`publication_sentence_trace.jsonl` is regenerated from
`publication_final.md`. A mapped exact output unit uses:

```text
transformation_kind = COPY_SOURCE_SLICE
new_content_basis = NONE
```

The validator derives the required bytes from the current source span and compares
them to the final output. Continuous exact groups are validated as one source slice,
including all whitespace and punctuation between member atoms.

## Release blockers

Release fails for:

- source revision or hash mismatch;
- `IDENTITY` original/canonical mismatch;
- generic or incomplete atom semantics;
- a byte-exact atom with any operation other than `COPY_SOURCE_SLICE`;
- editable completion/forbidden fields on a byte-exact atom;
- handwritten lock text;
- stale surface review or section plan;
- an Atom function without a P05 realization obligation;
- partial source snippets presented as a complete P05 responsibility;
- fragmentary target quotes presented as whole realizations;
- reuse of one output unit by different Atoms;
- unplanned reuse of one output unit for several functions;
- missing atom destination;
- missing atom-function evidence or topic-only consumption;
- changed output span/hash;
- broken continuous exact group;
- missing proof/formula invariants;
- stale validator evidence.
