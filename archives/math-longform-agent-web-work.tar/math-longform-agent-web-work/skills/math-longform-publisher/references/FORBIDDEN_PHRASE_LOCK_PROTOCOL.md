# Forbidden Phrase Lock Protocol

This protocol hard-locks recurring assistant/editor meta-phrases that previously damaged the user's desired voice. These phrases are not merely "less preferred"; they are banned from article surface files unless the current source literally contains the phrase and the usage is source-quoted or source-exact.

## Hard-banned phrases

```text
现场口气
收束
收住
不影响后面证明
开头就当
这段情绪
处理成
保留为
处理者口吻
```

## Scope

The ban applies to article surface files:

```text
draft.md
final.md
optimized_final.md
standardized_final.md
revised_final.md
aigc_rewritten_final.md
publication_final.md
wechat_publication_final.md
```

The ban does not apply to protocol files, validators, maintenance reports, or user feedback ledgers that are documenting the ban itself.

## Repair rule

If a banned phrase appears in an article surface, do not simply substitute a synonym. Rebuild the sentence from the current source atom and the active user feedback ledger. The problem is usually an assistant/editor stance leaking into the article.

## Pattern-family lock

The ban also applies to near variants that preserve the same editor/process meaning, especially around `现场口气`, `收束` / `收住`, `开头当作现场情绪`, `不影响后面证明`, and `处理者口吻`.
