# Single-Thread Runtime Protocol

Use this protocol only when the skill is bundled by the `math-longform-agent`
plugin. It adds execution control without changing the business authority of
this skill.

## Authority split

- The bundled Skill, canonical source, ledgers, plans, and validators remain
  the business authority.
- `references/SUPERVISOR_KERNEL.md` is the stable semantic supervision
  authority. It must be loaded and hash-bound for every semantic context; it
  carries the project model across physical Codex sessions without treating
  an empty reviewer or an old transcript as authority.
- The external runtime owns one logical thread, its current phase, context-pack
  hashes, action authorization, phase commits, and recovery checkpoints.
- The currently open Work task is the outer orchestrator and semantic worker.
  A fresh native Codex sub-agent is the read-only semantic reviewer for each
  completion request. Neither model may commit a phase, write runtime state, or
  write release evidence.

The logical `thread_id` is durable. A resumed Codex session is preferred, but a
replacement physical Codex session after interruption must retain the same
logical thread and reload its current context envelope.

## Runtime isolation

Keep the runtime directory outside the business output directory. Runtime
state, journals, context packs, and model-response files must not enter the
publication package or release snapshot.

Use the plugin runtime entry point:

```text
python <plugin-root>/scripts/agent_runtime.py
```

## Enabled phases

The V1 runtime implements the complete strict serial path:

```text
P00 THREAD_BOOTSTRAP
P01 SOURCE_AUTHORITY
P02 SOURCE_MODEL
P03 SOURCE_REVIEW
P04 MATH_LOCKS
P05 DEPENDENCY_AND_PLAN
P06 DRAFT
P07 REVIEW_AND_FINAL
P08 OPTIMIZE_AND_STANDARDIZE
P09 VERIFICATION_LOCKS
P10 ATTACK_AND_REVISION
P11 AIGC_REWRITE
P12 PUBLICATION_ASSEMBLY
P13 CONTENT_ACCEPTANCE
P14 RELEASE_EVIDENCE
```

Run P01 and P02 only through the runtime. They delegate to the existing
`pipeline.py init`, `prepare-source`, and source-atomization validation chain.
Do not regard P02 success as a mathematical or author-question resolution.

For every semantic phase, use the emitted turn envelope. Read only its bound
business and rule files, return one structured action proposal at most, and
request Runtime validation when the phase is genuinely ready. A proposal or a
model completion claim never commits a phase.

`emit-turn` is a read boundary and is idempotent for the active turn. If the
Runtime is already `AWAITING_ACTION` and its bound Context Envelope still
validates, a repeated request must return that same envelope without creating a
`CONTEXT_PACK_COMMIT`, changing `state_revision`, or replacing the response
binding. A new Context Envelope is created only after the previous action has
been validated/executed or an explicit recovery transition has cleared the
active binding. This prevents transport retries or a worker re-reading the
current turn from invalidating the action it is supposed to submit.

The Runtime never invokes Codex. The current Work task calls
`emit-turn`, reads the bound files, authors one action response, and submits it
through `validate-action` and `execute-action`. This transport rule changes no
business phase or gate; it prevents nested sessions from silently simulating the
workflow when they cannot be launched.

The outer task invokes the native Codex sub-agent capability directly for
review. This is not a nested CLI process or a second user-owned task. The
reviewer must start without the worker's conversational rationale, remain
read-only, and receive only the current Kernel, Context Envelope, bound source
authorities, and exact candidate outputs. If that capability is unavailable,
the phase is `BLOCKED`; same-context self-certification is not a fallback.

## Non-negotiable restrictions

- Never allow a runtime file to become source, math, proof, or release evidence.
- Never write `validator_result.*`, `release_manifest.*`, or
  `validator_evidence/` through Codex actions.
- Never bypass `apply_source_patch.py` for a canonical-source change.
- In V1, `pipeline.py prepare-publication` is a mechanical assembler. Its
  generated mappings must come from P11 atom/function evidence; positional
  fallback is forbidden. They remain release candidates, not proof of semantic correctness.
  P13 must reopen and review the actual compiled `publication_final.md`, and the
  complete release validator chain must still pass. A future explicit-mapping
  compiler may harden this handoff without blocking V1 operation.
- Call review passes `native sub-agent review`. After generation, a fresh
  read-only reviewer must reopen the current source and exact candidate output
  under the Supervisor Kernel and bind exact excerpts and hashes for every
  phase output. At P04 it must inspect every exact Atom; at P06-P11 and P13 it
  must inspect every P05 Atom/function realization. A related topic sentence,
  destination, or worker-authored PASS is never acceptance.

Every semantic phase follows the supervised transaction
`generate -> reopen source/output -> PASS/PARTIAL/BLOCK -> repair -> recheck`.
Only a PASS plus the deterministic phase checks may request a phase commit.

For the `PARTIAL/BLOCK -> repair` edge, the reviewer's diagnosis is a first-class
runtime input. The worker submits an empty-action `repair-handoff-v1` containing the
first loss boundary, exact source/target evidence and hashes, affected semantic
responsibilities, root cause, bounded repair scope, forbidden shortcut, and
acceptance condition. Runtime atomically stores the handoff JSON, sidecar, State
pointer, blocker, and journal event. `recover` is valid only with that active
handoff; a free-text reason cannot authorize a retry. The next Context Envelope
contains both the immutable control-file binding and the validated handoff payload,
so a cold-start Codex task receives the actual defect information rather than only
an instruction to “try again”. The original failed phase must be reviewed again
before the handoff is resolved. Ordinary in-progress write actions may continue to
use a non-ready claim, but they are not repair decisions and may not include a
handoff.

## V1 compiler handoff

P12 may invoke the existing `pipeline.py prepare-publication` only after the
reviewed article and `publication-blueprint-v1` semantic input have been created
through the preceding serial roles. The compiler may generate hashes, mirrors,
indexes, traces, and authorization candidates. It may not decide P13 acceptance
or P14 release. Placeholder PASS reports remain forbidden.

P12 copies `aigc_rewritten_final.md` exactly into the publication file. It must
not overwrite earlier draft/final/optimized/standardized/revised artifacts; those
are the boundaries used to locate the first content-function regression.

P13 writes current-hash-bound semantic acceptance files and the semantic body of
`PUBLICATION_AUDIT_REPORT.md`. That report is not final release evidence yet. P14
alone writes `validator_result.*`, `release_manifest.*`, validator logs, and the
machine-generated audit hashes and command row.
