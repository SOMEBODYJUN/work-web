# Author Question Obligation Protocol

## Purpose

Rough mathematical manuscripts often contain author-facing requests,
uncertainty, and instruction-like intellectual obligations. Their function may
be explicit or implicit; vocabulary and punctuation do not decide it.

These are not ordinary style fragments. They are source obligations. If the article simply polishes them away, the model has not actually consumed the author's intent.

## Rule

P02 may use lexical patterns only to create conservative
`P02_SEMANTIC_CANDIDATE` rows. It must also create one
`SOURCE_WIDE_SEMANTIC_SCAN` blocker, even when no pattern matches.

At P03, reread all of `source_canonical.txt` and:

1. confirm or reclassify every candidate as a real obligation;
2. mark a genuine false positive `DISMISSED_P02_CANDIDATE` with
   `DISMISSED_NOT_AN_OBLIGATION` and a concrete trace;
3. add obligations missed by the lexical safety net;
4. mark the source-wide row `SEMANTIC_SCAN_COMPLETE` with review evidence.

P03 confirms and routes an obligation; it does not pretend that a future article
has already fulfilled it.  Use `CONFIRMED_ACTIVE_OBLIGATION` for a genuine
question, request, method choice, explanatory duty, or voice intent that P04-P13
must still realize and verify.  The later fulfillment statuses below may be used
only when their cited target article bytes already exist.

P04 must place every actionable row into `source_obligation_contracts` in
`publication_blueprint.json`. The contract binds the unchanged `AQ` identity,
identity hash, complete source span, every overlapping Atom, the exact semantic
functions that implement it, one fulfillment mode, and a concrete implementation
requirement. A destination is not this contract.

P05 copies the applicable `AQ` IDs into each Atom/function realization as
`source_obligation_ids`. P06-P11 and P13 retain those IDs and add one
`source_obligation_results[AQ...]` judgment containing the P04 identity hash,
fulfillment mode, complete obligation source evidence, current complete-unit target
evidence, status, and semantic reason. The ordinary Atom/function PASS cannot
substitute for this duty.

Only the deterministic P13 finalizer may replace
`CONFIRMED_ACTIVE_OBLIGATION` with an article-fulfillment status. It writes a
current-publication hash and accepted realization evidence into `response_trace`.
If `publication_final.md` does not yet exist, the three final statuses are invalid.

The ledger is mandatory even when no author question exists. After the P03
whole-source scan, if no real obligation exists, add an explicit
`NO_AUTHOR_QUESTIONS` row in addition to the completed scan row. P02 may never
declare `NO_AUTHOR_QUESTIONS` from zero keyword matches.

## Required fields

```text
question_id
source_span
source_excerpt
obligation_type
required_action
destination_file
destination_anchor
resolution_status
response_trace
verification_note
```

## Obligation types

```text
UNDERSTANDING_CHECK
REQUEST_FOR_BETTER_METHOD
REQUEST_FOR_APPLICATION
REQUEST_FOR_DEEPER_EXPLANATION
REQUEST_FOR_GEOMETRIC_INTERPRETATION
UNCERTAINTY_TO_RESOLVE
VOICE_INTENT_TO_PRESERVE
P02_SEMANTIC_CANDIDATE
SOURCE_WIDE_SEMANTIC_SCAN
DISMISSED_P02_CANDIDATE
NO_AUTHOR_QUESTIONS
```

## Valid resolution statuses

```text
RESOLVED_IN_ARTICLE
PRESERVED_AS_AUTHOR_QUESTION
ANSWERED_IN_EXPLANATION
CONFIRMED_ACTIVE_OBLIGATION
BLOCKED_NEEDS_SOURCE_SUPPORT
DISMISSED_NOT_AN_OBLIGATION
SEMANTIC_SCAN_COMPLETE
NO_AUTHOR_QUESTIONS
```

`TODO`, `UNKNOWN`, `PENDING`, or blank status is invalid.

## Validation

Run:

```bash
python scripts/validate_author_question_obligations.py <output_dir>
```

This validator checks exact source spans, candidate dispositions, and completion
of the P03 whole-source scan. It does not use the lexical candidate detector as
semantic proof that a passage is or is not an author obligation.

Run `validate_source_obligation_contracts.py` after P04. Every later rewrite
boundary is enforced by `validate_content_function_preservation.py`.
