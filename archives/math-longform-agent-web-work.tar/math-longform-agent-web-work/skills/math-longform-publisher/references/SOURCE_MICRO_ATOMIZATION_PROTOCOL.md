# Source Semantic Atomization Protocol

## Input authority

Atomize only `source_canonical.txt` for the current `source_revision.json`.
`source_original.txt` is the immutable upload reference. `canonical_source.txt` and
`source.txt` are legacy mirrors only.

Every non-duplicate atom is:

```text
content_lock_state = CONTENT_LOCKED
```

## Segmentation

Split by coherent content responsibility, not punctuation count. Separate mixed
author voice from proof/formula material before assigning surface behavior. Preserve
global atom IDs and UTF-8 byte spans across chunks.

## Required schema

Every atom contains the common fields defined by
`CONTENT_AUTHORITY_PROTOCOL.md`, including:

```text
surface_mode
output_operation
surface_decision_json
surface_group_id
surface_group_mode
```

### Non-exact atom

```text
surface_mode = CONTENT_PRESERVE
output_operation = a finite semantic operation
allowed_completion = specific source-grounded permission
forbidden_change = specific source-grounded prohibition
```

### Exact atom

```text
surface_mode = BYTE_EXACT
output_operation = COPY_SOURCE_SLICE
```

For an exact atom, do not emit `content_output_mode`, `allowed_completion`, or
`forbidden_change`. Exact output is not an editable transformation contract.

## Content invariants

Proof atoms state premises, required steps, conclusion, forbidden alternative routes,
and required output fragments. Formula atoms state the mathematical object, canonical
formula, symbols, and conditions. Author insight/method atoms state the distinctive
claim or construction and forbidden generic substitution.

An exact author-voice atom may still have a semantic invariant for classification and
audit, but output is performed solely by copying its current source slice.

## Quality gate

Reject atomization when:

- most rows use one generic classification;
- source spans are false, overlapping, stale, or incomplete;
- mixed mathematical and exact-surface content was not split;
- a `BYTE_EXACT` row carries editing fields;
- a `BYTE_EXACT` row does not use `COPY_SOURCE_SLICE`;
- a non-exact row lacks finite completion and forbidden-change contracts;
- current-source content has no planned destination.

## P04 controlled resegmentation

If P04 discovers that one intake Atom combines independent responsibilities
(for example a formula correction and an author question), it may declare a
lossless byte split inside `publication_blueprint.json`:

```json
{
  "source_atom_resegmentation": [
    {
      "source_atom_id": "A0001",
      "children": [
        {"atom_id": "A0101", "source_byte_start": 0, "source_byte_end": 42},
        {"atom_id": "A0102", "source_byte_start": 42, "source_byte_end": 91}
      ]
    }
  ]
}
```

The Runtime validates UTF-8 boundaries and complete, contiguous coverage, then
rebuilds the source Atom/sentence/chunk mirrors and P03 overlap mirrors in the
same transaction as the blueprint. It never edits source bytes or invents a
new excerpt. Child contracts initially inherit the parent only as an explicit
`resegmentation_inherited` pending marker; P04 must replace that marker with a
fresh semantic contract for each child before the phase can pass. A child may
include a `contract` object in the declaration when that review is already
complete. Repeating an operation whose status is `APPLIED` is a no-op.
