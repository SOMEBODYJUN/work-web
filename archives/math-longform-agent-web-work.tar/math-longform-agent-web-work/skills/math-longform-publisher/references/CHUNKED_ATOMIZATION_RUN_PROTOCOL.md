# Chunked Atomization Run Protocol

This protocol prevents long-source context overload while keeping semantic atomization manageable. If Codex tries to split, read, reason over, and validate all atoms in one pass, it will either exceed context, compress the source too early, or silently produce coarse atoms.

The solution is staged chunk atomization: split first, atomize one chunk at a time, validate each chunk, lock it, then merge only after all chunks pass.

## Non-Negotiable Rule

Long sources must be processed in batches. Do not atomize a long WeChat/公众号 article, lecture transcript, or dense math draft in one monolithic pass.

Default batch budget:

```text
max_chunk_chars: about 8,000 characters
max_chunk_semantic_units: about 180 semantic units
target_chunk_semantic_units: 60-140 units when possible
```

A chunk may exceed the soft budget only for indivisible formula blocks, tables, OCR fragments, or other explicitly marked exceptions. Even exception chunks should stay below the absolute cap used by the validator.

## Required Long-Source Files

For long or dense sources, generate these before article drafting:

```text
source_chunk_index.md
source_sentence_index.md
chunk_ledger/chunk_C001_atom_ledger.md
chunk_ledger/chunk_C002_atom_ledger.md
...
source_atom_ledger.md
source_atom_manifest.md
chunk_processing_log.md
```

`source_atom_ledger.md` is the merged aggregate after chunk ledgers pass. It is not a substitute for per-chunk ledgers.

`source_atom_manifest.md` is a compact operating index for later stages. Later stages should read the manifest first, then open only the relevant chunk ledger when they need local details. This prevents context blow-up.

`chunk_processing_log.md` records per-chunk commands, exit codes, and status. It proves the workflow did not skip chunk-level validation.

## Chunk Index Schema

`source_chunk_index.md` should contain at least:

```text
chunk_id
char_span or start_char/end_char
start_sentence_id
end_sentence_id
semantic_unit_hint
target_atom_budget
context_left
context_right
ledger_file
status
```

Older columns such as `first source phrase`, `last source phrase`, `start_char`, `end_char`, `reason`, `chunk_file`, and `status` are still accepted for short fixtures, but long sources should use the batch schema above.

## Chunking Method

1. Preserve original order.
2. Build `source_sentence_index.md` first.
3. Split chunks on paragraph or sentence boundaries when possible.
4. Keep each chunk within the character and micro-unit budget.
5. Use read-only context halos only for continuity: a small `context_left` and `context_right` may be recorded, but halo text is not atomized twice.
6. Atomize one chunk at a time.
7. Validate the chunk ledger before moving to the next chunk.
8. Merge chunk ledgers into `source_atom_ledger.md` only after all chunks pass.
9. Create `source_atom_manifest.md` with counts and status.
10. Run the global validators.

## Context Halo Rule

For continuity, Codex may glance at adjacent text, but adjacent text must be marked as context, not source for the current chunk.

Do not duplicate atoms because of overlap. If an overlap fragment is needed, cite the existing atom id from the neighboring chunk.

## Merge Rule

Atom ids are global across the whole source:

```text
C001: A0001-A0120
C002: A0121-A0245
C003: A0246-A0380
```

Do not restart atom ids from `A0001` inside each chunk. Duplicate atom ids across chunk ledgers invalidate the package.

## Runtime Discipline

When writing or revising an article from a long source:

1. read `source_atom_manifest.md` first;
2. choose the relevant chunk ids for the section being written;
3. open only those chunk ledgers plus the local math/proof/voice/symbol ledgers;
4. write the section;
5. trace the section immediately;
6. move to the next section.

Do not load every chunk ledger into one reasoning pass unless the source is small enough.

## Failure Recovery

If chunk batching fails:

- oversized chunk: resplit the chunk, not the final article;
- too few atoms in a chunk: rebuild that chunk ledger;
- duplicate atom ids: reassign global ids and update references before drafting;
- missing chunk in aggregate ledger: rebuild the merge, not the writing stage;
- missing log/manifest: rebuild Stage 1 publication package evidence.

A long source with thin chunking is a root-cause failure. The correct response is pipeline rollback to Stage 0 or Stage 1, not final-surface patching.
