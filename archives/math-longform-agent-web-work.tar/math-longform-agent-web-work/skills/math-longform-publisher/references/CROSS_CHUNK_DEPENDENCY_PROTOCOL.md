# Cross-Chunk Dependency Protocol

## Purpose

Batched micro-atomization protects context and runtime, but it introduces a new failure mode: later chunks may be written without reopening definitions, symbols, voice turns, proof premises, examples, or warnings established earlier.

This protocol makes cross-chunk context explicit. A builder must not write from a chunk in isolation when another chunk contains material needed to understand or preserve it.

## Required Files

Create these files after chunk atomization and before section planning or drafting:

```text
cross_chunk_dependency_map.md
section_context_prefetch_plan.md
```

Run:

```bash
python scripts/validate_cross_chunk_dependencies.py <output_dir>
```

before drafting and again before publication.

## Mental Model

```text
chunk ledgers are local memory
cross_chunk_dependency_map.md is global memory routing
section_context_prefetch_plan.md is the operational read list before writing
```

The dependency map is not a summary. It is a routing table telling Codex which upstream chunks and ledgers must be reopened before writing each article section.

## What Counts As A Cross-Chunk Dependency

Use a dependency row when a consumer chunk requires source material from another chunk, including:

- definition introduced earlier and used later;
- symbol or notation convention introduced earlier and reused later;
- theorem/proof prerequisite established earlier;
- assumption or scope restriction that remains active;
- warning, caveat, exception, or do-not-overstate boundary;
- author voice pattern or rhetorical pressure that must continue later;
- example or analogy introduced earlier and completed later;
- explanation-chain step that later chunks depend on;
- future preview that should be preserved but not expanded.

## Required Map Columns

`cross_chunk_dependency_map.md` must contain:

```text
dep_id
consumer_chunk
consumer_ids
dependency_type
provider_chunk
provider_ids
required_for_sections
prefetch_files
status
verification_note
```

Allowed `dependency_type` values:

```text
DEFINITION
SYMBOL
VOICE
PROOF_PREREQ
ASSUMPTION
EXAMPLE
WARNING
NOTATION
EXPLANATION_CHAIN
STRUCTURE
FUTURE_PREVIEW
NO_EXTERNAL_DEPENDENCY
```

Allowed passing `status` values:

```text
VERIFIED
PASS
READY
NO_EXTERNAL_DEPENDENCY
NOT_NEEDED
```

Any `BLOCKED`, `FAILED`, `PENDING`, `TODO`, `UNKNOWN`, or equivalent unresolved status blocks drafting and publication.

## Negative Rows Are Required

For multi-chunk sources, every chunk after `C001` must be audited. If a chunk genuinely has no external dependency, write a negative row:

```text
D0007 | C004 | T0031-A0061 | NO_EXTERNAL_DEPENDENCY | none | none | SEC04 | current chunk only | NO_EXTERNAL_DEPENDENCY | checked against source_atom_manifest.md
```

Do not omit the row. Omission means the chunk was not audited.

## Prefetch Plan

`section_context_prefetch_plan.md` converts dependency rows into a concrete read list before writing.

It must contain:

```text
prefetch_id
section_id
article_target
consumer_chunks
must_open_chunks
must_open_dependency_ids
must_open_files
covered_dependency_ids
status
verification_note
```

Before writing a section, reopen every file listed in `must_open_files`. Do not rely on memory from a prior chunk pass.

## Hard Rules

1. Do not write a later section from its local chunk ledger only when the dependency map lists upstream providers.
2. Do not mark a dependency as verified unless the provider ids exist in upstream ledgers.
3. Do not use `NO_EXTERNAL_DEPENDENCY` to skip difficult dependencies. It is a claim that must be verified.
4. Do not make dependency rows after writing as decorative audit. They are pre-draft routing constraints.
5. If a dependency map fails validation, rebuild chunk dependency analysis before editing the article.
