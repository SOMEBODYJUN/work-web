# Formula Block Canonicalization Protocol

## Purpose

Some Chinese math drafts copied from WeChat, OCR, PDF, or note apps contain formulas split into many one-token lines, for example:

```text
x
[
D
>=
d
0
]
```

These fragments are not independent semantic atoms. Treating each line as a separate source atom creates fake understanding and destroys the mathematical object. The builder must first identify and lock fragmented formula blocks, then atomize the canonicalized formula block as one formula-bearing unit or as a small number of mathematically meaningful units.

## Rule

Before sentence indexing and source atomization, scan `source_canonical.txt` for multi-line formula fragments, OCR formula fragments, display math, and formula-like vertical runs. Record the decision in `source_formula_block_ledger.md`.

The ledger is mandatory even when no formula block exists. If no fragmented formula exists, write a single `NO_FRAGMENTED_FORMULA_BLOCKS` row.

## Required fields

`source_formula_block_ledger.md` must contain a table with at least these columns:

```text
formula_block_id
source_span
line_span
fragment_count
raw_fragment_hash
canonical_formula
canonicalization_status
atom_ids
review_status
verification_note
```

Use `raw_fragment_hash` instead of putting fragile multi-line or pipe-containing formulas directly into the table. If the raw formula must be displayed, place it below the table in a fenced block labeled with the same `formula_block_id`.

## Allowed statuses

```text
CANONICALIZED
NO_FRAGMENTED_FORMULA_BLOCKS
BLOCKED_NEEDS_HUMAN_REVIEW
```

`TODO`, `UNKNOWN`, `PENDING`, or blank status is invalid.

`CANONICALIZED` means only that a source-supported formula object has been
recovered for writing. It does not mean that its hypotheses, domain, signs,
convergence conditions, contour admissibility, or proof use are already accepted.
P04 must bind each canonicalized `FB` as a `FORMULA_BLOCK`
`source_obligation_contract` to every overlapping Atom and its applicable
mathematical functions. P05-P13 carry and review that ID at every text boundary.

Likewise, a source-math risk marked `RESOLVED_WITH_JUSTIFICATION` is not allowed
to disappear after P03. P04 binds its `MR` identity, source span, exact required
review, and implementation requirement through the same Atom/function chain.
Use `MATHEMATICAL_RISK_REVIEW_PROTOCOL.md` for the source-wide P02/P03 lifecycle;
do not derive these risks from formula or topic keywords.

## Validation

Run:

```bash
python scripts/validate_formula_block_canonicalization.py <output_dir>
```

This validator checks that detected vertical formula fragments are explicitly canonicalized or blocked, and that no source with fragmented formulas falsely claims `NO_FRAGMENTED_FORMULA_BLOCKS`.
