# Style Calibration Reference

This file is a current-source fidelity policy, not an example corpus. It must not provide reusable model sentences, finished-article patterns, or Bad/Better pairs. The writing standard is derived from the current source plus current-source ledgers only.

## Purpose

Use this file to prevent generic AIGC style from replacing the author's mathematical voice. It does not authorize imitation of any bundled text.

## Source-Fidelity Profile

The input may be messy, emotional, abrupt, repetitive, informal, or proof-fragmentary. Treat that as manuscript signal until a ledger proves it is OCR debris, duplicate text, placeholder text, or out-of-scope future preview.

Preserve current-source functions such as opening rhythm, live doubt, requests for verification, requests for better methods, warnings about traps, proof sketches, repeated explanations with pedagogical force, and rough words that carry attitude or teaching pressure.

## Calibration Procedure

Before drafting, build `voice_expression_ledger.md` from the current source only; load `active_state.md` and `user_feedback_ledger.jsonl`; record current-source voice constraints in ledgers rather than memory; reject old examples, old fixtures, maintenance reports, and sibling articles as style authority.

If the user provides a current standard article, treat it as secondary and subordinate to the current source, active feedback, validators, and hard phrase locks.

## AIGC Style Risks

Avoid generic summary/insight language, synthetic contrast frames, marketing-like explanation, and editor process language. High-risk fake-depth wording includes `不是……而是……`, `不只是……更是……`, `表面上……实际上……`, `真正的核心`, `问题的真正入口`, `本质上`, `底层逻辑`, `关键抓手`, `完整闭环`, `从直觉到严格`, `统一视角`, `系统梳理`, `全面解析`, `非常关键`, `极其重要`, and `整个证明的精髓`.

The exact phrases locked by `references/FORBIDDEN_PHRASE_LOCK_PROTOCOL.md` are hard-banned from article surface files.

## Structure Policy

Do not force `摘要`, `目录`, or `本期小结` unless the current source has that shape or the article length makes it necessary. Headings must come from current-source pressure, objects, proof steps, and reader difficulty, not from reusable content-plan templates.

## Proof Policy

When the source contains proof ideas, expand supported local steps, name hidden lemmas when useful, show the relevant estimate or algebra, and preserve preview material as preview rather than inventing a full section.

## Final Pass

Before release, check that publication prose still sounds like a completed version of the current source rather than a neutral textbook or editor report. Then run the validator chain; subjective confidence is not enough.
