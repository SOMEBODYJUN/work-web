# Claim Source Obligation Model

This model upgrades the claim ledger from paragraph-level trace to claim-level support, ownership, and lock interpretation.

## Principle

A claim can be mathematically true but still invalid for this article if it belongs to the wrong source, changes the author's scope, swaps the author's proof route, or silently upgrades a preview into a theorem.

Therefore each claim needs both:

1. support evidence; and
2. source ownership and lock scope.

## Required Claim Fields

Use these fields in `final_claim_ledger.md` and `publication_claim_ledger.md`:

```text
claim_id
file
location
claim_excerpt
claim_type
source_atoms
statement_ids
proof_ids
support_type
source_ownership
transformation_scope
verdict
allowed_new_reason
verification_note
```

## Allowed support_type Values

```text
DIRECT_SOURCE
DERIVED_MATH
SUPPORTED_COMPLETION
VOICE_PRESERVATION
AUTHOR_METHOD_PRESERVATION
INSIGHT_PRESERVATION
PROOF_ROUTE_PRESERVATION
FORMULA_CANONICALIZATION
EXACT_SURFACE_PRESERVATION
EXPLANATORY_BRIDGE
HEADING_LABEL
PLATFORM_FORMATTING
```

## Allowed source_ownership Values

```text
SOURCE_EXACT
SOURCE_LOCAL_REPHRASE
SOURCE_DERIVED
AUTHOR_VOICE
AUTHOR_METHOD
AUTHOR_INSIGHT
SOURCE_FORMULA_OBJECT
FORMAT_ONLY
```

## Allowed verdict Values

```text
SUPPORTED
DERIVED_SUPPORTED
VOICE_SUPPORTED
METHOD_SUPPORTED
INSIGHT_SUPPORTED
ROUTE_SUPPORTED
FORMULA_SUPPORTED
EXACT_SURFACE_SUPPORTED
FORMAT_ONLY
BLOCKED_UNSUPPORTED
BLOCKED_SOURCE_MISMATCH
BLOCKED_SCOPE_EXPANSION
```

Publication is blocked when any final publication claim has a `BLOCKED_*` verdict.

## Support Requirements

- definitions, theorems, propositions, proof steps, examples, warnings, assumptions, and formula claims need `source_atoms` and, when applicable, `statement_ids` or `proof_ids`.
- exact-surface claims need nearby `source_atoms` and `SOURCE_EXACT` ownership.
- voice claims need nearby `source_atoms` and `AUTHOR_VOICE` ownership.
- author-method and insight claims need nearby `source_atoms` and explicit method/insight preservation language.
- headings need nearby `source_atoms` or `HEADING_LABEL` with a local atom basis.
- platform formatting may be `FORMAT_ONLY`, but it must not change article order, mathematical content, headings, proof route, or author voice.
- explanation bridges are allowed only when they point to local atoms or statement/proof obligations and do not introduce outside theory.
