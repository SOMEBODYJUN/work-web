# Publication Blueprint Protocol

`publication-blueprint-v1` is the reviewed semantic input to
`scripts/pipeline.py prepare-publication`.

The blueprint is not a substitute for mathematical judgment. It records the
judgment that has already been made, while `prepare-publication` generates the
large mechanical artifact set deterministically.

## Required top-level fields

```json
{
  "schema_version": "publication-blueprint-v1",
  "section_title": "reader-facing article scope",
  "voices": [],
  "symbols": [],
  "chains": [],
  "statements": [],
  "proofs": [],
  "atom_function_contracts": [],
  "source_obligation_contracts": [],
  "function_preservation_reviews": [],
  "content_review_checks": [],
  "math_review_items": []
}
```

Every required list must be nonempty.

`source_obligation_contracts` may be empty only when the reviewed P03 ledgers have
no actionable author-question, canonicalized formula, or resolved mathematical-risk
row. When any such row exists, omission of its exact identity is blocking.

`atom_function_contracts` contains exactly one reviewed multi-function contract
per source atom. `function_preservation_reviews` retains the hash-bound review at
each rewrite boundary. Their schema and stage IDs are defined in
`CONTENT_FUNCTION_PRESERVATION_PROTOCOL.md`.

## Semantic ledgers

- `voices`: rows for `voice_expression_ledger.md`; each row needs a unique
  `voice_id` such as `V001` and current-source atom support.
- `symbols`: rows for `symbol_ledger.md`; each row needs a unique `symbol_id`
  such as `SYM001`.
- `chains`: rows for `explanation_chain_ledger.md`; each row needs a unique
  `chain_id` such as `CH001`.
- `statements`: rows for `math_statement_ledger.md`; each row needs a unique
  `statement_id` such as `S001`, assumptions, conclusion, symbols, source
  atoms, proof obligation IDs, destination, and a completed status.
- `proofs`: rows for `proof_obligations.md`; each row needs a unique `proof_id`
  such as `PR001`, source support, required completion, allowed method,
  forbidden expansion, destination, and a satisfied completion status.

Source-atom references may be comma-separated IDs or bounded ranges such as
`A0010-A0018`. Every referenced atom must exist in the current source revision.

## Review evidence

`content_review_checks` must contain PASS rows for all nine categories:

- `SOURCE_COVERAGE`
- `MATHEMATICAL_CORRECTNESS`
- `PROOF_ROUTE_FIDELITY`
- `FORMULA_REPAIR`
- `AUTHOR_VOICE`
- `STRUCTURE_READABILITY`
- `PUBLICATION_READINESS`
- `HEADING_AUTHORIZATION`
- `OUTPUT_AUTHORIZATION`

Every row must include `source_evidence` that occurs in
`source_canonical.txt`, `publication_evidence` that occurs in the reviewed
article, and a concrete note.

`math_review_items` must contain PASS rows with:

- a unique `item_id` such as `MRV001`;
- exact source evidence;
- exact publication evidence;
- substantive independent reasoning.

The compiler rejects shallow reasoning or missing evidence instead of silently
manufacturing approval.

## Optional fields

- `claims`: explicit claim-ledger rows. When omitted, the compiler derives
  claims from headings and mathematical-review evidence.
- `omissions`: explicit omission/correction rows.
- `recovery_rows`: failure-recovery evidence.
- `voice_atoms`: atom IDs that anchor article-level voice.
- `planned_function` and `writing_instruction`: planning metadata.

## P12 compiler responsibilities

`prepare-publication` is a mechanical assembler. It requires the supplied article
to be byte-identical to `aigc_rewritten_final.md`, copies those bytes to
`publication_final.md`, and deterministically generates only pending candidates:

- output-unit byte spans and hashes;
- paragraph and claim traces;
- pending Atom-consumption candidates derived from P11 function evidence;
- pending heading authorization;
- pending byte-fragment authorization.

It does not write the article history, section plan, semantic review PASS files,
mathematical review PASS files, omission decisions, recovery conclusions,
publication audit reports, or `CONSUMED`. P13 must reopen the exact source and
publication, write its own current-hash review artifacts, and authorize the
deterministic consumption finalizer.

## Required command order

```bash
python scripts/pipeline.py init source.txt output --mode source_atomization
python scripts/pipeline.py prepare-source output
python scripts/pipeline.py validate output --mode source_atomization

# Resolve formula, author-question, and mathematical-risk ledgers.
python scripts/pipeline.py set-mode output --mode full_publication
python scripts/pipeline.py prepare-publication output article.md blueprint.json
python scripts/pipeline.py release output --mode full_publication
```

Any article or blueprint byte change requires recompilation and release
evidence regeneration.
