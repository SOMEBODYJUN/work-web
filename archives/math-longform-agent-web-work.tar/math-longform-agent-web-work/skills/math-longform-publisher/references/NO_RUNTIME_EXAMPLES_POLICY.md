# No Runtime Evaluation Assets Policy

The production Skill must not contain or load manuscript examples, source-to-final
pairs, expected answers, regression fixtures, calibration corpora, historical test
outputs, or maintenance reports.

## Runtime authority

During article generation, the only content-bearing authorities are:

- current user-provided source files;
- current user feedback;
- ledgers generated from the current source revision;
- general protocols, validators, rubrics, and empty templates.

The runtime package may contain rules and schemas, but no previous manuscript text
or previous final publication.

## Evaluation boundary

Regression and content evaluation are executed from a separate external bundle. The
evaluation runner may invoke the production Skill, but the production Skill cannot
read the evaluation sources, reviewer judgments, expected outcomes, or prior runs
before generation.

Evaluation artifacts must not be copied into the Skill archive after a successful
test.

## User-provided standards

A standard article may be used only when the user explicitly supplies it for the
current run. It remains secondary to the current source and cannot become a permanent
runtime asset.

## Release

`scripts/validate_skill_package_integrity.py` rejects runtime archives containing
fixture directories, external evaluation runners, maintenance history, build caches,
or prohibited corpus paths.
