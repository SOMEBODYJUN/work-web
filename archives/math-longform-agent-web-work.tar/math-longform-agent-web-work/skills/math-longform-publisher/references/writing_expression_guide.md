# Writing Expression Guide

Use this guide only after the current source revision and current atom ledger validate.

## Scope

The current canonical source fixes the article's content. Writing may organize,
clarify, formalize, and repair local mathematical notation, but may not import new
subject matter, examples, opinions, proof routes, or author stance.

## Writing Priority

For every output unit:

1. identify exact current-source atom IDs;
2. preserve each atom's `content_invariant_json`;
3. obey `surface_mode`;
4. use only the atom's allowed transformation;
5. preserve the author's method, proof route, insight, terminology, and discourse
   function;
6. add only mathematically necessary or local connective material with an explicit
   `new_content_basis`;
7. bind the real output span and hash back to the atoms.

Every atom is `CONTENT_LOCKED`. A category such as voice, proof, formula, or insight
does not create a separate authority source.

## Surface and Content

Before writing, the Agent must decide whether surface form itself carries content.
Use `BYTE_EXACT` for distinctive voice, abrasive/taboo wording, repetition,
disfluency, punctuation rhythm, wordplay, fixed phrasing, and direct address when
paraphrase or sanitization would change author identity or force. User designation is
highest priority but not required. Record evidence in `surface_decision_json`.

When `surface_mode=BYTE_EXACT`, reproduce the canonical source byte slice exactly,
including punctuation, spacing, roughness, rhythm, and force. Continuous exact groups
must remain uninterrupted and in source order.

When `surface_mode=CONTENT_PRESERVE`, preserve content while applying the permitted
mode:

- `FORMALIZE_SOURCE_PROOF`: fill omitted steps only along the source route;
- `NORMALIZE_SOURCE_FORMULA`: repair OCR or oral notation without changing the mathematical
  object, variables, quantifiers, or conditions;
- `EXPLAIN`: unpack the author's insight or method without replacing it;
- `REORGANIZE`: improve local order while retaining every atom's role and destination;
- `RETAIN_SOURCE_ASIDE`: preserve reader dialogue, emotion, jokes, pressure, and rough voice.

Do not sanitize abrasive or emotional source material merely because a generic
article style would be calmer.

## Proof and Formula Discipline

A completed proof must preserve its source premises, key construction, required
technical moves, and conclusion boundary. A cleaner textbook proof is not a legal
substitute unless the current user changes the source.

A normalized formula must preserve the mathematical object and symbol dependencies.
Do not guess an unreadable formula. Mark it blocked when the object cannot be
determined safely.

## Sentence Sources

A sentence may come from:

- one or more current-source atoms;
- a source-route completion required by their proof invariant;
- formula normalization required by their formula invariant;
- an explicit quantifier or local connective necessary to express the same content;
- reader clarification attached to identified atoms.

“Make the article smoother” is not a source basis.

## Headings and Voice

Prefer local mathematical headings supported by the source's structure. Avoid generic
process headings, motivational summaries, or textbook framing that the author did not
supply.

The final article should sound like the author completed and organized their own
lecture, not like a model replaced it with a polished survey.

## Reverse Validation

Trace the article after it is written. The final Markdown is split deterministically,
and every real unit receives an exact byte span, hash, atom mapping, transformation,
and preserved-invariant list.

A trace cannot repair an unsupported sentence. When a unit has no source basis,
delete it or return to the source/plan stage.


## Final Fragment Authorization

After the article is written, do not trust sentence-level source labels alone. Split
the actual `publication_final.md` into byte-addressed fragments and write
`publication_fragment_authorization.jsonl`.

A source-supported sentence can still contain an unsupported preface, metaphor,
summary, or narrator posture. Authorize only the exact fragment that is source
derived or mathematically necessary. Delete any fragment whose removal does not
damage source content, mathematical correctness, formula readability, document
structure, or grammar.

Titles and headings use `heading_authorization.jsonl`. Prefer the shortest
current-source term. A mathematical standard name may be introduced only when it is
needed to normalize a source-described object and is independently reviewed.
