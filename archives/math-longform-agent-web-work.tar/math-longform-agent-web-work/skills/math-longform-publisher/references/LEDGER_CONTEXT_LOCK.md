# Content-Authority Context Contract

## Why This File Exists

A ledger is not evidence that the model understood the source merely because it exists.
The writing step must consume the current source revision, its content-locked atoms,
their invariants, and an explicit section execution plan.

The only authority chain is:

```text
current canonical source revision
-> source atoms
-> atom content invariants and permitted transformations
-> section execution plan
-> publication output units
-> deterministic reverse validation
```

No statement, proof, formula, voice, insight, trace, or historical ledger can override
the current canonical source revision.

## Required Pattern

```text
source_original.txt
-> source_revision.json + source_canonical.txt
-> source_sentence_index.*
-> source_atom_ledger.*
-> section execution plan
-> article versions
-> deterministic output-unit trace
-> content-invariant review
-> release validation
```

`source_atom_ledger.*` is the next-round understanding substrate. It is invalid to
write an article from memory and generate atoms or traces afterward to describe it.

## One Root Content Lock

Every non-duplicate atom from the current canonical source has:

```text
content_lock_state = CONTENT_LOCKED
```

This means the atom must be read, interpreted, assigned a real destination, and
preserved through a legal transformation. It may not be silently omitted, weakened,
sanitized, replaced with a generic idea, or converted into an unsupported claim.

Voice, method, insight, proof route, formula, reader dialogue, rough emotion, terms,
and ordinary prose are `content_type` categories inside this single root lock. They
are not independent lock ledgers and cannot create their own source authority.

When wording must remain character-for-character, the atom uses:

```text
surface_mode = BYTE_EXACT
```

The required text is computed from the atom's UTF-8 byte span in the current canonical
source. No handwritten exact text field or standalone surface-lock ledger is
authoritative.

## Context Pack Before Writing

Before each writing or revision step, load at least:

```text
source_revision.json
source_canonical.txt
source_identity.json
source_provenance.json
source_atom_ledger.jsonl
section_execution_plan.jsonl
context_pack_manifest.json
section_plan.md
pre_final_plan.md
```

When present and relevant, also load:

```text
source_formula_block_ledger.jsonl
author_question_obligation_ledger.jsonl
cross_chunk_dependency_map.jsonl
section_context_prefetch_plan.jsonl
math_statement_ledger.md
proof_obligations.md
voice_expression_ledger.md
symbol_ledger.md
explanation_chain_ledger.md
```

These secondary ledgers are navigation or compatibility material. Every obligation
they express must still resolve to current atom IDs and atom invariants.

`context_pack_manifest.json` records hashes and the current `source_revision_id`.
If the source revision or any authoritative atom file changes, the writing plan and
all downstream output must be rebuilt.

## Section Execution Plan

Before writing a section, record:

```text
section_id
source_atom_ids
required_invariants
transformation_kinds
forbidden_changes
function_realization_plan
```

A section may be written only when every included atom has a legal transformation and
destination. `function_realization_plan` contains exactly one source-grounded
writing obligation for every Atom/function pair. A plan must not cite a broad atom
range merely to look complete, and it must not predict final output-unit IDs before
the prose exists.

Each realization obligation records:

```text
realization_id
atom_id
function
source_evidence
writing_instruction
realization_group_id
merge_justification
```

Several obligations may share one realization group only when the planned passage
will retain each independent value and the merge is explicitly justified.

Allowed transformation kinds include:

```text
COPY_SOURCE_SLICE
CONTENT_PRESERVING_REWRITE
SOURCE_ROUTE_COMPLETION
FORMULA_NORMALIZATION
READER_CLARIFICATION
LOCAL_CONNECTIVE
EXPLICIT_QUANTIFIER
```

New connective or explanatory text must be local to identified atoms and must not
introduce a new theorem, condition, example, opinion, proof route, or author stance.

## Output-First Reverse Trace

After writing, split `publication_final.md` deterministically. For every real output
unit, record:

```text
output_unit_id
output_byte_start
output_byte_end
output_text_sha256
source_atom_ids
transformation_kind
preserved_invariants
new_content_basis
```

The validator recomputes every span and hash from the final file. There may be no
missing output unit, extra trace row, stale hash, unsupported source-free prose, or
wide irrelevant atom citation.

## Fail-Closed Rules

Block release when any of the following is true:

- an atom is bound to another source revision;
- an atom lacks a real content invariant or legal output mode;
- a non-duplicate atom is not consumed;
- exact output is not derived from the current source span;
- an output unit has no current-source basis;
- a proof route, formula object, author method, insight, or voice function is changed;
- the final file and output-unit trace disagree;
- a source patch was applied but downstream atoms or traces were not rebuilt.

The manifest flag `prepared_before_writing=true` means only that Runtime froze the
complete current input set before drafting. It never claims that a model actually
read or understood those files. Understanding is evidenced only by precise Atom
semantics, realization plans, output destinations, semantic review, and reverse
validation.
