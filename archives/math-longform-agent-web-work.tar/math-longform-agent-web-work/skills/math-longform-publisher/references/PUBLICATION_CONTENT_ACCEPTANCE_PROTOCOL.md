# Publication Content Acceptance Protocol

## Purpose

A validator chain is not a publication-quality test merely because it can detect
stale hashes or broken traces. A full publication run must be rejected when the
final article is only the rough source copied into `publication_final.md`.

This protocol adds a final content-acceptance gate after output trace validation
and before release-state reduction.

## Required artifacts

- `publication_content_review.json`
- `mathematical_review.json`

Both files must bind the current `source_revision_id`, the SHA-256 of
`source_canonical.txt`, and the SHA-256 of `publication_final.md`.

P13 must also append `P13_PUBLICATION` rows to the blueprint's
`function_preservation_reviews` for every Atom and every required function. The
category review below is an article-level summary; it cannot replace those
atom/function judgments.

Each P13 Atom/function result must separately accept every bound P03 source
obligation through `source_obligation_results`. P13 does not inherit P11's
judgment. Only after those current-publication results pass may the deterministic
finalizer change an `AQ` row from `CONFIRMED_ACTIVE_OBLIGATION` to its final
article status.

For every concrete P03 mathematical-risk row, P13 must also reopen its exact
source span, required review, and current target unit. Correct formula rendering
does not satisfy a missing hypothesis, domain, proof dependency, boundary case,
or other mathematical condition. The P13 finalizer records current-publication
evidence for each accepted concrete MR only after all bound functions pass.

## Publication content review

`publication_content_review.json` must review the full final article and contain
PASS evidence for all categories:

- `SOURCE_COVERAGE`
- `MATHEMATICAL_CORRECTNESS`
- `PROOF_ROUTE_FIDELITY`
- `FORMULA_REPAIR`
- `AUTHOR_VOICE`
- `STRUCTURE_READABILITY`
- `PUBLICATION_READINESS`

Evidence excerpts must actually occur in the bound source/article. For long-form
outputs, `reviewed_sections` must list every level-2 section heading in the final
article.

## Mathematical review

`mathematical_review.json` must contain claim/proof/formula review items. Each
item identifies exact source evidence, exact publication evidence, a PASS/BLOCK
status, and concrete mathematical reasoning.

For a long source, a one-line global claim such as “mathematics reviewed” is not
acceptable.

## Deterministic rejection conditions

The release gate must fail when:

1. a long `publication_final.md` is byte-identical or effectively identical to
   the rough source;
2. the article is implausibly short for a full completion;
3. long-form structure is absent;
4. raw OCR/invisible markers or placeholders remain;
5. review hashes are stale;
6. review categories or section coverage are incomplete;
7. review evidence is not found in the bound artifacts;
8. mathematical review is too shallow;
9. any current `BYTE_EXACT` source slice does not occur exactly once.
10. a source atom's question, explanation, method, perspective, intuition,
    proof dependency, follow-up, or warning function lacks current publication
    evidence even when the same topic appears elsewhere.

## Authority

The reviews do not create source authority. They inspect the current
source→atom→plan→output chain. Deterministic validators recompute all hashes,
evidence locations, exact slices, and structural conditions.

A synthetic integration fixture may prove that the validator chain runs. It may
not be cited as evidence that a complex real article is publishable. A real
backtest must include the actual `publication_final.md` and its bound reviews.
