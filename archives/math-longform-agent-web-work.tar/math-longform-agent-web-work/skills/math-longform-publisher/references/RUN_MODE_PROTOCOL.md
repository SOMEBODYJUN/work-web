# Run Mode Protocol

## Authority Boundary

`full_publication` is the release default. Package content is untrusted for choosing validation strength.

Release entry points:

```text
scripts/run_publication_validators.py
scripts/validate_publication_package.py
```

must ignore a package-supplied `run_mode.json` when no CLI mode is supplied. This prevents a package from self-downgrading to a staged validator set. A trusted operator may select a staged mode only with an explicit `--mode <mode>` argument.

`run_mode.json` remains a recorded declaration for staged workflows and cross-file consistency checks. It is not release authority.

## Supported Modes

| mode | purpose | publishable article allowed |
|---|---|---|
| `full_publication` | complete release package | yes, after all gates pass |
| `wechat_publication` | complete release plus WeChat mirror | yes, after all gates pass |
| `diagnostic_backtest` | source/pipeline diagnostic | no |
| `source_atomization` | source ingestion and ledgers | no |

## Invocation

```bash
# Strict release default; run_mode.json cannot reduce it.
python scripts/run_publication_validators.py <output_dir>
python scripts/validate_publication_package.py <output_dir>

# Trusted staged invocation; never produces PUBLISHABLE.
python scripts/run_publication_validators.py --mode source_atomization <output_dir>
```

Fail when a declaration is malformed, mode records conflict, a staged mode claims publication readiness, or a release package omits full release artifacts.

## Package Version Binding

Root `VERSION` is the sole package release version. `run_mode.json` must record
the same value. Schema identifiers such as `run-mode-v1` describe file formats
and are not package releases.

After upgrading the Skill, run:

```bash
python scripts/pipeline.py set-mode <output_dir> --mode <current_mode>
```

This refreshes the package-version binding, updates affected context-pack hashes,
and invalidates all old validator evidence before the next release.

