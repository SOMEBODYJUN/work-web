# External Patterns To Absorb

Borrow public-skill patterns only when they strengthen this source-faithful publication workflow.

## Math Skills Pattern

Use these as optional repair tools for difficult mathematical sources:

- **Dependency map**: record which definitions, lemmas, examples, and notation must appear before a claim.
- **Proof anatomy**: separate assumptions, objects, construction, key estimate/calculation, conclusion, and failure modes.
- **Hypothesis stress test**: check whether a statement relies on compactness, smoothness, connectedness, orientation, regularity, nonzero denominator, convergence, or domain conditions.
- **Minimal running example**: add the smallest local example only when the source's argument needs it or the author gestures toward one.
- **Audit-and-patch loop**: prefer concrete findings and target locations over vague style review.

Constraint: these tools cannot override the source. Do not add external examples, alternate proofs, historical context, or broader theory unless locally necessary and source-supported.

## Lesson Notes Pattern

Use lesson-note conventions only when they fit the source:

- route map for long lectures;
- brief recap when the source explicitly returns to a previous point;
- exercise/test items only when the source contains exam pressure, practice prompts, or solved examples;
- timeline or timecode only when timestamps exist in the source.

Constraint: do not force learning objectives, quiz blocks, summaries, or classroom metadata onto a rough author manuscript.

## WeChat Publishing Pattern

Use a discovery-first publishing plan:

1. Check whether `md2wechat` or another publishing tool is available.
2. Ask or inspect capabilities before choosing account target, theme, preview, draft upload, image handling, or cover handling.
3. Keep publishing/export separate from article generation. Publishing tools may transform Markdown, but must not rewrite mathematical content.
4. Always validate `publication_final.md` before export.
5. Do not upload, publish, authenticate, or install anything unless the user explicitly requests it.
