# Canonical Source Protocol

## Default TXT flow

For a user-uploaded UTF-8 text file, the source begins directly from the uploaded
text. There is no conceptual TXT-to-binary-to-TXT conversion.

```text
uploaded UTF-8 TXT
-> source_original.txt   immutable byte-for-byte upload copy
-> source_canonical.txt  current source revision
```

For an untouched upload, the operation is `IDENTITY` and the two files must have the
same bytes, length, and SHA-256 hash.

Create the initial revision with:

```bash
python scripts/canonicalize_source.py <uploaded-txt> <output_dir>
```

The script also writes `canonical_source.txt` and `source.txt` as read-only legacy
mirrors of `source_canonical.txt`. They have no independent authority.

## Required files

```text
source_original.txt
source_canonical.txt
canonical_source.txt
source.txt
source_identity.json
source_provenance.json
source_revision.json
source_normalization_map.jsonl
```

`source_original.txt` never changes. `source_canonical.txt` is the file used for
byte spans, atomization, exact copying, and output trace validation.

## Explicit non-identity setup

BOM removal or newline normalization is allowed only when the caller explicitly
passes the corresponding option. The operation must be recorded in the normalization
map. NFKC and NFKD are forbidden.

## Source patches

A user-authorized change to the manuscript is not ordinary canonicalization. Apply it
with `scripts/apply_source_patch.py`, create a new revision, retain
`source_original.txt`, archive the previous `source_canonical.txt`, and invalidate all
atoms, plans, drafts, traces, and release evidence bound to the old revision.

## Hard rules

1. For `IDENTITY`, `source_original.txt == source_canonical.txt` byte-for-byte.
2. All authoritative spans use UTF-8 byte offsets in `source_canonical.txt`.
3. Every atom excerpt must equal its declared current-source slice.
4. Legacy mirrors may be read by old tools but may never override the current source.
5. Never edit a source file merely to satisfy a validator.
6. Any source revision change forces downstream rebuild.
