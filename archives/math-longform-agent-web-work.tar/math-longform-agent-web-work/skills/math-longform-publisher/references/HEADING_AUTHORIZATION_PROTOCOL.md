# Heading Authorization Protocol

## Rule

A title or section heading is not harmless formatting. It can introduce a metaphor, judgment, narrative posture, or thesis that the author never supplied. Every Markdown heading in `publication_final.md` must therefore appear in `heading_authorization.jsonl`.

The heading ledger is generated from the final article, not drafted independently.

## Segment bases

Every heading is reconstructed exactly from authorized segments:

- `SOURCE_TERM`: an exact UTF-8 slice from the current `source_canonical.txt`.
- `STRUCTURAL_LABEL`: a closed mathematical label such as `定义`, `定理`, `命题`, `证明`, `必要性`, or `充分性`, optionally with numbering.
- `MINIMAL_CONNECTOR`: a minimal conjunction or punctuation mark such as `与`, `和`, `及`, `、`, or `：`.
- `MATHEMATICAL_STANDARD_TERM`: a standard name needed to normalize a source-described theorem or object. It must cite current mathematical-review item IDs.
- `USER_REQUESTED`: an exact current-run user request, with feedback IDs.

The concatenated segments must equal the exact heading text. Any substantive token left uncovered blocks publication.

## Forbidden default behavior

Do not invent literary, marketing, motivational, process, or editorial titles. Editorial, literary, marketing, motivational, and process-style wording cannot be justified as formatting. A phrase may appear only if it is itself exact current-source wording or an explicit current user request.

Prefer the shortest source-grounded title. When the source provides the topic name, use it directly.

## Release

Run:

```text
python scripts/validate_heading_authorization.py <output_dir>
```
