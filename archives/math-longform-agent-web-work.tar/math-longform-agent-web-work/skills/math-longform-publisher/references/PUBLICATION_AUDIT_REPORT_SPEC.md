# Publication Audit Report Specification

`PUBLICATION_AUDIT_REPORT.md` is the single release-status entrance for a completed article package.

It does not replace detailed ledgers or validators. It summarizes their evidence so Codex cannot claim publishability from memory, confidence, or file existence.

## Allowed Final States

```text
PUBLISHABLE
PARTIAL
BLOCKED
```

`PUBLISHABLE` is allowed only when every required validator has fresh command evidence and exit code `0`, every required audit subsection says `PASS`, and no unresolved failure appears in the recovery/security/provenance sections.

`PARTIAL` means the package has usable artifacts but cannot be published without further work.

`BLOCKED` means source support, security boundary, proof support, or pipeline integrity prevents safe publication.

## Required Sections

The report must contain these headings exactly:

```text
# Publication Audit Report
## Final State
## Source Identity
## Ledger Consumption
## Math And Proof Locks
## Claim Source Obligation
## Reverse Trace
## AIGC Regression
## Security Boundary
## Failure Recovery
## Command Evidence
## Release Decision
```

## Command Evidence Table

Use this table shape:

| command | target | exit_code | verdict | evidence_note |
|---|---|---:|---|---|
| python scripts/validate_publication_package.py | output_dir | 0 | PASS | fresh run before release |

Rules:

- `exit_code` must be numeric.
- `verdict` is `PASS`, `FAIL`, or `BLOCKED`.
- `PUBLISHABLE` requires at least one package-level validator row with exit code `0`.
- Do not record future-tense evidence such as “will run” or “should pass”.

## Release Decision

Use one of:

```text
RELEASE_DECISION: publishable
RELEASE_DECISION: partial_do_not_publish
RELEASE_DECISION: blocked_do_not_publish
```

The decision must agree with `FINAL_STATE`.


## Validator Evidence Lock

`PUBLICATION_AUDIT_REPORT.md` must contain a `## Validator Evidence Lock` section with:

```text
VALIDATOR_RESULT_FILE: validator_result.json
VALIDATOR_RESULT_SHA256: <64-char sha256>
VALIDATOR_RESULT_GENERATED_BY: scripts/run_publication_validators.py
TARGET_SNAPSHOT_SHA256: <64-char snapshot sha256>
```

The hash must match `validator_result.sha256`. A publishable report must list a PASS command row for `python scripts/run_publication_validators.py`.
