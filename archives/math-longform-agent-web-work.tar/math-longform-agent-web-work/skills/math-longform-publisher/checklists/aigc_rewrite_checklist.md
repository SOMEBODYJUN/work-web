# AIGC 改稿检查清单

1. `publication_fragment_authorization.jsonl` 是否覆盖最终稿全部 UTF-8 字节？
2. 是否存在整句有 atom、但局部前缀或总结没有来源的情况？
3. 所有数学补全是否绑定原证明路线和内容不变量？
4. 所有公式规范化是否保持同一数学对象、变量、量词和条件？
5. `MINIMAL_CONNECTIVE` 是否短、必要，而且删除后确实会破坏语法或局部逻辑？
6. 标题是否逐片段完成来源授权？
7. 是否仍有只负责宣布、升华、总结、安抚、戏剧化或伪装口语的片段？
8. 删除这些片段后，来源内容和数学是否完全不受影响？若是，必须删除。
9. 是否更新最终 span、hash、trace、fragment authorization 和 reviewer evidence？
10. 外部 AIGC 工具的结果是否只作为辅助攻击证据，而没有覆盖来源权威？
