#!/usr/bin/env python3
from pathlib import Path
import sys

HARD_BANNED = ["按照原文","按原文","根据用户意思","处理痕迹","补回来","补回","这段要表达","标准写法","几个原文","补充几个细节","遗漏内容补充"]
SOURCE_ALLOWED = ["不能省","后面再说","这个地方要注意"]
PATCH_TITLES = ["几个原文里不能省的细节","补充说明","补充几个细节","遗漏内容补充","原文还说"]

def main():
    if len(sys.argv) < 2:
        print("Usage: validate_clean_final.py <final.md> [source.txt]")
        return 2
    final = Path(sys.argv[1]).read_text(encoding="utf-8")
    source = Path(sys.argv[2]).read_text(encoding="utf-8") if len(sys.argv) >= 3 and Path(sys.argv[2]).exists() else ""
    failures = []

    for b in HARD_BANNED:
        if b in final:
            failures.append(f"hard banned phrase in final: {b}")

    for p in PATCH_TITLES:
        if f"## {p}" in final or f"### {p}" in final:
            failures.append(f"patch section found: {p}")

    for s in SOURCE_ALLOWED:
        if s in final and s not in source:
            failures.append(f"source-allowed phrase lacks source support: {s}")

    if failures:
        print("FAILED")
        for f in failures:
            print("-", f)
        return 1
    print("OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
