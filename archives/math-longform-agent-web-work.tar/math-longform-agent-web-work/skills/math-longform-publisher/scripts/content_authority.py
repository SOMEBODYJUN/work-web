#!/usr/bin/env python3
"""Deterministic helpers for the current content-authority model.

Authority chain:
    current canonical source revision
    -> 100% content-locked atoms
    -> atom invariants and permitted transformations
    -> final output units
    -> reproducible byte-span/hash validation

This module contains no model calls and creates no source authority from prose
ledgers.  All authoritative text is sliced from source_canonical.txt.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Any
import hashlib
import json
import re

from safe_io import read_json_strict, read_jsonl_strict

SOURCE_REVISION_SCHEMA = "content-authority-source-revision-v2"
ATOM_SCHEMA = "content-authority-atom-v3"
OUTPUT_TRACE_SCHEMA = "content-authority-output-trace-v3"
SECTION_PLAN_SCHEMA = "content-authority-section-plan-v4"
SURFACE_REVIEW_SCHEMA = "content-authority-surface-review-v1"

CONTENT_TYPES = {
    "PROSE",
    "DEFINITION",
    "STATEMENT",
    "THEOREM",
    "PROOF_ROUTE",
    "PROOF_STEP",
    "FORMULA",
    "EXAMPLE",
    "WARNING",
    "AUTHOR_VOICE",
    "AUTHOR_INSIGHT",
    "AUTHOR_METHOD",
    "READER_DIALOGUE",
    "TRANSITION",
    "FUTURE_PREVIEW",
    "TERM",
    "OCR_FRAGMENT",
    "DUPLICATE",
    "PLACEHOLDER",
}
SURFACE_MODES = {"CONTENT_PRESERVE", "BYTE_EXACT"}
SURFACE_GROUP_MODES = {"NONE", "CONTIGUOUS_BYTE_EXACT"}
SURFACE_CONFIDENCE = {"HIGH", "MEDIUM", "LOW"}
SURFACE_REVIEW_STATUSES = {"APPROVED", "BLOCKED_REVIEW"}
SURFACE_DECISION_BASES = {
    "USER_EXPLICIT_EXACT",
    "VERBATIM_QUOTE",
    "DISTINCTIVE_AUTHOR_VOICE",
    "ABRASIVE_OR_TABOO_WORDING",
    "RHYTHM_REPETITION_DISFLUENCY",
    "PUNCTUATION_OR_SPACING_IS_CONTENT",
    "WORDPLAY_SLOGAN_FIXED_FORM",
    "TITLE_OR_SIGNATURE_LINE",
    "READER_DIRECT_ADDRESS",
    "SANITIZATION_CHANGES_AUTHOR_IDENTITY",
    "FORMULA_REQUIRES_NORMALIZATION",
    "PROOF_REQUIRES_FORMALIZATION",
    "ORDINARY_SEMANTIC_CONTENT",
    "MIXED_CONTENT_SPLIT",
    "UNCERTAIN_BLOCKED_REVIEW",
}
OUTPUT_OPERATIONS = {
    "COPY_SOURCE_SLICE",
    "REORGANIZE_CONTENT",
    "EXPLAIN_CONTENT",
    "FORMALIZE_SOURCE_PROOF",
    "NORMALIZE_SOURCE_FORMULA",
    "DEFINE_SOURCE_TERM",
    "RETAIN_SOURCE_ASIDE",
    "RETAIN_SOURCE_CONTEXT",
    "OMIT_CONFIRMED_DUPLICATE",
    "BLOCK_UNRESOLVED",
    "BLOCKED_REVIEW",
}
CONSUMPTION_STATES = {"PLANNED", "CONSUMED", "DUPLICATE_CONSUMED", "BLOCKED"}
TRANSFORMATION_KINDS = {
    "COPY_SOURCE_SLICE",
    "CONTENT_PRESERVING_REWRITE",
    "SOURCE_ROUTE_COMPLETION",
    "FORMULA_NORMALIZATION",
    "LOCAL_CONNECTIVE",
    "EXPLICIT_QUANTIFIER",
    "READER_CLARIFICATION",
    "STRUCTURAL_HEADING",
    "DUPLICATE_OMISSION",
    "TASK_DIRECTIVE_EXPANSION",
}
NEW_CONTENT_BASES = {
    "NONE",
    "SOURCE_ROUTE_COMPLETION",
    "FORMULA_NORMALIZATION",
    "LOCAL_CONNECTIVE",
    "EXPLICIT_QUANTIFIER",
    "READER_CLARIFICATION",
    "STRUCTURAL_HEADING",
    "TASK_DIRECTIVE_EXPANSION",
}
GENERIC_VALUES = {
    "",
    "source_unit",
    "preserve",
    "preserved",
    "source_statement_or_voice",
    "source_voice",
    "local",
    "pending_publication",
    "todo",
    "tbd",
    "unknown",
    "概括",
    "保留",
}

ATOM_REQUIRED_FIELDS = {
    "schema_version",
    "atom_id",
    "source_revision_id",
    "source_byte_start",
    "source_byte_end",
    "source_excerpt_sha256",
    "raw_excerpt",
    "content_lock_state",
    "content_type",
    "required_functions",
    "local_context_role",
    "global_context_role",
    "content_invariant_json",
    "p02_surface_mode",
    "surface_mode",
    "output_operation",
    "consumption_status",
    "duplicate_of",
    "surface_decision_json",
    "surface_group_id",
    "surface_group_mode",
}

SURFACE_REVIEW_REQUIRED_FIELDS = {
    "schema_version",
    "review_id",
    "source_revision_id",
    "atom_id",
    "atom_decision_sha256",
    "detected_features_json",
    "reviewer_role",
    "reviewer_verdict",
    "reviewer_reason",
    "surface_group_id",
}

TRACE_REQUIRED_FIELDS = {
    "schema_version",
    "output_unit_id",
    "file",
    "output_byte_start",
    "output_byte_end",
    "output_text_sha256",
    "output_text",
    "unit_type",
    "source_atom_ids",
    "task_directive_ids",
    "transformation_kind",
    "preserved_invariants",
    "preserved_functions_json",
    "function_review_stage",
    "new_content_basis",
    "verdict",
    "verification_note",
}

SECTION_PLAN_REQUIRED_FIELDS = {
    "schema_version",
    "plan_id",
    "section_id",
    "section_order",
    "section_title",
    "source_revision_id",
    "source_atom_ids",
    "atom_contract_sha256",
    "required_invariants_json",
    "transformation_contract_json",
    "forbidden_changes_json",
    "function_realization_plan_json",
    "expansion_directive_ids",
    "status",
}

ATOM_CONTRACT_FIELDS = (
    "atom_id",
    "source_revision_id",
    "source_byte_start",
    "source_byte_end",
    "source_excerpt_sha256",
    "content_lock_state",
    "content_type",
    "required_functions",
    "local_context_role",
    "global_context_role",
    "content_invariant_json",
    "p02_surface_mode",
    "surface_mode",
    "output_operation",
    "allowed_completion",
    "forbidden_change",
    "surface_decision_json",
    "surface_group_id",
    "surface_group_mode",
)


_ABRASIVE_RE = re.compile(
    r"(傻(?:逼|福错|瓜|子)?|蠢|滚|闭嘴|冬瓜|乱叫|你根本不懂|骂|废物|狗屁|操你|我操|卧槽|草泥马|fuck|shit)",
    re.IGNORECASE,
)
_DISFLUENCY_RE = re.compile(
    r"(哦哦哦|不行不行|就是就是|然后然后|额+|呃+|哈哈+|呵呵+|gg|/gg|\bgoat\b)",
    re.IGNORECASE,
)
_REPEATED_PUNCT_RE = re.compile(r"([，。！？!?、；;…,.])\1+|……|\.\.\.")
_DIRECT_ADDRESS_RE = re.compile(r"(你们|你这个|你要|你都|读者|大家|朋友们)")
_FIRST_PERSON_VOICE_RE = re.compile(r"(我喜欢|我认为|我觉得|我觉的|我告诉你|我还是|我想|希望|切记|千万注意|顺带说一句)")
_FIXED_FORM_RE = re.compile(r"(?:#[^\s#]+|@[^\s@]+|“[^”]{1,40}”|「[^」]{1,40}」|『[^』]{1,40}』|《[^》]{1,40}》)", re.IGNORECASE)


def detect_surface_features(text: str, content_type: str = "") -> list[str]:
    """Return deterministic cues that make surface form itself likely content.

    The model remains responsible for the semantic decision.  This function is a
    fail-closed reviewer for obvious misses and must not create source authority.
    """
    features: list[str] = []
    if _ABRASIVE_RE.search(text):
        features.append("ABRASIVE_OR_TABOO_WORDING")
    if _REPEATED_PUNCT_RE.search(text):
        features.append("PUNCTUATION_OR_SPACING_IS_CONTENT")
    if _DISFLUENCY_RE.search(text) or re.search(r"(.{1,6})\1", text):
        features.append("RHYTHM_REPETITION_DISFLUENCY")
    if _DIRECT_ADDRESS_RE.search(text):
        features.append("READER_DIRECT_ADDRESS")
    if _FIRST_PERSON_VOICE_RE.search(text) or content_type in {"AUTHOR_VOICE", "READER_DIALOGUE"}:
        features.append("DISTINCTIVE_AUTHOR_VOICE")
    if _FIXED_FORM_RE.search(text):
        features.append("WORDPLAY_SLOGAN_FIXED_FORM")
    return list(dict.fromkeys(features))


def surface_features_require_exact(features: Iterable[str], content_type: str = "") -> bool:
    """Return True only when the *surface form itself* is an obligation.

    Distinctive voice, oral rhythm, punctuation noise, and OCR damage are normally
    content-preservation concerns, not byte locks. Freezing them made ordinary
    author prose impossible to edit and could preserve zero-width characters or
    OCR punctuation as if they were intentional typography.
    """
    feature_set = set(features)
    if feature_set & {"USER_EXPLICIT_EXACT", "VERBATIM_QUOTE"}:
        return True
    if "WORDPLAY_SLOGAN_FIXED_FORM" in feature_set:
        return True
    # Taboo/abrasive wording can carry authorial meaning, but mathematical/OCR
    # atoms still need normalization rather than byte-for-byte preservation.
    if (
        "ABRASIVE_OR_TABOO_WORDING" in feature_set
        and content_type not in {"FORMULA", "OCR_FRAGMENT", "PROOF_ROUTE", "PROOF_STEP"}
    ):
        return True
    return False


def surface_decision_sha256(row: dict[str, Any]) -> str:
    payload = {
        "atom_id": row.get("atom_id", ""),
        "source_revision_id": row.get("source_revision_id", ""),
        "source_excerpt_sha256": row.get("source_excerpt_sha256", ""),
        "surface_mode": row.get("surface_mode", ""),
        "output_operation": row.get("output_operation", ""),
        "surface_decision_json": row.get("surface_decision_json", ""),
        "surface_group_id": row.get("surface_group_id", ""),
        "surface_group_mode": row.get("surface_group_mode", ""),
    }
    return sha256_bytes(canonical_json(payload).encode("utf-8"))


@dataclass(frozen=True)
class OutputUnit:
    output_unit_id: str
    byte_start: int
    byte_end: int
    text: str
    unit_type: str

    @property
    def sha256(self) -> str:
        return sha256_bytes(self.text.encode("utf-8"))


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(",", ":"))


def atom_contract_sha256(rows: Iterable[dict[str, Any]]) -> str:
    """Hash the authoritative semantic contract for a deterministic atom set."""
    normalized = []
    for row in sorted(rows, key=lambda item: str(item.get("atom_id", ""))):
        normalized.append({field: row.get(field, "") for field in ATOM_CONTRACT_FIELDS})
    return sha256_bytes(canonical_json(normalized).encode("utf-8"))


def load_json_object(path: Path) -> dict[str, Any]:
    value = read_json_strict(path)
    if not isinstance(value, dict):
        raise ValueError(f"{path.name}: expected one JSON object")
    return value


def load_jsonl_objects(path: Path) -> list[dict[str, Any]]:
    rows = read_jsonl_strict(path)
    if not rows:
        raise ValueError(f"{path.name}: authoritative JSONL must not be empty")
    return rows


def parse_int(value: Any, label: str) -> int:
    if isinstance(value, bool):
        raise ValueError(f"{label}: boolean is not an integer")
    try:
        result = int(str(value))
    except Exception as exc:
        raise ValueError(f"{label}: invalid integer {value!r}") from exc
    return result


def parse_json_field(value: Any, label: str, expected: type = dict) -> Any:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{label}: missing JSON string")
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError as exc:
        raise ValueError(f"{label}: invalid JSON string: {exc}") from exc
    if not isinstance(parsed, expected):
        raise ValueError(f"{label}: expected {expected.__name__}")
    return parsed


def split_ids(value: Any, prefix: str) -> list[str]:
    text = str(value or "")
    return re.findall(rf"\b{re.escape(prefix)}\d{{4,}}\b", text)


def utf8_slice(data: bytes, start: int, end: int, label: str = "span") -> str:
    if not (0 <= start <= end <= len(data)):
        raise ValueError(f"{label}: byte span {start}-{end} outside 0-{len(data)}")
    try:
        return data[start:end].decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        raise ValueError(f"{label}: byte span splits a UTF-8 sequence") from exc


def normalize_visible(text: str) -> str:
    """Normalize only whitespace for deterministic invariant-fragment checks."""
    return re.sub(r"\s+", "", text)


def byte_prefix_map(text: str) -> list[int]:
    out = [0]
    total = 0
    for ch in text:
        total += len(ch.encode("utf-8"))
        out.append(total)
    return out


def _trim_char_span(text: str, start: int, end: int) -> tuple[int, int]:
    while start < end and text[start].isspace():
        start += 1
    while end > start and text[end - 1].isspace():
        end -= 1
    return start, end


def split_output_units(text: str) -> list[OutputUnit]:
    """Deterministically split Markdown into headings, formula/code blocks and sentence units.

    Whitespace between units is intentionally not represented.  Every non-whitespace
    character belongs to exactly one returned unit.
    """
    prefix = byte_prefix_map(text)
    units: list[tuple[int, int, str]] = []
    n = len(text)
    i = 0
    terminal = set("。！？!?；;")

    while i < n:
        while i < n and text[i].isspace():
            i += 1
        if i >= n:
            break

        line_start = i
        line_end = text.find("\n", i)
        if line_end < 0:
            line_end = n

        # Markdown heading.
        if text.startswith("#", i) and re.match(r"#{1,6}(?:\s|$)", text[i:line_end]):
            a, b = _trim_char_span(text, i, line_end)
            if a < b:
                units.append((a, b, "heading"))
            i = line_end + (1 if line_end < n else 0)
            continue

        # Fenced code block.
        if text.startswith("```", i):
            close = text.find("```", i + 3)
            end = n if close < 0 else close + 3
            a, b = _trim_char_span(text, i, end)
            units.append((a, b, "code_block"))
            i = end
            continue

        # Display formula block.
        if text.startswith("$$", i):
            close = text.find("$$", i + 2)
            end = n if close < 0 else close + 2
            a, b = _trim_char_span(text, i, end)
            units.append((a, b, "formula_block"))
            i = end
            continue

        # Ordinary line, split at sentence terminals while preserving exact text.
        cursor = i
        while cursor < line_end:
            end = cursor
            while end < line_end and text[end] not in terminal:
                end += 1
            if end < line_end:
                end += 1
            a, b = _trim_char_span(text, cursor, end)
            if a < b:
                unit_type = "formula_block" if (text[a:b].strip().startswith("$$") and text[a:b].strip().endswith("$$")) else "sentence"
                units.append((a, b, unit_type))
            cursor = end
        i = line_end + (1 if line_end < n else 0)

    result: list[OutputUnit] = []
    for index, (a, b, unit_type) in enumerate(units, 1):
        result.append(
            OutputUnit(
                output_unit_id=f"OU{index:04d}",
                byte_start=prefix[a],
                byte_end=prefix[b],
                text=text[a:b],
                unit_type=unit_type,
            )
        )
    return result


def atom_source_bytes(root: Path) -> tuple[bytes, dict[str, Any], list[dict[str, Any]]]:
    source_path = root / "source_canonical.txt"
    revision_path = root / "source_revision.json"
    atom_path = root / "source_atom_ledger.jsonl"
    if not source_path.exists():
        raise ValueError("missing source_canonical.txt")
    if not revision_path.exists():
        raise ValueError("missing source_revision.json")
    if not atom_path.exists():
        raise ValueError("missing authoritative source_atom_ledger.jsonl")
    return source_path.read_bytes(), load_json_object(revision_path), load_jsonl_objects(atom_path)


def atom_map(rows: Iterable[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for row in rows:
        atom_id = str(row.get("atom_id", ""))
        if atom_id in result:
            raise ValueError(f"duplicate atom_id: {atom_id}")
        result[atom_id] = row
    return result
