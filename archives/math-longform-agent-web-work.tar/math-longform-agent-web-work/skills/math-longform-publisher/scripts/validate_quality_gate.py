#!/usr/bin/env python3
"""Reject whole-article, section, Atom, or task-expansion compression."""
from pathlib import Path
import argparse
import json

from content_functions import INTERMEDIATE_STAGE_TARGETS, PUBLICATION_STAGE
from quality_contract import evaluate_quality_stage


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output")
    parser.add_argument("--stage")
    parser.add_argument("--target")
    parser.add_argument("--release-chain", action="store_true")
    args = parser.parse_args()
    root = Path(args.output).resolve()
    if args.release_chain:
        requested = [*INTERMEDIATE_STAGE_TARGETS, PUBLICATION_STAGE]
    elif args.stage and args.target:
        requested = [(args.stage, args.target, True)]
    else:
        parser.error("provide --stage and --target, or use --release-chain")

    errors: list[str] = []
    reports: list[dict] = []
    for stage_id, target_file, _all_atoms in requested:
        try:
            report, stage_errors = evaluate_quality_stage(root, stage_id, target_file)
        except Exception as exc:
            report, stage_errors = {}, [f"{stage_id}: quality gate failed to load: {exc}"]
        reports.append(report)
        errors.extend(stage_errors)
    if errors:
        print("FAILED")
        for error in errors:
            print(f"- {error}")
        return 1
    print("OK")
    for report in reports:
        print(json.dumps({
            key: report[key]
            for key in (
                "stage_id", "source_prose_cjk", "target_measurements",
                "minimum_source_realization_cjk", "actual_source_realization_cjk",
                "minimum_expansion_cjk", "actual_expansion_cjk", "minimum_article_cjk",
                "verdict",
            )
        }, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
