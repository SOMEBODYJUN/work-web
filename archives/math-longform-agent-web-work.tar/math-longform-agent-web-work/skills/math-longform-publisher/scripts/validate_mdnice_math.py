#!/usr/bin/env python3
"""Validate mdnice / MathJax-compatible formula style for publication Markdown.

This script checks formatting hazards only. It must not rewrite article prose.
Rules are based on references/mdnice_formula_rules.md.
"""
from pathlib import Path
import re
import sys

LEGACY_DELIMITERS = [
    (r"\\\(", r"\("),
    (r"\\\)", r"\)"),
    (r"\\\[", r"\["),
    (r"\\\]", r"\]"),
]

UNSUPPORTED_LATEX = [
    r"\\usepackage\b",
    r"\\documentclass\b",
    r"\\begin\{equation\*?\}",
    r"\\begin\{align\*?\}",
    r"\\begin\{gather\*?\}",
    r"\\begin\{multline\*?\}",
]

CJK_RE = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")
UNESCAPED_DOLLAR_RE = re.compile(r"(?<!\\)\$")

def line_no(text: str, pos: int) -> int:
    return text.count("\n", 0, pos) + 1

def strip_fenced_code(text: str) -> str:
    lines = text.splitlines(keepends=True)
    out = []
    in_fence = False
    fence_marker = None
    for line in lines:
        stripped = line.lstrip()
        if stripped.startswith("```") or stripped.startswith("~~~"):
            marker = stripped[:3]
            if not in_fence:
                in_fence = True
                fence_marker = marker
            elif marker == fence_marker:
                in_fence = False
                fence_marker = None
            out.append("\n")
        elif in_fence:
            out.append("\n")
        else:
            out.append(line)
    return "".join(out)

def extract_math(text: str):
    """Return list of (kind, start_pos, body)."""
    items = []
    spans = []
    for m in re.finditer(r"(?<!\\)\$\$(.*?)(?<!\\)\$\$", text, flags=re.S):
        items.append(("display", m.start(), m.group(1)))
        spans.append((m.start(), m.end()))
    mask = list(text)
    for a, b in spans:
        for i in range(a, b):
            mask[i] = "\n" if text[i] == "\n" else " "
    no_display = "".join(mask)
    for m in re.finditer(r"(?<!\\)\$(?!\$)(.*?)(?<!\\)\$(?!\$)", no_display, flags=re.S):
        items.append(("inline", m.start(), m.group(1)))
    items.sort(key=lambda x: x[1])
    return items

def validate_text(text: str):
    errors = []
    clean = strip_fenced_code(text)

    for pat, label in LEGACY_DELIMITERS:
        for m in re.finditer(pat, clean):
            errors.append(f"mdnice formula delimiter forbidden at line {line_no(clean, m.start())}: use $...$ or $$...$$ instead of {label}")

    if clean.count("$$") % 2 != 0:
        errors.append("unbalanced display math delimiters: odd number of $$")

    without_display = re.sub(r"(?<!\\)\$\$.*?(?<!\\)\$\$", "", clean, flags=re.S)
    if len(UNESCAPED_DOLLAR_RE.findall(without_display)) % 2 != 0:
        errors.append("unbalanced inline math delimiters: odd number of unescaped $ outside display math")

    for i, line in enumerate(clean.splitlines(), start=1):
        stripped = line.strip()
        if "|" in line and "$" in line and not stripped.startswith(">"):
            errors.append(f"MathJax formula appears inside a Markdown table at line {i}; use a MathJax array or move the formula out of the table")

    for pat in UNSUPPORTED_LATEX:
        for m in re.finditer(pat, clean):
            errors.append(f"unsupported LaTeX environment/package pattern at line {line_no(clean, m.start())}: {pat}")

    for kind, pos, body in extract_math(clean):
        ln = line_no(clean, pos)
        if CJK_RE.search(body):
            errors.append(f"CJK text inside {kind} math at line {ln}; move Chinese prose outside the formula environment")
        for m in re.finditer(r"<(?![ =])", body):
            errors.append(f"`<` without following space inside {kind} math at line {ln}; write `$a < b$`, not `$a <b$`")
        if "\\boxed{\\text{" in body and CJK_RE.search(body):
            errors.append(f"Chinese sentence boxed inside math at line {ln}; use a Markdown quote/block instead")

    return errors

def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: validate_mdnice_math.py publication.md")
        return 2
    path = Path(sys.argv[1])
    text = path.read_text(encoding="utf-8")
    errors = validate_text(text)
    if errors:
        print("FAILED")
        for e in errors:
            print("-", e)
        return 1
    print("OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
