#!/usr/bin/env python3
"""Materialize a BYTE_EXACT atom or contiguous group from source_canonical.txt.

This command performs the only legal output action for exact-surface content:
COPY_SOURCE_SLICE. It never accepts handwritten lock text.
"""
from __future__ import annotations

from pathlib import Path
import argparse
import json
import sys

from content_authority import atom_source_bytes, atom_map, sha256_bytes


def fail(message: str) -> int:
    print("FAILED")
    print(f"- {message}")
    return 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output_dir")
    target = parser.add_mutually_exclusive_group(required=True)
    target.add_argument("--atom-id")
    target.add_argument("--group-id")
    parser.add_argument("--output-file", required=True)
    args = parser.parse_args()

    root = Path(args.output_dir).resolve()
    try:
        source, revision, rows = atom_source_bytes(root)
        atoms = atom_map(rows)
    except Exception as exc:
        return fail(str(exc))

    selected: list[dict] = []
    label = ""
    if args.atom_id:
        atom = atoms.get(args.atom_id)
        if atom is None:
            return fail(f"unknown atom_id: {args.atom_id}")
        selected = [atom]
        label = args.atom_id
    else:
        label = args.group_id
        selected = [
            row for row in rows
            if row.get("surface_group_id") == args.group_id
            and row.get("surface_group_mode") == "CONTIGUOUS_BYTE_EXACT"
        ]
        if not selected:
            return fail(f"unknown contiguous exact group: {args.group_id}")
        selected.sort(key=lambda row: int(row["source_byte_start"]))

    for row in selected:
        atom_id = str(row.get("atom_id", ""))
        if row.get("surface_mode") != "BYTE_EXACT":
            return fail(f"{atom_id}: is not BYTE_EXACT")
        if row.get("output_operation") != "COPY_SOURCE_SLICE":
            return fail(f"{atom_id}: exact atom output_operation must be COPY_SOURCE_SLICE")

    start = min(int(row["source_byte_start"]) for row in selected)
    end = max(int(row["source_byte_end"]) for row in selected)
    exact_bytes = source[start:end]
    try:
        exact_bytes.decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        return fail(f"exact source span splits UTF-8: {exc}")

    out_path = Path(args.output_file).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(exact_bytes)

    manifest = {
        "schema_version": "copy-source-slice-manifest-v1",
        "source_revision_id": revision.get("source_revision_id"),
        "target": label,
        "source_byte_start": start,
        "source_byte_end": end,
        "source_slice_sha256": sha256_bytes(exact_bytes),
        "operation": "COPY_SOURCE_SLICE",
        "output_file": out_path.name,
    }
    manifest_path = out_path.with_suffix(out_path.suffix + ".manifest.json")
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n",
        encoding="utf-8",
    )

    print("OK")
    print(f"operation=COPY_SOURCE_SLICE target={label} bytes={len(exact_bytes)} sha256={manifest['source_slice_sha256']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
