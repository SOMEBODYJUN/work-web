#!/usr/bin/env python3
"""Freeze an uploaded UTF-8 text file and establish the current source revision.

Default behavior is identity:

    uploaded .txt bytes
    -> source_original.txt  (immutable upload copy)
    -> source_canonical.txt (identical current source revision)

No text transformation occurs unless an explicit canonicalization flag is supplied.
Legacy files ``canonical_source.txt`` and ``source.txt`` are byte-for-byte mirrors
only; they are not independent authorities.
"""
from __future__ import annotations

from pathlib import Path
import argparse
import hashlib
import json

from safe_io import atomic_write_bytes, atomic_write_json, atomic_write_text, read_bytes_strict
from content_authority import SOURCE_REVISION_SCHEMA


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def normalize_text(
    text: str,
    *,
    strip_bom: bool = False,
    normalize_line_endings: bool = False,
) -> tuple[str, list[dict[str, object]]]:
    original_text = text
    operations: list[str] = []
    if strip_bom and text.startswith("\ufeff"):
        text = text[1:]
        operations.append("REMOVE_UTF8_BOM")
    if normalize_line_endings and "\r" in text:
        text = text.replace("\r\n", "\n").replace("\r", "\n")
        operations.append("NORMALIZE_LINE_ENDINGS_TO_LF")

    operation = "+".join(operations) if operations else "IDENTITY"
    rows: list[dict[str, object]] = [{
        "schema_version": "source-normalization-map-v3",
        "map_id": "N0001",
        "span_unit": "utf8_byte_offset",
        "original_byte_span": f"0-{len(original_text.encode('utf-8'))}",
        "original_codepoint_span": f"0-{len(original_text)}",
        "canonical_byte_span": f"0-{len(text.encode('utf-8'))}",
        "canonical_codepoint_span": f"0-{len(text)}",
        "operation": operation,
        "note": (
            "source_original.txt is immutable. IDENTITY means source_canonical.txt "
            "must be byte-for-byte identical. Any later user-authorized change is a "
            "versioned source patch, not canonicalization."
        ),
    }]
    return text, rows


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Freeze an uploaded UTF-8 text file and create an identity canonical source revision."
    )
    parser.add_argument("input", help="uploaded UTF-8 text source")
    parser.add_argument("output_dir", nargs="?", default=".", help="output directory")
    parser.add_argument("--strip-bom", action="store_true", help="explicitly remove one leading UTF-8 BOM from the canonical revision")
    parser.add_argument("--normalize-line-endings", action="store_true", help="explicitly normalize CRLF/CR to LF")
    parser.add_argument("--nfkc", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()

    if args.nfkc:
        parser.error("--nfkc is forbidden: compatibility normalization can change mathematical meaning")

    input_path = Path(args.input)
    out = Path(args.output_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)

    original_bytes = read_bytes_strict(input_path)
    try:
        original_text = original_bytes.decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        print("FAILED")
        print(f"- input is not strict UTF-8: byte {exc.start}: {exc.reason}")
        return 1

    canonical_text, map_rows = normalize_text(
        original_text,
        strip_bom=args.strip_bom,
        normalize_line_endings=args.normalize_line_endings,
    )
    canonical_bytes = canonical_text.encode("utf-8")
    transformation = str(map_rows[0]["operation"])

    # Primary source files.
    atomic_write_bytes(out / "source_original.txt", original_bytes)
    atomic_write_bytes(out / "source_canonical.txt", canonical_bytes)

    # Legacy read-only mirrors for old validators/tools. They have no independent authority.
    atomic_write_bytes(out / "canonical_source.txt", canonical_bytes)
    atomic_write_bytes(out / "source.txt", canonical_bytes)

    original_hash = sha256_bytes(original_bytes)
    canonical_hash = sha256_bytes(canonical_bytes)

    identity = {
        "schema_version": "source-identity-v3",
        "original_file": "source_original.txt",
        "original_sha256": original_hash,
        "original_length_bytes": len(original_bytes),
        "canonical_file": "source_canonical.txt",
        "canonical_sha256": canonical_hash,
        "canonical_length_bytes": len(canonical_bytes),
        "canonical_length_codepoints": len(canonical_text),
        "canonical_transformation": transformation,
        "span_unit": "utf8_byte_offset",
        "legacy_mirror_files": ["canonical_source.txt", "source.txt"],
        "created_by": "scripts/canonicalize_source.py",
        "notes": (
            "The uploaded TXT begins directly as source_original.txt. Under IDENTITY, "
            "source_canonical.txt is the same byte sequence. No compatibility Unicode "
            "normalization is permitted."
        ),
    }
    provenance = {
        "schema_version": "source-provenance-v2",
        "original_source_file": "source_original.txt",
        "original_source_sha256": original_hash,
        "canonical_source_file": "source_canonical.txt",
        "canonical_source_sha256": canonical_hash,
        "canonical_transformation": transformation,
        "normalization_operations": [row["operation"] for row in map_rows],
        "span_unit": "utf8_byte_offset",
    }
    revision = {
        "schema_version": SOURCE_REVISION_SCHEMA,
        "source_revision_id": "R0001",
        "parent_revision_id": "none",
        "original_source_file": "source_original.txt",
        "original_source_sha256": original_hash,
        "canonical_source_file": "source_canonical.txt",
        "canonical_source_sha256": canonical_hash,
        "canonical_source_length_bytes": len(canonical_bytes),
        "canonical_transformation": transformation,
        "span_unit": "utf8_byte_offset",
        "authority": "CURRENT_CANONICAL_SOURCE_ONLY",
        "applied_patch_ids": "",
        "downstream_state": "REATOMIZE_REQUIRED",
        "created_by": "scripts/canonicalize_source.py",
    }

    atomic_write_json(out / "source_identity.json", identity)
    atomic_write_json(out / "source_provenance.json", provenance)
    atomic_write_json(out / "source_revision.json", revision)
    atomic_write_text(
        out / "source_normalization_map.jsonl",
        "".join(
            json.dumps(row, ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n"
            for row in map_rows
        ),
    )

    print("OK")
    print(f"original_sha256={original_hash}")
    print(f"canonical_sha256={canonical_hash}")
    print(f"canonical_transformation={transformation}")
    print(f"canonical_length_bytes={len(canonical_bytes)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
