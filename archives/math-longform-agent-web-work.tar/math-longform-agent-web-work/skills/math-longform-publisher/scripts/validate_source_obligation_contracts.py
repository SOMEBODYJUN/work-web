#!/usr/bin/env python3
"""Validate the P03 -> P04 source-obligation responsibility handoff."""
from __future__ import annotations

from pathlib import Path
import sys

from content_functions import read_jsonl
from safe_io import read_json_strict
from source_obligations import source_obligation_contracts


def main() -> int:
    root = (Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")).resolve()
    try:
        blueprint = read_json_strict(root / "publication_blueprint.json", root=root)
        if not isinstance(blueprint, dict):
            raise ValueError("publication_blueprint.json must contain one object")
        atoms = read_jsonl(root / "source_atom_ledger.jsonl")
        contracts, errors = source_obligation_contracts(
            root, blueprint, atoms, require_ledgers=True
        )
    except Exception as exc:
        errors = [str(exc)]
        contracts = {}
    if errors:
        print("FAILED")
        for error in errors:
            print(f"- {error}")
        return 1
    print("OK")
    print(f"source_obligation_contracts={len(contracts)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
