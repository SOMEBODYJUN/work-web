#!/usr/bin/env python3
"""Validate that ledgers are consumed by plans and post-hoc trace maps."""
from pathlib import Path
import re
import sys

REQUIRED_INPUTS = [
    "source_atom_ledger.md", "math_statement_ledger.md", "proof_obligations.md",
    "voice_expression_ledger.md", "symbol_ledger.md", "explanation_chain_ledger.md",
    "section_plan.md", "pre_final_plan.md", "final_trace_map.md", "final_claim_ledger.md",
]

def read(p):
    return p.read_text(encoding="utf-8") if p.exists() else ""

def rows(text, prefix):
    return re.findall(rf"^\|\s*({prefix}\d+)\s*\|(.+)$", text, flags=re.M)

def all_ids(text, prefix):
    return set(re.findall(rf"\b{prefix}\d{{3,}}\b", text))

def bad_placeholders(text):
    return re.search(r"\b(TBD|TODO|pending|unknown|unclear)\b|待定|未定|不清楚|\?\s*(?:\||$)", text, flags=re.I)

def main():
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    failures = []
    for name in REQUIRED_INPUTS:
        p = root / name
        if not p.exists() or not read(p).strip():
            failures.append(f"missing or empty {name}")

    atom = read(root / "source_atom_ledger.md")
    statements = read(root / "math_statement_ledger.md")
    proofs = read(root / "proof_obligations.md")
    section = read(root / "section_plan.md")
    plan = read(root / "pre_final_plan.md")
    trace = read(root / "final_trace_map.md")
    claims = read(root / "final_claim_ledger.md")
    index = read(root / "final_paragraph_index.md")

    atom_ids = all_ids(atom, "A")
    st_ids = all_ids(statements, "S")
    pr_ids = all_ids(proofs, "PR")
    trace_ids = all_ids(trace, "P")
    index_ids = all_ids(index, "P")

    if len(atom_ids) < 5:
        failures.append(f"source_atom_ledger.md has too few atom ids: {len(atom_ids)}")
    if st_ids and not (st_ids & all_ids(plan + trace + claims, "S")):
        failures.append("math statement ids are not consumed by pre_final_plan/final_trace_map/final_claim_ledger")
    if atom_ids and not (atom_ids & all_ids(plan + trace + claims, "A")):
        failures.append("atom ids are not consumed by pre_final_plan/final_trace_map/final_claim_ledger")
    if pr_ids and not (pr_ids & set(re.findall(r"\bPR\d{3,}\b", plan + trace + claims))):
        failures.append("proof ids are not consumed by pre_final_plan/final_trace_map/final_claim_ledger")

    if not all_ids(plan, "A") and not all_ids(plan, "S"):
        failures.append("pre_final_plan.md does not cite atom or statement ids")
    if not all_ids(section, "A") and not all_ids(section, "S"):
        failures.append("section_plan.md does not cite atom or statement ids")

    if index_ids:
        missing = sorted(index_ids - trace_ids)
        if missing:
            failures.append("final_paragraph_index ids missing from final_trace_map: " + ", ".join(missing[:20]))

    for pid, rest in rows(trace, "P"):
        if not re.search(r"\bA\d{3,}\b|\bS\d{3,}\b|\bPR\d{3,}\b", rest):
            failures.append(f"{pid} has no atom/statement/proof support in final_trace_map")
        if bad_placeholders(rest):
            failures.append(f"{pid} contains placeholder/pending support")

    claim_rows = rows(claims, "CL")
    if not claim_rows:
        failures.append("final_claim_ledger.md has no claim rows")
    for cid, rest in claim_rows:
        if not re.search(r"\bA\d{3,}\b|\bS\d{3,}\b|\bPR\d{3,}\b", rest):
            failures.append(f"{cid} has no atom/statement/proof support")
        if re.search(r"unsupported", rest, flags=re.I):
            failures.append(f"{cid} is marked unsupported")
        if bad_placeholders(rest):
            failures.append(f"{cid} contains placeholder/pending support")

    if (root / "final_paragraph_trace.md").exists() and not (root / "final_trace_map.md").exists():
        failures.append("deprecated final_paragraph_trace.md exists without final_trace_map.md")

    if failures:
        print("FAILED")
        for f in failures:
            print(f"- {f}")
        return 1
    print("OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
