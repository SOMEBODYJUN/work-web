#!/usr/bin/env python3
"""Validate byte-exact authorization for every final-publication fragment."""
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import re
import sys

ALLOWED_TYPES = {
    "SOURCE_EXACT",
    "SOURCE_REORGANIZATION",
    "MATHEMATICAL_COMPLETION",
    "FORMULA_NORMALIZATION",
    "STRUCTURAL_LABEL",
    "MINIMAL_CONNECTIVE",
    "USER_REQUESTED",
    "TASK_DIRECTIVE_EXPANSION",
    "FORMAT_SYNTAX",
}
CONNECTIVE_FUNCTIONS = {
    "SEQUENCE",
    "CONTRAST",
    "CONCLUSION",
    "CONVERSE",
    "LOCAL_REFERENCE",
    "GRAMMATICAL_LINK",
}
EDITORIAL_STANCE_PATTERNS = [
    r"收起来", r"讲一下", r"真正(?:重要|核心|值得)", r"底层逻辑",
    r"把视线", r"回头看", r"事情到这里", r"一口气", r"完整闭环",
    r"不妨停", r"先别急", r"看懂这篇", r"灵魂", r"秘密", r"冒险",
]
ID_RE = re.compile(r"^A\d{4,}$")
EXP_RE = re.compile(r"^EXP\d{3,}$")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def fail(errors: list[str]) -> int:
    print("FAILED")
    for error in errors:
        print(f"- {error}")
    return 1


def load_jsonl(path: Path) -> list[dict]:
    rows: list[dict] = []
    for lineno, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            value = json.loads(line)
        except Exception as exc:
            raise ValueError(f"{path.name}:{lineno}: invalid JSON: {exc}") from exc
        if not isinstance(value, dict):
            raise ValueError(f"{path.name}:{lineno}: row is not an object")
        rows.append(value)
    return rows


def atom_map(root: Path) -> dict[str, dict]:
    path = root / "source_atom_ledger.jsonl"
    if not path.exists():
        return {}
    return {str(row.get("atom_id", "")): row for row in load_jsonl(path)}


def substantive_text(raw: bytes) -> str:
    return raw.decode("utf-8", errors="strict")


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    article_path = root / "publication_final.md"
    ledger_path = root / "publication_fragment_authorization.jsonl"
    source_path = root / "source_canonical.txt"
    required = [article_path, ledger_path, source_path]
    missing = [p.name for p in required if not p.exists()]
    if missing:
        return fail(["missing required fragment-authorization file: " + ", ".join(missing)])

    try:
        article = article_path.read_bytes()
        source = source_path.read_bytes()
        rows = load_jsonl(ledger_path)
        atoms = atom_map(root)
        quality = json.loads((root / "quality_contract.json").read_text(encoding="utf-8"))
        known_directives = {
            str(row.get("directive_id", ""))
            for row in quality.get("expansion_budgets", [])
        }
    except Exception as exc:
        return fail([str(exc)])

    errors: list[str] = []
    if not rows:
        errors.append("publication_fragment_authorization.jsonl is empty")
        return fail(errors)

    seen_ids: set[str] = set()
    cursor = 0
    for idx, row in enumerate(rows, 1):
        fid = str(row.get("fragment_id", ""))
        if not fid or fid in seen_ids:
            errors.append(f"row {idx}: missing or duplicate fragment_id")
        seen_ids.add(fid)

        try:
            start = int(row.get("output_byte_start"))
            end = int(row.get("output_byte_end"))
        except Exception:
            errors.append(f"{fid or idx}: invalid output byte span")
            continue
        if start != cursor:
            relation = "gap" if start > cursor else "overlap/out-of-order"
            errors.append(f"{fid or idx}: {relation}: expected start {cursor}, got {start}")
        if end <= start or end > len(article):
            errors.append(f"{fid or idx}: invalid output span [{start},{end})")
            cursor = max(cursor, end)
            continue

        raw = article[start:end]
        cursor = end
        if str(row.get("output_text_sha256", "")) != sha(raw):
            errors.append(f"{fid}: output_text_sha256 mismatch")
        if row.get("output_file") not in {None, "", "publication_final.md"}:
            errors.append(f"{fid}: output_file must be publication_final.md")

        auth = str(row.get("authorization_type", ""))
        if auth not in ALLOWED_TYPES:
            errors.append(f"{fid}: invalid authorization_type {auth!r}")
            continue
        if str(row.get("review_status", "")) != "APPROVED":
            errors.append(f"{fid}: review_status must be APPROVED")
        try:
            text = substantive_text(raw)
        except UnicodeDecodeError:
            errors.append(f"{fid}: output span does not align to UTF-8 character boundaries")
            continue

        source_ids = row.get("source_atom_ids", [])
        if not isinstance(source_ids, list):
            errors.append(f"{fid}: source_atom_ids must be a list")
            source_ids = []
        unknown = [sid for sid in source_ids if not ID_RE.fullmatch(str(sid)) or (atoms and str(sid) not in atoms)]
        if unknown:
            errors.append(f"{fid}: unknown source atom ids: {unknown}")
        task_ids = row.get("task_directive_ids", [])
        if not isinstance(task_ids, list):
            errors.append(f"{fid}: task_directive_ids must be a list")
            task_ids = []
        unknown_tasks = [
            item for item in task_ids
            if not EXP_RE.fullmatch(str(item)) or str(item) not in known_directives
        ]
        if unknown_tasks:
            errors.append(f"{fid}: unknown author task directives: {unknown_tasks}")

        if auth == "SOURCE_EXACT":
            evidence = row.get("source_slice")
            if not isinstance(evidence, dict):
                errors.append(f"{fid}: SOURCE_EXACT requires source_slice")
            else:
                try:
                    ss = int(evidence.get("source_byte_start"))
                    se = int(evidence.get("source_byte_end"))
                    src_raw = source[ss:se]
                    if ss < 0 or se <= ss or se > len(source):
                        raise ValueError("bad source span")
                    if src_raw != raw:
                        errors.append(f"{fid}: SOURCE_EXACT output is not the current source slice")
                    if str(evidence.get("source_text_sha256", "")) != sha(src_raw):
                        errors.append(f"{fid}: source slice hash mismatch")
                except Exception:
                    errors.append(f"{fid}: invalid SOURCE_EXACT source span")
            if not source_ids:
                errors.append(f"{fid}: SOURCE_EXACT requires source_atom_ids")

        elif auth == "SOURCE_REORGANIZATION":
            if not source_ids:
                errors.append(f"{fid}: SOURCE_REORGANIZATION requires source_atom_ids")
            preserved = row.get("preserved_invariants", [])
            if not isinstance(preserved, list) or not preserved:
                errors.append(f"{fid}: SOURCE_REORGANIZATION requires preserved_invariants")
            if len(text.strip()) > 0 and len(raw) > 480:
                errors.append(f"{fid}: SOURCE_REORGANIZATION fragment too broad; split below 480 bytes")

        elif auth == "MATHEMATICAL_COMPLETION":
            if not source_ids:
                errors.append(f"{fid}: MATHEMATICAL_COMPLETION requires source_atom_ids")
            if row.get("completion_basis") != "SOURCE_ROUTE_COMPLETION":
                errors.append(f"{fid}: mathematical completion must use SOURCE_ROUTE_COMPLETION")
            if len(str(row.get("necessity", "")).strip()) < 20:
                errors.append(f"{fid}: mathematical completion necessity is too shallow")
            invariants = row.get("preserved_invariants", [])
            if not isinstance(invariants, list) or not invariants:
                errors.append(f"{fid}: mathematical completion requires preserved_invariants")
            if len(raw) > 720:
                errors.append(f"{fid}: mathematical completion fragment too broad; split below 720 bytes")

        elif auth == "FORMULA_NORMALIZATION":
            if not source_ids:
                errors.append(f"{fid}: FORMULA_NORMALIZATION requires source_atom_ids")
            if row.get("completion_basis") != "FORMULA_NORMALIZATION":
                errors.append(f"{fid}: formula fragment must use FORMULA_NORMALIZATION basis")
            if not re.search(r"[$\\]", text):
                errors.append(f"{fid}: formula normalization fragment contains no math surface")

        elif auth == "MINIMAL_CONNECTIVE":
            compact = re.sub(r"\s+", "", text)
            if len(compact) > 12:
                errors.append(f"{fid}: MINIMAL_CONNECTIVE exceeds 12 non-space characters")
            if row.get("connective_function") not in CONNECTIVE_FUNCTIONS:
                errors.append(f"{fid}: invalid connective_function")
            if source_ids:
                errors.append(f"{fid}: MINIMAL_CONNECTIVE must not hide broad source attribution")
            if any(re.search(pattern, compact) for pattern in EDITORIAL_STANCE_PATTERNS):
                errors.append(f"{fid}: editorial stance cannot be authorized as MINIMAL_CONNECTIVE")
            if str(row.get("deletion_impact", "")) not in {"GRAMMATICAL_BREAK", "LOGICAL_LINK_LOSS"}:
                errors.append(f"{fid}: MINIMAL_CONNECTIVE requires a concrete deletion_impact")

        elif auth == "STRUCTURAL_LABEL":
            if not row.get("heading_id") and not row.get("label_function"):
                errors.append(f"{fid}: STRUCTURAL_LABEL requires heading_id or label_function")

        elif auth == "USER_REQUESTED":
            feedback_ids = row.get("feedback_ids", [])
            if not isinstance(feedback_ids, list) or not feedback_ids:
                errors.append(f"{fid}: USER_REQUESTED requires feedback_ids")

        elif auth == "TASK_DIRECTIVE_EXPANSION":
            if source_ids:
                errors.append(f"{fid}: task expansion cannot also receive source-reorganization credit")
            if not task_ids:
                errors.append(f"{fid}: TASK_DIRECTIVE_EXPANSION requires task_directive_ids")
            if row.get("completion_basis") != "TASK_DIRECTIVE_EXPANSION":
                errors.append(f"{fid}: task expansion requires its explicit completion basis")

        elif auth == "FORMAT_SYNTAX":
            # Formatting rows may contain whitespace or Markdown/LaTeX delimiters only.
            stripped = re.sub(r"[\s#>*_`~\-\[\]\(\){}|:;,.，。；：!?！？$\\]+", "", text)
            if stripped:
                errors.append(f"{fid}: FORMAT_SYNTAX contains substantive text: {stripped[:30]!r}")

        for pattern in EDITORIAL_STANCE_PATTERNS:
            if re.search(pattern, text) and auth not in {"SOURCE_EXACT", "USER_REQUESTED"}:
                errors.append(f"{fid}: unsupported editorial stance phrase matched {pattern!r}")

    if cursor != len(article):
        errors.append(f"fragment ledger does not cover final bytes: stopped at {cursor}, file length {len(article)}")

    if errors:
        return fail(errors)
    print(f"OK: authorized_fragments={len(rows)} article_bytes={len(article)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
