#!/usr/bin/env python3
"""Compatibility entry point for the P12 mechanical publication assembler."""
from publication_assembler import main


if __name__ == "__main__":
    raise SystemExit(main())
