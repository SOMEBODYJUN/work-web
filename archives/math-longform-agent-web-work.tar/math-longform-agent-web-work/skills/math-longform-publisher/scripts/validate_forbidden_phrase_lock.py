#!/usr/bin/env python3
"""Fail article-surface outputs that contain hard-banned assistant/editor phrases."""
from __future__ import annotations

import json
from pathlib import Path
import re
import sys

from content_authority import atom_map, atom_source_bytes, load_jsonl_objects, split_ids, split_output_units

FORBIDDEN_PHRASES = [
    "现场口气",
    "收束",
    "收住",
    "不影响后面证明",
    "开头就当",
    "这段情绪",
    "处理成",
    "保留为",
    "处理者口吻",
    "足球情绪先放在这里",
    "情绪先放在这里",
    "先放在这里",
    "先放一边",
    "先搁一边",
]
FORBIDDEN_PATTERNS = [
    (re.compile(r"现场.{0,4}口[气吻]"), "现场口气/口吻 family"),
    (re.compile(r"口[气吻].{0,8}收[束住]"), "口气收束/收住 family"),
    (re.compile(r"收[束住].{0,6}(?:一下|一点|掉|掉吧)?"), "收束/收住 family"),
    (re.compile(r"不影响.{0,8}(?:后面|后文).{0,4}(?:证明|论证)"), "不影响后面证明 family"),
    (re.compile(r"开头.{0,8}(?:就当|当作|作为).{0,14}(?:现场|情绪|笔记|自用)"), "开头当作现场情绪 family"),
    (re.compile(r"这段.{0,8}(?:情绪|现场).{0,10}(?:处理|保留|收束|收住)"), "这段情绪处理 family"),
    (re.compile(r"(?:处理|保留).{0,8}(?:成|为).{0,12}(?:现场|情绪|口吻|笔记)"), "处理成现场/情绪/口吻 family"),
    (re.compile(r"(?:编辑|处理者|旁白).{0,8}(?:口吻|口气)"), "处理者口吻 family"),
    (re.compile(r"(?:足球)?情绪.{0,8}(?:先)?放(?:在)?这[里儿]"), "情绪先放在这里 family"),
    (re.compile(r"(?:情绪|话题|足球).{0,8}先(?:放|搁).{0,6}(?:一边|这[里儿])"), "话题/情绪先放一边 family"),
]

ARTICLE_FILES = [
    "draft.md",
    "final.md",
    "optimized_final.md",
    "standardized_final.md",
    "revised_final.md",
    "aigc_rewritten_final.md",
    "publication_final.md",
    "wechat_publication_final.md",
]


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def load_legacy_exact_lock_rows(root: Path) -> list[dict[str, str]]:
    """Load the retired ledger only to reject independent handwritten authority."""
    path = root / "surface_exact_lock_ledger.jsonl"
    if not path.exists() or not read_text(path).strip():
        return []
    rows: list[dict[str, str]] = []
    for line_no, line in enumerate(read_text(path).splitlines(), 1):
        if not line.strip():
            continue
        try:
            obj = json.loads(line)
        except Exception as exc:
            rows.append({"lock_id": f"<invalid:{line_no}>", "_error": f"invalid JSONL row: {exc}"})
            continue
        if isinstance(obj, dict):
            rows.append({str(k): str(v) for k, v in obj.items()})
    return rows


def load_source_authority(root: Path) -> tuple[str, dict[str, dict], list[dict], list] | None:
    """Load current source atoms and deterministic final units for source-origin exceptions."""
    try:
        source_bytes, _revision, atom_rows = atom_source_bytes(root)
        source_text = source_bytes.decode("utf-8", errors="strict")
        atoms = atom_map(atom_rows)
        trace_path = root / "publication_sentence_trace.jsonl"
        final_path = root / "publication_final.md"
        if not trace_path.exists() or not final_path.exists():
            return source_text, atoms, [], []
        traces = load_jsonl_objects(trace_path)
        units = split_output_units(final_path.read_text(encoding="utf-8"))
        return source_text, atoms, traces, units
    except Exception:
        return None


def source_authorized_occurrence(
    *,
    rel: str,
    article_text: str,
    start_char: int,
    end_char: int,
    matched_text: str,
    authority: tuple[str, dict[str, dict], list[dict], list] | None,
) -> bool:
    """Allow a banned-looking fragment only when it is current-source content.

    For the authoritative final article, require the real deterministic output unit
    to cite a current atom whose canonical source slice contains the exact fragment.
    Intermediate article files may retain an exact current-source fragment, but they
    cannot grant authority to text absent from the source.
    """
    if authority is None or not matched_text:
        return False
    source_text, atoms, traces, units = authority
    if matched_text not in source_text:
        return False
    if rel != "publication_final.md":
        return True

    start_byte = len(article_text[:start_char].encode("utf-8"))
    end_byte = len(article_text[:end_char].encode("utf-8"))
    unit_index = None
    for index, unit in enumerate(units):
        if unit.byte_start <= start_byte and end_byte <= unit.byte_end:
            unit_index = index
            break
    if unit_index is None or unit_index >= len(traces):
        return False
    row = traces[unit_index]
    if row.get("output_unit_id") != units[unit_index].output_unit_id:
        return False
    atom_ids = split_ids(row.get("source_atom_ids"), "A")
    return any(matched_text in str(atoms[atom_id].get("raw_excerpt", "")) for atom_id in atom_ids if atom_id in atoms)


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    failures: list[str] = []
    checked = 0
    authority = load_source_authority(root)
    for rel in ARTICLE_FILES:
        path = root / rel
        if not path.exists():
            continue
        checked += 1
        text = path.read_text(encoding="utf-8")
        for phrase in FORBIDDEN_PHRASES:
            for match in re.finditer(re.escape(phrase), text):
                if not source_authorized_occurrence(
                    rel=rel,
                    article_text=text,
                    start_char=match.start(),
                    end_char=match.end(),
                    matched_text=match.group(0),
                    authority=authority,
                ):
                    failures.append(f"{rel} contains unsupported hard-banned phrase: {phrase}")
        for pattern, label in FORBIDDEN_PATTERNS:
            for match in pattern.finditer(text):
                if not source_authorized_occurrence(
                    rel=rel,
                    article_text=text,
                    start_char=match.start(),
                    end_char=match.end(),
                    matched_text=match.group(0),
                    authority=authority,
                ):
                    failures.append(f"{rel} contains unsupported hard-banned phrase pattern: {label}")

    for row in load_legacy_exact_lock_rows(root):
        lock_id = row.get("lock_id", "<unknown>")
        if row.get("_error"):
            failures.append(f"{lock_id}: {row['_error']}")
            continue
        if "locked_text" in row:
            failures.append(
                f"{lock_id}: handwritten locked_text authority is retired; "
                "mark canonical source atoms surface_mode=BYTE_EXACT instead"
            )
        else:
            failures.append(
                f"{lock_id}: independent surface_exact_lock_ledger authority is retired; "
                "exact surface constraints must be derived from canonical atom spans"
            )

    if failures:
        print("FAILED")
        for f in failures:
            print(f"- {f}")
        return 1
    print("OK")
    print(f"checked_article_files={checked} hard_banned_phrases={len(FORBIDDEN_PHRASES)} hard_banned_patterns={len(FORBIDDEN_PATTERNS)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
