#!/usr/bin/env python3
"""Strict local I/O and JSON helpers for publication validators.

These helpers deliberately fail closed: malformed UTF-8, duplicate JSON keys,
NaN/Infinity, symlinks, and non-regular files are validation errors rather
than data that may be silently ignored.
"""
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import os
import stat
import tempfile
from typing import Any, Iterable


class DuplicateKeyError(ValueError):
    pass


def _reject_duplicate_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in pairs:
        if key in out:
            raise DuplicateKeyError(f"duplicate JSON key: {key}")
        out[key] = value
    return out


def _reject_constant(value: str) -> None:
    raise ValueError(f"non-standard JSON constant is forbidden: {value}")


def strict_json_loads(text: str) -> Any:
    return json.loads(
        text,
        object_pairs_hook=_reject_duplicate_pairs,
        parse_constant=_reject_constant,
    )


def ensure_regular_file(path: Path, *, root: Path | None = None) -> Path:
    path = Path(path)
    if root is not None:
        root = Path(root).resolve()
        # Resolve the parent only; the leaf may not yet exist for writes.
        parent = path.parent.resolve()
        try:
            parent.relative_to(root)
        except ValueError as exc:
            raise ValueError(f"path escapes allowed root: {path}") from exc
    try:
        mode = path.lstat().st_mode
    except FileNotFoundError:
        raise
    if stat.S_ISLNK(mode):
        raise ValueError(f"symlink is forbidden: {path}")
    if not stat.S_ISREG(mode):
        raise ValueError(f"non-regular file is forbidden: {path}")
    return path


def read_bytes_strict(path: Path, *, root: Path | None = None) -> bytes:
    path = ensure_regular_file(Path(path), root=root)
    return path.read_bytes()


def read_text_strict(path: Path, *, root: Path | None = None) -> str:
    return read_bytes_strict(path, root=root).decode("utf-8", errors="strict")


def read_optional_text(path: Path, *, root: Path | None = None) -> str:
    path = Path(path)
    if not path.exists():
        return ""
    return read_text_strict(path, root=root)


def read_json_strict(path: Path, *, root: Path | None = None) -> Any:
    return strict_json_loads(read_text_strict(path, root=root))


def read_jsonl_strict(path: Path, *, root: Path | None = None) -> list[dict[str, Any]]:
    text = read_text_strict(path, root=root)
    rows: list[dict[str, Any]] = []
    for line_no, line in enumerate(text.splitlines(), start=1):
        if not line.strip():
            continue
        try:
            value = strict_json_loads(line)
        except Exception as exc:
            raise ValueError(f"{path.name} line {line_no}: {exc}") from exc
        if not isinstance(value, dict):
            raise ValueError(f"{path.name} line {line_no}: expected JSON object")
        rows.append(value)
    if not rows:
        raise ValueError(f"{path.name}: no JSON object rows")
    return rows


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path, *, root: Path | None = None) -> str:
    return sha256_bytes(read_bytes_strict(path, root=root))


def atomic_write_bytes(path: Path, data: bytes) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.is_symlink():
        raise ValueError(f"refusing to replace symlink: {path}")
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    tmp = Path(tmp_name)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
        # Best-effort directory durability on POSIX.
        try:
            dir_fd = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except OSError:
            pass
    finally:
        if tmp.exists():
            tmp.unlink()


def atomic_write_text(path: Path, text: str) -> None:
    atomic_write_bytes(path, text.encode("utf-8"))


def atomic_write_json(path: Path, value: Any) -> None:
    data = (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n").encode("utf-8")
    atomic_write_bytes(path, data)


def flatten_status_fields(value: Any, *, prefix: str = "") -> Iterable[tuple[str, Any]]:
    """Yield explicit state/status/verdict/result fields from nested JSON objects."""
    if isinstance(value, dict):
        for key, child in value.items():
            path = f"{prefix}.{key}" if prefix else str(key)
            key_l = str(key).lower()
            if key_l.endswith(("status", "state", "verdict", "decision", "result")):
                yield path, child
            yield from flatten_status_fields(child, prefix=path)
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            yield from flatten_status_fields(child, prefix=f"{prefix}[{idx}]")
