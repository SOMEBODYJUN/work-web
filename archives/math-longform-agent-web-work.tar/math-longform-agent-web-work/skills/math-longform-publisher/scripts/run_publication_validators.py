#!/usr/bin/env python3
"""Run the canonical pre-evidence validator chain and write tamper-evident evidence."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import shutil
import sys

from mode_utils import FULL_PUBLICATION, parse_mode_args, resolve_mode
from pipeline_registry import EVIDENCE_FILES, RELEASE_MODES, package_version, validator_specs_for_mode
from safe_io import atomic_write_bytes, atomic_write_json, atomic_write_text
from validator_runner import OUTPUT_DIR_TOKEN, argv_for_spec, portable_args, run_script

for stream in (sys.stdout, sys.stderr):
    if hasattr(stream, "reconfigure"):
        stream.reconfigure(encoding="utf-8", errors="replace")

EVIDENCE_NAMES = set(EVIDENCE_FILES) | {"PUBLICATION_AUDIT_REPORT.md"}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_sha256(path: Path) -> str:
    return sha256_bytes(path.read_bytes()) if path.exists() else ""


def output_tail(text: str, limit: int = 4000) -> str:
    text = text.strip()
    return text[-limit:] if len(text) > limit else text


def snapshot_dir(root: Path) -> str:
    items: list[dict[str, str | int]] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root).as_posix()
        if Path(rel).name in EVIDENCE_NAMES:
            continue
        if "__pycache__" in path.parts or "validator_evidence" in path.parts:
            continue
        data = path.read_bytes()
        items.append({"path": rel, "size": len(data), "sha256": sha256_bytes(data)})
    blob = json.dumps(
        items, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")
    return sha256_bytes(blob)


def validator_code_snapshot(scripts_dir: Path) -> str:
    items = []
    for path in sorted(scripts_dir.glob("*.py")):
        data = path.read_bytes()
        items.append({"path": path.name, "size": len(data), "sha256": sha256_bytes(data)})
    blob = json.dumps(
        items, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")
    return sha256_bytes(blob)


def replace_or_append_field(
    text: str,
    name: str,
    value: str,
    section_heading: str = "## Validator Evidence Lock",
) -> str:
    pattern = re.compile(rf"^\s*{re.escape(name)}\s*:\s*.*$", re.M)
    text = pattern.sub("", text)
    text = re.sub(r"\n{3,}", "\n\n", text).rstrip() + "\n"
    line = f"{name}: {value}"
    if section_heading in text:
        return text.replace(section_heading, section_heading + "\n\n" + line, 1)
    return text.rstrip() + "\n\n" + section_heading + "\n\n" + line + "\n"


def sync_publication_audit_report(root: Path, evidence: dict, result_sha: str) -> bool:
    path = root / "PUBLICATION_AUDIT_REPORT.md"
    if not path.exists():
        return False
    text = path.read_text(encoding="utf-8")
    for name, value in (
        ("RUN_MODE", str(evidence["run_mode"])),
        ("VALIDATOR_RESULT_FILE", "validator_result.json"),
        ("VALIDATOR_RESULT_SHA256", result_sha),
        ("VALIDATOR_RESULT_GENERATED_BY", "scripts/run_publication_validators.py"),
        ("TARGET_SNAPSHOT_SHA256", str(evidence["target_snapshot_sha256"])),
    ):
        text = replace_or_append_field(text, name, value)

    code = int(evidence["overall_exit_code"])
    verdict = "PASS" if code == 0 else "FAIL"
    row = (
        f"| python scripts/run_publication_validators.py | {root.name or 'output_dir'} "
        f"| {code} | {verdict} | mode={evidence['run_mode']} "
        f"machine-generated validator_result.json sha256={result_sha} |"
    )

    lines = text.splitlines()
    in_section = False
    replaced = False
    out: list[str] = []
    for line in lines:
        if line.strip() == "## Command Evidence":
            in_section = True
            out.append(line)
            continue
        if in_section and line.startswith("## "):
            if not replaced:
                out.append(row)
                replaced = True
            in_section = False
            out.append(line)
            continue
        if in_section and line.startswith("|") and "run_publication_validators.py" in line:
            if not replaced:
                out.append(row)
                replaced = True
            continue
        out.append(line)
    if in_section and not replaced:
        out.append(row)
    text = "\n".join(out).rstrip() + "\n"
    if "## Command Evidence" not in text:
        text += (
            "\n## Command Evidence\n\n"
            "| command | target | exit_code | verdict | evidence_note |\n"
            "|---|---|---:|---|---|\n"
            + row
            + "\n"
        )
    atomic_write_text(path, text)
    return True


def main() -> int:
    try:
        explicit_mode, args = parse_mode_args(sys.argv[1:])
    except ValueError as exc:
        print("FAILED")
        print(f"- {exc}")
        return 1

    root = (Path(args[0]) if args else Path(".")).resolve()
    try:
        mode = resolve_mode(root, explicit_mode, allow_mode_file=False)
    except ValueError as exc:
        print("FAILED")
        print(f"- {exc}")
        return 1

    scripts = Path(__file__).resolve().parent
    include_wechat = mode == FULL_PUBLICATION and (root / "wechat_publication_final.md").exists()
    specs = validator_specs_for_mode(
        mode,
        include_post_evidence=False,
        include_optional_wechat=include_wechat,
    )
    code_snapshot = validator_code_snapshot(scripts)
    pre_snapshot = snapshot_dir(root)

    logs_dir = root / "validator_evidence"
    if logs_dir.exists():
        shutil.rmtree(logs_dir)
    logs_dir.mkdir(parents=True, exist_ok=True)

    results: list[dict[str, object]] = []
    failed: list[str] = []
    for index, spec in enumerate(specs, start=1):
        script = scripts / spec.script
        args_for_script = argv_for_spec(spec, root, mode)
        recorded_args = portable_args(args_for_script, root)
        command = "python scripts/" + spec.script
        if recorded_args:
            command += " " + " ".join(recorded_args)
        code, stdout, stderr, duration_ms = run_script(script, args_for_script)
        warning_lines = [
            line
            for line in (stdout + "\n" + stderr).splitlines()
            if line.strip().upper().startswith("WARNING:")
        ]
        if warning_lines and code == 0 and mode in RELEASE_MODES:
            code = 1
            stderr = (
                (stderr.rstrip() + "\n" if stderr.strip() else "")
                + "FAILED: release evidence forbids unresolved WARNING output"
            )
        verdict = "PASS" if code == 0 else "FAIL"
        if code:
            failed.append(spec.script)

        stdout_rel = f"validator_evidence/{index:03d}_{spec.script}.stdout.txt"
        stderr_rel = f"validator_evidence/{index:03d}_{spec.script}.stderr.txt"
        atomic_write_text(root / stdout_rel, stdout)
        atomic_write_text(root / stderr_rel, stderr)

        results.append(
            {
                "invocation_index": index,
                "stage": spec.stage,
                "script": spec.script,
                "command": command,
                "args": recorded_args,
                "exit_code": code,
                "verdict": verdict,
                "warning_count": len(warning_lines),
                "duration_ms": duration_ms,
                "script_sha256": file_sha256(script),
                "execution_closure_sha256": code_snapshot,
                "stdout_file": stdout_rel,
                "stderr_file": stderr_rel,
                "stdout_sha256": sha256_bytes(stdout.encode("utf-8")),
                "stderr_sha256": sha256_bytes(stderr.encode("utf-8")),
                "stdout_tail": output_tail(stdout),
                "stderr_tail": output_tail(stderr),
            }
        )
        print(f"== {spec.script} ==")
        print((stdout + ("\n" + stderr if stderr else "")).strip() or "(no output)")
        print(f"exit {code}\n")

    post_snapshot = snapshot_dir(root)
    stable = pre_snapshot == post_snapshot
    if not stable:
        failed.append("__package_stability__")
        print("FAILED: non-evidence package artifacts changed during validation")

    overall_exit = 0 if not failed else 1
    evidence = {
        "schema_version": "validator-result-v2",
        "package_version": package_version(),
        "run_mode": mode,
        "generated_by": "scripts/run_publication_validators.py",
        "generated_by_command": "python scripts/run_publication_validators.py <output_dir>",
        "generated_at_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "target_dir": OUTPUT_DIR_TOKEN,
        "argument_path_encoding": "output-dir-token-v1",
        "validator_code_snapshot_sha256": code_snapshot,
        "pre_validation_snapshot_sha256": pre_snapshot,
        "post_validation_snapshot_sha256": post_snapshot,
        "package_stable_during_validation": stable,
        "target_snapshot_sha256": post_snapshot,
        "overall_exit_code": overall_exit,
        "overall_verdict": "PASS" if overall_exit == 0 else "FAIL",
        "results": results,
    }

    result_bytes = (
        json.dumps(evidence, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")
    atomic_write_bytes(root / "validator_result.json", result_bytes)
    digest = sha256_bytes(result_bytes)
    atomic_write_text(root / "validator_result.sha256", f"{digest}  validator_result.json\n")

    summary = [
        "# Validator Result Summary",
        "",
        f"package_version: {evidence['package_version']}",
        f"run_mode: {mode}",
        f"generated_at_utc: {evidence['generated_at_utc']}",
        f"target_snapshot_sha256: {post_snapshot}",
        f"overall_verdict: {evidence['overall_verdict']}",
        f"overall_exit_code: {overall_exit}",
        f"validator_result_sha256: {digest}",
        "",
        "| stage | script | exit_code | verdict | duration_ms |",
        "|---|---|---:|---|---:|",
    ]
    for item in results:
        summary.append(
            f"| {item['stage']} | {item['script']} | {item['exit_code']} "
            f"| {item['verdict']} | {item['duration_ms']} |"
        )
    atomic_write_text(root / "validator_result.txt", "\n".join(summary) + "\n")
    audit_synced = sync_publication_audit_report(root, evidence, digest)

    audit_path = root / "PUBLICATION_AUDIT_REPORT.md"
    manifest = {
        "schema_version": "release-manifest-v2",
        "package_version": package_version(),
        "generated_by": "scripts/run_publication_validators.py",
        "run_mode": mode,
        "overall_verdict": evidence["overall_verdict"],
        "target_snapshot_sha256": post_snapshot,
        "validator_code_snapshot_sha256": code_snapshot,
        "package_stable_during_validation": stable,
        "validator_result_sha256": digest,
        "publication_audit_report_sha256": file_sha256(audit_path),
        "publication_final_sha256": file_sha256(root / "publication_final.md"),
        "wechat_publication_final_sha256": file_sha256(root / "wechat_publication_final.md"),
        "validator_log_files": [
            {
                "invocation_index": item["invocation_index"],
                "script": item["script"],
                "stdout_file": item["stdout_file"],
                "stdout_sha256": item["stdout_sha256"],
                "stderr_file": item["stderr_file"],
                "stderr_sha256": item["stderr_sha256"],
            }
            for item in results
        ],
    }
    atomic_write_json(root / "release_manifest.json", manifest)
    manifest_bytes = (root / "release_manifest.json").read_bytes()
    manifest_sha = sha256_bytes(manifest_bytes)
    atomic_write_text(root / "release_manifest.sha256", f"{manifest_sha}  release_manifest.json\n")

    print("VALIDATOR_EVIDENCE_WRITTEN" if not failed else "VALIDATOR_EVIDENCE_WRITTEN_WITH_FAILURES")
    if failed:
        print("failed:", ", ".join(failed))
    print(f"run_mode: {mode}")
    print(f"validator_result_sha256: {digest}")
    print(f"audit_report_synced: {audit_synced}")
    print(f"release_manifest_sha256: {manifest_sha}")
    return overall_exit


if __name__ == "__main__":
    raise SystemExit(main())
