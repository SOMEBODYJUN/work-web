#!/usr/bin/env python3
"""Apply one explicitly authorized patch and create a new canonical source revision."""
from __future__ import annotations

from pathlib import Path
import argparse
import base64
import json
import re

from content_authority import SOURCE_REVISION_SCHEMA, load_json_object, sha256_bytes, utf8_slice
from safe_io import atomic_write_bytes, atomic_write_json, atomic_write_text


def next_id(current: str, prefix: str) -> str:
    m = re.fullmatch(rf"{re.escape(prefix)}(\d+)", current)
    if not m:
        raise ValueError(f"invalid current id: {current}")
    return f"{prefix}{int(m.group(1)) + 1:04d}"


def main() -> int:
    parser = argparse.ArgumentParser(description="Apply an explicit current-user patch to source_canonical.txt.")
    parser.add_argument("output_dir")
    parser.add_argument("--start-byte", type=int, required=True)
    parser.add_argument("--end-byte", type=int, required=True)
    parser.add_argument("--replacement-file", required=True)
    parser.add_argument("--authorization-ref", required=True, help="current user instruction authorizing this exact patch")
    args = parser.parse_args()

    root = Path(args.output_dir).resolve()
    replacement_path = Path(args.replacement_file).resolve()
    required = [
        root / "source_original.txt",
        root / "source_canonical.txt",
        root / "source_revision.json",
        root / "source_identity.json",
        root / "source_provenance.json",
    ]
    missing = [p.name for p in required if not p.exists()]
    if missing:
        print("FAILED")
        print("- missing files: " + ", ".join(missing))
        return 1
    if not args.authorization_ref.strip():
        print("FAILED")
        print("- --authorization-ref must not be empty")
        return 1

    try:
        replacement = replacement_path.read_bytes()
        replacement.decode("utf-8", errors="strict")
        revision = load_json_object(root / "source_revision.json")
        identity = load_json_object(root / "source_identity.json")
        provenance = load_json_object(root / "source_provenance.json")
        current = (root / "source_canonical.txt").read_bytes()
        utf8_slice(current, args.start_byte, args.end_byte, "source patch")
    except Exception as exc:
        print("FAILED")
        print(f"- {exc}")
        return 1

    current_id = str(revision.get("source_revision_id", ""))
    new_id = next_id(current_id, "R")
    ledger_path = root / "source_patch_ledger.jsonl"
    existing_rows: list[dict] = []
    if ledger_path.exists() and ledger_path.read_text(encoding="utf-8").strip():
        for line in ledger_path.read_text(encoding="utf-8").splitlines():
            existing_rows.append(json.loads(line))
    patch_id = f"SP{len(existing_rows) + 1:04d}"

    archive_dir = root / "source_revisions" / current_id
    archive_dir.mkdir(parents=True, exist_ok=True)
    atomic_write_bytes(archive_dir / "source_canonical.txt", current)

    old_slice = current[args.start_byte:args.end_byte]
    updated = current[:args.start_byte] + replacement + current[args.end_byte:]
    updated_text = updated.decode("utf-8", errors="strict")
    updated_hash = sha256_bytes(updated)

    row = {
        "schema_version": "content-authority-source-patch-v2",
        "patch_id": patch_id,
        "base_revision_id": current_id,
        "result_revision_id": new_id,
        "base_source_sha256": sha256_bytes(current),
        "result_source_sha256": updated_hash,
        "source_byte_start": args.start_byte,
        "source_byte_end": args.end_byte,
        "expected_slice_sha256": sha256_bytes(old_slice),
        "replacement_utf8_b64": base64.b64encode(replacement).decode("ascii"),
        "replacement_sha256": sha256_bytes(replacement),
        "user_authorization_ref": args.authorization_ref.strip(),
        "status": "APPLIED_CURRENT_USER_PATCH",
    }
    existing_rows.append(row)

    applied = [x for x in re.split(r"[\s,;]+", str(revision.get("applied_patch_ids", ""))) if x]
    applied.append(patch_id)
    revision.update({
        "schema_version": SOURCE_REVISION_SCHEMA,
        "source_revision_id": new_id,
        "parent_revision_id": current_id,
        "canonical_source_file": "source_canonical.txt",
        "canonical_source_sha256": updated_hash,
        "canonical_source_length_bytes": len(updated),
        "canonical_transformation": "USER_PATCH_CHAIN",
        "span_unit": "utf8_byte_offset",
        "authority": "CURRENT_CANONICAL_SOURCE_ONLY",
        "applied_patch_ids": ",".join(applied),
        "downstream_state": "REATOMIZE_REQUIRED",
        "created_by": "scripts/apply_source_patch.py",
    })
    identity.update({
        "canonical_file": "source_canonical.txt",
        "canonical_sha256": updated_hash,
        "canonical_length_bytes": len(updated),
        "canonical_length_codepoints": len(updated_text),
        "canonical_transformation": "USER_PATCH_CHAIN",
        "span_unit": "utf8_byte_offset",
    })
    provenance.update({
        "canonical_source_file": "source_canonical.txt",
        "canonical_source_sha256": updated_hash,
        "canonical_transformation": "USER_PATCH_CHAIN",
        "applied_patch_ids": ",".join(applied),
        "span_unit": "utf8_byte_offset",
    })

    atomic_write_bytes(root / "source_canonical.txt", updated)
    atomic_write_bytes(root / "canonical_source.txt", updated)
    atomic_write_bytes(root / "source.txt", updated)
    atomic_write_json(root / "source_revision.json", revision)
    atomic_write_json(root / "source_identity.json", identity)
    atomic_write_json(root / "source_provenance.json", provenance)
    atomic_write_text(
        ledger_path,
        "".join(
            json.dumps(item, ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(",", ":")) + "\n"
            for item in existing_rows
        ),
    )

    print("OK")
    print(f"patch_id={patch_id} source_revision_id={new_id} canonical_sha256={updated_hash}")
    print("downstream_state=REATOMIZE_REQUIRED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
