#!/usr/bin/env python3
from pathlib import Path
import re
import sys

def rows(md, prefix):
    return re.findall(rf"^\|\s*({prefix}\d+)\s*\|(.+)$", md, flags=re.M)

def ids(md, prefix):
    return set(re.findall(rf"\b{prefix}\d{{3,}}\b", md))

def nonempty_paragraphs(md):
    blocks = [b.strip() for b in re.split(r"\n\s*\n", md) if b.strip()]
    return blocks

def read(p):
    return p.read_text(encoding="utf-8") if p.exists() else ""

def check_map(root, article_name, index_name, trace_name, claim_name, id_prefix, min_ratio=0.85):
    failures = []
    article_path = root / article_name
    index_path = root / index_name
    trace_path = root / trace_name
    claim_path = root / claim_name
    for p in [article_path, index_path, trace_path, claim_path]:
        if not p.exists() or not read(p).strip():
            failures.append(f"missing or empty {p.name}")
    if failures:
        return failures
    article = read(article_path)
    index = read(index_path)
    trace = read(trace_path)
    claims = read(claim_path)
    index_ids = ids(index, id_prefix)
    trace_ids = ids(trace, id_prefix)
    if not index_ids:
        failures.append(f"no {id_prefix} rows in {index_name}")
    if not trace_ids:
        failures.append(f"no {id_prefix} rows in {trace_name}")
    missing = sorted(index_ids - trace_ids)
    if missing:
        failures.append(f"{trace_name} missing ids from {index_name}: " + ", ".join(missing[:20]))
    count = len(nonempty_paragraphs(article))
    if len(index_ids) < max(1, int(count * min_ratio)):
        failures.append(f"{article_name} has {count} nonempty blocks, {index_name} has {len(index_ids)} rows")
    for pid, rest in rows(trace, id_prefix):
        if not re.search(r"\bA\d{3,}\b|\bS\d{3,}\b|\bPR\d{3,}\b", rest):
            failures.append(f"{pid} in {trace_name} lacks atom/statement/proof support")
        if re.search(r"pending|unknown|unclear|TODO|TBD|待定|不清楚", rest, flags=re.I):
            failures.append(f"{pid} in {trace_name} has unresolved placeholder")
    if not re.search(r"^\|\s*(?:CL|PCL)\d+\s*\|", claims, flags=re.M):
        failures.append(f"{claim_name} has no claim rows")
    return failures

def main():
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    failures = []
    failures.extend(check_map(root, "standardized_final.md", "final_paragraph_index.md", "final_trace_map.md", "final_claim_ledger.md", "P", 0.85))
    if (root / "publication_final.md").exists():
        failures.extend(check_map(root, "publication_final.md", "publication_paragraph_index.md", "publication_trace_map.md", "publication_claim_ledger.md", "PP", 0.90))
    chain_path = root / "explanation_chain_ledger.md"
    trace_all = read(root / "final_trace_map.md") + read(root / "publication_trace_map.md")
    if chain_path.exists():
        chains = ids(read(chain_path), "CH")
        missing_chains = [c for c in chains if c not in trace_all]
        if missing_chains:
            failures.append("explanation chains not referenced in trace maps: " + ", ".join(missing_chains[:20]))
    if failures:
        print("FAILED")
        for f in failures:
            print(f"- {f}")
        return 1
    print("OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
