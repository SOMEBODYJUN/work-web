#!/usr/bin/env python3
"""Validate control-plane coherence and reject package-version drift."""
from __future__ import annotations

from pathlib import Path
import ast
import json
import re
import sys

from pipeline_registry import (
    MODE_REQUIRED_FILES,
    VALID_MODES,
    VERSION_FILE,
    package_version,
    validator_specs_for_mode,
)

SEMVER_RE = re.compile(r"\d+\.\d+\.\d+")
DOTTED_V_LABEL_RE = re.compile(r"\bv(\d+\.\d+(?:\.\d+)?)\b", re.I)
PACKAGE_CONTEXT_VERSION_RE = re.compile(
    r"(?:package(?:_version| version)?|skill version|runtime version|包版本|版本)"
    r"[^\n]{0,48}?\b(v?\d+\.\d+\.\d+)\b",
    re.I,
)
VERSIONED_SCRIPT_RE = re.compile(r"(?:^|_)v\d+(?:\d+|_\d+)*", re.I)
DUPLICATE_REGISTRY_TOKENS = (
    "FULL_CHECKS =",
    "SOURCE_ONLY_CHECKS =",
    "MODE_CHECKS =",
    "FULL_VALIDATORS =",
    "SOURCE_ONLY_VALIDATORS =",
)


def main() -> int:
    root = (Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")).resolve()
    failures: list[str] = []

    version = package_version()
    if not SEMVER_RE.fullmatch(version):
        failures.append(f"VERSION must contain one semantic version, got {version!r}")
    if VERSION_FILE.resolve() != (root / "VERSION").resolve():
        failures.append("pipeline_registry VERSION_FILE does not point to the package VERSION")
    elif (root / "VERSION").read_text(encoding="utf-8").strip() != version:
        failures.append("VERSION file and registry package_version disagree")

    scripts = root / "scripts"
    for mode in VALID_MODES:
        required = MODE_REQUIRED_FILES[mode]
        if len(required) != len(set(required)):
            failures.append(f"{mode}: duplicate required-file entries")
        seen_invocations: set[tuple[str, tuple[str, ...]]] = set()
        for spec in validator_specs_for_mode(mode, include_post_evidence=True):
            invocation = (spec.script, spec.args)
            if invocation in seen_invocations:
                failures.append(f"{mode}: duplicate validator invocation {spec.script} {spec.args}")
            seen_invocations.add(invocation)
            if not (scripts / spec.script).is_file():
                failures.append(f"{mode}: registry references missing validator scripts/{spec.script}")

    for path in scripts.glob("*.py"):
        if VERSIONED_SCRIPT_RE.search(path.stem):
            failures.append(f"versioned runtime script name is forbidden: scripts/{path.name}")
        try:
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except SyntaxError as exc:
            failures.append(f"Python syntax failed: scripts/{path.name}: {exc}")

    for rel in ("scripts/run_publication_validators.py", "scripts/validate_publication_package.py"):
        text = (root / rel).read_text(encoding="utf-8")
        for token in DUPLICATE_REGISTRY_TOKENS:
            if token in text:
                failures.append(f"{rel} duplicates registry token {token!r}")

    scan_paths = [
        root / "AGENTS.md",
        root / "SKILL.md",
        *sorted((root / "references").glob("*.md")),
        *sorted((root / "scripts").glob("*.py")),
    ]
    current_parts = tuple(int(part) for part in version.split("."))
    for path in scan_paths:
        text = path.read_text(encoding="utf-8")
        for match in DOTTED_V_LABEL_RE.finditer(text):
            raw = match.group(1)
            parts = tuple(int(part) for part in raw.split("."))
            normalized = parts + (0,) * (3 - len(parts))
            if normalized != current_parts:
                failures.append(
                    f"legacy package-version label {match.group(0)!r} remains in "
                    f"{path.relative_to(root)}"
                )
        for match in PACKAGE_CONTEXT_VERSION_RE.finditer(text):
            raw = match.group(1).lstrip("vV")
            if raw != version:
                failures.append(
                    f"package-version context references {match.group(1)!r}, expected {version}, "
                    f"in {path.relative_to(root)}"
                )

    skill = (root / "SKILL.md").read_text(encoding="utf-8")
    agents = (root / "AGENTS.md").read_text(encoding="utf-8")
    for token in (
        "scripts/pipeline.py",
        "scripts/pipeline_registry.py",
        "scripts/build_source_model.py",
        "VERSION",
    ):
        if token not in skill + "\n" + agents:
            failures.append(f"control plane does not document {token}")

    try:
        run_mode = json.loads((root / "templates" / "run_mode.json").read_text(encoding="utf-8"))
    except Exception as exc:
        failures.append(f"templates/run_mode.json invalid: {exc}")
        run_mode = {}
    if run_mode.get("mode") != "source_atomization":
        failures.append("templates/run_mode.json must default to source_atomization, not release")
    if run_mode.get("package_version") != "SET_BY_PIPELINE_INIT":
        failures.append("templates/run_mode.json must defer package_version to pipeline init")

    if failures:
        print("FAILED")
        for item in failures:
            print(f"- {item}")
        return 1
    print("OK")
    print(f"package_version={version} modes={len(VALID_MODES)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
