#!/usr/bin/env python3
"""Compatibility entry point for the unique quality-contract gate.

The former quality-mode ratios and omission-row exemptions were removed. This
script now accepts the legacy CLI shape but delegates to the same P13 contract
used by every rewrite boundary.
"""
from pathlib import Path
import sys

from quality_contract import evaluate_quality_stage


def main() -> int:
    if len(sys.argv) < 3:
        print("Usage: validate_length_gate.py <source.txt> <final.md> [omission_ledger.md]")
        return 2
    source_path = Path(sys.argv[1]).resolve()
    final_path = Path(sys.argv[2]).resolve()
    root = source_path.parent
    if final_path.parent != root:
        print("FAILED: source and final must belong to the same contract-bound run")
        return 1
    try:
        report, errors = evaluate_quality_stage(root, "P13_PUBLICATION", final_path.name)
    except Exception as exc:
        print(f"FAILED: {exc}")
        return 1
    if errors:
        print("FAILED")
        for error in errors:
            print(f"- {error}")
        return 1
    print(
        "OK: "
        f"source_prose_cjk={report['source_prose_cjk']} "
        f"target_prose_cjk={report['target_measurements']['prose_cjk']} "
        f"minimum_article_cjk={report['minimum_article_cjk']} "
        "omission_rows_do_not_change_contract=true"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
