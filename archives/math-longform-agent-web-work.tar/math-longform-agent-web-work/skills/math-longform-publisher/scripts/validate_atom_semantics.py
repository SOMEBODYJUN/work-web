#!/usr/bin/env python3
"""Validate current atoms as the only content-lock authority."""
from __future__ import annotations

from pathlib import Path
import json
import re
import sys

from content_authority import (
    ATOM_REQUIRED_FIELDS,
    ATOM_SCHEMA,
    CONTENT_TYPES,
    SURFACE_MODES,
    SURFACE_GROUP_MODES,
    SURFACE_CONFIDENCE,
    SURFACE_REVIEW_STATUSES,
    SURFACE_DECISION_BASES,
    OUTPUT_OPERATIONS,
    CONSUMPTION_STATES,
    GENERIC_VALUES,
    atom_source_bytes,
    parse_int,
    parse_json_field,
    sha256_bytes,
    utf8_slice,
    detect_surface_features,
    surface_features_require_exact,
)
from content_functions import normalize_functions


TYPE_REQUIRED_INVARIANTS = {
    "PROOF_ROUTE": {"summary", "premises", "required_steps", "conclusion", "forbidden_alternatives", "required_output_fragments"},
    "PROOF_STEP": {"summary", "premises", "required_steps", "conclusion", "forbidden_alternatives", "required_output_fragments"},
    "FORMULA": {"summary", "mathematical_object", "canonical_formula", "symbols", "conditions"},
    "OCR_FRAGMENT": {"summary", "mathematical_object", "canonical_formula", "symbols", "conditions"},
    "AUTHOR_INSIGHT": {"summary", "claim", "method", "forbidden_substitution"},
    "AUTHOR_METHOD": {"summary", "claim", "method", "forbidden_substitution"},
    "AUTHOR_VOICE": {"summary", "voice_function", "preserve_tone"},
    "READER_DIALOGUE": {"summary", "voice_function", "preserve_tone"},
}
NONEMPTY_SEQUENCE_KEYS = {
    "premises",
    "required_steps",
    "forbidden_alternatives",
    "required_output_fragments",
    "symbols",
}


def fail(messages: list[str], warnings: list[str] | None = None) -> int:
    print("FAILED")
    for message in messages:
        print(f"- {message}")
    for warning in warnings or []:
        print(f"WARNING: {warning}")
    return 1


def is_generic(value: str) -> bool:
    return value.strip().lower() in GENERIC_VALUES


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    failures: list[str] = []
    warnings: list[str] = []

    try:
        source, revision, rows = atom_source_bytes(root)
    except Exception as exc:
        return fail([str(exc)])

    revision_id = str(revision.get("source_revision_id", ""))
    seen_ids: set[str] = set()
    intervals: list[tuple[int, int, str]] = []
    types: list[str] = []
    surface_groups: dict[str, list[tuple[int, int, str]]] = {}

    for index, row in enumerate(rows, 1):
        missing = sorted(ATOM_REQUIRED_FIELDS - set(row))
        atom_id = str(row.get("atom_id", f"<row:{index}>"))
        if missing:
            failures.append(f"{atom_id}: missing fields: {', '.join(missing)}")
            continue
        if row.get("schema_version") != ATOM_SCHEMA:
            failures.append(f"{atom_id}: schema_version must be {ATOM_SCHEMA}")
        if not re.fullmatch(r"A\d{4,}", atom_id):
            failures.append(f"row {index}: invalid atom_id {atom_id!r}")
        elif atom_id in seen_ids:
            failures.append(f"duplicate atom_id: {atom_id}")
        seen_ids.add(atom_id)

        if row.get("source_revision_id") != revision_id:
            failures.append(f"{atom_id}: source_revision_id does not match current source revision")

        try:
            start = parse_int(row.get("source_byte_start"), f"{atom_id}.source_byte_start")
            end = parse_int(row.get("source_byte_end"), f"{atom_id}.source_byte_end")
            excerpt = utf8_slice(source, start, end, atom_id)
            intervals.append((start, end, atom_id))
        except Exception as exc:
            failures.append(str(exc))
            continue

        raw_excerpt = str(row.get("raw_excerpt", ""))
        if raw_excerpt != excerpt:
            failures.append(f"{atom_id}: raw_excerpt is not the exact canonical-source byte slice")
        digest = sha256_bytes(source[start:end])
        if row.get("source_excerpt_sha256") != digest:
            failures.append(f"{atom_id}: source_excerpt_sha256 mismatch")
        if start == end:
            failures.append(f"{atom_id}: zero-length atoms are forbidden")
        if not excerpt.strip() and row.get("content_type") != "PLACEHOLDER":
            failures.append(f"{atom_id}: whitespace-only atom is forbidden")

        if row.get("content_lock_state") != "CONTENT_LOCKED":
            failures.append(f"{atom_id}: every source atom must be CONTENT_LOCKED")

        content_type = str(row.get("content_type", ""))
        types.append(content_type)
        if content_type not in CONTENT_TYPES:
            failures.append(f"{atom_id}: invalid content_type {content_type!r}")
        try:
            required_functions = normalize_functions(
                row.get("required_functions"), f"{atom_id}.required_functions"
            )
        except ValueError as exc:
            failures.append(str(exc))
            required_functions = []
        # P02 routing and prelocks are provisional. P04 owns the semantic
        # function, role, invariant, and final surface decision.
        local_role = str(row.get("local_context_role", "")).strip()
        global_role = str(row.get("global_context_role", "")).strip()
        if is_generic(local_role) or len(local_role) < 4:
            failures.append(f"{atom_id}: local_context_role is empty/generic")
        if is_generic(global_role) or len(global_role) < 4:
            failures.append(f"{atom_id}: global_context_role is empty/generic")

        try:
            invariant = parse_json_field(row.get("content_invariant_json"), f"{atom_id}.content_invariant_json", dict)
        except Exception as exc:
            failures.append(str(exc))
            invariant = {}
        summary = str(invariant.get("summary", "")).strip()
        if is_generic(summary) or len(summary) < 2:
            failures.append(f"{atom_id}: invariant summary is empty/generic")
        try:
            invariant_functions = normalize_functions(
                invariant.get("required_functions"),
                f"{atom_id}.content_invariant_json.required_functions",
            )
        except ValueError as exc:
            failures.append(str(exc))
            invariant_functions = []
        if invariant_functions != required_functions:
            failures.append(
                f"{atom_id}: invariant required_functions must match the atom contract"
            )
        required = TYPE_REQUIRED_INVARIANTS.get(content_type, {"summary"})
        missing_inv = sorted(key for key in required if key not in invariant)
        if missing_inv:
            failures.append(f"{atom_id}: content invariant missing keys for {content_type}: {', '.join(missing_inv)}")
        for key in required & NONEMPTY_SEQUENCE_KEYS:
            value = invariant.get(key)
            if not isinstance(value, list) or not value:
                failures.append(f"{atom_id}: invariant {key} must be a non-empty list")
        if content_type in {"PROOF_ROUTE", "PROOF_STEP"}:
            conclusion = invariant.get("conclusion")
            if not isinstance(conclusion, str) or len(conclusion.strip()) < 2:
                failures.append(f"{atom_id}: proof conclusion must be explicit")
        if content_type in {"FORMULA", "OCR_FRAGMENT"}:
            formula = invariant.get("canonical_formula")
            if not isinstance(formula, str) or not formula.strip():
                failures.append(f"{atom_id}: formula atom requires canonical_formula")
            obj = invariant.get("mathematical_object")
            if not isinstance(obj, str) or len(obj.strip()) < 2:
                failures.append(f"{atom_id}: formula atom requires mathematical_object")

        surface_mode = str(row.get("surface_mode", ""))
        p02_surface_mode = str(row.get("p02_surface_mode", ""))
        output_operation = str(row.get("output_operation", ""))
        consumption = str(row.get("consumption_status", ""))
        if surface_mode not in SURFACE_MODES:
            failures.append(f"{atom_id}: invalid surface_mode {surface_mode!r}")
        if p02_surface_mode not in SURFACE_MODES:
            failures.append(f"{atom_id}: invalid p02_surface_mode {p02_surface_mode!r}")
        if output_operation not in OUTPUT_OPERATIONS:
            failures.append(f"{atom_id}: invalid output_operation {output_operation!r}")
        if consumption not in CONSUMPTION_STATES:
            failures.append(f"{atom_id}: invalid consumption_status {consumption!r}")
        if surface_mode == "BYTE_EXACT":
            if output_operation != "COPY_SOURCE_SLICE":
                failures.append(f"{atom_id}: BYTE_EXACT has exactly one legal output_operation: COPY_SOURCE_SLICE")
            for legacy_field in ("content_output_mode", "allowed_completion", "forbidden_change"):
                if str(row.get(legacy_field, "")).strip():
                    failures.append(
                        f"{atom_id}: BYTE_EXACT must not carry editable contract field {legacy_field}; "
                        "the only operation is COPY_SOURCE_SLICE"
                    )
        elif output_operation == "COPY_SOURCE_SLICE":
            failures.append(f"{atom_id}: COPY_SOURCE_SLICE is reserved for BYTE_EXACT atoms")

        try:
            decision = parse_json_field(row.get("surface_decision_json"), f"{atom_id}.surface_decision_json", dict)
        except Exception as exc:
            failures.append(str(exc))
            decision = {}
        decision_required = {"decision", "basis", "source_cues", "rationale", "confidence", "review_status"}
        missing_decision = sorted(decision_required - set(decision))
        if missing_decision:
            failures.append(f"{atom_id}: surface decision missing keys: {', '.join(missing_decision)}")
        if decision.get("decision") != surface_mode:
            failures.append(f"{atom_id}: surface decision does not match surface_mode")
        basis = decision.get("basis", [])
        if not isinstance(basis, list) or not basis:
            failures.append(f"{atom_id}: surface decision basis must be a non-empty list")
            basis = []
        else:
            invalid_basis = sorted({str(x) for x in basis} - SURFACE_DECISION_BASES)
            if invalid_basis:
                failures.append(f"{atom_id}: invalid surface decision basis: {', '.join(invalid_basis)}")
        cues = decision.get("source_cues", [])
        if not isinstance(cues, list):
            failures.append(f"{atom_id}: surface decision source_cues must be a list")
            cues = []
        for cue in cues:
            if not isinstance(cue, str) or not cue:
                failures.append(f"{atom_id}: surface decision source cue must be non-empty text")
            elif cue not in excerpt:
                failures.append(f"{atom_id}: surface decision cue is not an exact substring of raw_excerpt: {cue!r}")
        rationale = str(decision.get("rationale", "")).strip()
        if len(rationale) < 12:
            failures.append(f"{atom_id}: surface decision rationale is too weak")
        if decision.get("confidence") not in SURFACE_CONFIDENCE:
            failures.append(f"{atom_id}: invalid surface decision confidence")
        if decision.get("review_status") not in SURFACE_REVIEW_STATUSES:
            failures.append(f"{atom_id}: invalid surface decision review_status")

        detected_features = detect_surface_features(excerpt, content_type)
        if p02_surface_mode == "BYTE_EXACT" and surface_mode != "BYTE_EXACT":
            disposition = str(decision.get("prelock_disposition", ""))
            if (
                disposition != "DOWNGRADED_FALSE_POSITIVE"
                and output_operation != "BLOCKED_REVIEW"
                and consumption != "BLOCKED"
            ):
                failures.append(
                    f"{atom_id}: P02 BYTE_EXACT prelock was downgraded without an explicit false-positive disposition"
                )
        if surface_mode == "BYTE_EXACT":
            exact_basis = {
                "USER_EXPLICIT_EXACT", "VERBATIM_QUOTE", "DISTINCTIVE_AUTHOR_VOICE",
                "ABRASIVE_OR_TABOO_WORDING", "RHYTHM_REPETITION_DISFLUENCY",
                "PUNCTUATION_OR_SPACING_IS_CONTENT", "WORDPLAY_SLOGAN_FIXED_FORM",
                "TITLE_OR_SIGNATURE_LINE", "READER_DIRECT_ADDRESS",
                "SANITIZATION_CHANGES_AUTHOR_IDENTITY",
            }
            if not (set(str(x) for x in basis) & exact_basis):
                failures.append(f"{atom_id}: BYTE_EXACT lacks a surface-bearing decision basis")
            if not cues:
                failures.append(f"{atom_id}: BYTE_EXACT requires exact source cues")

        group_id = str(row.get("surface_group_id", "")).strip()
        group_mode = str(row.get("surface_group_mode", "")).strip()
        if group_mode not in SURFACE_GROUP_MODES:
            failures.append(f"{atom_id}: invalid surface_group_mode {group_mode!r}")
        elif group_mode == "NONE":
            if group_id not in {"", "none"}:
                failures.append(f"{atom_id}: surface_group_id requires CONTIGUOUS_BYTE_EXACT")
        else:
            if surface_mode != "BYTE_EXACT":
                failures.append(f"{atom_id}: contiguous exact group members must be BYTE_EXACT")
            if not re.fullmatch(r"SG\d{4,}", group_id):
                failures.append(f"{atom_id}: invalid contiguous surface_group_id {group_id!r}")
            else:
                surface_groups.setdefault(group_id, []).append((start, end, atom_id))
        if content_type == "DUPLICATE":
            if not re.fullmatch(r"A\d{4,}", str(row.get("duplicate_of", ""))):
                failures.append(f"{atom_id}: DUPLICATE atom requires duplicate_of")
            if output_operation != "OMIT_CONFIRMED_DUPLICATE":
                failures.append(f"{atom_id}: DUPLICATE atom must use OMIT_CONFIRMED_DUPLICATE")
        elif str(row.get("duplicate_of", "")).strip() not in {"", "none"}:
            failures.append(f"{atom_id}: duplicate_of is only valid for DUPLICATE atoms")

        if surface_mode != "BYTE_EXACT":
            allowed = str(row.get("allowed_completion", "")).strip()
            forbidden = str(row.get("forbidden_change", "")).strip()
            if is_generic(allowed) or len(allowed) < 4:
                failures.append(f"{atom_id}: non-exact atom requires a specific allowed_completion")
            if is_generic(forbidden) or len(forbidden) < 4:
                failures.append(f"{atom_id}: non-exact atom requires a specific forbidden_change")

    # A continuous exact group protects order, adjacency, punctuation, and whitespace
    # across multiple atoms. It is not a bag of independently reproduced excerpts.
    for group_id, members in sorted(surface_groups.items()):
        members.sort()
        if len(members) < 2:
            failures.append(f"{group_id}: CONTIGUOUS_BYTE_EXACT group must contain at least two atoms")
            continue
        for (_prev_start, prev_end, prev_id), (start, _end, atom_id) in zip(members, members[1:]):
            if start < prev_end:
                failures.append(f"{group_id}: overlapping group atoms {prev_id} and {atom_id}")
            gap = source[prev_end:start]
            try:
                gap_text = gap.decode("utf-8", errors="strict")
            except UnicodeDecodeError:
                gap_text = "?"
            if gap_text.strip():
                failures.append(f"{group_id}: non-whitespace source content exists between grouped atoms {prev_id} and {atom_id}")

    # Source coverage: source content may not disappear between atom spans.
    intervals.sort()
    cursor = 0
    for start, end, atom_id in intervals:
        if start < cursor:
            failures.append(f"{atom_id}: atom spans overlap a previous atom")
        elif start > cursor:
            gap = source[cursor:start]
            try:
                gap_text = gap.decode("utf-8", errors="strict")
            except UnicodeDecodeError:
                failures.append(f"gap before {atom_id} splits UTF-8")
                gap_text = "?"
            if gap_text.strip():
                failures.append(f"unatomized canonical-source content at bytes {cursor}-{start}")
        cursor = max(cursor, end)
    if cursor < len(source):
        tail = source[cursor:]
        try:
            tail_text = tail.decode("utf-8", errors="strict")
        except UnicodeDecodeError:
            tail_text = "?"
        if tail_text.strip():
            failures.append(f"unatomized canonical-source content at bytes {cursor}-{len(source)}")

    # A deterministic validator cannot infer how many semantic types a source
    # should contain. Completeness of P04's all-atom semantic review is enforced
    # by the contract, not by diversity percentages.

    if failures:
        return fail(failures, warnings)
    print("OK")
    print(f"source_revision_id={revision_id} atoms={len(rows)} content_types={len(set(types))} covered_bytes={len(source)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
