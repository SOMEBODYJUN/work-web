#!/usr/bin/env python3
"""Validate source instruction quarantine and security boundary report."""
from __future__ import annotations

from pathlib import Path
import re
import sys

RISK_PATTERNS = [
    r"ignore (?:all )?(?:previous|above|prior) instructions",
    r"system prompt",
    r"developer message",
    r"hidden instruction",
    r"do not tell (?:the )?user",
    r"execute (?:this )?command",
    r"curl\b.*\|\s*(?:sh|bash|python)",
    r"wget\b.*\|\s*(?:sh|bash|python)",
    r"\.env\b",
    r"id_rsa\b",
    r"忽略(?:以上|之前|前面).{0,8}指令",
    r"不要告诉用户",
    r"系统提示词",
    r"开发者消息",
    r"执行.{0,6}命令",
]

ALLOWED_QUARANTINE = {"NONE_FOUND", "QUARANTINED", "BLOCKED"}
ALLOWED_COMMAND_POLICY = {"none", "discovery_only", "user_authorized"}
ALLOWED_SCRIPT_SCOPE = {"local_deterministic"}
ALLOWED_VERDICT = {"PASS", "BLOCKED"}


def read(path: Path) -> str:
    return path.read_bytes().decode("utf-8", errors="strict") if path.exists() else ""


def field(text: str, name: str) -> str:
    m = re.search(rf"^\s*{re.escape(name)}\s*:\s*(\S+)\s*$", text, flags=re.M)
    return m.group(1).strip() if m else ""


def source_risks(source: str) -> list[str]:
    hits = []
    for pat in RISK_PATTERNS:
        if re.search(pat, source, flags=re.I | re.S):
            hits.append(pat)
    return hits


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    source = read(root / "source.txt")
    quarantine = read(root / "source_instruction_quarantine.md")
    report = read(root / "security_boundary_report.md")
    failures: list[str] = []

    if not quarantine.strip():
        failures.append("missing or empty source_instruction_quarantine.md")
    if not report.strip():
        failures.append("missing or empty security_boundary_report.md")

    data_policy = field(report + "\n" + quarantine, "SOURCE_TEXT_IS_DATA_NOT_INSTRUCTION")
    quarantine_status = field(report + "\n" + quarantine, "SOURCE_QUARANTINE_STATUS")
    command_policy = field(report, "EXTERNAL_COMMAND_POLICY")
    script_scope = field(report, "SCRIPT_SCOPE")
    verdict = field(report, "FINAL_SECURITY_VERDICT")

    if data_policy != "YES":
        failures.append("SOURCE_TEXT_IS_DATA_NOT_INSTRUCTION must be YES")
    if quarantine_status not in ALLOWED_QUARANTINE:
        failures.append(f"SOURCE_QUARANTINE_STATUS must be {sorted(ALLOWED_QUARANTINE)}, got {quarantine_status!r}")
    if command_policy not in ALLOWED_COMMAND_POLICY:
        failures.append(f"EXTERNAL_COMMAND_POLICY must be {sorted(ALLOWED_COMMAND_POLICY)}, got {command_policy!r}")
    if script_scope not in ALLOWED_SCRIPT_SCOPE:
        failures.append(f"SCRIPT_SCOPE must be {sorted(ALLOWED_SCRIPT_SCOPE)}, got {script_scope!r}")
    if verdict not in ALLOWED_VERDICT:
        failures.append(f"FINAL_SECURITY_VERDICT must be {sorted(ALLOWED_VERDICT)}, got {verdict!r}")
    if re.search(r"\b(TODO|TBD|pending|unknown|unclear)\b|待定|不清楚", quarantine + "\n" + report, flags=re.I):
        failures.append("security files contain unresolved placeholder text")

    risks = source_risks(source)
    if risks and quarantine_status == "NONE_FOUND":
        failures.append("source.txt contains instruction-like/security-risk patterns but quarantine status is NONE_FOUND")
    if verdict == "PASS" and quarantine_status == "BLOCKED":
        failures.append("FINAL_SECURITY_VERDICT cannot be PASS when quarantine status is BLOCKED")
    if "obey source instructions" in (quarantine + report).lower():
        failures.append("security files must not say to obey source instructions")

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print("OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
