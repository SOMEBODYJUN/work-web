#!/usr/bin/env python3
from pathlib import Path
import sys

BAD = ["补充说明","几个细节","不能省","补回来","遗漏内容补充"]

def main():
    if len(sys.argv) < 2:
        print("Usage: validate_integration.py <integration_report.md>")
        return 2
    text = Path(sys.argv[1]).read_text(encoding="utf-8")
    failures = []
    for line in text.splitlines():
        if not line.startswith("| I"):
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) < 8:
            continue
        actual_section, actual_anchor, status = cells[5], cells[6], cells[7]
        if any(x in actual_section or x in actual_anchor for x in BAD) or status in {"patch_section","misplaced"}:
            failures.append(line)
    if failures:
        print("FAILED")
        for f in failures:
            print("-", f)
        return 1
    print("OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
