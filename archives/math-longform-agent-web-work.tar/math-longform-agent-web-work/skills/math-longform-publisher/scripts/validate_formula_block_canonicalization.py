#!/usr/bin/env python3
"""Validate fragmented formula block canonicalization before atomization."""
from __future__ import annotations

from pathlib import Path
import hashlib
import re
import sys

from structured_ledger import load_required_ledger

FORMULA_CHARS = set(r"[](){}<>≤≥≠=+-−±*/\^_∈∉⊂⊆⊃⊇∪∩∀∃∅∞→←↔⇒⇔Σ∑Π∏∫∮∂∇√≈≃≅·⋅λξηθμνρσφψωαβγδεκℝℕℤℚℂ∣|.,:;0123456789")
MATH_SYMBOL_RE = re.compile(r"[∫∮∂∇√≈≃≅−±·⋅∈∉⊂⊆⊃⊇∪∩∀∃∅∞→←↔⇒⇔≤≥≠=∣|\^_{}\[\]()<>\+\-*/]")
MATH_ALNUM_RE = re.compile(r"[\U0001D400-\U0001D7FF]")
BAD_STATUS = {"", "TODO", "UNKNOWN", "PENDING", "TBD"}
VALID_STATUS = {"CANONICALIZED", "NO_FRAGMENTED_FORMULA_BLOCKS", "BLOCKED_NEEDS_HUMAN_REVIEW"}


def read(path: Path) -> str:
    return path.read_bytes().decode("utf-8", errors="strict") if path.exists() else ""


def parse_span(span: str) -> tuple[int, int] | None:
    m = re.match(r"^\s*(\d+)\s*-\s*(\d+)\s*$", span or "")
    if not m:
        return None
    a, b = int(m.group(1)), int(m.group(2))
    return (a, b) if a <= b else None


def _strip_format_noise(text: str) -> str:
    return "".join(ch for ch in text.strip() if ch not in {"\u200b", "\ufeff", "\u2060"})


def is_fragment_line(line: str) -> bool:
    s = _strip_format_noise(line)
    if not s:
        return False
    if len(s) > 40:
        return False
    if MATH_ALNUM_RE.search(s) and len(s) <= 30:
        return True
    chinese_count = len(re.findall(r"[\u4e00-\u9fff]", s))
    if chinese_count and not MATH_SYMBOL_RE.search(s):
        return False
    formula_like = sum(1 for ch in s if ch in FORMULA_CHARS)
    latin_math = bool(re.fullmatch(r"[A-Za-z0-9_\\^+\-−*/=<>≤≥|.,:;\[\](){}]+", s))
    return bool(
        formula_like >= max(1, len(s) // 3)
        or latin_math
        or (MATH_SYMBOL_RE.search(s) and len(s) <= 30)
    )

def is_soft_gap(line: str) -> bool:
    s = line.strip()
    return s == "" or s in {"\u200b", "\ufeff"}


def detect_fragment_runs(source: str) -> list[dict[str, int | str]]:
    """Detect compact vertical OCR/math runs and report UTF-8 byte spans.

    This is a damage detector, not a formula parser. It deliberately ignores
    isolated short math lines and no longer imposes the old twelve-line cap,
    which silently missed long damaged displays.
    """
    lines = source.splitlines(keepends=True)
    char_starts: list[int] = []
    byte_starts: list[int] = []
    char_pos = 0
    byte_pos = 0
    for line in lines:
        char_starts.append(char_pos)
        byte_starts.append(byte_pos)
        char_pos += len(line)
        byte_pos += len(line.encode("utf-8"))

    runs: list[dict[str, int | str]] = []
    i = 0
    while i < len(lines):
        if not is_fragment_line(lines[i]):
            i += 1
            continue
        j = i
        fragment_count = 0
        last_fragment = i
        while j < len(lines):
            if is_fragment_line(lines[j]):
                fragment_count += 1
                last_fragment = j
                j += 1
                continue
            if is_soft_gap(lines[j]) and fragment_count:
                j += 1
                continue
            break

        raw = "".join(lines[i:last_fragment + 1])
        visible = "".join(ch for ch in raw if not ch.isspace())
        has_math_identity = bool(
            MATH_ALNUM_RE.search(raw)
            or re.search(r"[A-Za-zα-ωΑ-Ω∫∑ΣΠ∏∞→←↔⇒⇔≤≥≠∈∉⊂⊆⊃⊇]", raw)
        )
        # Three punctuation-only or digit-only lines are usually layout noise.
        # A real damaged formula run must either be longer or carry a symbol/name.
        qualifies = fragment_count >= 5 or (
            fragment_count >= 3 and has_math_identity and len(visible) >= 3
        )
        if qualifies:
            raw_bytes = raw.encode("utf-8")
            start_byte = byte_starts[i]
            end_byte = start_byte + len(raw_bytes)
            runs.append({
                "line_start": i + 1,
                "line_end": last_fragment + 1,
                "byte_start": start_byte,
                "byte_end": end_byte,
                # Compatibility aliases now explicitly use byte values.
                "char_start": start_byte,
                "char_end": end_byte,
                "fragment_count": fragment_count,
                "raw_fragment_hash": hashlib.sha256(raw_bytes).hexdigest(),
            })
        i = max(j, i + 1)
    return runs

def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    source_path = root / "source_canonical.txt"
    if not source_path.exists():
        source_path = root / "source.txt"
    source = read(source_path)
    ledger = root / "source_formula_block_ledger.md"
    failures: list[str] = []
    rows_kind, rows, row_failures = load_required_ledger(ledger, {'atom_ids', 'canonical_formula', 'canonicalization_status', 'formula_block_id', 'fragment_count', 'line_span', 'raw_fragment_hash', 'review_status', 'source_span', 'verification_note'})
    failures.extend(row_failures)
    if rows_kind == "missing":
        failures.append("missing or empty source_formula_block_ledger.jsonl/source_formula_block_ledger.md")

    runs = detect_fragment_runs(source)
    if not rows:
        failures.append("source_formula_block_ledger has no parseable rows")

    no_formula_rows = [r for r in rows if (r.get("canonicalization_status", "").upper() == "NO_FRAGMENTED_FORMULA_BLOCKS" or r.get("formula_block_id", "").upper() == "NO_FRAGMENTED_FORMULA_BLOCKS")]
    canonical_rows = [r for r in rows if r.get("canonicalization_status", "").upper() in {"CANONICALIZED", "BLOCKED_NEEDS_HUMAN_REVIEW"}]

    if runs and no_formula_rows and not canonical_rows:
        failures.append(f"source contains {len(runs)} detected fragmented formula run(s), but ledger claims no fragmented formula blocks")
    if runs and not canonical_rows:
        failures.append("detected fragmented formula runs require at least one CANONICALIZED or BLOCKED_NEEDS_HUMAN_REVIEW row")
    if not runs and not rows:
        failures.append("no fragmented formula runs detected, but explicit NO_FRAGMENTED_FORMULA_BLOCKS row is still required")

    source_bytes = source.encode("utf-8")
    source_len = len(source_bytes)
    ledger_spans: list[tuple[int, int, str]] = []
    for idx, row in enumerate(rows, 1):
        status = row.get("canonicalization_status", "").upper().strip()
        fb_id = row.get("formula_block_id", "").strip()
        if status in BAD_STATUS:
            failures.append(f"row {idx} has unresolved canonicalization_status: {status or '<blank>'}")
        if status and status not in VALID_STATUS:
            failures.append(f"row {idx} has invalid canonicalization_status: {status}")
        if status == "NO_FRAGMENTED_FORMULA_BLOCKS":
            continue
        span = parse_span(row.get("source_span", ""))
        if span is None:
            failures.append(f"row {idx} {fb_id} missing valid source_span")
        else:
            a, b = span
            if b > source_len:
                failures.append(f"row {idx} {fb_id} source_span out of canonical source range")
            else:
                try:
                    source_bytes[a:b].decode("utf-8", errors="strict")
                except UnicodeDecodeError:
                    failures.append(f"row {idx} {fb_id} source_span splits UTF-8")
                ledger_spans.append((a, b, fb_id))
        try:
            frag_count = int(row.get("fragment_count", "0") or "0")
        except ValueError:
            frag_count = -1
        if frag_count <= 0:
            failures.append(f"row {idx} {fb_id} must record positive fragment_count")
        digest = row.get("raw_fragment_hash", "").strip().lower()
        if not re.fullmatch(r"[0-9a-f]{64}", digest):
            failures.append(f"row {idx} {fb_id} raw_fragment_hash must be a sha256 hex digest")
        elif span is not None:
            a, b = span
            if 0 <= a <= b <= source_len:
                expected_digest = hashlib.sha256(source_bytes[a:b]).hexdigest()
                if digest != expected_digest:
                    failures.append(f"row {idx} {fb_id} raw_fragment_hash does not bind source_span")
        canon = row.get("canonical_formula", "").strip()
        if status == "CANONICALIZED" and canon.lower() in {"", "none", "todo", "unknown"}:
            failures.append(f"row {idx} {fb_id} CANONICALIZED row has empty canonical_formula")
        review = row.get("review_status", "").upper().strip()
        if review in BAD_STATUS:
            failures.append(f"row {idx} {fb_id} has unresolved review_status: {review or '<blank>'}")

    if runs:
        for run in runs:
            start, end = int(run["byte_start"]), int(run["byte_end"])
            if not any(a <= start and end <= b for a, b, _fb_id in ledger_spans):
                failures.append(
                    f"detected formula run {start}-{end} is not covered by any formula ledger span"
                )

    if failures:
        print("FAILED")
        for f in failures:
            print(f"- {f}")
        if runs:
            print("detected_fragment_runs:")
            for run in runs[:10]:
                print(f"- lines {run['line_start']}-{run['line_end']} byte_span {run['byte_start']}-{run['byte_end']} fragments={run['fragment_count']} hash={run['raw_fragment_hash']}")
        return 1
    print(f"OK: formula block ledger reviewed; ledger_source={rows_kind} detected_fragment_runs={len(runs)} rows={len(rows)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
