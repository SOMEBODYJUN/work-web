#!/usr/bin/env python3
"""Validate the production Skill distribution.

The runtime distribution intentionally excludes example articles, expected outputs,
fixtures, regression harnesses, and maintenance history. Evaluation assets belong
outside the package consumed by the generation Agent.
"""
from __future__ import annotations

from pathlib import Path, PurePosixPath
import ast
import re
import stat
import sys
import unicodedata
import zipfile

REQUIRED = [
    "AGENTS.md",
    "SKILL.md",
    "VERSION",
    "scripts/pipeline.py",
    "scripts/build_source_model.py",
    "scripts/source_review_state.py",
    "scripts/validate_source_review_resolution.py",
    "scripts/pipeline_registry.py",
    "scripts/validator_runner.py",
    "scripts/validate_control_plane_consistency.py",
    "agents/openai.yaml",
    "references/NO_RUNTIME_EXAMPLES_POLICY.md",
    "references/CANONICAL_SOURCE_PROTOCOL.md",
    "references/CONTENT_AUTHORITY_PROTOCOL.md",
    "references/CONTENT_FUNCTION_PRESERVATION_PROTOCOL.md",
    "references/SURFACE_DECISION_PROTOCOL.md",
    "references/OUTPUT_FRAGMENT_AUTHORIZATION_PROTOCOL.md",
    "references/HEADING_AUTHORIZATION_PROTOCOL.md",
    "references/PUBLICATION_CONTENT_ACCEPTANCE_PROTOCOL.md",
    "references/DETAILED_WORKFLOW_PROTOCOL.md",
    "scripts/canonicalize_source.py",
    "scripts/apply_source_patch.py",
    "scripts/materialize_exact_source_slice.py",
    "scripts/validate_source_revision.py",
    "scripts/validate_atom_semantics.py",
    "scripts/validate_surface_decisions.py",
    "scripts/validate_section_execution_plan.py",
    "scripts/validate_publication_sentence_trace.py",
    "scripts/validate_content_function_preservation.py",
    "scripts/validate_source_obligation_contracts.py",
    "scripts/validate_heading_authorization.py",
    "scripts/validate_output_fragment_authorization.py",
    "scripts/validate_publication_content_acceptance.py",
    "scripts/run_publication_validators.py",
    "templates/source_original.txt",
    "templates/source_canonical.txt",
    "templates/source_revision.json",
    "templates/source_atom_ledger.jsonl",
    "templates/section_execution_plan.jsonl",
    "templates/surface_decision_review.jsonl",
    "templates/publication_sentence_trace.jsonl",
    "templates/heading_authorization.jsonl",
    "templates/publication_fragment_authorization.jsonl",
]

FORBIDDEN_RUNTIME_PATHS = {
    "examples",
    "tests",
    "fixtures",
    "maintenance/history",
}
FORBIDDEN_SCRIPT_PREFIXES = (
    "run_",
)
ALLOWED_RUNTIME_RUNNERS = {"run_publication_validators.py"}
HIDDEN_TAG_RE = re.compile("[\U000E0000-\U000E007F]")
SUSPICIOUS = [
    (re.compile(r"shell\s*=\s*True"), "shell=True"),
    (re.compile(r"\b(?:eval|exec)\s*\("), "eval/exec"),
    (re.compile(r"curl\b.*\|\s*(?:sh|bash|python)", re.I | re.S), "curl piped to interpreter"),
    (re.compile(r"wget\b.*\|\s*(?:sh|bash|python)", re.I | re.S), "wget piped to interpreter"),
]


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def referenced_paths(text: str) -> set[str]:
    refs = re.findall(r"(?:references|scripts|templates|checklists|rubrics)/[A-Za-z0-9_.\-/]+", text)
    return {item.rstrip("`.,):]") for item in refs}


def check_zip_safe(path: Path) -> list[str]:
    errors: list[str] = []
    seen: dict[str, str] = {}
    try:
        with zipfile.ZipFile(path) as zf:
            if len(zf.infolist()) > 5000:
                errors.append("zip has too many entries")
            total = 0
            for info in zf.infolist():
                name = info.filename
                p = PurePosixPath(name)
                if "\\" in name or p.is_absolute() or any(part in {"", ".", ".."} for part in p.parts):
                    errors.append(f"unsafe zip path: {name!r}")
                norm = unicodedata.normalize("NFC", p.as_posix()).casefold()
                if norm in seen:
                    errors.append(f"colliding zip paths: {seen[norm]!r} and {name!r}")
                seen[norm] = name
                mode = (info.external_attr >> 16) & 0xFFFF
                if mode and stat.S_ISLNK(mode):
                    errors.append(f"zip symlink forbidden: {name}")
                if info.file_size > 50 * 1024 * 1024:
                    errors.append(f"zip entry too large: {name}")
                total += info.file_size
            if total > 100 * 1024 * 1024:
                errors.append("zip uncompressed total too large")
    except Exception as exc:
        errors.append(f"bad zip: {exc}")
    return errors


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    root = root.resolve()
    errors: list[str] = []

    for rel in REQUIRED:
        path = root / rel
        if not path.exists():
            errors.append(f"missing required runtime file: {rel}")
        elif path.suffix not in {".jsonl", ".txt"} and not path.read_bytes().strip():
            errors.append(f"empty required runtime file: {rel}")

    for rel in FORBIDDEN_RUNTIME_PATHS:
        if (root / rel).exists():
            errors.append(f"evaluation/example asset forbidden in runtime package: {rel}")
    maintenance = root / "maintenance"
    if maintenance.exists():
        # Runtime lifecycle documentation is allowed, history is not.
        if (maintenance / "history").exists():
            errors.append("maintenance/history is forbidden in runtime package")

    for script in (root / "scripts").glob("*.py"):
        if script.name.startswith(FORBIDDEN_SCRIPT_PREFIXES) and script.name not in ALLOWED_RUNTIME_RUNNERS:
            errors.append(f"test/backtest runner forbidden in runtime package: scripts/{script.name}")

    skill_text = read(root / "SKILL.md") if (root / "SKILL.md").exists() else ""
    agents_text = read(root / "AGENTS.md") if (root / "AGENTS.md").exists() else ""
    combined = skill_text + "\n" + agents_text
    for token in [
        "tests/fixtures",
        "references/calibration_corpus.md",
        "scripts/run_skill_self_tests.py",
        "scripts/run_full_publication_integration_fixture.py",
        "scripts/run_hardening_regression_tests.py",
    ]:
        if token.lower() in combined.lower():
            errors.append(f"runtime instructions reference evaluation/example asset: {token}")
    for required_phrase in [
        "COPY_SOURCE_SLICE",
        "publication_fragment_authorization.jsonl",
        "heading_authorization.jsonl",
        "validate_output_fragment_authorization.py",
        "validate_heading_authorization.py",
    ]:
        if required_phrase not in combined:
            errors.append(f"runtime control plane missing required authorization rule: {required_phrase}")

    for rel in referenced_paths(skill_text):
        if not (root / rel).exists():
            errors.append(f"SKILL.md references missing runtime file: {rel}")

    for path in root.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if "__pycache__" in path.parts or path.suffix in {".pyc", ".pyo"}:
            errors.append(f"build cache forbidden in runtime package: {rel}")
            continue
        if path.suffix.lower() in {".md", ".py", ".json", ".jsonl", ".yaml", ".yml", ".txt"} or path.name in {"SKILL.md", "AGENTS.md"}:
            try:
                text = read(path)
            except UnicodeDecodeError as exc:
                errors.append(f"invalid UTF-8: {rel}: {exc}")
                continue
            if HIDDEN_TAG_RE.search(text):
                errors.append(f"hidden Unicode tag characters: {rel}")
            if path.suffix == ".py":
                try:
                    ast.parse(text, filename=str(path))
                except SyntaxError as exc:
                    errors.append(f"python syntax failed: {rel}: {exc}")
                for pattern, label in SUSPICIOUS:
                    if pattern.search(text):
                        if path.name in {"validate_skill_package_integrity.py", "validate_security_boundary.py"}:
                            continue
                        errors.append(f"suspicious script pattern: {rel}: {label}")

    for raw_zip in sys.argv[2:]:
        errors.extend(check_zip_safe(Path(raw_zip)))

    if errors:
        print("FAILED")
        for error in errors:
            print(f"- {error}")
        return 1
    print("OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
