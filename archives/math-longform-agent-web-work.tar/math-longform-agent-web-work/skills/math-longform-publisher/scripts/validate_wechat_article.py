#!/usr/bin/env python3
"""Validate the WeChat-specific article surface."""
from pathlib import Path
import re
import subprocess
import sys

BANNED_HEADING_TERMS = [
    "偷偷", "真正", "核心", "底层逻辑", "完整闭环", "系统梳理", "全面解析",
]
PROCESS_HEADING_TERMS = [
    "先说", "先把", "先来", "先看", "然后", "接下来", "最后", "再说", "这里先",
    "先别", "先记", "先写", "先给", "一波", "收尾", "说完", "看一下", "也可以这么看",
]

def read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path and path.exists() else ""

def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: validate_wechat_article.py <wechat_publication_final.md> [source.txt] [heading_voice_gate.md]")
        return 2

    article_path = Path(sys.argv[1])
    source_path = Path(sys.argv[2]) if len(sys.argv) >= 3 else None
    gate_path = Path(sys.argv[3]) if len(sys.argv) >= 4 else None
    raw = read(article_path)
    article = raw.lstrip("\ufeff")
    source = read(source_path) if source_path else ""
    failures = []

    if not article:
        print(f"FAILED: missing or empty {article_path}")
        return 1
    if raw.startswith("\ufeff"):
        failures.append("file starts with UTF-8 BOM")

    headings = re.findall(r"^(#{1,6})\s+(.+?)\s*$", article, flags=re.M)
    h1 = [text for level, text in headings if level == "#"]
    h2 = [text for level, text in headings if level == "##"]
    h3 = [text for level, text in headings if level == "###"]

    if not h1:
        failures.append("missing # title")
    if len(article) > 5000 and len(h2) < 4:
        failures.append(f"too few ## section headings for a long WeChat article: {len(h2)}")
    if len(article) > 5000 and len(h3) < 3:
        failures.append(f"too few ### subsection headings for a long WeChat article: {len(h3)}")

    seen = set()
    prev = None
    def norm(s):
        s = re.sub(r"^\s*\d+(?:\.\d+)*[、.．\s-]*", "", s)
        return re.sub(r"[\s\u3000:：，,。.!！?？；;（）()《》<>【】\[\]$`*_\\-]+", "", s).lower()

    gate = read(gate_path) if gate_path else ""
    def allowed(text):
        n = norm(text)
        return bool(gate and "ALLOW_SOURCE_EXACT" in gate and n in norm(gate))

    for level, text in headings:
        key = (level, norm(text))
        if key in seen:
            failures.append(f"duplicate heading: {level} {text}")
        seen.add(key)

        if prev:
            pl, pt = prev
            if pl == "##" and level == "###":
                pn, tn = norm(pt), norm(text)
                if tn and (tn == pn or tn in pn or pn in tn):
                    failures.append(f"adjacent H2/H3 heading repetition: {pl} {pt} -> {level} {text}")
        prev = (level, text)

        if "$" in text:
            failures.append(f"math delimiter in heading: {level} {text}")
        for term in BANNED_HEADING_TERMS:
            if term in text and term not in source and not allowed(text):
                failures.append(f"unsupported AI-flavored heading term: {level} {text}")
        for term in PROCESS_HEADING_TERMS:
            if term in text and not allowed(text):
                failures.append(f"process-style heading term: {level} {text}")

    script = Path(__file__).resolve().parent / "validate_heading_voice.py"
    if script.exists():
        cmd = [sys.executable, str(script), str(article_path)]
        if source_path:
            cmd.append(str(source_path))
        if gate_path:
            cmd.append(str(gate_path))
        proc = subprocess.run(cmd, text=True, capture_output=True)
        if proc.returncode != 0:
            failures.append("validate_heading_voice.py failed:\n" + (proc.stdout.strip() or proc.stderr.strip()))

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1

    print("OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
