#!/usr/bin/env python3
from pathlib import Path
import re
import sys

def main():
    if len(sys.argv) < 3:
        print("Usage: validate_symbol_lock.py <symbol_ledger.md> <final.md>")
        return 2
    ledger = Path(sys.argv[1]).read_text(encoding="utf-8")
    final = Path(sys.argv[2]).read_text(encoding="utf-8")
    failures = []
    for line in ledger.splitlines():
        if not line.startswith("| SYM"):
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) < 6:
            continue
        sym_id, preferred, banned = cells[0], cells[4], cells[5]
        for b in re.split(r"[,，;；]", banned):
            b = b.strip()
            if b and b.lower() not in {"none","无"} and b in final:
                failures.append(f"{sym_id}: banned replacement found {b}; preferred {preferred}")
    if failures:
        print("FAILED")
        for f in failures:
            print("-", f)
        return 1
    print("OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
