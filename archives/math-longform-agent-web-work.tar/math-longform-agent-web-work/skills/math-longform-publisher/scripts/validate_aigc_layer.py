#!/usr/bin/env python3
"""Validate the AIGC rewrite layer before publication."""
from pathlib import Path
import json
import re
import sys

AIGC_REQUIRED = [
    "aigc_source_type_ledger.md",
    "aigc_rewrite_tasks.md",
    "aigc_rewritten_final.md",
    "aigc_rewrite_changelog.md",
    "post_aigc_regression_check.md",
    "post_aigc_trace_check.md",
    "post_aigc_formula_check.md",
    "post_aigc_clean_gate.md",
    "publication_final.md",
    "publication_trace_map.md",
    "publication_claim_ledger.md",
    "heading_authorization.jsonl",
    "publication_fragment_authorization.jsonl",
]

HIGH_RISK_PATTERNS = [
    "真正重要的不是",
    "真正的核心",
    "底层逻辑",
    "完整闭环",
    "系统梳理",
    "全面解析",
    "不是凭空出现的",
    "不是突然冒出来的",
    "看懂这篇就够了",
    "你不会只记住一个公式",
]

FAKE_COLLOQUIAL = [
    "别急",
    "说白了",
    "看见没",
    "这一步别跳",
    "交给它接住",
    "落地了",
    "别把它看神秘了",
    "不是硬塞进来的",
]

PROCESS_HEADINGS = ["先说", "先把", "然后", "接下来", "最后", "一波", "也可以这么看"]

def read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""

def table_rows(text: str):
    for line in text.splitlines():
        if line.startswith("|") and not line.startswith("|---"):
            cells = [cell.strip() for cell in line.strip("|").split("|")]
            if cells:
                yield cells

def md_rows(text: str) -> list[dict[str, str]]:
    table_lines = [line.rstrip() for line in text.splitlines() if line.strip().startswith("|")]
    if len(table_lines) < 2:
        return []
    header = [cell.strip() for cell in table_lines[0].strip().strip("|").split("|")]
    rows: list[dict[str, str]] = []
    for line in table_lines[1:]:
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        if cells and all(re.fullmatch(r":?-{3,}:?", cell.replace(" ", "")) for cell in cells):
            continue
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        if len(cells) > len(header):
            cells = cells[: len(header) - 1] + ["|".join(cells[len(header) - 1 :])]
        row = dict(zip(header, cells))
        if any(row.values()):
            rows.append(row)
    return rows

def is_c_source_type(row: dict[str, str]) -> bool:
    source_type = str(row.get("source_type", "")).strip().upper()
    return source_type == "C" or source_type.startswith("C_")

def headings(text):
    return re.findall(r"^(#{1,6})\s+(.+?)\s*$", text, flags=re.M)

def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    failures = []

    for name in AIGC_REQUIRED:
        if not (root / name).exists():
            failures.append(f"missing {name}")

    source = read(root / "source.txt")
    ledger = read(root / "aigc_source_type_ledger.md")
    tasks = read(root / "aigc_rewrite_tasks.md")
    changelog = read(root / "aigc_rewrite_changelog.md")
    publication = read(root / "publication_final.md")
    revised = read(root / "revised_final.md")

    fragment_rows = []
    fragment_path = root / "publication_fragment_authorization.jsonl"
    if fragment_path.exists():
        try:
            fragment_rows = [json.loads(line) for line in fragment_path.read_text(encoding="utf-8").splitlines() if line.strip()]
        except Exception as exc:
            failures.append(f"cannot parse publication_fragment_authorization.jsonl: {exc}")
    for row in fragment_rows:
        if str(row.get("authorization_type", "")) == "UNAUTHORIZED_EDITORIAL":
            failures.append(f"unauthorized editorial fragment remains: {row.get('fragment_id', '')}")
        if str(row.get("review_status", "")) != "APPROVED":
            failures.append(f"fragment lacks APPROVED review status: {row.get('fragment_id', '')}")

    ledger_rows = md_rows(ledger)
    task_rows = md_rows(tasks)

    for row_obj in ledger_rows:
        row = " | ".join(row_obj.values())
        if is_c_source_type(row_obj) and re.search(r"\bpending\b", row, flags=re.I):
            failures.append(f"C-class sentence still pending in AIGC ledger: {row[:160]}")
        if re.search(r"heading", row, flags=re.I) and is_c_source_type(row_obj) and not re.search(r"delete|compress|replace|done", row, flags=re.I):
            failures.append(f"C-class heading lacks real action: {row[:160]}")

    for row_obj in task_rows:
        row = " | ".join(row_obj.values())
        if is_c_source_type(row_obj) and re.search(r"\bpending\b", row, flags=re.I):
            failures.append(f"C-class task still pending: {row[:160]}")

    for phrase in HIGH_RISK_PATTERNS + FAKE_COLLOQUIAL:
        if phrase in publication and phrase not in source:
            failures.append(f"unsupported AIGC-risk phrase in publication_final.md: {phrase}")

    for level, text in headings(publication):
        for phrase in PROCESS_HEADINGS:
            if phrase in text and phrase not in source:
                failures.append(f"process-style heading survived AIGC layer: {level} {text}")

    has_c_material = any(is_c_source_type(row) for row in ledger_rows + task_rows)
    if revised and publication and revised.strip() == publication.strip() and has_c_material:
        failures.append("publication_final.md is identical to revised_final.md while AIGC C-class material exists")

    if re.search(r"changed_math_object\s*\|\s*yes|changed_assumption\s*\|\s*yes|changed_conclusion\s*\|\s*yes|changed_proof_dependency\s*\|\s*yes", changelog, flags=re.I):
        failures.append("aigc_rewrite_changelog.md records mathematical changes; rerun math regression")

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1

    print("OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
