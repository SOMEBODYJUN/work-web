#!/usr/bin/env python3
"""Check that the files required for the selected run mode exist.

Default mode is full_publication, preserving the historical strict release gate.
Use run_mode.json or --mode diagnostic_backtest for staged source/backtest runs.
"""
from __future__ import annotations

from pathlib import Path
import sys

from mode_utils import required_files_for_mode, resolve_mode, parse_mode_args

DEPRECATED = ["final_paragraph_trace.md"]


def nonempty(path: Path) -> bool:
    return path.exists() and path.read_text(encoding="utf-8").strip() != ""


def main() -> int:
    args = sys.argv[1:]
    pre_evidence = False
    if "--pre-evidence" in args:
        pre_evidence = True
        args.remove("--pre-evidence")
    try:
        explicit_mode, args = parse_mode_args(args)
    except ValueError as exc:
        print("FAILED")
        print(f"- {exc}")
        return 1
    root = Path(args[0]) if args else Path(".")
    try:
        mode = resolve_mode(root, explicit_mode)
    except ValueError as exc:
        print("FAILED")
        print(f"- {exc}")
        return 1

    required = required_files_for_mode(mode, pre_evidence=pre_evidence)
    missing = [name for name in required if not (root / name).exists()]
    empty = [name for name in required if (root / name).exists() and not nonempty(root / name)]
    warnings = [name for name in DEPRECATED if (root / name).exists()]
    if missing or empty:
        print("FAILED")
        print(f"mode={mode}")
        if missing:
            print(f"missing {len(missing)} required files:")
            for name in missing:
                print(f"- {name}")
        if empty:
            print("empty required files:")
            for name in empty:
                print(f"- {name}")
        return 1
    print(f"OK: mode={mode} {len(required)} required files present and nonempty" + (" (pre-evidence mode)" if pre_evidence else ""))
    if warnings:
        print("WARNING: deprecated files present; use pre_final_plan.md + final_trace_map.md instead:")
        for name in warnings:
            print(f"- {name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
