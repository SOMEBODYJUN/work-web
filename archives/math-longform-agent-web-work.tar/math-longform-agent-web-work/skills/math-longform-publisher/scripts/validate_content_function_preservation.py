#!/usr/bin/env python3
"""Validate atom-level function preservation across semantic rewrite stages."""
from __future__ import annotations

from pathlib import Path
import argparse
import json

from content_functions import (
    INTERMEDIATE_STAGE_TARGETS,
    PUBLICATION_STAGE,
    read_jsonl,
    stage_function_reviews,
    atom_function_contracts,
)


def validate_one(
    root: Path, stage_id: str, target_file: str, require_all_atoms: bool
) -> list[str]:
    blueprint_path = root / "publication_blueprint.json"
    atom_path = root / "source_atom_ledger.jsonl"
    if not blueprint_path.is_file():
        return ["missing publication_blueprint.json"]
    if not atom_path.is_file():
        return ["missing source_atom_ledger.jsonl"]
    try:
        blueprint = json.loads(blueprint_path.read_text(encoding="utf-8"))
        if not isinstance(blueprint, dict):
            return ["publication_blueprint.json root must be an object"]
        atoms = read_jsonl(atom_path)
        _reviews, errors = stage_function_reviews(
            root,
            blueprint,
            atoms,
            stage_id,
            target_file,
            require_all_atoms=require_all_atoms,
            require_function_matrix=True,
        )
        return errors
    except Exception as exc:
        return [f"content-function validation failed to load: {exc}"]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output")
    parser.add_argument("--stage")
    parser.add_argument("--target")
    parser.add_argument("--all-atoms", action="store_true")
    parser.add_argument("--contracts-only", action="store_true")
    parser.add_argument(
        "--release-chain",
        action="store_true",
        help="validate every rewrite boundary plus P13 publication acceptance",
    )
    args = parser.parse_args()
    root = Path(args.output).resolve()

    requested: list[tuple[str, str, bool]]
    if args.contracts_only:
        try:
            blueprint = json.loads(
                (root / "publication_blueprint.json").read_text(encoding="utf-8")
            )
            atoms = read_jsonl(root / "source_atom_ledger.jsonl")
            _contracts, errors = atom_function_contracts(
                blueprint, atoms, require_function_matrix=True
            )
        except Exception as exc:
            errors = [f"content-function contract validation failed to load: {exc}"]
        if errors:
            print("FAILED")
            for error in errors:
                print(f"- {error}")
            return 1
        print("OK")
        print("validated=atom_function_contracts")
        return 0
    if args.release_chain:
        requested = [*INTERMEDIATE_STAGE_TARGETS, PUBLICATION_STAGE]
    elif args.stage and args.target:
        requested = [(args.stage, args.target, bool(args.all_atoms))]
    else:
        parser.error("provide --stage and --target, or use --release-chain")

    errors: list[str] = []
    for stage_id, target_file, require_all in requested:
        errors.extend(validate_one(root, stage_id, target_file, require_all))
    if errors:
        print("FAILED")
        for error in errors:
            print(f"- {error}")
        return 1
    print("OK")
    print("validated=" + ",".join(stage for stage, _target, _all in requested))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
