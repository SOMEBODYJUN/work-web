#!/usr/bin/env python3
"""Validate cross-chunk dependency mapping and section prefetch coverage.

This gate prevents batched micro-atomization from turning into isolated chunk writing.
For every non-first chunk in a multi-chunk source, the package must either declare the
upstream chunk/atom/symbol/proof/voice dependencies that must be reopened before writing,
or explicitly record that no external dependency exists.
"""
from __future__ import annotations

from pathlib import Path
import re
import sys

from structured_ledger import load_ledger, load_required_ledger, id_set_from_rows, read_text

REQUIRED_DEP_COLUMNS = {
    "dep_id", "consumer_chunk", "consumer_ids", "dependency_type", "provider_chunk",
    "provider_ids", "required_for_sections", "prefetch_files", "status", "verification_note",
}
REQUIRED_PREFETCH_COLUMNS = {
    "prefetch_id", "section_id", "article_target", "consumer_chunks", "must_open_chunks",
    "must_open_dependency_ids", "must_open_files", "covered_dependency_ids", "status", "verification_note",
}
ALLOWED_DEP_TYPES = {
    "DEFINITION", "SYMBOL", "VOICE", "PROOF_PREREQ", "ASSUMPTION", "EXAMPLE",
    "WARNING", "NOTATION", "EXPLANATION_CHAIN", "STRUCTURE", "FUTURE_PREVIEW",
    "NO_EXTERNAL_DEPENDENCY",
}
PASS_STATUSES = {"VERIFIED", "PASS", "READY", "NO_EXTERNAL_DEPENDENCY", "NOT_NEEDED"}
BLOCKING_STATUSES = {"BLOCKED", "FAILED", "PENDING", "TODO", "UNKNOWN", "UNVERIFIED"}
ID_RE = re.compile(r"\b(?:A\d{3,}|T\d{3,}|C\d{3,}|S\d{3,}|PR\d{3,}|V\d{3,}|SYM\d{3,}|CH\d{3,}|SEC\d{2,}|D\d{3,})\b")
CHUNK_RE = re.compile(r"\bC\d{3,}\b")
DEP_RE = re.compile(r"\bD\d{3,}\b")


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def table_header(text: str) -> list[str]:
    for ln in text.splitlines():
        if ln.strip().startswith("|"):
            return [c.strip() for c in ln.strip().strip("|").split("|")]
    return []


def table_rows(text: str) -> list[dict[str, str]]:
    lines = [ln.rstrip() for ln in text.splitlines() if ln.strip().startswith("|")]
    if len(lines) < 2:
        return []
    header = [c.strip() for c in lines[0].strip().strip("|").split("|")]
    rows: list[dict[str, str]] = []
    for line in lines[2:]:
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        if len(cells) > len(header):
            # Keep diagnostics usable if a markdown cell accidentally contains an unescaped pipe.
            cells = cells[: len(header) - 1] + ["|".join(cells[len(header) - 1 :])]
        row = dict(zip(header, cells))
        if any(v.strip() for v in row.values()):
            rows.append(row)
    return rows


def ids(text: str) -> set[str]:
    return set(ID_RE.findall(text))


def listed_ids(value: str) -> list[str]:
    return ID_RE.findall(value or "")


def chunks_from_value(value: str) -> set[str]:
    return set(CHUNK_RE.findall(value or ""))


def chunk_sort_key(cid: str) -> int:
    m = re.search(r"\d+", cid)
    return int(m.group(0)) if m else 10**9


def is_noneish(value: str) -> bool:
    return value.strip().lower() in {"", "none", "n/a", "na", "无", "not_needed", "-"}


def is_blocking_text(value: str) -> bool:
    blob = value.strip().upper()
    return any(token in blob for token in BLOCKING_STATUSES) or bool(re.search(r"待定|未验证|不清楚", value))


def collect_known_ids(root: Path) -> set[str]:
    rels = [
        "source_chunk_index.md", "source_sentence_index.md", "source_atom_ledger.md",
        "source_atom_manifest.md", "source_destination_ledger.md", "voice_expression_ledger.md",
        "symbol_ledger.md", "explanation_chain_ledger.md", "math_statement_ledger.md",
        "proof_obligations.md", "section_plan.md", "merge_plan.md", "pre_final_plan.md",
        "publication_sentence_trace.md", "publication_claim_ledger.md", "final_claim_ledger.md",
        "source_formula_block_ledger.md", "author_question_obligation_ledger.md",
    ]
    out: set[str] = set()
    for rel in rels:
        kind, _header, rows, _errs = load_ledger(root / rel)
        if kind != "missing" and rows:
            for prefix in ["A", "T", "C", "S", "PR", "V", "SYM", "CH", "D", "PF", "FB", "AQ", "CL", "PCL", "PS"]:
                out |= id_set_from_rows(rows, prefix)
        else:
            out |= ids(read(root / rel))
    chunk_dir = root / "chunk_ledger"
    if chunk_dir.exists():
        for path in chunk_dir.glob("*atom_ledger.md"):
            kind, _header, rows, _errs = load_ledger(path)
            if kind != "missing" and rows:
                out |= id_set_from_rows(rows, "A") | id_set_from_rows(rows, "T") | id_set_from_rows(rows, "C")
            else:
                out |= ids(read(path))
    return out


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    failures: list[str] = []
    warnings: list[str] = []

    chunk_text = read(root / "source_chunk_index.md")
    chunk_ids = sorted(set(re.findall(r"\bC\d{3,}\b", chunk_text)), key=chunk_sort_key)
    if not chunk_ids:
        failures.append("source_chunk_index.md has no Cxxx chunk ids")

    dep_path = root / "cross_chunk_dependency_map.md"
    prefetch_path = root / "section_context_prefetch_plan.md"
    dep_kind, dep_rows, dep_failures = load_required_ledger(dep_path, REQUIRED_DEP_COLUMNS, "dep_id", "D")
    pf_kind, prefetch_rows, pf_failures = load_required_ledger(prefetch_path, REQUIRED_PREFETCH_COLUMNS, "prefetch_id", "PF")
    failures.extend(dep_failures)
    failures.extend(pf_failures)
    if dep_kind == "missing":
        failures.append("cross_chunk_dependency_map.jsonl/cross_chunk_dependency_map.md is missing or empty")
    if pf_kind == "missing":
        failures.append("section_context_prefetch_plan.jsonl/section_context_prefetch_plan.md is missing or empty")
    if failures:
        print("FAILED")
        for f in failures:
            print(f"- {f}")
        return 1

    if not dep_rows:
        failures.append("cross_chunk_dependency_map.md has no Dxxx dependency rows")
    if not prefetch_rows:
        failures.append("section_context_prefetch_plan.md has no PFxxx prefetch rows")

    known = collect_known_ids(root) | set(chunk_ids)
    dep_ids = {r.get("dep_id", "") for r in dep_rows}
    audited_consumers: set[str] = set()
    covered_dep_ids: set[str] = set()
    for row in prefetch_rows:
        covered_dep_ids |= set(DEP_RE.findall(" ".join([row.get("must_open_dependency_ids", ""), row.get("covered_dependency_ids", "")])) )

    for row in dep_rows:
        dep_id = row.get("dep_id", "<unknown>")
        consumer = row.get("consumer_chunk", "").strip()
        provider = row.get("provider_chunk", "").strip()
        dep_type = row.get("dependency_type", "").strip().upper()
        status = row.get("status", "").strip().upper()
        joined = " | ".join(row.values())

        if consumer not in chunk_ids and consumer != "ALL":
            failures.append(f"{dep_id}: consumer_chunk {consumer!r} is not in source_chunk_index.md")
        else:
            if consumer != "ALL":
                audited_consumers.add(consumer)
        if dep_type not in ALLOWED_DEP_TYPES:
            failures.append(f"{dep_id}: invalid dependency_type {dep_type!r}")
        if status not in PASS_STATUSES:
            failures.append(f"{dep_id}: status must be a passing or explicit no-dependency state, got {status!r}")
        if is_blocking_text(joined):
            failures.append(f"{dep_id}: unresolved/blocking text appears in dependency row")
        if not row.get("verification_note", "").strip():
            failures.append(f"{dep_id}: missing verification_note")

        no_external = dep_type == "NO_EXTERNAL_DEPENDENCY" or status == "NO_EXTERNAL_DEPENDENCY"
        if no_external:
            if len(chunk_ids) > 1 and consumer == "ALL":
                failures.append(f"{dep_id}: no-external-dependency rows must name the audited consumer_chunk, not ALL")
            continue

        if provider not in chunk_ids:
            failures.append(f"{dep_id}: provider_chunk {provider!r} is not in source_chunk_index.md")
        elif provider == consumer:
            failures.append(f"{dep_id}: cross-chunk dependency points to the same chunk {provider}; keep local dependencies out of this map")
        elif chunk_sort_key(provider) > chunk_sort_key(consumer) and dep_type != "FUTURE_PREVIEW":
            warnings.append(f"{dep_id}: provider_chunk {provider} occurs after consumer_chunk {consumer}; verify deliberate article reordering")

        provider_ids = listed_ids(row.get("provider_ids", ""))
        consumer_ids = listed_ids(row.get("consumer_ids", ""))
        if not provider_ids:
            failures.append(f"{dep_id}: non-empty provider_ids required for real dependencies")
        if not consumer_ids and consumer != "ALL":
            failures.append(f"{dep_id}: consumer_ids should identify target atoms/statements/sections")
        for ref in provider_ids + consumer_ids:
            if ref.startswith("D"):
                continue
            if ref not in known:
                failures.append(f"{dep_id}: referenced id {ref} not found in upstream ledgers")
        if is_noneish(row.get("required_for_sections", "")):
            failures.append(f"{dep_id}: required_for_sections is empty; dependency is not operationalized")
        if is_noneish(row.get("prefetch_files", "")):
            failures.append(f"{dep_id}: prefetch_files is empty; builder will not know what to reopen")
        if dep_id not in covered_dep_ids:
            failures.append(f"{dep_id}: not covered by section_context_prefetch_plan.md")

    # Every non-first chunk must be audited, either by real dependencies or by a no-external row.
    if len(chunk_ids) > 1:
        for cid in chunk_ids[1:]:
            if cid not in audited_consumers:
                failures.append(f"{cid}: no dependency audit row found; add real dependencies or NO_EXTERNAL_DEPENDENCY")

    for row in prefetch_rows:
        pfid = row.get("prefetch_id", "<unknown>")
        status = row.get("status", "").strip().upper()
        joined = " | ".join(row.values())
        if status not in PASS_STATUSES:
            failures.append(f"{pfid}: status must be PASS/READY/VERIFIED/NO_EXTERNAL_DEPENDENCY/NOT_NEEDED, got {status!r}")
        if is_blocking_text(joined):
            failures.append(f"{pfid}: unresolved/blocking text appears in prefetch row")
        if not row.get("verification_note", "").strip():
            failures.append(f"{pfid}: missing verification_note")
        pdeps = set(DEP_RE.findall(" ".join([row.get("must_open_dependency_ids", ""), row.get("covered_dependency_ids", "")])) )
        unknown_deps = sorted(pdeps - dep_ids)
        if unknown_deps:
            failures.append(f"{pfid}: prefetch row references unknown dep ids: {', '.join(unknown_deps)}")
        must_chunks = chunks_from_value(row.get("must_open_chunks", ""))
        unknown_chunks = sorted(must_chunks - set(chunk_ids), key=chunk_sort_key)
        if unknown_chunks:
            failures.append(f"{pfid}: must_open_chunks references unknown chunks: {', '.join(unknown_chunks)}")
        must_files = row.get("must_open_files", "")
        if len(chunk_ids) > 1 and not re.search(r"cross_chunk_dependency_map\.md", must_files):
            failures.append(f"{pfid}: must_open_files should include cross_chunk_dependency_map.md")
        if len(chunk_ids) > 1 and not re.search(r"source_atom_manifest\.md|source_atom_ledger\.md", must_files):
            failures.append(f"{pfid}: must_open_files should include source_atom_manifest.md or source_atom_ledger.md")
        if len(chunk_ids) > 1 and not re.search(r"chunk_ledger/|chunk_C", must_files):
            failures.append(f"{pfid}: must_open_files should include the relevant chunk ledger files")

        for dep_id in pdeps:
            dep = next((r for r in dep_rows if r.get("dep_id") == dep_id), None)
            if not dep:
                continue
            needed_chunks = {dep.get("consumer_chunk", ""), dep.get("provider_chunk", "")} - {"", "none", "NONE", "ALL"}
            missing_chunks = sorted(needed_chunks - must_chunks, key=chunk_sort_key)
            if missing_chunks:
                failures.append(f"{pfid}: does not open chunks required by {dep_id}: {', '.join(missing_chunks)}")

    if failures:
        print("FAILED")
        print(f"chunks={len(chunk_ids)} dependency_rows={len(dep_rows)} prefetch_rows={len(prefetch_rows)} dependency_source={dep_kind} prefetch_source={pf_kind}")
        for f in failures:
            print(f"- {f}")
        for w in warnings[:20]:
            print(f"WARNING: {w}")
        return 1

    print("OK")
    print(f"chunks={len(chunk_ids)} dependency_rows={len(dep_rows)} prefetch_rows={len(prefetch_rows)} dependency_source={dep_kind} prefetch_source={pf_kind}")
    for w in warnings[:20]:
        print(f"WARNING: {w}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
