#!/usr/bin/env python3
"""Validate that AIGC source-type classification covers the publication surface."""
from __future__ import annotations

from pathlib import Path
import json
import re
import sys


ALLOWED_SOURCE_TYPES = {"A", "B", "C", "D", "A_SOURCE", "B_BRIDGE", "C_ASSISTANT", "D_UNSUPPORTED"}
ID_RE = re.compile(r"\b(?:A|S|PR|PCL|PS|PP|V|SYM|CH)\d{3,}\b")
PLACEHOLDER_RE = re.compile(r"\b(TODO|TBD|pending|unknown|unclear)\b", re.I)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def compact(text: str) -> str:
    return re.sub(r"\s+", "", str(text or "")).strip()


def md_rows(text: str) -> list[dict[str, str]]:
    table_lines = [ln.rstrip() for ln in text.splitlines() if ln.strip().startswith("|")]
    if len(table_lines) < 2:
        return []
    header = [c.strip() for c in table_lines[0].strip().strip("|").split("|")]
    rows: list[dict[str, str]] = []
    for line in table_lines[1:]:
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if cells and all(re.fullmatch(r":?-{3,}:?", c.replace(" ", "")) for c in cells):
            continue
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        if len(cells) > len(header):
            cells = cells[: len(header) - 1] + ["|".join(cells[len(header) - 1 :])]
        row = dict(zip(header, cells))
        if any(row.values()):
            rows.append(row)
    return rows


def load_jsonl(path: Path) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    if not path.exists():
        return rows
    for line in read(path).splitlines():
        if not line.strip():
            continue
        try:
            item = json.loads(line)
        except Exception:
            return []
        if isinstance(item, dict):
            rows.append({str(k): str(v) for k, v in item.items()})
    return rows


def publication_units(root: Path) -> list[dict[str, str]]:
    rows = load_jsonl(root / "publication_sentence_trace.jsonl")
    if not rows:
        rows = md_rows(read(root / "publication_sentence_trace.md"))
    units = []
    for row in rows:
        text = row.get("sentence_or_heading") or row.get("sentence_excerpt") or row.get("claim_excerpt") or ""
        if compact(text):
            units.append(row)
    return units


def aigc_rows(root: Path) -> list[dict[str, str]]:
    return md_rows(read(root / "aigc_source_type_ledger.md"))


def text_field(row: dict[str, str]) -> str:
    for key in ["sentence_or_heading", "sentence_excerpt", "claim_excerpt", "text", "excerpt"]:
        if compact(row.get(key, "")):
            return row.get(key, "")
    return ""


def source_type(row: dict[str, str]) -> str:
    return str(row.get("source_type", "")).strip().upper()


def row_support(row: dict[str, str]) -> str:
    return " ".join(str(row.get(k, "")) for k in ["source_atoms", "statement_ids", "proof_ids", "required_action", "status", "sentence_id", "aigc_id"])


def is_covered(unit_text: str, ledger_rows: list[dict[str, str]]) -> bool:
    needle = compact(unit_text)
    if not needle:
        return True
    for row in ledger_rows:
        hay = compact(text_field(row))
        if not hay:
            continue
        if needle in hay or hay in needle:
            return True
        # Allow short heading markers to match after dropping markdown hashes.
        if needle.lstrip("#") and needle.lstrip("#") in hay.lstrip("#"):
            return True
    return False


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    root = root.resolve()
    failures: list[str] = []

    units = publication_units(root)
    ledger = aigc_rows(root)
    if not units:
        failures.append("publication_sentence_trace has no sentence/heading units to classify")
    if not ledger:
        failures.append("aigc_source_type_ledger.md has no classification rows")

    if units and ledger and len(ledger) < len(units):
        failures.append(f"aigc_source_type_ledger.md rows ({len(ledger)}) fewer than publication sentence trace units ({len(units)})")

    for idx, row in enumerate(ledger, 1):
        stype = source_type(row)
        if stype not in ALLOWED_SOURCE_TYPES:
            failures.append(f"AIGC row {idx} has invalid source_type: {stype!r}")
        if PLACEHOLDER_RE.search(" ".join(row.values())):
            failures.append(f"AIGC row {idx} contains unresolved placeholder")
        support = row_support(row)
        if stype.startswith(("A", "B")) and not ID_RE.search(support):
            failures.append(f"AIGC row {idx} source_type {stype} has no source/proof ids")
        if stype.startswith(("C", "D")):
            action = str(row.get("required_action") or row.get("action_status") or row.get("status") or "").lower()
            if not re.search(r"delete|compress|replace|done|resolved", action):
                failures.append(f"AIGC row {idx} source_type {stype} lacks a completed removal/replacement action")

    missing = []
    for unit in units:
        unit_text = text_field(unit)
        if unit_text and not is_covered(unit_text, ledger):
            missing.append(unit_text)
    if missing:
        failures.append("publication units missing AIGC classification: " + "; ".join(missing[:5]))

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print(f"OK: publication_units={len(units)} aigc_rows={len(ledger)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
