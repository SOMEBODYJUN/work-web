#!/usr/bin/env python3
"""Reject over-broad source-atom support ranges in trace and claim ledgers.

This gate is intentionally conservative: it does not judge prose quality, but it
prevents a publication package from claiming that one sentence, paragraph, or
claim is supported by an entire source manuscript range such as A0001-A0538.
"""
from __future__ import annotations

from pathlib import Path
import json
import re
import sys


TRACE_FILES = {
    "final_trace_map.md": 80,
    "publication_trace_map.md": 80,
    "final_claim_ledger.md": 60,
    "publication_claim_ledger.md": 60,
    "publication_sentence_trace.md": 30,
}

RANGE_RE = re.compile(r"\bA(\d{3,})\s*[-:]\s*A(\d{3,})\b")
ATOM_RE = re.compile(r"\bA\d{3,}\b")


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def table_rows(text: str) -> list[dict[str, str]]:
    lines = [line.rstrip() for line in text.splitlines() if line.strip().startswith("|")]
    if len(lines) < 2:
        return []
    header = [cell.strip() for cell in lines[0].strip().strip("|").split("|")]
    rows: list[dict[str, str]] = []
    for line in lines[2:]:
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        if not cells or all(re.fullmatch(r":?-{3,}:?", cell.replace(" ", "")) for cell in cells):
            continue
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        if len(cells) > len(header):
            cells = cells[: len(header) - 1] + ["|".join(cells[len(header) - 1 :])]
        row = dict(zip(header, cells))
        if any(row.values()):
            rows.append(row)
    return rows


def read_jsonl(path: Path) -> list[dict[str, str]]:
    if not path.exists() or not read(path).strip():
        return []
    out: list[dict[str, str]] = []
    for line in read(path).splitlines():
        if not line.strip():
            continue
        try:
            obj = json.loads(line)
        except Exception:
            continue
        if isinstance(obj, dict):
            out.append({str(k): str(v) for k, v in obj.items()})
    return out


def support_width(value: str) -> tuple[int, list[str]]:
    failures: list[str] = []
    width = len(set(ATOM_RE.findall(value or "")))
    for start, end in RANGE_RE.findall(value or ""):
        a, b = int(start), int(end)
        if b >= a:
            span = b - a + 1
            width += span
            if span > 40:
                failures.append(f"over-broad atom range A{a:04d}-A{b:04d} spans {span} atoms")
    return width, failures


def row_id(row: dict[str, str]) -> str:
    for key in ["paragraph_id", "claim_id", "sentence_trace_id", "trace_id"]:
        if row.get(key):
            return row[key]
    for value in row.values():
        m = re.search(r"\b(?:P|PP|CL|PCL|PS)\d{3,}\b", value)
        if m:
            return m.group(0)
    return "<unknown>"


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    failures: list[str] = []

    for rel, max_atoms in TRACE_FILES.items():
        path = root / rel
        rows = table_rows(read(path))
        jsonl_path = path.with_suffix(".jsonl")
        if jsonl_path.exists():
            rows = read_jsonl(jsonl_path) or rows
        for row in rows:
            source_atoms = row.get("source_atoms", "")
            if not source_atoms:
                continue
            width, range_failures = support_width(source_atoms)
            rid = row_id(row)
            for failure in range_failures:
                failures.append(f"{rel}:{rid}: {failure}")
            if width > max_atoms:
                failures.append(f"{rel}:{rid}: source_atoms support is too broad ({width} atom refs, max {max_atoms})")

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print("OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
