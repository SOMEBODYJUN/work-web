#!/usr/bin/env python3
"""Shared source-review blocker policy for mode transition and release validation."""
from __future__ import annotations

from pathlib import Path

from safe_io import read_jsonl_strict

BLOCKING_CONTRACTS = {
    "source_formula_block_ledger.jsonl": (
        "canonicalization_status",
        {"BLOCKED_NEEDS_HUMAN_REVIEW"},
    ),
    "author_question_obligation_ledger.jsonl": (
        "resolution_status",
        {"BLOCKED_NEEDS_SOURCE_SUPPORT"},
    ),
    "source_math_risk_ledger.jsonl": (
        "resolution_status",
        {"BLOCKED_NEEDS_MATHEMATICAL_REVIEW"},
    ),
}


def unresolved_source_review_counts(root: Path) -> dict[str, int]:
    root = Path(root).resolve()
    counts: dict[str, int] = {}
    for name, (field, blocking) in BLOCKING_CONTRACTS.items():
        path = root / name
        if not path.exists():
            counts[name] = -1
            continue
        try:
            rows = read_jsonl_strict(path, root=root)
        except Exception:
            counts[name] = -1
            continue
        counts[name] = sum(
            str(row.get(field, "")).upper() in blocking
            for row in rows
        )
    return counts
