#!/usr/bin/env python3
"""Conservative reader-visible Markdown surface helpers."""
from __future__ import annotations

import html
import re
import unicodedata

HTML_COMMENT_RE = re.compile(r"<!--.*?-->", re.S)
LINK_DEFINITION_RE = re.compile(r"(?m)^\s{0,3}\[[^\]]+\]:\s*\S+.*$")
FENCE_RE = re.compile(r"(?m)^\s*(`{3,}|~{3,}).*$")
RAW_TAG_RE = re.compile(r"</?\s*([A-Za-z][A-Za-z0-9:-]*)\b[^>]*>")
MARKDOWN_LINK_RE = re.compile(r"!?\[([^\]]*)\]\(([^)]+)\)")
MARKDOWN_AUTOLINK_RE = re.compile(r"<((?:https?|mailto):[^>]+)>", re.I)
INVISIBLE_CODEPOINTS = {
    "\u200b", "\u200c", "\u200d", "\u2060", "\ufeff", "\u00ad",
    "\u202a", "\u202b", "\u202c", "\u202d", "\u202e",
    "\u2066", "\u2067", "\u2068", "\u2069",
}


def fence_ranges(text: str) -> tuple[list[tuple[int, int]], bool]:
    ranges: list[tuple[int, int]] = []
    open_marker: tuple[str, int] | None = None
    for match in FENCE_RE.finditer(text):
        marker = match.group(1)
        char = marker[0]
        length = len(marker)
        if open_marker is None:
            open_marker = (char * length, match.start())
        else:
            opener, start = open_marker
            if marker[0] == opener[0] and len(marker) >= len(opener):
                ranges.append((start, match.end()))
                open_marker = None
    return ranges, open_marker is not None


def strip_markdown_syntax(text: str) -> str:
    text = HTML_COMMENT_RE.sub("", text)
    text = LINK_DEFINITION_RE.sub("", text)
    text = MARKDOWN_LINK_RE.sub(lambda m: m.group(1), text)
    text = MARKDOWN_AUTOLINK_RE.sub(lambda m: m.group(1), text)
    text = re.sub(r"(?m)^\s{0,3}(?:#{1,6}\s+|>\s?|[-*+]\s+|\d+[.)]\s+)", "", text)
    text = re.sub(r"(?m)^\s*(?:=+|-+)\s*$", "", text)
    text = re.sub(r"[*_~`]", "", text)
    text = RAW_TAG_RE.sub("", text)
    return html.unescape(text)


def visible_text(text: str) -> str:
    surface = strip_markdown_syntax(text)
    surface = "".join(ch for ch in surface if ch not in INVISIBLE_CODEPOINTS and unicodedata.category(ch) != "Cf")
    return re.sub(r"\s+", " ", surface).strip()


def normalized_visible_text(text: str) -> str:
    return unicodedata.normalize("NFC", visible_text(text))


def code_fence_fraction(text: str) -> float:
    ranges, unclosed = fence_ranges(text)
    if unclosed:
        return 1.0
    covered = sum(end - start for start, end in ranges)
    return covered / max(1, len(text))
