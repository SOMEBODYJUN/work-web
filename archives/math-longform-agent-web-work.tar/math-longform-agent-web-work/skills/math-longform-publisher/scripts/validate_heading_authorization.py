#!/usr/bin/env python3
"""Validate source-grounded authorization for every final heading."""
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import re
import sys

ALLOWED_BASES = {
    "SOURCE_TERM",
    "STRUCTURAL_LABEL",
    "MINIMAL_CONNECTOR",
    "MATHEMATICAL_STANDARD_TERM",
    "USER_REQUESTED",
}
STRUCTURAL_LABELS = {
    "定义", "定理", "命题", "证明", "必要性", "充分性", "例", "反例", "注意",
    "性质", "推论", "引理", "应用", "结论",
}
MINIMAL_CONNECTORS = {"与", "和", "及", "到", "从", "的", "、", "：", ":", "—", "-", "（", "）", "(", ")"}
CREATIVE_PATTERNS = [
    r"收起来", r"讲一下", r"真正", r"核心", r"底层逻辑", r"秘密", r"灵魂",
    r"冒险", r"一口气", r"全景", r"完整闭环", r"重新认识", r"把.*装进",
]


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_jsonl(path: Path) -> list[dict]:
    rows = []
    for lineno, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        value = json.loads(line)
        if not isinstance(value, dict):
            raise ValueError(f"{path.name}:{lineno}: row is not an object")
        rows.append(value)
    return rows


def heading_spans(data: bytes) -> list[dict]:
    text = data.decode("utf-8", errors="strict")
    rows = []
    byte_cursor = 0
    for line in text.splitlines(keepends=True):
        raw = line.encode("utf-8")
        m = re.match(r"^(#{1,6})[ \t]+(.+?)[ \t]*(?:\r?\n)?$", line)
        if m:
            content = m.group(2)
            content = content.rstrip("\r\n")
            prefix = line[:m.start(2)].encode("utf-8")
            content_raw = content.encode("utf-8")
            rows.append({
                "level": len(m.group(1)),
                "text": content,
                "line_start": byte_cursor,
                "content_start": byte_cursor + len(prefix),
                "content_end": byte_cursor + len(prefix) + len(content_raw),
                "line_end": byte_cursor + len(raw.rstrip(b"\r\n")),
            })
        byte_cursor += len(raw)
    return rows


def fail(errors: list[str]) -> int:
    print("FAILED")
    for error in errors:
        print(f"- {error}")
    return 1


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    article_path = root / "publication_final.md"
    source_path = root / "source_canonical.txt"
    ledger_path = root / "heading_authorization.jsonl"
    missing = [p.name for p in [article_path, source_path, ledger_path] if not p.exists()]
    if missing:
        return fail(["missing required heading-authorization file: " + ", ".join(missing)])

    try:
        article = article_path.read_bytes()
        source = source_path.read_bytes()
        actual = heading_spans(article)
        rows = load_jsonl(ledger_path)
        math_review_path = root / "mathematical_review.json"
        math_review = json.loads(math_review_path.read_text(encoding="utf-8")) if math_review_path.exists() else {}
        math_item_ids = {str(item.get("item_id", "")) for item in math_review.get("items", []) if isinstance(item, dict)}
    except Exception as exc:
        return fail([str(exc)])

    errors: list[str] = []
    if len(rows) != len(actual):
        errors.append(f"heading authorization row count {len(rows)} != actual headings {len(actual)}")

    for idx, heading in enumerate(actual):
        if idx >= len(rows):
            break
        row = rows[idx]
        hid = str(row.get("heading_id", f"row {idx+1}"))
        if int(row.get("heading_level", -1)) != heading["level"]:
            errors.append(f"{hid}: heading level mismatch")
        if str(row.get("heading_text", "")) != heading["text"]:
            errors.append(f"{hid}: heading text mismatch")
        raw = article[heading["content_start"]:heading["content_end"]]
        if str(row.get("heading_text_sha256", "")) != sha(raw):
            errors.append(f"{hid}: heading hash mismatch")
        if str(row.get("review_status", "")) != "APPROVED":
            errors.append(f"{hid}: review_status must be APPROVED")

        segments = row.get("segments")
        if not isinstance(segments, list) or not segments:
            errors.append(f"{hid}: heading must have authorization segments")
            continue
        reconstructed = "".join(str(seg.get("text", "")) for seg in segments)
        if reconstructed != heading["text"]:
            errors.append(f"{hid}: authorization segments do not reconstruct heading text")

        for seg_idx, seg in enumerate(segments, 1):
            text = str(seg.get("text", ""))
            basis = str(seg.get("basis", ""))
            if not text:
                errors.append(f"{hid}: empty segment {seg_idx}")
                continue
            if basis not in ALLOWED_BASES:
                errors.append(f"{hid}: invalid segment basis {basis!r}")
                continue
            if basis == "SOURCE_TERM":
                try:
                    start = int(seg.get("source_byte_start"))
                    end = int(seg.get("source_byte_end"))
                    raw_src = source[start:end]
                    if raw_src.decode("utf-8", errors="strict") != text:
                        errors.append(f"{hid}: SOURCE_TERM segment is not exact current-source text: {text!r}")
                    if str(seg.get("source_text_sha256", "")) != sha(raw_src):
                        errors.append(f"{hid}: SOURCE_TERM hash mismatch")
                except Exception:
                    errors.append(f"{hid}: invalid SOURCE_TERM span")
            elif basis == "STRUCTURAL_LABEL":
                stripped = re.sub(r"[\d.\s：:]+", "", text)
                if stripped and stripped not in STRUCTURAL_LABELS:
                    errors.append(f"{hid}: unsupported structural label {text!r}")
            elif basis == "MINIMAL_CONNECTOR":
                if text not in MINIMAL_CONNECTORS:
                    errors.append(f"{hid}: unsupported minimal connector {text!r}")
            elif basis == "MATHEMATICAL_STANDARD_TERM":
                ids = seg.get("math_review_item_ids", [])
                if not isinstance(ids, list) or not ids:
                    errors.append(f"{hid}: mathematical standard term requires math_review_item_ids")
                elif any(str(item_id) not in math_item_ids for item_id in ids):
                    errors.append(f"{hid}: mathematical standard term cites unknown review item")
                if len(text) > 36:
                    errors.append(f"{hid}: mathematical standard term segment is too broad")
            elif basis == "USER_REQUESTED":
                ids = seg.get("feedback_ids", [])
                if not isinstance(ids, list) or not ids:
                    errors.append(f"{hid}: USER_REQUESTED segment requires feedback_ids")

        for pattern in CREATIVE_PATTERNS:
            if re.search(pattern, heading["text"]):
                # Source exact or user-requested wording may legitimately contain it.
                if not all(seg.get("basis") in {"SOURCE_TERM", "USER_REQUESTED"} for seg in segments):
                    errors.append(f"{hid}: unsupported editorial/creative heading pattern {pattern!r}")

    if errors:
        return fail(errors)
    print(f"OK: authorized_headings={len(actual)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
