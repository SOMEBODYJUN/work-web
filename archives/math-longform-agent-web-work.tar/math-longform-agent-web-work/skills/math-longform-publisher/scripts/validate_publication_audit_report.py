#!/usr/bin/env python3
"""Validate the unified PUBLICATION_AUDIT_REPORT.md release gate."""
from __future__ import annotations

from pathlib import Path
import hashlib
import re
import sys

from mode_utils import FULL_PUBLICATION, WECHAT_PUBLICATION, resolve_mode
from safe_io import read_json_strict, read_optional_text

REQUIRED_HEADINGS = [
    "# Publication Audit Report",
    "## Final State",
    "## Source Identity",
    "## Ledger Consumption",
    "## Math And Proof Locks",
    "## Claim Source Obligation",
    "## Reverse Trace",
    "## AIGC Regression",
    "## Security Boundary",
    "## Failure Recovery",
    "## Validator Evidence Lock",
    "## Command Evidence",
    "## Release Decision",
]
ALLOWED_STATES = {"PUBLISHABLE", "PARTIAL", "BLOCKED"}
DECISION_FOR_STATE = {
    "PUBLISHABLE": "publishable",
    "PARTIAL": "partial_do_not_publish",
    "BLOCKED": "blocked_do_not_publish",
}


def read(path: Path) -> str:
    return read_optional_text(path)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def field(text: str, name: str, failures: list[str]) -> str:
    matches = re.findall(rf"(?mi)^\s*{re.escape(name)}\s*:\s*(\S+)\s*$", text)
    if len(matches) != 1:
        failures.append(f"audit report must contain exactly one {name}, found {len(matches)}")
        return ""
    return matches[0].strip()


def command_rows(text: str) -> list[dict[str, str]]:
    rows = []
    header = None
    in_section = False
    for line in text.splitlines():
        if line.strip() == "## Command Evidence":
            in_section = True
            continue
        if in_section and line.startswith("## "):
            break
        if not in_section or not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if not cells or cells[0].startswith("---"):
            continue
        if cells[0] == "command":
            header = cells
            continue
        if header and len(cells) >= len(header):
            rows.append(dict(zip(header, cells)))
    return rows


def load_validator_result(root: Path, failures: list[str]) -> tuple[dict | None, str]:
    json_path = root / "validator_result.json"
    sha_path = root / "validator_result.sha256"
    if not json_path.exists():
        failures.append("missing validator_result.json")
        return None, ""
    raw = json_path.read_bytes()
    actual_sha = sha256_bytes(raw)
    if not sha_path.exists():
        failures.append("missing validator_result.sha256")
    else:
        m = re.search(r"\b([0-9a-f]{64})\b", read(sha_path))
        if not m:
            failures.append("validator_result.sha256 has no 64-character digest")
        elif m.group(1) != actual_sha:
            failures.append("validator_result.sha256 does not match validator_result.json")
    try:
        data = read_json_strict(json_path)
    except Exception as exc:
        failures.append(f"validator_result.json is not valid strict JSON: {exc}")
        return None, actual_sha
    return data, actual_sha


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    path = root / "PUBLICATION_AUDIT_REPORT.md"
    text = read(path)
    failures: list[str] = []
    if not text.strip():
        failures.append("missing or empty PUBLICATION_AUDIT_REPORT.md")
    for heading in REQUIRED_HEADINGS:
        if heading not in text:
            failures.append(f"missing required heading: {heading}")

    state = field(text, "FINAL_STATE", failures)
    decision = field(text, "RELEASE_DECISION", failures)
    audit_mode = field(text, "RUN_MODE", failures) or ""
    try:
        package_mode = resolve_mode(root, None, allow_mode_file=False)
    except ValueError as exc:
        failures.append(str(exc))
        package_mode = audit_mode or FULL_PUBLICATION
    if audit_mode and audit_mode != package_mode:
        failures.append(f"audit RUN_MODE {audit_mode!r} does not match package mode {package_mode!r}")
    if state == "PUBLISHABLE" and package_mode not in {FULL_PUBLICATION, WECHAT_PUBLICATION}:
        failures.append(f"{package_mode} mode cannot declare FINAL_STATE PUBLISHABLE; rerun full_publication or wechat_publication")
    if state not in ALLOWED_STATES:
        failures.append(f"FINAL_STATE must be {sorted(ALLOWED_STATES)}, got {state!r}")
    elif decision != DECISION_FOR_STATE[state]:
        failures.append(f"RELEASE_DECISION {decision!r} does not match FINAL_STATE {state}")

    if re.search(r"\b(TODO|TBD|pending|unknown|unclear|should pass|will run|probably)\b|待定|不清楚", text, flags=re.I):
        failures.append("audit report contains future-tense or unresolved evidence wording")

    validator_data, actual_sha = load_validator_result(root, failures)
    audit_sha = field(text, "VALIDATOR_RESULT_SHA256", failures)
    audit_file = field(text, "VALIDATOR_RESULT_FILE", failures)
    if audit_file != "validator_result.json":
        failures.append("VALIDATOR_RESULT_FILE must be validator_result.json")
    if not re.fullmatch(r"[0-9a-f]{64}", audit_sha):
        failures.append("VALIDATOR_RESULT_SHA256 must be a 64-character hex digest")
    elif actual_sha and audit_sha != actual_sha:
        failures.append("VALIDATOR_RESULT_SHA256 in audit report does not match validator_result.json")

    rows = command_rows(text)
    if not rows:
        failures.append("Command Evidence table has no command rows")
    seen_runner_row = False
    failed_rows = []
    for row in rows:
        cmd = row.get("command", "")
        code = row.get("exit_code", "")
        verdict = row.get("verdict", "")
        if not re.fullmatch(r"\d+", str(code)):
            failures.append(f"command row has non-numeric exit_code: {row}")
            continue
        if verdict not in {"PASS", "FAIL", "BLOCKED"}:
            failures.append(f"command row has invalid verdict: {row}")
        if int(code) != 0 or verdict != "PASS":
            failed_rows.append(row)
        if "run_publication_validators.py" in cmd and int(code) == 0 and verdict == "PASS":
            seen_runner_row = True

    if isinstance(validator_data, dict):
        overall_verdict = validator_data.get("overall_verdict")
        overall_code = validator_data.get("overall_exit_code")
        result_mode = str(validator_data.get("run_mode") or FULL_PUBLICATION)
        if result_mode != package_mode:
            failures.append(f"validator_result run_mode {result_mode!r} does not match package mode {package_mode!r}")
        if state == "PUBLISHABLE":
            if overall_verdict != "PASS" or overall_code != 0:
                failures.append("PUBLISHABLE requires validator_result overall_verdict PASS and overall_exit_code 0")
            for item in validator_data.get("results", []):
                if isinstance(item, dict) and (item.get("exit_code") != 0 or item.get("verdict") != "PASS"):
                    failures.append(f"PUBLISHABLE cannot cite failed validator_result row: {item.get('script')}")
                    break
        if state != "PUBLISHABLE" and overall_verdict == "PASS" and decision != "publishable":
            # Partial/blocked is allowed for editorial reasons, but it must be explicit in release sections.
            pass

    if state == "PUBLISHABLE":
        if not seen_runner_row:
            failures.append("PUBLISHABLE requires a PASS row for run_publication_validators.py with exit_code 0")
        if failed_rows:
            failures.append("PUBLISHABLE cannot include failed/BLOCKED command rows")
        for section in [
            "Ledger Consumption", "Math And Proof Locks", "Claim Source Obligation",
            "Reverse Trace", "AIGC Regression", "Security Boundary", "Failure Recovery",
        ]:
            pattern = rf"## {re.escape(section)}(.*?)(?:\n## |\Z)"
            m = re.search(pattern, text, flags=re.S)
            if not m:
                continue
            header = None
            for line in m.group(1).splitlines():
                if not line.startswith("|"):
                    continue
                cells = [c.strip() for c in line.strip().strip("|").split("|")]
                if not cells or cells[0].startswith("---"):
                    continue
                if "status" in cells:
                    header = cells
                    continue
                if header and len(cells) >= len(header):
                    row = dict(zip(header, cells))
                    status = row.get("status", "").upper()
                    if status in {"FAIL", "BLOCKED", "PENDING"}:
                        failures.append(f"PUBLISHABLE audit has non-pass status in section {section}: {line}")

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print("OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
