#!/usr/bin/env python3
"""Bind P03 source obligations into the existing Atom/function realization chain.

The deterministic layer does not decide whether prose fulfills an obligation.
P03 identifies the obligation, P04 selects its semantic function bindings, and
the phase reviewer judges the cited target text.  This module only prevents an
obligation identity from disappearing between those decisions.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any
import hashlib
import json
import re

from content_functions import CONTENT_FUNCTIONS, normalize_functions
from safe_io import atomic_write_text, read_jsonl_strict
from structured_ledger import markdown_table


AQ_LEDGER = "author_question_obligation_ledger.jsonl"
FORMULA_LEDGER = "source_formula_block_ledger.jsonl"
MATH_RISK_LEDGER = "source_math_risk_ledger.jsonl"

AQ_NON_OBLIGATION_TYPES = {
    "P02_SEMANTIC_CANDIDATE",
    "SOURCE_WIDE_SEMANTIC_SCAN",
    "DISMISSED_P02_CANDIDATE",
    "NO_AUTHOR_QUESTIONS",
}
AQ_FINAL_STATUSES = {
    "RESOLVED_IN_ARTICLE",
    "PRESERVED_AS_AUTHOR_QUESTION",
    "ANSWERED_IN_EXPLANATION",
}
AQ_REQUIRED_FUNCTIONS = {
    "UNDERSTANDING_CHECK": {"QUESTION_OR_DOUBT"},
    "REQUEST_FOR_BETTER_METHOD": {"METHOD_OBSERVATION", "FOLLOWUP_REQUEST"},
    "REQUEST_FOR_APPLICATION": {"FOLLOWUP_REQUEST"},
    "REQUEST_FOR_DEEPER_EXPLANATION": {"EXPLANATION_CHAIN", "FOLLOWUP_REQUEST"},
    "REQUEST_FOR_GEOMETRIC_INTERPRETATION": {
        "INTUITION_OR_ANALOGY",
        "FOLLOWUP_REQUEST",
    },
    "UNCERTAINTY_TO_RESOLVE": {"QUESTION_OR_DOUBT"},
    "VOICE_INTENT_TO_PRESERVE": {"AUTHOR_PERSPECTIVE"},
}

FULFILLMENT_MODES = {
    "AUTHOR_QUESTION": {
        "PRESERVE_AS_QUESTION",
        "ANSWER_IN_EXPLANATION",
        "RESOLVE_IN_ARTICLE",
        "PRESERVE_VOICE_INTENT",
    },
    "FORMULA_BLOCK": {"SATISFY_MATHEMATICAL_CONDITIONS"},
    "MATH_RISK": {"SATISFY_MATHEMATICAL_CONDITIONS"},
}


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def parse_span(value: Any) -> tuple[int, int] | None:
    match = re.fullmatch(r"\s*(\d+)\s*-\s*(\d+)\s*", str(value or ""))
    if not match:
        return None
    start, end = int(match.group(1)), int(match.group(2))
    return (start, end) if 0 <= start < end else None


def normalize_ids(value: Any, prefix: str) -> list[str]:
    raw = value if isinstance(value, list) else re.split(r"[,;\s]+", str(value or ""))
    result: list[str] = []
    for item in raw:
        token = str(item).strip()
        if not token:
            continue
        if not re.fullmatch(rf"{re.escape(prefix)}\d{{3,}}", token):
            raise ValueError(f"invalid {prefix} identifier {token!r}")
        if token not in result:
            result.append(token)
    return result


def normalize_obligation_ids(value: Any) -> list[str]:
    raw = value if isinstance(value, list) else re.split(r"[,;\s]+", str(value or ""))
    result: list[str] = []
    for item in raw:
        token = str(item).strip()
        if not token:
            continue
        if not re.fullmatch(r"(?:AQ|FB|MR)\d{3,}", token):
            raise ValueError(f"invalid source obligation identifier {token!r}")
        if token not in result:
            result.append(token)
    return result


def _identity_payload(kind: str, row: dict[str, Any]) -> dict[str, Any]:
    if kind == "AUTHOR_QUESTION":
        fields = (
            "question_id",
            "source_span",
            "source_excerpt",
            "obligation_type",
            "required_action",
        )
    elif kind == "FORMULA_BLOCK":
        fields = (
            "formula_block_id",
            "source_span",
            "raw_fragment_hash",
            "canonical_formula",
        )
    else:
        fields = (
            "risk_id",
            "source_revision_id",
            "source_sha256",
            "source_span",
            "risk_type",
            "claim_excerpt",
            "reason",
            "required_review",
        )
    return {field: row.get(field, "") for field in fields}


def obligation_identity_sha256(kind: str, row: dict[str, Any]) -> str:
    return sha256_text(canonical_json(_identity_payload(kind, row)))


def _load_rows(root: Path, name: str, *, required: bool) -> list[dict[str, Any]]:
    path = root / name
    if not path.is_file():
        if required:
            raise ValueError(f"missing source obligation ledger: {name}")
        return []
    rows = read_jsonl_strict(path, root=root)
    if not rows:
        raise ValueError(f"source obligation ledger is empty: {name}")
    return rows


def expected_source_obligations(
    root: Path, *, require_ledgers: bool
) -> tuple[dict[str, dict[str, Any]], list[str]]:
    """Return every P03 item that must survive into article realization."""
    errors: list[str] = []
    expected: dict[str, dict[str, Any]] = {}
    ledger_presence = any(
        (root / name).is_file() for name in (AQ_LEDGER, FORMULA_LEDGER, MATH_RISK_LEDGER)
    )
    require_all = require_ledgers or ledger_presence
    try:
        aq_rows = _load_rows(root, AQ_LEDGER, required=require_all)
        formula_rows = _load_rows(root, FORMULA_LEDGER, required=require_all)
        risk_rows = _load_rows(root, MATH_RISK_LEDGER, required=require_all)
    except Exception as exc:
        return {}, [str(exc)]

    def add(kind: str, ledger: str, obligation_id: str, row: dict[str, Any]) -> None:
        if obligation_id in expected:
            errors.append(f"duplicate source obligation id: {obligation_id}")
            return
        span = parse_span(row.get("source_span"))
        if span is None:
            errors.append(f"{obligation_id}: source obligation lacks a valid UTF-8 byte span")
            return
        expected[obligation_id] = {
            "obligation_id": obligation_id,
            "obligation_kind": kind,
            "source_ledger": ledger,
            "source_span": span,
            "row": row,
            "identity_sha256": obligation_identity_sha256(kind, row),
        }

    for row in aq_rows:
        typ = str(row.get("obligation_type", "")).upper()
        status = str(row.get("resolution_status", "")).upper()
        if typ in AQ_NON_OBLIGATION_TYPES or status in {
            "DISMISSED_NOT_AN_OBLIGATION",
            "NO_AUTHOR_QUESTIONS",
            "SEMANTIC_SCAN_COMPLETE",
        }:
            continue
        if typ not in AQ_REQUIRED_FUNCTIONS:
            errors.append(
                f"{row.get('question_id', '<unknown>')}: unrecognized semantic author obligation type {typ!r}"
            )
            continue
        if status not in {
            "CONFIRMED_ACTIVE_OBLIGATION",
            "BLOCKED_NEEDS_SOURCE_SUPPORT",
            *AQ_FINAL_STATUSES,
        }:
            errors.append(
                f"{row.get('question_id', '<unknown>')}: invalid author-obligation lifecycle status {status!r}"
            )
            continue
        add("AUTHOR_QUESTION", AQ_LEDGER, str(row.get("question_id", "")), row)

    for row in formula_rows:
        status = str(row.get("canonicalization_status", "")).upper()
        if status == "NO_FRAGMENTED_FORMULA_BLOCKS":
            continue
        if status == "CANONICALIZED":
            add("FORMULA_BLOCK", FORMULA_LEDGER, str(row.get("formula_block_id", "")), row)

    for row in risk_rows:
        typ = str(row.get("risk_type", "")).upper()
        status = str(row.get("resolution_status", "")).upper()
        if typ in {"SOURCE_WIDE_MATH_SEMANTIC_SCAN", "NO_MATHEMATICAL_RISKS"}:
            continue
        if status == "RESOLVED_WITH_JUSTIFICATION":
            add("MATH_RISK", MATH_RISK_LEDGER, str(row.get("risk_id", "")), row)

    return expected, errors


def _expected_source_evidence(source_bytes: bytes, span: tuple[int, int]) -> str:
    start, end = span
    if not (0 <= start < end <= len(source_bytes)):
        raise ValueError(f"source obligation span {start}-{end} is outside source_canonical.txt")
    return source_bytes[start:end].decode("utf-8", errors="strict")


def source_obligation_contracts(
    root: Path,
    blueprint: dict[str, Any],
    atoms: list[dict[str, Any]],
    *,
    require_ledgers: bool = False,
) -> tuple[dict[str, dict[str, Any]], list[str]]:
    """Validate P04's bindings from source obligations to Atom/functions."""
    errors: list[str] = []
    expected, expected_errors = expected_source_obligations(
        root, require_ledgers=require_ledgers
    )
    errors.extend(expected_errors)
    raw_contracts = blueprint.get("source_obligation_contracts")
    if not isinstance(raw_contracts, list):
        if not expected and not require_ledgers:
            return {}, errors
        return {}, [*errors, "publication blueprint source_obligation_contracts must be a list"]
    source_path = root / "source_canonical.txt"
    source_bytes = source_path.read_bytes() if source_path.is_file() else b""
    atom_by_id = {str(row.get("atom_id", "")): row for row in atoms}
    reviewed_atom_functions: dict[str, list[str]] = {}
    raw_atom_contracts = blueprint.get("atom_function_contracts")
    if not isinstance(raw_atom_contracts, list):
        errors.append("publication blueprint atom_function_contracts must be a list")
        raw_atom_contracts = []
    for item in raw_atom_contracts:
        if not isinstance(item, dict):
            continue
        atom_id = str(item.get("atom_id", ""))
        try:
            reviewed_atom_functions[atom_id] = normalize_functions(
                item.get("required_functions"),
                f"{atom_id}.P04_required_functions",
            )
        except ValueError as exc:
            errors.append(str(exc))
    contracts: dict[str, dict[str, Any]] = {}

    for index, row in enumerate(raw_contracts, 1):
        if not isinstance(row, dict):
            errors.append(f"source_obligation_contracts row {index} is not an object")
            continue
        obligation_id = str(row.get("obligation_id", ""))
        authority = expected.get(obligation_id)
        if authority is None:
            errors.append(
                f"source_obligation_contracts row {index} cites unknown or non-actionable obligation {obligation_id!r}"
            )
            continue
        if obligation_id in contracts:
            errors.append(f"duplicate source obligation contract: {obligation_id}")
            continue
        kind = str(row.get("obligation_kind", ""))
        if kind != authority["obligation_kind"]:
            errors.append(f"{obligation_id}: obligation_kind does not match its P03 ledger")
        if str(row.get("source_ledger", "")) != authority["source_ledger"]:
            errors.append(f"{obligation_id}: source_ledger does not match its P03 authority")
        if str(row.get("obligation_identity_sha256", "")) != authority["identity_sha256"]:
            errors.append(f"{obligation_id}: obligation identity hash is stale or incorrect")
        try:
            evidence = _expected_source_evidence(source_bytes, authority["source_span"])
        except Exception as exc:
            errors.append(f"{obligation_id}: {exc}")
            evidence = ""
        if str(row.get("source_evidence", "")) != evidence:
            errors.append(
                f"{obligation_id}: source_evidence must equal the complete exact source span"
            )
        try:
            source_atom_ids = normalize_ids(row.get("source_atom_ids"), "A")
            required_functions = normalize_functions(
                row.get("required_functions"), f"{obligation_id}.required_functions"
            )
        except ValueError as exc:
            errors.append(str(exc))
            continue

        start, end = authority["source_span"]
        overlapping = {
            atom_id
            for atom_id, atom in atom_by_id.items()
            if str(atom.get("content_type", "")) != "DUPLICATE"
            and max(start, int(atom.get("source_byte_start", -1)))
            < min(end, int(atom.get("source_byte_end", -1)))
        }
        if set(source_atom_ids) != overlapping:
            errors.append(
                f"{obligation_id}: source_atom_ids must equal every current Atom overlapping the obligation span"
            )

        bindings = row.get("function_bindings")
        if not isinstance(bindings, list) or not bindings:
            errors.append(f"{obligation_id}: function_bindings must be a nonempty list")
            bindings = []
        normalized_bindings: list[dict[str, str]] = []
        seen_pairs: set[tuple[str, str]] = set()
        for bind_index, binding in enumerate(bindings, 1):
            if not isinstance(binding, dict):
                errors.append(f"{obligation_id}.function_bindings[{bind_index}] is not an object")
                continue
            atom_id = str(binding.get("atom_id", ""))
            function = str(binding.get("function", ""))
            pair = (atom_id, function)
            if pair in seen_pairs:
                errors.append(f"{obligation_id}: duplicate function binding {atom_id}/{function}")
                continue
            seen_pairs.add(pair)
            atom = atom_by_id.get(atom_id)
            if atom_id not in source_atom_ids or atom is None:
                errors.append(f"{obligation_id}: function binding uses a non-overlapping Atom {atom_id!r}")
                continue
            if function not in CONTENT_FUNCTIONS:
                errors.append(f"{obligation_id}: invalid bound function {function!r}")
                continue
            atom_functions = reviewed_atom_functions.get(atom_id, [])
            if function not in atom_functions:
                errors.append(
                    f"{obligation_id}: bound function {atom_id}/{function} is absent from the P04 Atom contract"
                )
            normalized_bindings.append({"atom_id": atom_id, "function": function})

        bound_atoms = {item["atom_id"] for item in normalized_bindings}
        if set(source_atom_ids) - bound_atoms:
            errors.append(
                f"{obligation_id}: every overlapping Atom needs at least one obligation function binding"
            )
        bound_functions = {item["function"] for item in normalized_bindings}
        if set(required_functions) != bound_functions:
            errors.append(
                f"{obligation_id}: required_functions must equal the function_bindings union"
            )
        if kind == "AUTHOR_QUESTION":
            typ = str(authority["row"].get("obligation_type", "")).upper()
            missing_semantic = AQ_REQUIRED_FUNCTIONS.get(typ, set()) - bound_functions
            if missing_semantic:
                errors.append(
                    f"{obligation_id}: P03 semantic type {typ} requires functions: "
                    + ", ".join(sorted(missing_semantic))
                )
        elif "SUBSTANTIVE_CONTENT" not in bound_functions:
            errors.append(
                f"{obligation_id}: formula and mathematical-risk obligations require SUBSTANTIVE_CONTENT"
            )

        fulfillment_mode = str(row.get("fulfillment_mode", ""))
        if fulfillment_mode not in FULFILLMENT_MODES.get(kind, set()):
            errors.append(f"{obligation_id}: invalid fulfillment_mode {fulfillment_mode!r}")
        implementation = str(row.get("implementation_requirement", "")).strip()
        reason = str(row.get("reason", "")).strip()
        if len(implementation) < 16:
            errors.append(f"{obligation_id}: implementation_requirement is too shallow")
        if len(reason) < 16:
            errors.append(f"{obligation_id}: obligation binding reason is too shallow")
        normalized = dict(row)
        normalized["source_atom_ids"] = source_atom_ids
        normalized["required_functions"] = required_functions
        normalized["function_bindings"] = normalized_bindings
        contracts[obligation_id] = normalized

    missing = sorted(set(expected) - set(contracts))
    if missing:
        errors.append(
            "P03 source obligations lack P04 realization contracts: " + ", ".join(missing)
        )
    return contracts, errors


def obligation_ids_by_pair(
    contracts: dict[str, dict[str, Any]]
) -> dict[tuple[str, str], list[str]]:
    result: dict[tuple[str, str], list[str]] = {}
    for obligation_id, contract in contracts.items():
        for binding in contract.get("function_bindings", []):
            pair = (str(binding.get("atom_id", "")), str(binding.get("function", "")))
            result.setdefault(pair, []).append(obligation_id)
    for ids in result.values():
        ids.sort()
    return result


def resolved_author_question_rows(
    root: Path,
    contracts: dict[str, dict[str, Any]],
    p13_reviews: dict[str, dict[str, Any]],
    publication_sha256: str,
) -> list[dict[str, Any]]:
    """Materialize P13-reviewed AQ lifecycle completion without semantic guessing."""
    rows = read_jsonl_strict(root / AQ_LEDGER, root=root)
    by_id = {str(row.get("question_id", "")): row for row in rows}
    mode_status = {
        "PRESERVE_AS_QUESTION": "PRESERVED_AS_AUTHOR_QUESTION",
        "ANSWER_IN_EXPLANATION": "ANSWERED_IN_EXPLANATION",
        "RESOLVE_IN_ARTICLE": "RESOLVED_IN_ARTICLE",
        "PRESERVE_VOICE_INTENT": "RESOLVED_IN_ARTICLE",
    }
    for obligation_id, contract in contracts.items():
        if contract.get("obligation_kind") != "AUTHOR_QUESTION":
            continue
        row = by_id.get(obligation_id)
        if row is None:
            raise ValueError(f"{obligation_id}: author-question row disappeared before P13")
        evidence: list[str] = []
        realization_ids: list[str] = []
        for binding in contract.get("function_bindings", []):
            atom_id = str(binding["atom_id"])
            function = str(binding["function"])
            review = p13_reviews.get(atom_id, {})
            result = review.get("function_results", {}).get(function, {})
            realization_id = str(result.get("realization_id", ""))
            if not realization_id:
                raise ValueError(f"{obligation_id}: P13 lacks {atom_id}/{function} realization")
            realization_ids.append(realization_id)
            obligation_result = result.get("source_obligation_results", {}).get(
                obligation_id, {}
            )
            raw = obligation_result.get("target_evidence", "")
            items = raw if isinstance(raw, list) else [raw]
            evidence.extend(str(item) for item in items if str(item).strip())
        mode = str(contract.get("fulfillment_mode", ""))
        row["resolution_status"] = mode_status[mode]
        row["destination_file"] = "publication_final.md"
        row["response_trace"] = canonical_json(
            {
                "stage_id": "P13_PUBLICATION",
                "target_file": "publication_final.md",
                "target_sha256": publication_sha256,
                "realization_ids": sorted(set(realization_ids)),
                "target_evidence": list(dict.fromkeys(evidence)),
            }
        )
        row["verification_note"] = (
            "P13 finalized this P03 obligation only after every bound Atom/function "
            "passed against the exact publication bytes."
        )
    return rows


def write_author_question_rows(root: Path, rows: list[dict[str, Any]]) -> None:
    atomic_write_text(
        root / AQ_LEDGER,
        "".join(canonical_json(row) + "\n" for row in rows),
    )
    atomic_write_text(
        root / "author_question_obligation_ledger.md",
        markdown_table(rows, title="Author Question Obligation Ledger"),
    )


def finalized_math_risk_rows(
    root: Path,
    contracts: dict[str, dict[str, Any]],
    p13_reviews: dict[str, dict[str, Any]],
    publication_sha256: str,
) -> list[dict[str, Any]]:
    """Attach accepted P13 evidence to each concrete mathematical risk.

    The lifecycle status remains ``RESOLVED_WITH_JUSTIFICATION`` because P03
    resolved what the article must do.  This function records that the exact
    publication bytes later satisfied that duty; it never creates the semantic
    judgment itself.
    """
    rows = read_jsonl_strict(root / MATH_RISK_LEDGER, root=root)
    by_id = {str(row.get("risk_id", "")): row for row in rows}
    for obligation_id, contract in contracts.items():
        if contract.get("obligation_kind") != "MATH_RISK":
            continue
        row = by_id.get(obligation_id)
        if row is None:
            raise ValueError(f"{obligation_id}: mathematical-risk row disappeared before P13")
        evidence: list[str] = []
        realization_ids: list[str] = []
        for binding in contract.get("function_bindings", []):
            atom_id = str(binding["atom_id"])
            function = str(binding["function"])
            review = p13_reviews.get(atom_id, {})
            result = review.get("function_results", {}).get(function, {})
            realization_id = str(result.get("realization_id", ""))
            if not realization_id:
                raise ValueError(f"{obligation_id}: P13 lacks {atom_id}/{function} realization")
            realization_ids.append(realization_id)
            obligation_result = result.get("source_obligation_results", {}).get(
                obligation_id, {}
            )
            raw = obligation_result.get("target_evidence", "")
            items = raw if isinstance(raw, list) else [raw]
            evidence.extend(str(item) for item in items if str(item).strip())
        row["resolution_note"] = canonical_json(
            {
                "stage_id": "P13_PUBLICATION",
                "target_file": "publication_final.md",
                "target_sha256": publication_sha256,
                "realization_ids": sorted(set(realization_ids)),
                "target_evidence": list(dict.fromkeys(evidence)),
            }
        )
    return rows


def write_math_risk_rows(root: Path, rows: list[dict[str, Any]]) -> None:
    atomic_write_text(
        root / MATH_RISK_LEDGER,
        "".join(canonical_json(row) + "\n" for row in rows),
    )
    atomic_write_text(
        root / "source_math_risk_ledger.md",
        markdown_table(rows, title="Source Math Risk Ledger"),
    )
