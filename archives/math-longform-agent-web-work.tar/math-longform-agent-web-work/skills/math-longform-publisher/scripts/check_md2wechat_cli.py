#!/usr/bin/env python3
"""Discover local md2wechat CLI availability without installing or publishing."""
from __future__ import annotations

import json
import shutil
import subprocess


COMMANDS = [
    ["--version"],
    ["version"],
    ["capabilities", "--json"],
    ["inspect", "--json"],
]


def run(cmd: list[str]) -> tuple[int, str]:
    try:
        proc = subprocess.run(cmd, text=True, capture_output=True, timeout=15)
    except FileNotFoundError:
        return 127, "command not found"
    except subprocess.TimeoutExpired:
        return 124, "command timed out"

    out = proc.stdout.strip()
    err = proc.stderr.strip()
    text = out + ("\n" + err if err else "")
    return proc.returncode, text.strip()


def maybe_json(text: str):
    try:
        return json.loads(text)
    except Exception:
        return None


def main() -> int:
    exe = shutil.which("md2wechat")
    if not exe:
        print("md2wechat: NOT_FOUND")
        print("No install, auth, upload, or publish action was taken.")
        return 1

    print(f"md2wechat: {exe}")
    for args in COMMANDS:
        cmd = [exe, *args]
        code, output = run(cmd)
        print(f"\n== md2wechat {' '.join(args)} ==")
        print(f"exit {code}")
        if output:
            parsed = maybe_json(output)
            if parsed is not None:
                print(json.dumps(parsed, ensure_ascii=False, indent=2))
            else:
                print(output[:4000])
        else:
            print("(no output)")

    print("\nNo install, auth, upload, or publish action was taken.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
