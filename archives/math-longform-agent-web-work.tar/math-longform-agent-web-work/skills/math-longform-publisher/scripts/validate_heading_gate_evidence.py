#!/usr/bin/env python3
"""Validate that heading_voice_gate.md does not rubber-stamp headings.

`ALLOW_SOURCE_EXACT` is reserved for headings whose normalized text is actually
present in the current source. Derived headings may be allowed, but they must be
marked as derived and cite source atoms with a usable reason.
"""
from __future__ import annotations

from pathlib import Path
import re
import sys


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def norm(text: str) -> str:
    text = re.sub(r"^#+\s*", "", text)
    text = re.sub(r"`([^`]+)`", r"\1", text)
    text = re.sub(r"[\s\u3000:：，,。.!！?？;；()（）【】\[\]$`*_\\\-]+", "", text)
    return text.strip().lower()


def table_rows(text: str) -> list[dict[str, str]]:
    lines = [line.rstrip() for line in text.splitlines() if line.strip().startswith("|")]
    if len(lines) < 2:
        return []
    header = [cell.strip() for cell in lines[0].strip().strip("|").split("|")]
    rows: list[dict[str, str]] = []
    for line in lines[2:]:
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        if not cells or all(re.fullmatch(r":?-{3,}:?", cell.replace(" ", "")) for cell in cells):
            continue
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        if len(cells) > len(header):
            cells = cells[: len(header) - 1] + ["|".join(cells[len(header) - 1 :])]
        row = dict(zip(header, cells))
        if any(row.values()):
            rows.append(row)
    return rows


def source_excerpt_for_atoms(source: str, atom_text: str, atom_ledger: str) -> str:
    ids = set(re.findall(r"\bA\d{3,}\b", atom_text or ""))
    if not ids:
        return ""
    out: list[str] = []
    for line in atom_ledger.splitlines():
        if not line.startswith("|"):
            continue
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        if not cells or cells[0] not in ids:
            continue
        if len(cells) >= 5:
            out.append(cells[4])
    return "".join(out) or source


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    gate_path = root / "heading_voice_gate.md"
    gate = read(gate_path)
    source = read(root / "source.txt") or read(root / "source_canonical.txt")
    atom_ledger = read(root / "source_atom_ledger.md")
    rows = table_rows(gate)
    failures: list[str] = []

    if not gate.strip():
        failures.append("missing or empty heading_voice_gate.md")
    if not rows:
        failures.append("heading_voice_gate.md has no parseable rows")

    source_norm = norm(source)
    for idx, row in enumerate(rows, 1):
        heading = row.get("heading_text") or row.get("heading") or row.get("title") or ""
        decision = (row.get("decision") or row.get("verdict") or "").upper()
        atoms = row.get("source_atoms") or row.get("atom_ids") or ""
        note = row.get("verification_note") or row.get("derived_heading_reason") or row.get("reason") or ""
        hid = row.get("heading_id") or f"row {idx}"
        hnorm = norm(heading)
        local_source_norm = norm(source_excerpt_for_atoms(source, atoms, atom_ledger))

        if not hnorm:
            failures.append(f"{hid}: missing heading_text")
            continue
        if not decision:
            failures.append(f"{hid}: missing decision")
            continue
        if "EXACT" in decision:
            if hnorm not in source_norm and hnorm not in local_source_norm:
                failures.append(f"{hid}: decision {decision} claims source-exact heading, but heading text is not found in source or cited atoms: {heading}")
        else:
            if "DERIVED" not in decision and "ALLOW" in decision:
                failures.append(f"{hid}: allowed non-exact heading must use a derived decision, got {decision}")
            if not re.search(r"\bA\d{3,}\b", atoms):
                failures.append(f"{hid}: derived heading requires source_atoms")
            if not note or note.strip().lower() in {"none", "todo", "unknown"}:
                failures.append(f"{hid}: derived heading requires verification_note or derived_heading_reason")

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print("OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
