#!/usr/bin/env python3
"""Materialize Agent-reviewed P04 function contracts into atom-ledger views."""
from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from typing import Any
import argparse
import json

from content_authority import (
    canonical_json,
    detect_surface_features,
    surface_decision_sha256,
)
from content_functions import atom_function_contracts, read_jsonl
from publication_assembler import markdown_table, write_jsonl
from safe_io import atomic_write_text, read_json_strict
from source_obligations import source_obligation_contracts


def materialize(root: Path) -> None:
    atoms = read_jsonl(root / "source_atom_ledger.jsonl")
    blueprint = read_json_strict(root / "publication_blueprint.json")
    if not isinstance(blueprint, dict):
        raise ValueError("publication_blueprint.json must be an object")
    contracts, errors = atom_function_contracts(
        blueprint, atoms, require_function_matrix=True
    )
    _source_obligations, source_obligation_errors = source_obligation_contracts(
        root, blueprint, atoms, require_ledgers=False
    )
    errors.extend(source_obligation_errors)
    if errors:
        raise ValueError(
            "P04 semantic contracts are invalid: " + "; ".join(errors[:16])
        )
    surface_reviews: list[dict[str, Any]] = []
    for atom in atoms:
        atom_id = str(atom["atom_id"])
        contract = contracts[atom_id]
        functions = list(contract["required_functions"])
        surface = dict(contract["surface_contract"])
        atom["required_functions"] = functions
        atom["content_type"] = contract["content_type"]
        atom["atom_type"] = str(contract["content_type"]).lower()
        atom["local_context_role"] = contract["local_context_role"]
        atom["global_context_role"] = contract["global_context_role"]
        invariant = dict(contract["content_invariant"])
        invariant["required_functions"] = functions
        atom["content_invariant_json"] = json.dumps(
            invariant, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        )
        atom["surface_mode"] = surface["decision"]
        atom["output_operation"] = surface["output_operation"]
        atom["surface_decision_json"] = canonical_json(
            {
                "decision": surface["decision"],
                "basis": surface["basis"],
                "source_cues": surface["source_cues"],
                "rationale": surface["rationale"],
                "confidence": surface["confidence"],
                "review_status": "APPROVED",
                "prelock_disposition": surface["prelock_disposition"],
            }
        )
        if surface["decision"] == "BYTE_EXACT":
            atom.pop("allowed_completion", None)
            atom.pop("forbidden_change", None)
        else:
            atom["allowed_completion"] = surface["allowed_completion"]
            atom["forbidden_change"] = surface["forbidden_change"]
        atom["author_intent"] = contract["reason"]
        atom["function_contract_stage"] = "P04_MATH_LOCKS"
        atom["function_contract_reason"] = contract["reason"]
        surface_reviews.append(
            {
                "schema_version": "content-authority-surface-review-v1",
                "review_id": f"SR{len(surface_reviews) + 1:04d}",
                "source_revision_id": atom["source_revision_id"],
                "atom_id": atom_id,
                "atom_decision_sha256": surface_decision_sha256(atom),
                "detected_features_json": canonical_json(
                    detect_surface_features(
                        str(atom["raw_excerpt"]), str(atom["content_type"])
                    )
                ),
                "reviewer_role": "P04_SEMANTIC_CONTRACT_REVIEW",
                "reviewer_verdict": "APPROVED",
                "reviewer_reason": surface["rationale"],
                "surface_group_id": atom["surface_group_id"],
                "prelock_disposition": surface["prelock_disposition"],
            }
        )

    write_jsonl(root / "source_atom_ledger.jsonl", atoms)
    atomic_write_text(
        root / "source_atom_ledger.md", markdown_table(atoms, "Source Atom Ledger")
    )
    write_jsonl(root / "surface_decision_review.jsonl", surface_reviews)
    chunks: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for atom in atoms:
        chunks[str(atom.get("chunk_id"))].append(atom)
    for chunk_id, rows in chunks.items():
        chunk_root = root / "chunk_ledger"
        chunk_root.mkdir(parents=True, exist_ok=True)
        stem = f"chunk_{chunk_id}_atom_ledger"
        write_jsonl(chunk_root / f"{stem}.jsonl", rows)
        atomic_write_text(
            chunk_root / f"{stem}.md", markdown_table(rows, f"{chunk_id} Atom Ledger")
        )
    print(f"P04_ATOM_FUNCTIONS_MATERIALIZED atoms={len(atoms)}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output")
    args = parser.parse_args()
    try:
        materialize(Path(args.output).resolve())
    except Exception as exc:
        print(f"FAILED: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
