#!/usr/bin/env python3
"""Validate proof_obligations.md."""
from pathlib import Path
import re
import sys

ALLOWED_TYPES = {"PRESERVE", "COMPLETE_SUPPORTED", "DO_NOT_EXPAND", "NO_PROOF_NEEDED"}
GOOD_STATUS = {"satisfied", "preview_preserved", "not_needed"}

def read(p):
    return p.read_text(encoding="utf-8") if p.exists() else ""

def rows(text):
    for line in text.splitlines():
        if re.match(r"^\|\s*PR\d+\s*\|", line):
            yield [c.strip() for c in line.strip().strip("|").split("|")]

def ids(text, prefix):
    return set(re.findall(rf"\b{prefix}\d{{3,}}\b", text))

def main():
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    proof = read(root / "proof_obligations.md")
    statements = read(root / "math_statement_ledger.md")
    maps = read(root / "final_trace_map.md") + read(root / "revised_trace_map.md") + read(root / "publication_trace_map.md") + read(root / "final_claim_ledger.md") + read(root / "publication_claim_ledger.md")
    failures = []
    defined_statements = ids(statements, "S")
    proof_rows = list(rows(proof))
    if not proof_rows:
        failures.append("no PR rows in proof_obligations.md")

    for cells in proof_rows:
        pid = cells[0]
        row = " | ".join(cells)
        if len(cells) < 11:
            failures.append(f"{pid}: row has too few columns")
            continue
        statement_ids = set(re.findall(r"S\d+", cells[1]))
        source_atoms = cells[2]
        obligation_type = cells[4].upper()
        status = cells[-1].lower()
        if not statement_ids:
            failures.append(f"{pid}: no statement_ids")
        for sid in statement_ids:
            if sid not in defined_statements:
                failures.append(f"{pid}: unknown statement id {sid}")
        if not re.search(r"\bA\d{3,}\b", source_atoms) and obligation_type != "NO_PROOF_NEEDED":
            failures.append(f"{pid}: no source atom support")
        if obligation_type not in ALLOWED_TYPES:
            failures.append(f"{pid}: invalid obligation_type {obligation_type}")
        if re.search(r"pending|blocked|unknown|unclear|TODO|TBD|待定|不清楚", row, flags=re.I):
            failures.append(f"{pid}: unresolved placeholder/status")
        if status not in GOOD_STATUS:
            failures.append(f"{pid}: completion_status must be satisfied/preview_preserved/not_needed, got {status!r}")
        if obligation_type in {"PRESERVE", "COMPLETE_SUPPORTED"} and pid not in maps:
            failures.append(f"{pid}: required proof obligation not referenced in trace/claim maps")
        if obligation_type == "DO_NOT_EXPAND" and status != "preview_preserved":
            failures.append(f"{pid}: DO_NOT_EXPAND should have completion_status preview_preserved")
        if obligation_type == "NO_PROOF_NEEDED" and status != "not_needed":
            failures.append(f"{pid}: NO_PROOF_NEEDED should have completion_status not_needed")

    used = ids(maps, "PR")
    defined = ids(proof, "PR")
    unknown = sorted(used - defined)
    if unknown:
        failures.append("trace/claim maps use undefined proof ids: " + ", ".join(unknown[:20]))

    if failures:
        print("FAILED")
        for f in failures:
            print(f"- {f}")
        return 1
    print("OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
