#!/usr/bin/env python3
"""Validate machine evidence, full logs, final manifest, and staleness locks."""
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import re
import sys
from typing import Any

from mode_utils import FULL_PUBLICATION, WECHAT_PUBLICATION, resolve_mode
from pipeline_registry import package_version, validator_specs_for_mode
from validator_runner import OUTPUT_DIR_TOKEN, argv_for_spec, normalize_recorded_args, portable_args
from safe_io import read_bytes_strict, read_json_strict, read_optional_text, sha256_file

EVIDENCE_NAMES = {
    "validator_result.json", "validator_result.sha256", "validator_result.txt",
    "PUBLICATION_AUDIT_REPORT.md", "release_manifest.json", "release_manifest.sha256",
}

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_sha256(path: Path) -> str:
    return sha256_bytes(path.read_bytes()) if path.exists() else ""


def snapshot_dir(root: Path) -> str:
    items: list[dict[str, str | int]] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root).as_posix()
        if path.name in EVIDENCE_NAMES:
            continue
        if "__pycache__" in path.parts or "validator_evidence" in path.parts:
            continue
        data = path.read_bytes()
        items.append({"path": rel, "size": len(data), "sha256": sha256_bytes(data)})
    blob = json.dumps(items, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return sha256_bytes(blob)


def validator_code_snapshot(scripts_dir: Path) -> str:
    items: list[dict[str, str | int]] = []
    for path in sorted(scripts_dir.glob("*.py")):
        data = path.read_bytes()
        items.append({"path": path.name, "size": len(data), "sha256": sha256_bytes(data)})
    blob = json.dumps(items, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return sha256_bytes(blob)


def expected_plan(run_mode: str, root: Path) -> list[tuple[str, list[str]]]:
    include_wechat = run_mode == FULL_PUBLICATION and (root / "wechat_publication_final.md").exists()
    specs = validator_specs_for_mode(
        run_mode,
        include_post_evidence=False,
        include_optional_wechat=include_wechat,
    )
    return [
        (spec.script, portable_args(argv_for_spec(spec, root, run_mode), root))
        for spec in specs
    ]


def digest_from_sha_file(path: Path, label: str, failures: list[str]) -> str:
    try:
        text = read_optional_text(path)
    except Exception as exc:
        failures.append(f"{label}: {exc}")
        return ""
    match = re.fullmatch(r"\s*([0-9a-f]{64})\s+[^\r\n]+\s*", text)
    if not match:
        failures.append(f"{label} must contain exactly one SHA-256 line")
        return ""
    return match.group(1)


def safe_evidence_path(root: Path, value: Any, failures: list[str], label: str) -> Path | None:
    rel = str(value or "")
    if not rel.startswith("validator_evidence/") or ".." in Path(rel).parts or Path(rel).is_absolute():
        failures.append(f"{label} has unsafe evidence path: {rel!r}")
        return None
    path = root / rel
    try:
        path.resolve().relative_to(root.resolve())
    except ValueError:
        failures.append(f"{label} escapes root: {rel!r}")
        return None
    return path


def main() -> int:
    root = (Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")).resolve()
    failures: list[str] = []
    result_path = root / "validator_result.json"

    try:
        raw = read_bytes_strict(result_path, root=root)
        data = read_json_strict(result_path, root=root)
        if not isinstance(data, dict):
            raise ValueError("expected JSON object")
    except Exception as exc:
        print("FAILED")
        print(f"- validator_result.json invalid: {exc}")
        return 1
    result_sha = sha256_bytes(raw)
    recorded_result_sha = digest_from_sha_file(root / "validator_result.sha256", "validator_result.sha256", failures)
    if recorded_result_sha and recorded_result_sha != result_sha:
        failures.append("validator_result.sha256 does not match validator_result.json")

    if data.get("schema_version") != "validator-result-v2":
        failures.append("validator_result schema_version must be validator-result-v2")
    if data.get("package_version") != package_version():
        failures.append("validator_result package_version mismatch")
    if data.get("generated_by") != "scripts/run_publication_validators.py":
        failures.append("validator_result generated_by mismatch")
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}T.*Z", str(data.get("generated_at_utc", ""))):
        failures.append("validator_result generated_at_utc is malformed")

    path_encoding = data.get("argument_path_encoding")
    if path_encoding not in {None, "output-dir-token-v1"}:
        failures.append(f"unsupported validator argument path encoding: {path_encoding!r}")
    if path_encoding == "output-dir-token-v1" and data.get("target_dir") != OUTPUT_DIR_TOKEN:
        failures.append("portable validator evidence must use target_dir=<output_dir>")

    run_mode = str(data.get("run_mode") or "")
    if run_mode not in {FULL_PUBLICATION, WECHAT_PUBLICATION, "diagnostic_backtest", "source_atomization"}:
        failures.append(f"unsupported validator_result run_mode: {run_mode!r}")
        run_mode = FULL_PUBLICATION
    mode_file = root / "run_mode.json"
    if mode_file.exists():
        try:
            declared = resolve_mode(root, None, allow_mode_file=True)
            if declared != run_mode:
                failures.append(f"run_mode.json declares {declared!r} but evidence ran {run_mode!r}")
        except ValueError as exc:
            failures.append(str(exc))

    try:
        plan = expected_plan(run_mode, root)
    except Exception as exc:
        failures.append(f"cannot reconstruct validator plan: {exc}")
        plan = expected_plan(FULL_PUBLICATION, root)

    scripts_dir = Path(__file__).resolve().parent
    current_code_snapshot = validator_code_snapshot(scripts_dir)
    recorded_code_snapshot = str(data.get("validator_code_snapshot_sha256", ""))
    if recorded_code_snapshot != current_code_snapshot:
        failures.append("validator code snapshot mismatch; shared validator code changed")
    pre_snapshot = str(data.get("pre_validation_snapshot_sha256", ""))
    post_snapshot = str(data.get("post_validation_snapshot_sha256", ""))
    package_stable = data.get("package_stable_during_validation")
    if not re.fullmatch(r"[0-9a-f]{64}", pre_snapshot) or not re.fullmatch(r"[0-9a-f]{64}", post_snapshot):
        failures.append("pre/post validation snapshot digests are missing or malformed")
    if not isinstance(package_stable, bool):
        failures.append("package_stable_during_validation must be boolean")
    elif package_stable != (pre_snapshot == post_snapshot):
        failures.append("package stability flag conflicts with pre/post snapshots")
    if data.get("target_snapshot_sha256") != post_snapshot:
        failures.append("target snapshot must equal post-validation snapshot")

    results = data.get("results")
    if not isinstance(results, list) or not results:
        failures.append("validator_result results must be a nonempty list")
        results = []
    scripts_seen: list[str] = []
    failed_rows: list[str] = []
    indexes: list[int] = []
    manifest_logs: list[dict[str, Any]] = []

    for row_no, item in enumerate(results, start=1):
        if not isinstance(item, dict):
            failures.append(f"result row {row_no} is not an object")
            continue
        script = str(item.get("script", ""))
        scripts_seen.append(script)
        index = item.get("invocation_index")
        if not isinstance(index, int):
            failures.append(f"result {row_no} invocation_index must be integer")
            index = row_no
        indexes.append(index)
        if not re.fullmatch(r"[A-Za-z0-9_]+\.py", script):
            failures.append(f"result {row_no} invalid script name: {script!r}")
        script_path = scripts_dir / script
        if not script_path.exists():
            failures.append(f"result {row_no} references missing script: {script}")
        elif item.get("script_sha256") != file_sha256(script_path):
            failures.append(f"result {row_no} script_sha256 mismatch for {script}")
        args = item.get("args")
        if not isinstance(args, list) or not all(isinstance(arg, str) for arg in args):
            failures.append(f"result {row_no} args must be a list of strings")
            args = []
        normalized_args = normalize_recorded_args(
            args,
            root,
            str(data.get("target_dir") or ""),
        )
        if row_no <= len(plan):
            expected_script, expected_args = plan[row_no - 1]
            if script != expected_script:
                failures.append(f"result {row_no} script/order mismatch: expected {expected_script}, got {script}")
            if normalized_args != expected_args:
                failures.append(
                    f"result {row_no} args mismatch: expected {expected_args!r}, "
                    f"got {normalized_args!r}"
                )
        expected_command = "python scripts/" + script + ((" " + " ".join(args)) if args else "")
        if item.get("command") != expected_command:
            failures.append(f"result {row_no} command does not exactly match script+args")
        if item.get("execution_closure_sha256") != current_code_snapshot:
            failures.append(f"result {row_no} execution closure hash mismatch")
        exit_code = item.get("exit_code")
        verdict = item.get("verdict")
        if not isinstance(exit_code, int):
            failures.append(f"result {row_no} exit_code must be integer")
        if verdict not in {"PASS", "FAIL", "BLOCKED"}:
            failures.append(f"result {row_no} invalid verdict: {verdict!r}")
        if exit_code != 0 or verdict != "PASS":
            failed_rows.append(script or f"row-{row_no}")
        warning_count = item.get("warning_count", 0)
        if not isinstance(warning_count, int) or warning_count < 0:
            failures.append(f"result {row_no} warning_count must be nonnegative integer")
        if run_mode in {FULL_PUBLICATION, WECHAT_PUBLICATION} and verdict == "PASS" and warning_count:
            failures.append(f"result {row_no} release PASS contains unresolved warnings")

        log_record: dict[str, Any] = {"invocation_index": index, "script": script}
        for stream in ("stdout", "stderr"):
            rel_key = f"{stream}_file"
            sha_key = f"{stream}_sha256"
            path = safe_evidence_path(root, item.get(rel_key), failures, f"result {row_no} {rel_key}")
            expected_sha = str(item.get(sha_key, ""))
            if not re.fullmatch(r"[0-9a-f]{64}", expected_sha):
                failures.append(f"result {row_no} invalid {sha_key}")
            if path is not None:
                try:
                    actual_sha = sha256_file(path, root=root)
                    if actual_sha != expected_sha:
                        failures.append(f"result {row_no} {stream} full-log hash mismatch")
                except Exception as exc:
                    failures.append(f"result {row_no} {stream} log invalid: {exc}")
            log_record[rel_key] = str(item.get(rel_key, ""))
            log_record[sha_key] = expected_sha
        manifest_logs.append(log_record)

    if indexes != list(range(1, len(results) + 1)):
        failures.append("validator invocation_index values must be unique and sequential")
    if len(results) != len(plan):
        failures.append(f"validator invocation count mismatch: expected {len(plan)}, got {len(results)}")
    if len(scripts_seen) != len(indexes):
        failures.append("validator_result contains malformed invocation identities")

    overall_code = data.get("overall_exit_code")
    overall_verdict = data.get("overall_verdict")
    if overall_verdict not in {"PASS", "FAIL"} or not isinstance(overall_code, int):
        failures.append("invalid overall verdict/exit code")
    if failed_rows and (overall_verdict == "PASS" or overall_code == 0):
        failures.append("overall PASS conflicts with failed rows: " + ", ".join(failed_rows))
    if package_stable is False and (overall_verdict == "PASS" or overall_code == 0):
        failures.append("unstable package cannot have overall PASS")
    if not failed_rows and package_stable is True and (overall_verdict != "PASS" or overall_code != 0):
        failures.append("overall result is not PASS although all rows passed and package was stable")
    recorded_snapshot = str(data.get("target_snapshot_sha256", ""))
    current_snapshot = snapshot_dir(root)
    if recorded_snapshot != current_snapshot:
        failures.append("validator_result is stale: non-evidence artifact snapshot changed")

    # Final immutable release manifest binds the audit report and release surfaces.
    manifest_path = root / "release_manifest.json"
    try:
        manifest_raw = read_bytes_strict(manifest_path, root=root)
        manifest = read_json_strict(manifest_path, root=root)
        if not isinstance(manifest, dict):
            raise ValueError("expected JSON object")
    except Exception as exc:
        failures.append(f"release_manifest.json invalid: {exc}")
        manifest, manifest_raw = {}, b""
    manifest_sha = sha256_bytes(manifest_raw) if manifest_raw else ""
    recorded_manifest_sha = digest_from_sha_file(root / "release_manifest.sha256", "release_manifest.sha256", failures)
    if recorded_manifest_sha and recorded_manifest_sha != manifest_sha:
        failures.append("release_manifest.sha256 does not match release_manifest.json")
    if manifest:
        if manifest.get("schema_version") != "release-manifest-v2":
            failures.append("release_manifest schema_version mismatch")
        if manifest.get("package_version") != package_version():
            failures.append("release_manifest package_version mismatch")
        if manifest.get("validator_result_sha256") != result_sha:
            failures.append("release_manifest does not bind current validator_result.json")
        if manifest.get("target_snapshot_sha256") != current_snapshot:
            failures.append("release_manifest target snapshot mismatch")
        if manifest.get("validator_code_snapshot_sha256") != current_code_snapshot:
            failures.append("release_manifest validator code snapshot mismatch")
        if manifest.get("package_stable_during_validation") is not package_stable:
            failures.append("release_manifest package stability differs from validator_result")
        if manifest.get("publication_audit_report_sha256") != file_sha256(root / "PUBLICATION_AUDIT_REPORT.md"):
            failures.append("release_manifest audit report hash mismatch")
        if manifest.get("publication_final_sha256") != file_sha256(root / "publication_final.md"):
            failures.append("release_manifest publication_final hash mismatch")
        if manifest.get("wechat_publication_final_sha256", "") != file_sha256(root / "wechat_publication_final.md"):
            failures.append("release_manifest wechat surface hash mismatch")
        if manifest.get("validator_log_files") != manifest_logs:
            failures.append("release_manifest validator log list differs from validator_result")
        if manifest.get("overall_verdict") != overall_verdict:
            failures.append("release_manifest overall verdict differs from validator_result")

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print("OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
