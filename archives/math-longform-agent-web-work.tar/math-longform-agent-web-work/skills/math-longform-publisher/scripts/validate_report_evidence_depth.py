#!/usr/bin/env python3
"""Reject shallow PASS reports that do not cite concrete files or trace ids."""
from __future__ import annotations

from pathlib import Path
import re
import sys


REPORT_FILES = [
    "ledger_integrity_check.md",
    "statement_completeness_check.md",
    "independent_review.md",
    "post_final_structure_review.md",
    "symbol_lock_report.md",
    "integration_report.md",
    "clean_final_gate.md",
    "formula_compatibility_report.md",
    "coverage_check.md",
    "attack_report.md",
    "revision_tasks.md",
    "revision_changelog.md",
    "regression_check.md",
    "aigc_rewrite_tasks.md",
    "post_aigc_regression_check.md",
    "post_aigc_trace_check.md",
    "post_aigc_formula_check.md",
    "post_aigc_clean_gate.md",
]

SOURCE_ID_RE = re.compile(r"\b(?:A|S|PR|CL|PCL|P|PP|PS|V|SYM|CH)\d{3,}(?:\s*-\s*(?:A|S|PR|CL|PCL|P|PP|PS|V|SYM|CH)?\d{3,})?\b")
FILE_RE = re.compile(r"\b(?:source|canonical_source|source_atom_ledger|publication_final|standardized_final|revised_final|aigc_rewritten_final|publication_sentence_trace|publication_trace_map|publication_claim_ledger|final_trace_map|final_claim_ledger)\.(?:txt|md|jsonl)\b")
PLACEHOLDER_RE = re.compile(r"\b(TODO|TBD|pending|unknown|unclear|probably|should pass|will run)\b", re.I)
SHALLOW_RE = re.compile(r"^(?:none|ok|clean|checked|pass|n/a|na|not needed|no failure|no regression|same|done)$", re.I)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def md_rows(text: str) -> list[dict[str, str]]:
    table_lines = [ln.rstrip() for ln in text.splitlines() if ln.strip().startswith("|")]
    if len(table_lines) < 2:
        return []
    header = [c.strip() for c in table_lines[0].strip().strip("|").split("|")]
    rows: list[dict[str, str]] = []
    for line in table_lines[1:]:
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if cells and all(re.fullmatch(r":?-{3,}:?", c.replace(" ", "")) for c in cells):
            continue
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        if len(cells) > len(header):
            cells = cells[: len(header) - 1] + ["|".join(cells[len(header) - 1 :])]
        row = dict(zip(header, cells))
        if any(row.values()):
            rows.append(row)
    return rows


def has_concrete_evidence(text: str) -> bool:
    return bool(SOURCE_ID_RE.search(text) or FILE_RE.search(text))


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    root = root.resolve()
    failures: list[str] = []
    checked = 0

    for rel in REPORT_FILES:
        path = root / rel
        if not path.exists():
            continue
        text = read(path)
        if not text.strip():
            failures.append(f"{rel} is empty")
            continue
        checked += 1
        if PLACEHOLDER_RE.search(text):
            failures.append(f"{rel} contains unresolved or future-tense wording")
        rows = md_rows(text)
        if not rows:
            if not has_concrete_evidence(text):
                failures.append(f"{rel} has no table rows and no concrete file/id evidence")
            continue
        concrete_rows = 0
        for idx, row in enumerate(rows, 1):
            row_text = " | ".join(str(v) for v in row.values())
            if has_concrete_evidence(row_text):
                concrete_rows += 1
            status = str(row.get("status") or row.get("verdict") or row.get("completion_status") or "").strip().upper()
            evidence_values = [str(v).strip() for k, v in row.items() if "evidence" in k.lower() or "note" in k.lower()]
            if status in {"PASS", "DONE", "APPROVED", "SATISFIED"}:
                if evidence_values and all(SHALLOW_RE.fullmatch(v or "none") for v in evidence_values):
                    failures.append(f"{rel} row {idx} has shallow evidence wording")
                if not has_concrete_evidence(row_text):
                    failures.append(f"{rel} row {idx} passes without concrete file/id evidence")
        if concrete_rows == 0:
            failures.append(f"{rel} has no rows with concrete file/id evidence")

    if checked == 0:
        failures.append("no report files found for evidence-depth validation")

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print(f"OK: report_files_checked={checked}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
