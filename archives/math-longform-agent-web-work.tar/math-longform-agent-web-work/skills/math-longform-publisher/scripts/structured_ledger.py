#!/usr/bin/env python3
"""Strict JSONL-first ledger helpers.

JSONL is authoritative whenever the file exists. A malformed or empty JSONL
file is an error and must never cause fallback to an older Markdown mirror.
"""
from __future__ import annotations

from pathlib import Path
import re
from typing import Iterable, Any

from safe_io import read_optional_text, read_jsonl_strict


def read_text(path: Path) -> str:
    return read_optional_text(path)


def is_nonempty(path: Path) -> bool:
    return path.exists() and read_text(path).strip() != ""


def jsonl_path_for(md_path: Path) -> Path:
    return md_path.with_suffix(".jsonl")


def _split_md_row(line: str) -> list[str]:
    """Split one Markdown row and decode the runtime's lossless cell escapes.

    Mirrors encode ``|``, backslash and control whitespace as ``\\|``, ``\\\\``,
    ``\\n``, ``\\r`` and ``\\t``. Decoding here keeps Markdown mirrors exact
    without allowing embedded newlines to corrupt the table shape.
    """
    body = line.strip().strip("|")
    cells: list[str] = []
    current: list[str] = []
    escaped = False
    for ch in body:
        if escaped:
            current.append({"n": "\n", "r": "\r", "t": "\t"}.get(ch, ch))
            escaped = False
        elif ch == "\\":
            escaped = True
        elif ch == "|":
            cells.append("".join(current).strip())
            current = []
        else:
            current.append(ch)
    if escaped:
        current.append("\\")
    cells.append("".join(current).strip())
    return cells


def md_escape_cell(value: Any) -> str:
    """Encode a scalar as one lossless Markdown-table cell."""
    text = _scalar(value)
    return (
        text.replace("\\", "\\\\")
        .replace("|", "\\|")
        .replace("\r", "\\r")
        .replace("\n", "\\n")
        .replace("\t", "\\t")
    )


def markdown_table(rows: Iterable[dict[str, Any]], *, title: str = "") -> str:
    """Render rows as an ordered, lossless Markdown mirror."""
    materialized = list(rows)
    if not materialized:
        return (f"# {title}\n\n" if title else "") + "_No rows._\n"
    header = list(materialized[0].keys())
    lines: list[str] = []
    if title:
        lines.extend([f"# {title}", ""])
    lines.append("| " + " | ".join(md_escape_cell(key) for key in header) + " |")
    lines.append("|" + "|".join("---" for _ in header) + "|")
    for row in materialized:
        lines.append("| " + " | ".join(md_escape_cell(row.get(key, "")) for key in header) + " |")
    return "\n".join(lines) + "\n"


def md_table_header(text: str) -> list[str]:
    for line in text.splitlines():
        if line.strip().startswith("|"):
            return _split_md_row(line)
    return []


def md_table_rows(text: str) -> list[dict[str, str]]:
    lines = [line.rstrip() for line in text.splitlines() if line.strip().startswith("|")]
    if len(lines) < 2:
        return []
    header = _split_md_row(lines[0])
    rows: list[dict[str, str]] = []
    for line in lines[1:]:
        cells = _split_md_row(line)
        if cells and all(re.fullmatch(r":?-{3,}:?", cell.replace(" ", "")) for cell in cells):
            continue
        if len(cells) != len(header):
            # Markdown is only a mirror; malformed rows must not be guessed into shape.
            continue
        row = dict(zip(header, cells))
        if any(str(value).strip() for value in row.values()):
            rows.append(row)
    return rows


def _scalar(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (dict, list)):
        raise ValueError("nested JSON values are forbidden in ledger rows")
    return str(value)


def read_jsonl(path: Path) -> tuple[list[dict[str, str]], list[str]]:
    try:
        raw_rows = read_jsonl_strict(path)
    except Exception as exc:
        return [], [f"{path.name}: {exc}"]
    rows: list[dict[str, str]] = []
    failures: list[str] = []
    for idx, row in enumerate(raw_rows, start=1):
        try:
            rows.append({str(key): _scalar(value) for key, value in row.items()})
        except ValueError as exc:
            failures.append(f"{path.name} row {idx}: {exc}")
    return rows, failures


def load_ledger(md_path: Path) -> tuple[str, list[str], list[dict[str, str]], list[str]]:
    """Return ``(source_kind, header, rows, failures)``.

    If the JSONL path exists, it is authoritative even when empty or malformed.
    Markdown fallback is permitted only when no JSONL file exists at all.
    """
    jsonl_path = jsonl_path_for(md_path)
    if jsonl_path.exists():
        rows, failures = read_jsonl(jsonl_path)
        header = list(rows[0].keys()) if rows else []
        if not rows and not failures:
            failures.append(f"{jsonl_path.name}: empty authoritative JSONL ledger")
        return "jsonl", header, rows, failures
    text = read_text(md_path)
    if text.strip():
        rows = md_table_rows(text)
        failures = [] if rows else [f"{md_path.name}: Markdown ledger has no parseable table rows"]
        return "markdown", md_table_header(text), rows, failures
    return "missing", [], [], [f"missing ledger: {jsonl_path.name} and {md_path.name}"]


def load_required_ledger(
    md_path: Path,
    required_columns: Iterable[str],
    id_field: str | None = None,
    id_prefix: str | None = None,
) -> tuple[str, list[dict[str, str]], list[str]]:
    kind, header, rows, failures = load_ledger(md_path)
    missing = sorted(set(required_columns) - set(header))
    if missing:
        label = jsonl_path_for(md_path).name if kind == "jsonl" else md_path.name
        failures.append(f"{label} missing required columns: {', '.join(missing)}")
    if id_field and id_prefix:
        pattern = re.compile(rf"{re.escape(id_prefix)}\d{{3,}}")
        seen: set[str] = set()
        for idx, row in enumerate(rows, start=1):
            row_id = row.get(id_field, "")
            if not pattern.fullmatch(row_id):
                failures.append(f"{md_path.name} row {idx}: invalid {id_field} {row_id!r}")
            elif row_id in seen:
                failures.append(f"{md_path.name}: duplicate {id_field} {row_id}")
            seen.add(row_id)
    return kind, rows, failures


def existing_dual_ledger(root: Path, rel: str) -> tuple[Path, Path]:
    md = root / rel
    return md.with_suffix(".jsonl"), md


def ledger_exists(root: Path, rel: str) -> bool:
    jsonl, md = existing_dual_ledger(root, rel)
    return jsonl.exists() or is_nonempty(md)


def id_set_from_rows(rows: Iterable[dict[str, str]], prefix: str, field: str | None = None) -> set[str]:
    """Extract IDs only from an explicit field when supplied.

    The legacy all-fields scan remains available only for callers that omit
    ``field``; new validators should always specify the foreign-key field.
    """
    pattern = re.compile(rf"\b{re.escape(prefix)}\d{{3,}}\b")
    out: set[str] = set()
    for row in rows:
        values = [row.get(field, "")] if field else row.values()
        for value in values:
            out.update(pattern.findall(str(value)))
    return out


def ids_from_text(text: str, prefix: str) -> set[str]:
    return set(re.findall(rf"\b{re.escape(prefix)}\d{{3,}}\b", text))


def count_id_rows(md_path: Path, id_field: str, prefix: str) -> int:
    _kind, _header, rows, _failures = load_ledger(md_path)
    return sum(1 for row in rows if re.fullmatch(rf"{re.escape(prefix)}\d{{3,}}", row.get(id_field, "")))
