#!/usr/bin/env python3
"""Validate that a full publication run produced an actual publishable article.

This gate intentionally differs from provenance/trace gates.  It rejects a long
rough source copied verbatim into publication_final.md, requires an independent
content review and mathematical review bound to the current source/article
hashes, and checks that reviewer evidence points to text that really exists.
"""
from __future__ import annotations

from pathlib import Path
from difflib import SequenceMatcher
import hashlib
import json
import re
import sys

from safe_io import read_json_strict, read_jsonl_strict, read_text_strict
from content_functions import read_jsonl, stage_function_reviews
from source_obligations import source_obligation_contracts

SCHEMA = "publication-content-review-v1"
MATH_SCHEMA = "publication-mathematical-review-v1"
REQUIRED_CATEGORIES = {
    "SOURCE_COVERAGE",
    "MATHEMATICAL_CORRECTNESS",
    "PROOF_ROUTE_FIDELITY",
    "FORMULA_REPAIR",
    "AUTHOR_VOICE",
    "STRUCTURE_READABILITY",
    "PUBLICATION_READINESS",
    "HEADING_AUTHORIZATION",
    "OUTPUT_AUTHORIZATION",
}
ROUGH_MARKERS = ("\u200b", "\ufeff", "", "​")
PLACEHOLDER_PATTERNS = (
    r"\bTBD\b", r"\bTODO\b", r"\bFIXME\b", r"待补", r"待核", r"占位",
)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def normalize_for_similarity(text: str) -> str:
    return re.sub(r"\s+", "", text)


def fail(errors: list[str]) -> int:
    print("FAILED")
    for item in errors:
        print(f"- {item}")
    return 1


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    errors: list[str] = []
    required = [
        "source_canonical.txt",
        "source_revision.json",
        "publication_final.md",
        "publication_content_review.json",
        "mathematical_review.json",
        "heading_authorization.jsonl",
        "publication_fragment_authorization.jsonl",
    ]
    for name in required:
        if not (root / name).exists():
            errors.append(f"missing required content-acceptance file: {name}")
    if errors:
        return fail(errors)

    source_bytes = (root / "source_canonical.txt").read_bytes()
    article_bytes = (root / "publication_final.md").read_bytes()
    try:
        source = source_bytes.decode("utf-8", errors="strict")
        article = article_bytes.decode("utf-8", errors="strict")
        revision = read_json_strict(root / "source_revision.json", root=root)
        review = read_json_strict(root / "publication_content_review.json", root=root)
        math_review = read_json_strict(root / "mathematical_review.json", root=root)
    except Exception as exc:
        return fail([f"strict content-acceptance load failed: {exc}"])

    source_hash = sha(source_bytes)
    article_hash = sha(article_bytes)
    revision_id = str(revision.get("source_revision_id", ""))

    # A long-form publisher must not pass by copying rough notes as the article.
    if len(source_bytes) >= 1000:
        if article_bytes == source_bytes:
            errors.append("publication_final.md is byte-identical to the long source; raw-source copy is not a completed publication")
        similarity = SequenceMatcher(
            None,
            normalize_for_similarity(source),
            normalize_for_similarity(article),
            autojunk=False,
        ).ratio()
        if similarity >= 0.975:
            errors.append(f"publication is effectively a source copy (normalized similarity={similarity:.4f})")

    for marker in ROUGH_MARKERS:
        if marker and marker in article:
            errors.append(f"publication contains unresolved OCR/invisible marker: U+{ord(marker[0]):04X}")
    for pattern in PLACEHOLDER_PATTERNS:
        if re.search(pattern, article, flags=re.I):
            errors.append(f"publication contains unresolved placeholder pattern: {pattern}")

    if not isinstance(review, dict) or review.get("schema_version") != SCHEMA:
        errors.append(f"publication_content_review.json must use schema_version={SCHEMA}")
    else:
        for field, expected in [
            ("source_revision_id", revision_id),
            ("source_sha256", source_hash),
            ("publication_sha256", article_hash),
            ("publication_file", "publication_final.md"),
            ("review_scope", "FULL_ARTICLE"),
            ("verdict", "PASS"),
        ]:
            if str(review.get(field, "")) != expected:
                errors.append(f"publication content review field {field} does not match current artifact")
        checks = review.get("checks")
        if not isinstance(checks, list):
            errors.append("publication content review checks must be a list")
            checks = []
        seen: set[str] = set()
        for idx, item in enumerate(checks, 1):
            if not isinstance(item, dict):
                errors.append(f"content review check {idx} is not an object")
                continue
            category = str(item.get("category", ""))
            status = str(item.get("status", ""))
            seen.add(category)
            if status != "PASS":
                errors.append(f"content review category {category or idx} is not PASS")
            src_ev = str(item.get("source_evidence", "")).strip()
            pub_ev = str(item.get("publication_evidence", "")).strip()
            if src_ev and src_ev not in source:
                errors.append(f"content review source evidence not found for category {category}: {src_ev[:80]}")
            if pub_ev and pub_ev not in article:
                errors.append(f"content review publication evidence not found for category {category}: {pub_ev[:80]}")
            note = str(item.get("note", "")).strip()
            if len(note) < 16:
                errors.append(f"content review note too shallow for category {category}")
        missing = sorted(REQUIRED_CATEGORIES - seen)
        if missing:
            errors.append("publication content review missing categories: " + ", ".join(missing))
        headings = re.findall(r"^##\s+(.+?)\s*$", article, flags=re.M)
        reviewed_sections = review.get("reviewed_sections")
        if len(source_bytes) >= 1000:
            if not isinstance(reviewed_sections, list):
                errors.append("publication content review must list reviewed_sections for long-form output")
            else:
                missing_sections = [h for h in headings if h not in reviewed_sections]
                if missing_sections:
                    errors.append("content review did not cover sections: " + " | ".join(missing_sections))

    if not isinstance(math_review, dict) or math_review.get("schema_version") != MATH_SCHEMA:
        errors.append(f"mathematical_review.json must use schema_version={MATH_SCHEMA}")
    else:
        for field, expected in [
            ("source_revision_id", revision_id),
            ("source_sha256", source_hash),
            ("publication_sha256", article_hash),
            ("verdict", "PASS"),
        ]:
            if str(math_review.get(field, "")) != expected:
                errors.append(f"mathematical review field {field} does not match current artifact")
        items = math_review.get("items")
        if not isinstance(items, list):
            errors.append("mathematical review items must be a list")
            items = []
        min_items = 6 if len(source_bytes) >= 1000 else 1
        if len(items) < min_items:
            errors.append(f"mathematical review is too shallow: {len(items)} items, need at least {min_items}")
        for idx, item in enumerate(items, 1):
            if not isinstance(item, dict):
                errors.append(f"mathematical review item {idx} is not an object")
                continue
            if str(item.get("status", "")) != "PASS":
                errors.append(f"mathematical review item {idx} is not PASS")
            src_ev = str(item.get("source_evidence", "")).strip()
            pub_ev = str(item.get("publication_evidence", "")).strip()
            if not src_ev or src_ev not in source:
                errors.append(f"mathematical review item {idx} source evidence missing or not found")
            if not pub_ev or pub_ev not in article:
                errors.append(f"mathematical review item {idx} publication evidence missing or not found")
            reasoning = str(item.get("reasoning", "")).strip()
            if len(reasoning) < 24:
                errors.append(f"mathematical review item {idx} reasoning too shallow")

    # Category reviews are summaries.  Revalidate every P03 obligation through
    # the P04 Atom bindings and current P13 Atom/function evidence so a related
    # theorem or conclusion cannot masquerade as fulfillment.
    try:
        atoms_for_obligations = read_jsonl(root / "source_atom_ledger.jsonl")
        blueprint = read_json_strict(root / "publication_blueprint.json", root=root)
        if not isinstance(blueprint, dict):
            raise ValueError("publication_blueprint.json must contain one object")
        _obligation_rows, obligation_errors = source_obligation_contracts(
            root, blueprint, atoms_for_obligations, require_ledgers=False
        )
        errors.extend(obligation_errors)
        _p13_rows, p13_errors = stage_function_reviews(
            root,
            blueprint,
            atoms_for_obligations,
            "P13_PUBLICATION",
            "publication_final.md",
            require_all_atoms=True,
            require_function_matrix=True,
        )
        errors.extend(p13_errors)
    except Exception as exc:
        errors.append(f"source-obligation publication acceptance failed: {exc}")

    # Recompute every BYTE_EXACT atom/group against the actual final article.
    atom_path = root / "source_atom_ledger.jsonl"
    if atom_path.exists():
        try:
            atoms = read_jsonl_strict(atom_path, root=root)
        except Exception as exc:
            errors.append(f"cannot load source atoms for exact-output acceptance: {exc}")
            atoms = []
        exact_atoms = [a for a in atoms if a.get("surface_mode") == "BYTE_EXACT"]
        groups: dict[str, list[dict]] = {}
        singles: list[dict] = []
        for atom in exact_atoms:
            gid = str(atom.get("surface_group_id", "")).strip()
            if gid:
                groups.setdefault(gid, []).append(atom)
            else:
                singles.append(atom)
        slices: list[tuple[str, bytes]] = []
        for atom in singles:
            try:
                s = int(atom["source_byte_start"]); e = int(atom["source_byte_end"])
                slices.append((str(atom.get("atom_id")), source_bytes[s:e]))
            except Exception:
                errors.append(f"invalid BYTE_EXACT atom span: {atom.get('atom_id')}")
        for gid, rows in groups.items():
            try:
                s = min(int(a["source_byte_start"]) for a in rows)
                e = max(int(a["source_byte_end"]) for a in rows)
                slices.append((gid, source_bytes[s:e]))
            except Exception:
                errors.append(f"invalid BYTE_EXACT group spans: {gid}")
        for label, raw in slices:
            if raw and article_bytes.count(raw) != 1:
                errors.append(f"BYTE_EXACT source slice {label} must occur exactly once in publication_final.md")

    if errors:
        return fail(errors)
    similarity = SequenceMatcher(
        None,
        normalize_for_similarity(source),
        normalize_for_similarity(article),
        autojunk=False,
    ).ratio()
    print("OK: publication content acceptance passed")
    print(f"source_bytes={len(source_bytes)} publication_bytes={len(article_bytes)} normalized_similarity={similarity:.4f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
