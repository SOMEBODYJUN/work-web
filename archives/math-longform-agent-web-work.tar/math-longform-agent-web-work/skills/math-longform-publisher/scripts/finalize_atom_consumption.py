#!/usr/bin/env python3
"""Finalize atom consumption only after full P13 semantic acceptance."""
from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from typing import Any
import argparse
import hashlib
import json

from content_functions import read_jsonl, stage_function_reviews
from context_pack import build_context_pack
from publication_assembler import markdown_table, write_jsonl
from safe_io import atomic_write_json, atomic_write_text, read_json_strict
from source_obligations import (
    finalized_math_risk_rows,
    resolved_author_question_rows,
    source_obligation_contracts,
    write_author_question_rows,
    write_math_risk_rows,
)


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require_bound_review(
    path: Path,
    *,
    schema_version: str,
    source_sha: str,
    publication_sha: str,
) -> dict[str, Any]:
    value = read_json_strict(path)
    if not isinstance(value, dict) or value.get("schema_version") != schema_version:
        raise ValueError(f"{path.name} has the wrong schema")
    if value.get("source_sha256") != source_sha:
        raise ValueError(f"{path.name} source hash is stale")
    if value.get("publication_sha256") != publication_sha:
        raise ValueError(f"{path.name} publication hash is stale")
    if value.get("verdict") != "PASS":
        raise ValueError(f"{path.name} verdict is not PASS")
    return value


def require_authorization_approval(root: Path, name: str) -> None:
    rows = read_jsonl(root / name)
    if not rows:
        raise ValueError(f"{name} is empty")
    pending = [
        str(row.get("fragment_id") or row.get("heading_id") or index)
        for index, row in enumerate(rows, 1)
        if row.get("review_status") != "APPROVED"
    ]
    if pending:
        raise ValueError(f"{name} still has non-approved rows: {', '.join(pending[:12])}")


def finalize(root: Path) -> None:
    source_path = root / "source_canonical.txt"
    publication_path = root / "publication_final.md"
    p11_path = root / "aigc_rewritten_final.md"
    if publication_path.read_bytes() != p11_path.read_bytes():
        raise ValueError("P12 publication bytes no longer match the reviewed P11 article")
    source_sha = sha256_file(source_path)
    publication_sha = sha256_file(publication_path)

    atoms = read_jsonl(root / "source_atom_ledger.jsonl")
    blueprint = read_json_strict(root / "publication_blueprint.json")
    if not isinstance(blueprint, dict):
        raise ValueError("publication_blueprint.json must be an object")
    p13_reviews, errors = stage_function_reviews(
        root,
        blueprint,
        atoms,
        "P13_PUBLICATION",
        "publication_final.md",
        require_all_atoms=True,
        require_function_matrix=True,
    )
    if errors:
        raise ValueError("P13 atom/function review failed: " + "; ".join(errors[:16]))
    source_obligation_rows, source_obligation_errors = source_obligation_contracts(
        root, blueprint, atoms, require_ledgers=False
    )
    if source_obligation_errors:
        raise ValueError(
            "P13 source-obligation review failed: "
            + "; ".join(source_obligation_errors[:16])
        )

    require_bound_review(
        root / "publication_content_review.json",
        schema_version="publication-content-review-v1",
        source_sha=source_sha,
        publication_sha=publication_sha,
    )
    require_bound_review(
        root / "mathematical_review.json",
        schema_version="publication-mathematical-review-v1",
        source_sha=source_sha,
        publication_sha=publication_sha,
    )
    require_authorization_approval(root, "heading_authorization.jsonl")
    require_authorization_approval(root, "publication_fragment_authorization.jsonl")

    candidates = read_jsonl(root / "atom_consumption_candidates.jsonl")
    by_atom = {str(row.get("atom_id")): row for row in candidates}
    atom_ids = {str(atom.get("atom_id")) for atom in atoms}
    if set(by_atom) != atom_ids:
        raise ValueError("P12 consumption candidates do not cover the exact current atom set")

    for atom in atoms:
        atom_id = str(atom["atom_id"])
        candidate = by_atom[atom_id]
        if candidate.get("candidate_status") != "MAPPED_PENDING_P13_REVIEW":
            raise ValueError(f"{atom_id}: invalid P12 candidate status")
        unit_ids = candidate.get("output_unit_ids")
        if not isinstance(unit_ids, list) or not unit_ids:
            raise ValueError(f"{atom_id}: P12 candidate has no output units")
        duplicate = str(atom.get("content_type", "")) == "DUPLICATE"
        atom["consumption_status"] = "DUPLICATE_CONSUMED" if duplicate else "CONSUMED"
        atom["destination_status"] = "accepted"
        atom["final_destination"] = (
            "publication_final.md:" + ",".join(str(item) for item in unit_ids)
        )
        atom["consumption_basis"] = (
            "P13 reopened the exact source atom and publication bytes and passed every "
            "required function with exact source/output evidence"
        )
        atom["consumption_review_stage"] = "P13_PUBLICATION"

    # Compute the final AQ rows only after every P13 precondition and candidate
    # has passed.  Keep the actual write adjacent to the Atom-ledger writes so
    # an earlier validation failure cannot leave a false final lifecycle state.
    final_author_question_rows = None
    if (root / "author_question_obligation_ledger.jsonl").is_file():
        final_author_question_rows = resolved_author_question_rows(
            root, source_obligation_rows, p13_reviews, publication_sha
        )
    final_math_risk_rows = None
    if (root / "source_math_risk_ledger.jsonl").is_file():
        final_math_risk_rows = finalized_math_risk_rows(
            root, source_obligation_rows, p13_reviews, publication_sha
        )

    write_jsonl(root / "source_atom_ledger.jsonl", atoms)
    atomic_write_text(
        root / "source_atom_ledger.md", markdown_table(atoms, "Source Atom Ledger")
    )
    chunks: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for atom in atoms:
        chunks[str(atom.get("chunk_id"))].append(atom)
    for chunk_id, rows in chunks.items():
        chunk_root = root / "chunk_ledger"
        chunk_root.mkdir(parents=True, exist_ok=True)
        stem = f"chunk_{chunk_id}_atom_ledger"
        write_jsonl(chunk_root / f"{stem}.jsonl", rows)
        atomic_write_text(
            chunk_root / f"{stem}.md", markdown_table(rows, f"{chunk_id} Atom Ledger")
        )
    if final_author_question_rows is not None:
        write_author_question_rows(root, final_author_question_rows)
    if final_math_risk_rows is not None:
        write_math_risk_rows(root, final_math_risk_rows)

    state_path = root / "active_state.json"
    if state_path.is_file():
        state = read_json_strict(state_path)
        if isinstance(state, dict):
            state["current_stage"] = "publication_validation"
            state["resume_point"] = "P13 semantic acceptance finalized; run release validators"
            state["resume_instruction"] = (
                "Invalidate P13 reviews and return to the first changed rewrite boundary after any byte change."
            )
            atomic_write_json(state_path, state)
            active_md = "\n".join(
                [
                    "# Active State",
                    "",
                    f"RUN_ID: {state['run_id']}",
                    f"RUN_MODE: {state['run_mode']}",
                    f"CURRENT_STAGE: {state['current_stage']}",
                    f"RESUME_POINT: {state['resume_point']}",
                    f"FEEDBACK_LEDGER_SHA256: {state['feedback_ledger_sha256']}",
                    "ACTIVE_FEEDBACK_IDS: "
                    + (",".join(state.get("active_feedback_ids", [])) or "none"),
                    "",
                    "## Resume Instruction",
                    "",
                    str(state["resume_instruction"]),
                    "",
                    "## Hard Constraints",
                    "",
                    *[f"- {item}" for item in state.get("hard_constraints", [])],
                    "",
                ]
            )
            atomic_write_text(root / "active_state.md", active_md)

    # The business context manifest is a deterministic mirror. Refreshing its
    # hashes after accepted status changes does not create semantic evidence.
    if (root / "context_pack_manifest.json").is_file():
        build_context_pack(root)

    print("ATOM_CONSUMPTION_FINALIZED")
    print(f"consumed_atoms={len(atoms)}")
    print("review_stage=P13_PUBLICATION")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output")
    args = parser.parse_args()
    try:
        finalize(Path(args.output).resolve())
    except Exception as exc:
        print(f"FAILED: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
