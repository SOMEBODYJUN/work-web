#!/usr/bin/env python3
"""Validate publication Markdown for the current longform workflow.

This script only checks known failure modes. It never writes article prose.
"""
from pathlib import Path
import sys
import re

BANNED = [
    "以一般形式说明",
    "设对象满足命题中的全部假设",
    "第一步展开定义",
    "第二步利用假设",
    "第三步把得到的条件代回目标",
    "一个典型关系可以写成",
    "这份材料主要按概念、结论、证明和复习提醒展开",
    "高频词包括",
    "原稿里",
    "原文这里",
    "原笔记",
    "草稿里",
    "你笔记里",
    "占位符",
    "这里不保留",
    "补出来",
    "source_id",
    "ledger",
    "coverage_check",
    "workflow",
    "xxxxxxxx",
    "真正的核心",
    "问题的真正入口",
    "本质上",
    "底层逻辑",
    "关键抓手",
    "完整闭环",
    "从直觉到严格",
    "统一视角",
    "系统梳理",
    "全面解析",
    "非常关键",
    "极其重要",
    "整个证明的精髓",
]

HTML = [r"<div\b", r"</div>", r"<span\b", r"</span>", r"<table\b", r"</table>", r"<a\b", r"</a>"]

CONTRAST_PATTERNS = [
    r"不是[^。\n]{0,40}而是",
    r"不只是[^。\n]{0,40}更是",
    r"表面上[^。\n]{0,40}实际上",
]

# mdnice / MathJax formula checks
MDNICE_LEGACY_DELIMITERS = [
    (r"\\\(", r"\("),
    (r"\\\)", r"\)"),
    (r"\\\[", r"\["),
    (r"\\\]", r"\]"),
]

MDNICE_UNSUPPORTED_LATEX = [
    r"\\usepackage\b",
    r"\\documentclass\b",
    r"\\begin\{equation\*?\}",
    r"\\begin\{align\*?\}",
    r"\\begin\{gather\*?\}",
    r"\\begin\{multline\*?\}",
]

MDNICE_CJK_RE = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")
MDNICE_UNESCAPED_DOLLAR_RE = re.compile(r"(?<!\\)\$")

def _mdnice_line_no(text: str, pos: int) -> int:
    return text.count("\n", 0, pos) + 1

def _mdnice_strip_fenced_code(text: str) -> str:
    lines = text.splitlines(keepends=True)
    out = []
    in_fence = False
    fence_marker = None
    for line in lines:
        stripped = line.lstrip()
        if stripped.startswith("```") or stripped.startswith("~~~"):
            marker = stripped[:3]
            if not in_fence:
                in_fence = True
                fence_marker = marker
            elif marker == fence_marker:
                in_fence = False
                fence_marker = None
            out.append("\n")
        elif in_fence:
            out.append("\n")
        else:
            out.append(line)
    return "".join(out)

def _mdnice_extract_math(text: str):
    items = []
    spans = []
    for m in re.finditer(r"(?<!\\)\$\$(.*?)(?<!\\)\$\$", text, flags=re.S):
        items.append(("display", m.start(), m.group(1)))
        spans.append((m.start(), m.end()))
    mask = list(text)
    for a, b in spans:
        for i in range(a, b):
            mask[i] = "\n" if text[i] == "\n" else " "
    no_display = "".join(mask)
    for m in re.finditer(r"(?<!\\)\$(?!\$)(.*?)(?<!\\)\$(?!\$)", no_display, flags=re.S):
        items.append(("inline", m.start(), m.group(1)))
    items.sort(key=lambda x: x[1])
    return items

def validate_mdnice_math_text(text: str):
    mdnice_errors = []
    clean = _mdnice_strip_fenced_code(text)

    for pat, label in MDNICE_LEGACY_DELIMITERS:
        for m in re.finditer(pat, clean):
            mdnice_errors.append(f"mdnice formula delimiter forbidden at line {_mdnice_line_no(clean, m.start())}: use $...$ or $$...$$ instead of {label}")

    if clean.count("$$") % 2 != 0:
        mdnice_errors.append("unbalanced display math delimiters: odd number of $$")

    without_display = re.sub(r"(?<!\\)\$\$.*?(?<!\\)\$\$", "", clean, flags=re.S)
    if len(MDNICE_UNESCAPED_DOLLAR_RE.findall(without_display)) % 2 != 0:
        mdnice_errors.append("unbalanced inline math delimiters: odd number of unescaped $ outside display math")

    for i, line in enumerate(clean.splitlines(), start=1):
        stripped = line.strip()
        if "|" in line and "$" in line and not stripped.startswith(">"):
            mdnice_errors.append(f"MathJax formula appears inside a Markdown table at line {i}; use a MathJax array or move the formula out of the table")

    for pat in MDNICE_UNSUPPORTED_LATEX:
        for m in re.finditer(pat, clean):
            mdnice_errors.append(f"unsupported LaTeX environment/package pattern at line {_mdnice_line_no(clean, m.start())}: {pat}")

    for kind, pos, body in _mdnice_extract_math(clean):
        ln = _mdnice_line_no(clean, pos)
        if MDNICE_CJK_RE.search(body):
            mdnice_errors.append(f"CJK text inside {kind} math at line {ln}; move Chinese prose outside the formula environment")
        for m in re.finditer(r"<(?![ =])", body):
            mdnice_errors.append(f"`<` without following space inside {kind} math at line {ln}; write `$a < b$`, not `$a <b$`")
        if "\\boxed{\\text{" in body and MDNICE_CJK_RE.search(body):
            mdnice_errors.append(f"Chinese sentence boxed inside math at line {ln}; use a Markdown quote/block instead")
    return mdnice_errors
# --- end mdnice checks ---


def main() -> int:
    args = [arg for arg in sys.argv[1:] if arg != "--require-draft"]
    require_draft = len(args) != len(sys.argv[1:])

    if len(args) < 1:
        print("Usage: validate_final_article.py [--require-draft] final.md|optimized_final.md|standardized_final.md [source.txt]")
        return 2
    final_path = Path(args[0])
    final = final_path.read_text(encoding="utf-8")
    errors = []

    for phrase in BANNED:
        if phrase in final:
            errors.append(f"banned phrase: {phrase}")

    for pat in HTML:
        if re.search(pat, final, flags=re.IGNORECASE):
            errors.append(f"raw HTML detected: {pat}")

    for e in validate_mdnice_math_text(final):
        errors.append(e)

    contrast_hits = []
    for pat in CONTRAST_PATTERNS:
        contrast_hits.extend(re.findall(pat, final))
    if len(contrast_hits) > 1:
        errors.append(f"too many AI-flavored contrast patterns: {len(contrast_hits)}")

    source = Path(args[1]).read_text(encoding="utf-8") if len(args) >= 2 else ""

    draft_path = final_path.parent / "draft.md"
    if require_draft:
        if not draft_path.exists():
            errors.append("missing draft.md beside final.md")
        else:
            draft = draft_path.read_text(encoding="utf-8")
            if len(draft.strip()) < 1000:
                errors.append("draft.md is too short to be a serious first article")

    review_path = final_path.parent / "independent_review.md"
    if not review_path.exists():
        errors.append("missing independent_review.md beside final.md")
    else:
        review = review_path.read_text(encoding="utf-8")
        required_review_markers = [
            "## Findings",
            "## Required Rewrite Actions",
            "## Rewrite Decision",
        ]
        for marker in required_review_markers:
            if marker not in review:
                errors.append(f"independent_review.md missing marker: {marker}")
        if "Validator pass treated as enough? yes" in review:
            errors.append("independent_review.md treats validator pass as enough")
        try:
            if require_draft and draft_path.exists() and review_path.stat().st_mtime < draft_path.stat().st_mtime - 2:
                errors.append("independent_review.md appears older than draft.md; audit should review the completed draft")
            if review_path.stat().st_mtime > final_path.stat().st_mtime + 2:
                errors.append("independent_review.md appears newer than final.md; audit should lead the rewrite")
        except OSError:
            pass

    post_review_path = final_path.parent / "post_final_structure_review.md"
    optimized_path = final_path.parent / "optimized_final.md"
    content_final_path = final_path.parent / "final.md"
    standardized_path = final_path.parent / "standardized_final.md"

    if final_path.name in {"optimized_final.md", "standardized_final.md"}:
        if not content_final_path.exists():
            errors.append("missing final.md content-final beside publication output")
        if not post_review_path.exists():
            errors.append("missing post_final_structure_review.md beside publication output")
        else:
            post_review = post_review_path.read_text(encoding="utf-8")
            required_post_markers = [
                "## Findings",
                "## Required Optimization Actions",
                "## Optimization Decision",
            ]
            for marker in required_post_markers:
                if marker not in post_review:
                    errors.append(f"post_final_structure_review.md missing marker: {marker}")
            if "Validator pass treated as enough? yes" in post_review:
                errors.append("post_final_structure_review.md treats validator pass as enough")
        try:
            if content_final_path.exists() and post_review_path.exists():
                if post_review_path.stat().st_mtime < content_final_path.stat().st_mtime - 2:
                    errors.append("post_final_structure_review.md appears older than final.md; structure audit should review final.md")
            if post_review_path.exists() and optimized_path.exists():
                if optimized_path.stat().st_mtime < post_review_path.stat().st_mtime - 2:
                    errors.append("optimized_final.md appears older than post_final_structure_review.md; optimization should follow the audit")
        except OSError:
            pass

    if final_path.name == "standardized_final.md":
        if not optimized_path.exists():
            errors.append("missing optimized_final.md beside standardized_final.md")
        if standardized_path.exists() and standardized_path.resolve() != final_path.resolve():
            errors.append("standardized_final.md path mismatch")
        if re.search(r"^###", final, flags=re.MULTILINE):
            errors.append("standardized_final.md should avoid deep ### headings by default")
        block_label_pattern = r"\*\*(定义|记号|命题|引理|定理|推论|证明|证明思路|注释|例|分析|解|警告|对照)"
        if source and len(source.strip()) > 5000 and not re.search(block_label_pattern, final):
            errors.append("standardized_final.md lacks theorem/proof/example block labels")
        try:
            if optimized_path.exists() and optimized_path.stat().st_mtime > final_path.stat().st_mtime + 2:
                errors.append("optimized_final.md appears newer than standardized_final.md; normalization should be last")
        except OSError:
            pass

    if errors:
        print("FAILED")
        for e in errors:
            print("-", e)
        return 1

    print("OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
