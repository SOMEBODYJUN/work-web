#!/usr/bin/env python3
"""Validate staged chunk batching for long-source semantic atomization.

Chunking protects context size. It is not a punctuation quota and must not force
one atom per comma or OCR symbol.
"""
from __future__ import annotations

from pathlib import Path
import json
import math
import re
import sys

from structured_ledger import load_ledger, id_set_from_rows

LONG_SOURCE_CHARS = 12000
MAX_CHUNK_CHARS = 8000
SOFT_MAX_CHUNK_SEMANTIC_UNITS = 160
ABSOLUTE_MAX_CHUNK_CHARS_WITH_EXCEPTION = 12000

SEMANTIC_BOUNDARY_RE = re.compile(r"(?<=[。！？!?])|\n{2,}")
ID_RE = re.compile(r"\b([ACT]\d{3,})\b")
SPAN_RE = re.compile(r"^\s*(\d+)\s*-\s*(\d+)\s*$")


def read(path: Path) -> str:
    return path.read_bytes().decode("utf-8", errors="strict") if path.exists() else ""


def strip_blocks(text: str) -> str:
    text = re.sub(r"```.*?```", " FORMULA_BLOCK ", text, flags=re.S)
    text = re.sub(r"\$\$.*?\$\$", " FORMULA_BLOCK ", text, flags=re.S)
    return text


def semantic_units(text: str) -> list[str]:
    text = strip_blocks(text)
    return [
        unit.strip()
        for unit in SEMANTIC_BOUNDARY_RE.split(text)
        if unit.strip() and not re.fullmatch(r"[\s\W_]+", unit)
    ]


def table_rows(text: str) -> list[dict[str, str]]:
    lines = [ln.rstrip() for ln in text.splitlines() if ln.strip().startswith("|")]
    if len(lines) < 2:
        return []
    header = [c.strip() for c in lines[0].strip().strip("|").split("|")]
    rows: list[dict[str, str]] = []
    for line in lines[2:]:
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < len(header):
            cells += [""] * (len(header) - len(cells))
        row = dict(zip(header, cells))
        if any(row.values()):
            rows.append(row)
    return rows


def table_header(text: str) -> set[str]:
    for ln in text.splitlines():
        if ln.strip().startswith("|"):
            return {c.strip() for c in ln.strip().strip("|").split("|")}
    return set()


def row_count(text: str, prefix: str) -> int:
    return len(re.findall(rf"^\|\s*{prefix}\d+\s*\|", text, flags=re.M))


def extract_span(row: dict[str, str]) -> tuple[int, int] | None:
    blob = row.get("char_span") or ""
    if not blob:
        start = row.get("start_char") or row.get("start") or ""
        end = row.get("end_char") or row.get("end") or ""
        if start and end:
            blob = f"{start}-{end}"
    m = SPAN_RE.match(blob.replace(":", "-"))
    if not m:
        return None
    return int(m.group(1)), int(m.group(2))


def ids(text: str, prefix: str) -> set[str]:
    return set(re.findall(rf"\b{prefix}\d{{3,}}\b", text))




def load_rows(path: Path) -> list[dict[str, str]]:
    _kind, _header, rows, _errs = load_ledger(path)
    return rows


def load_ids(path: Path, prefix: str) -> set[str]:
    kind, _header, rows, _errs = load_ledger(path)
    if kind != "missing" and rows:
        return id_set_from_rows(rows, prefix)
    return ids(read(path), prefix)


def load_row_count(path: Path, id_field: str, prefix: str) -> int:
    kind, _header, rows, _errs = load_ledger(path)
    if kind != "missing" and rows:
        return sum(1 for row in rows if re.fullmatch(rf"{prefix}\d{{3,}}", row.get(id_field, "")))
    return row_count(read(path), prefix)


def load_header(path: Path) -> set[str]:
    kind, header, rows, _errs = load_ledger(path)
    if kind != "missing" and header:
        return set(header)
    return table_header(read(path))


def status_is_exception(row: dict[str, str]) -> bool:
    blob = " ".join(str(v) for v in row.values())
    return bool(re.search(r"formula_block|table|ocr|cannot_split|exception|oversize_allowed", blob, re.I))


def looks_complete(value: str) -> bool:
    return bool(re.search(r"complete|pass|done|locked|ok|verified", value or "", re.I))


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    source = read(root / "source.txt")
    chunk_index_text = read(root / "source_chunk_index.md")
    aggregate_text = read(root / "source_atom_ledger.md")
    failures: list[str] = []
    warnings: list[str] = []

    if not source.strip():
        failures.append("source.txt is missing or empty")
    if not chunk_index_text.strip():
        failures.append("source_chunk_index.md is missing or empty")
    if failures:
        print("FAILED")
        for f in failures:
            print(f"- {f}")
        return 1

    source_len = len(source)
    span_unit = "unicode_codepoint"
    identity_path = root / "source_identity.json"
    if identity_path.exists():
        try:
            span_unit = str(json.loads(identity_path.read_text(encoding="utf-8")).get("span_unit", span_unit))
        except Exception:
            pass
    source_span_len = len(source.encode("utf-8")) if span_unit == "utf8_byte_offset" else source_len
    estimated_semantic_total = len(semantic_units(source))
    rows = [r for r in load_rows(root / "source_chunk_index.md") if re.fullmatch(r"C\d{3,}", r.get("chunk_id", ""))]
    chunk_ids = [r.get("chunk_id", "") for r in rows]
    unique_chunk_ids = sorted(set(chunk_ids))
    is_long = source_len > LONG_SOURCE_CHARS or estimated_semantic_total > SOFT_MAX_CHUNK_SEMANTIC_UNITS

    if not rows:
        failures.append("source_chunk_index.md has no Cxxx rows")
    if len(chunk_ids) != len(unique_chunk_ids):
        failures.append("duplicate chunk_id rows in source_chunk_index.md")

    required_chunk_count = 1
    if is_long:
        required_chunk_count = max(
            math.ceil(source_len / MAX_CHUNK_CHARS),
            math.ceil(max(estimated_semantic_total, 1) / SOFT_MAX_CHUNK_SEMANTIC_UNITS),
        )
        if len(unique_chunk_ids) < required_chunk_count:
            failures.append(
                f"long source is under-batched: len={source_len}, semantic_units≈{estimated_semantic_total}, "
                f"chunks={len(unique_chunk_ids)}, expected at least {required_chunk_count} "
                f"by {MAX_CHUNK_CHARS} chars/{SOFT_MAX_CHUNK_SEMANTIC_UNITS} semantic-units budget"
            )

    spans: list[tuple[str, int, int, dict[str, str]]] = []
    for row in rows:
        cid = row.get("chunk_id", "")
        span = extract_span(row)
        if span is None:
            failures.append(f"{cid}: missing numeric char span; use char_span or start_char/end_char")
            continue
        start, end = span
        if not (0 <= start < end <= source_span_len):
            failures.append(f"{cid}: char span out of source range: {start}-{end} for source span length {source_span_len}")
            continue
        spans.append((cid, start, end, row))

    spans_sorted = sorted(spans, key=lambda x: x[1])
    if spans_sorted:
        first_start = spans_sorted[0][1]
        last_end = spans_sorted[-1][2]
        if first_start != 0:
            failures.append(f"first chunk must start at 0; found {first_start}")
        if last_end != source_span_len:
            warnings.append(f"last chunk ends at {last_end}, source span length is {source_span_len}; verify trailing whitespace or omitted tail")
        prev_end = 0
        for cid, start, end, row in spans_sorted:
            if start != prev_end:
                failures.append(f"chunk spans are not contiguous before {cid}: previous end {prev_end}, current start {start}")
            prev_end = end
            if span_unit == "utf8_byte_offset":
                chunk_text = source.encode("utf-8")[start:end].decode("utf-8", errors="strict")
            else:
                chunk_text = source[start:end]
            chunk_len = len(chunk_text)
            chunk_semantic = len(semantic_units(chunk_text))
            exception = status_is_exception(row)
            if chunk_len > MAX_CHUNK_CHARS and not exception:
                failures.append(f"{cid}: chunk too large for reliable atomization: {chunk_len} chars > {MAX_CHUNK_CHARS}")
            if chunk_len > ABSOLUTE_MAX_CHUNK_CHARS_WITH_EXCEPTION:
                failures.append(f"{cid}: chunk exceeds absolute exception cap: {chunk_len} chars > {ABSOLUTE_MAX_CHUNK_CHARS_WITH_EXCEPTION}")
            if chunk_semantic > SOFT_MAX_CHUNK_SEMANTIC_UNITS and not exception:
                failures.append(f"{cid}: chunk too dense: about {chunk_semantic} semantic units > {SOFT_MAX_CHUNK_SEMANTIC_UNITS}")

    chunk_dir = root / "chunk_ledger"
    if is_long and not chunk_dir.exists():
        failures.append("long source requires chunk_ledger/ with one atom ledger per chunk")

    chunk_atom_total = 0
    atom_ids_seen: set[str] = set()
    for cid in unique_chunk_ids:
        candidates = [chunk_dir / f"chunk_{cid}_atom_ledger.md", chunk_dir / f"{cid}_atom_ledger.md"]
        path = next((p for p in candidates if p.exists() or p.with_suffix(".jsonl").exists()), None)
        if path is None:
            if is_long:
                failures.append(f"missing atom ledger for {cid}: expected chunk_ledger/chunk_{cid}_atom_ledger.md")
            continue
        text = read(path)
        header = load_header(path)
        if is_long and not {"atom_id", "sentence_id", "chunk_id", "char_span", "source_excerpt"}.issubset(header):
            failures.append(f"{path.relative_to(root)} missing semantic atom columns needed for batch-safe merge")
        atom_count = load_row_count(path, "atom_id", "A")
        chunk_atom_total += atom_count
        if is_long and atom_count < 3:
            failures.append(f"{path.relative_to(root)} has too few atoms: {atom_count}")
        kind_tmp, _h_tmp, rows_tmp, _e_tmp = load_ledger(path)
        if not any(cid in " ".join(str(v) for v in row.values()) for row in rows_tmp) and cid not in text:
            failures.append(f"{path.relative_to(root)} does not mention its chunk id {cid}")
        for aid in load_ids(path, "A"):
            if aid in atom_ids_seen:
                failures.append(f"duplicate atom id across chunk ledgers: {aid}")
            atom_ids_seen.add(aid)

    aggregate_ids = load_ids(root / "source_atom_ledger.md", "A")
    if is_long:
        missing_in_aggregate = sorted(atom_ids_seen - aggregate_ids)
        if missing_in_aggregate:
            failures.append("aggregate source_atom_ledger.md is missing atom ids from chunk ledgers: " + ", ".join(missing_in_aggregate[:20]))
        if chunk_atom_total and len(aggregate_ids) < int(chunk_atom_total * 0.95):
            failures.append(
                f"aggregate source_atom_ledger.md too small for merged chunk ledgers: aggregate ids={len(aggregate_ids)}, chunk atoms={chunk_atom_total}"
            )

        manifest = read(root / "source_atom_manifest.md")
        if not manifest.strip():
            failures.append("long source requires source_atom_manifest.md so later stages can load compact counts before opening chunk ledgers")
        else:
            for cid in unique_chunk_ids:
                if cid not in manifest:
                    failures.append(f"source_atom_manifest.md missing {cid}")

        log = read(root / "chunk_processing_log.md")
        if not log.strip():
            failures.append("long source requires chunk_processing_log.md with per-chunk validation status")
        else:
            for cid in unique_chunk_ids:
                if cid not in log:
                    failures.append(f"chunk_processing_log.md missing {cid}")
            if not re.search(r"validate_source_atom_granularity\.py|validate_chunk_batching\.py|validate_chunk_ledgers\.py", log):
                failures.append("chunk_processing_log.md must record actual validator commands used on the chunk stage")
            if not re.search(r"exit[_ ]?code\s*[:|]\s*0|\|\s*0\s*\|", log, re.I):
                failures.append("chunk_processing_log.md must include successful exit_code evidence")

    if failures:
        print("FAILED")
        print(f"source_chars={source_len} semantic_unit_hint={estimated_semantic_total} chunks={len(unique_chunk_ids)}")
        for f in failures:
            print(f"- {f}")
        for w in warnings[:20]:
            print(f"WARNING: {w}")
        return 1

    print("OK")
    print(f"source_chars={source_len} semantic_unit_hint={estimated_semantic_total} chunks={len(unique_chunk_ids)}")
    if is_long:
        print(f"batch_budget=max {MAX_CHUNK_CHARS} chars and about {SOFT_MAX_CHUNK_SEMANTIC_UNITS} semantic units per chunk")
    for w in warnings[:20]:
        print(f"WARNING: {w}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
