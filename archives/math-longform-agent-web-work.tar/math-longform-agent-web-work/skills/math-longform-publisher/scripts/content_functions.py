#!/usr/bin/env python3
"""Shared content-function contracts for source atoms and staged rewrites.

The deterministic layer never infers a prose function from words or patterns.
P04 assigns functions after semantic review of each exact atom.  This module
only validates that the resulting contracts and phase-local source/output
evidence are structurally complete and current.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any
import hashlib
import json
import re

from content_authority import (
    CONTENT_TYPES,
    OUTPUT_OPERATIONS,
    SURFACE_CONFIDENCE,
    SURFACE_DECISION_BASES,
    SURFACE_MODES,
    load_jsonl_objects,
    parse_json_field,
    split_output_units,
)


# Keep a stable order for serialized contracts and native-review evidence.  The
# public ``CONTENT_FUNCTIONS`` set is retained for callers that only need
# membership checks.
CONTENT_FUNCTION_ORDER = (
    "SUBSTANTIVE_CONTENT",
    "QUESTION_OR_DOUBT",
    "EXPLANATION_CHAIN",
    "METHOD_OBSERVATION",
    "AUTHOR_PERSPECTIVE",
    "INTUITION_OR_ANALOGY",
    "PROOF_DEPENDENCY",
    "FOLLOWUP_REQUEST",
    "WARNING_OR_CONTRAST",
)
CONTENT_FUNCTIONS = set(CONTENT_FUNCTION_ORDER)
FUNCTION_DECISIONS = {"REQUIRED", "NOT_REQUIRED"}

# ``function_matrix`` is deliberately a separate P04 field rather than a
# derivation of ``required_functions``.  A required-only list cannot show that
# the reviewer considered (and rejected, where appropriate) every other
# semantic responsibility.
FUNCTION_MATRIX_KEY = "function_matrix"

PASS_FUNCTION_STATUSES = {"PRESERVED", "REASONABLE_TRANSFORM"}
SENSITIVE_FUNCTIONS = CONTENT_FUNCTIONS - {"SUBSTANTIVE_CONTENT"}

INTERMEDIATE_STAGE_TARGETS: tuple[tuple[str, str, bool], ...] = (
    ("P06_DRAFT", "draft.md", True),
    ("P07_FINAL", "final.md", True),
    ("P08_OPTIMIZED", "optimized_final.md", True),
    ("P08_STANDARDIZED", "standardized_final.md", True),
    ("P10_REVISED", "revised_final.md", True),
    ("P11_AIGC", "aigc_rewritten_final.md", True),
)
PUBLICATION_STAGE = ("P13_PUBLICATION", "publication_final.md", True)

PRELOCK_DISPOSITIONS = {
    "CONFIRMED_PRELOCK",
    "DOWNGRADED_FALSE_POSITIVE",
    "ADDED_BY_P04",
    "NO_PRELOCK",
}


def normalize_functions(value: Any, label: str) -> list[str]:
    if isinstance(value, str):
        value = [item for item in re.split(r"[,;\s]+", value) if item]
    if not isinstance(value, list) or not value:
        raise ValueError(f"{label} must be a nonempty list or comma-separated string")
    result: list[str] = []
    for item in value:
        token = str(item).strip()
        if token not in CONTENT_FUNCTIONS:
            raise ValueError(f"{label} has invalid function {token!r}")
        if token not in result:
            result.append(token)
    return result


def normalize_function_matrix(
    value: Any,
    label: str,
    *,
    source_excerpt: str = "",
    required_functions: Any = None,
    require_matrix: bool = True,
) -> tuple[dict[str, dict[str, str]], list[str]]:
    """Validate and normalize the complete P04 responsibility matrix.

    ``required_functions`` is intentionally checked *against* the matrix, not
    used to construct it.  A contract is complete only when every member of
    :data:`CONTENT_FUNCTIONS` has an explicit ``REQUIRED`` or ``NOT_REQUIRED``
    decision, an exact source fragment, and a source-grounded semantic reason.

    ``require_matrix=False`` is a narrow compatibility mode for old library
    fixtures.  Production callers pass ``True``; when the field is present it
    is validated strictly in either mode.
    """
    errors: list[str] = []
    if value is None:
        if require_matrix:
            errors.append(f"{label} is required and must enumerate every CONTENT_FUNCTION")
        return {}, errors
    if not isinstance(value, dict):
        errors.append(f"{label} must be an object keyed by CONTENT_FUNCTION")
        return {}, errors

    expected = set(CONTENT_FUNCTION_ORDER)
    actual = {str(key) for key in value}
    missing = sorted(expected - actual)
    extra = sorted(actual - expected)
    if missing:
        errors.append(f"{label} is missing function decisions: {', '.join(missing)}")
    if extra:
        errors.append(f"{label} has unknown functions: {', '.join(extra)}")

    normalized: dict[str, dict[str, str]] = {}
    for function in CONTENT_FUNCTION_ORDER:
        entry = value.get(function)
        if not isinstance(entry, dict):
            errors.append(f"{label}.{function} must be an object")
            continue
        # ``status`` is canonical.  ``decision``/``source_fragment``/``reason``
        # are accepted as read-only aliases so an older hand-authored blueprint
        # can be diagnosed rather than silently discarded; normalized output
        # always uses the canonical names.
        raw_status = entry.get("status", entry.get("decision", ""))
        status = str(raw_status).strip().upper()
        if status not in FUNCTION_DECISIONS:
            errors.append(
                f"{label}.{function}.status must be REQUIRED or NOT_REQUIRED"
            )
        if "status" in entry and "decision" in entry:
            if str(entry.get("decision", "")).strip().upper() != status:
                errors.append(f"{label}.{function}: status and decision disagree")

        source_evidence = str(
            entry.get("source_evidence", entry.get("source_fragment", ""))
        )
        semantic_reason = str(
            entry.get("semantic_reason", entry.get("reason", ""))
        ).strip()
        if not source_evidence:
            errors.append(f"{label}.{function}.source_evidence must be nonempty")
        elif source_excerpt and source_evidence not in source_excerpt:
            errors.append(
                f"{label}.{function}.source_evidence must be an exact substring of the Atom"
            )
        if len(semantic_reason) < 12:
            errors.append(f"{label}.{function}.semantic_reason is too shallow")
        normalized[function] = {
            "status": status,
            "source_evidence": source_evidence,
            "semantic_reason": semantic_reason,
        }

    if required_functions is not None:
        try:
            required = set(normalize_functions(required_functions, f"{label}.required_functions"))
        except ValueError as exc:
            errors.append(str(exc))
        else:
            matrix_required = {
                function
                for function, entry in normalized.items()
                if entry.get("status") == "REQUIRED"
            }
            if matrix_required != required:
                errors.append(
                    f"{label}: required_functions must equal the REQUIRED matrix set "
                    f"(required={sorted(required)}, matrix={sorted(matrix_required)})"
                )
            if "SUBSTANTIVE_CONTENT" not in matrix_required:
                errors.append(
                    f"{label}: SUBSTANTIVE_CONTENT must be REQUIRED in the function matrix"
                )
    return normalized, errors


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _normalize_surface_contract(
    value: Any, atom: dict[str, Any], label: str
) -> tuple[dict[str, Any] | None, list[str]]:
    errors: list[str] = []
    if not isinstance(value, dict):
        return None, [f"{label} must be an object"]
    decision = str(value.get("decision", ""))
    operation = str(value.get("output_operation", ""))
    disposition = str(value.get("prelock_disposition", ""))
    if decision not in SURFACE_MODES:
        errors.append(f"{label}.decision has invalid value {decision!r}")
    if operation not in OUTPUT_OPERATIONS:
        errors.append(f"{label}.output_operation has invalid value {operation!r}")
    if disposition not in PRELOCK_DISPOSITIONS:
        errors.append(f"{label}.prelock_disposition has invalid value {disposition!r}")

    prelocked = str(atom.get("p02_surface_mode", atom.get("surface_mode", ""))) == "BYTE_EXACT"
    expected = {
        (True, "BYTE_EXACT"): "CONFIRMED_PRELOCK",
        (True, "CONTENT_PRESERVE"): "DOWNGRADED_FALSE_POSITIVE",
        (False, "BYTE_EXACT"): "ADDED_BY_P04",
        (False, "CONTENT_PRESERVE"): "NO_PRELOCK",
    }.get((prelocked, decision))
    if expected and disposition != expected:
        errors.append(
            f"{label}.prelock_disposition must be {expected} for the P02 prelock/final decision"
        )

    basis = value.get("basis")
    if not isinstance(basis, list) or not basis:
        errors.append(f"{label}.basis must be a nonempty list")
        basis = []
    else:
        invalid = sorted({str(item) for item in basis} - SURFACE_DECISION_BASES)
        if invalid:
            errors.append(f"{label}.basis has invalid values: {', '.join(invalid)}")
    cues = value.get("source_cues")
    if not isinstance(cues, list):
        errors.append(f"{label}.source_cues must be a list")
        cues = []
    excerpt = str(atom.get("raw_excerpt", ""))
    for cue in cues:
        if not isinstance(cue, str) or not cue or cue not in excerpt:
            errors.append(f"{label}.source_cues must contain exact atom substrings")
    rationale = str(value.get("rationale", "")).strip()
    if len(rationale) < 12:
        errors.append(f"{label}.rationale is too shallow")
    if value.get("confidence") not in SURFACE_CONFIDENCE:
        errors.append(f"{label}.confidence is invalid")

    allowed = str(value.get("allowed_completion", "")).strip()
    forbidden = str(value.get("forbidden_change", "")).strip()
    if decision == "BYTE_EXACT":
        if operation != "COPY_SOURCE_SLICE":
            errors.append(f"{label}: BYTE_EXACT requires COPY_SOURCE_SLICE")
        if not cues:
            errors.append(f"{label}: BYTE_EXACT requires exact source_cues")
        if allowed or forbidden:
            errors.append(f"{label}: BYTE_EXACT cannot carry editable transformation fields")
    elif decision == "CONTENT_PRESERVE":
        if operation in {"COPY_SOURCE_SLICE", "BLOCKED_REVIEW"}:
            errors.append(f"{label}: reviewed CONTENT_PRESERVE requires an editable operation")
        if len(allowed) < 4 or len(forbidden) < 4:
            errors.append(
                f"{label}: CONTENT_PRESERVE requires specific allowed_completion and forbidden_change"
            )
    return dict(value), errors


def atom_function_contracts(
    blueprint: dict[str, Any],
    atoms: list[dict[str, Any]],
    *,
    require_function_matrix: bool = False,
) -> tuple[dict[str, dict[str, Any]], list[str]]:
    """Validate P04 contracts for every source Atom.

    The default keeps the small, public helper backwards-compatible for old
    unit fixtures.  All production publication/materialization validators pass
    ``require_function_matrix=True``; those paths reject a contract that does
    not explicitly account for every content-function dimension.
    """
    errors: list[str] = []
    atom_by_id = {str(row.get("atom_id", "")): row for row in atoms}
    rows = blueprint.get("atom_function_contracts")
    if not isinstance(rows, list):
        return {}, ["publication blueprint atom_function_contracts must be a list"]
    contracts: dict[str, dict[str, Any]] = {}
    for index, row in enumerate(rows, 1):
        if not isinstance(row, dict):
            errors.append(f"atom_function_contracts row {index} is not an object")
            continue
        atom_id = str(row.get("atom_id", ""))
        atom = atom_by_id.get(atom_id)
        if atom is None:
            errors.append(f"atom_function_contracts row {index} cites unknown atom {atom_id!r}")
            continue
        if atom_id in contracts:
            errors.append(f"duplicate atom function contract: {atom_id}")
            continue
        if row.get("resegmentation_inherited") is True:
            errors.append(
                f"{atom_id}: resegmented Atom contract is inherited and requires an explicit P04 semantic review"
            )
        try:
            required = normalize_functions(row.get("required_functions"), f"{atom_id}.required_functions")
            floor = normalize_functions(atom.get("required_functions"), f"{atom_id}.atom_required_functions")
        except ValueError as exc:
            errors.append(str(exc))
            continue
        missing_floor = sorted(set(floor) - set(required))
        if missing_floor:
            errors.append(
                f"{atom_id}: semantic contract dropped source-model functions: {', '.join(missing_floor)}"
            )
        matrix, matrix_errors = normalize_function_matrix(
            row.get(FUNCTION_MATRIX_KEY),
            f"{atom_id}.{FUNCTION_MATRIX_KEY}",
            source_excerpt=str(atom.get("raw_excerpt", "")),
            required_functions=required,
            require_matrix=require_function_matrix,
        )
        errors.extend(matrix_errors)
        evidence = str(row.get("source_evidence", ""))
        atom_excerpt = str(atom.get("raw_excerpt", ""))
        if evidence != atom_excerpt:
            errors.append(
                f"{atom_id}: contract source_evidence must equal the complete exact Atom slice"
            )
        reason = str(row.get("reason", "")).strip()
        if len(reason) < 12:
            errors.append(f"{atom_id}: function contract reason is too shallow")
        content_type = str(row.get("content_type", ""))
        if content_type not in CONTENT_TYPES:
            errors.append(f"{atom_id}: P04 content_type is invalid: {content_type!r}")
        local_role = str(row.get("local_context_role", "")).strip()
        global_role = str(row.get("global_context_role", "")).strip()
        if len(local_role) < 4:
            errors.append(f"{atom_id}: P04 local_context_role is too shallow")
        if len(global_role) < 4:
            errors.append(f"{atom_id}: P04 global_context_role is too shallow")
        invariant = row.get("content_invariant")
        if not isinstance(invariant, dict):
            errors.append(f"{atom_id}: P04 content_invariant must be an object")
            invariant = {}
        if len(str(invariant.get("summary", "")).strip()) < 2:
            errors.append(f"{atom_id}: P04 content_invariant.summary is too shallow")
        surface_contract, surface_errors = _normalize_surface_contract(
            row.get("surface_contract"), atom, f"{atom_id}.surface_contract"
        )
        errors.extend(surface_errors)
        normalized = dict(row)
        normalized["required_functions"] = required
        normalized["content_type"] = content_type
        normalized["local_context_role"] = local_role
        normalized["global_context_role"] = global_role
        normalized["content_invariant"] = dict(invariant)
        normalized["surface_contract"] = surface_contract or {}
        if matrix:
            normalized[FUNCTION_MATRIX_KEY] = matrix
        contracts[atom_id] = normalized
    missing_atoms = sorted(set(atom_by_id) - set(contracts))
    if missing_atoms:
        errors.append(
            "atom function contracts do not cover every source atom: "
            + ", ".join(missing_atoms[:12])
        )
    return contracts, errors


def function_realization_obligations(
    root: Path,
) -> tuple[dict[tuple[str, str], dict[str, Any]], list[str]]:
    """Load the P05 plan as the bridge from Atom semantics to prose work."""
    path = root / "section_execution_plan.jsonl"
    if not path.is_file():
        return {}, ["missing section_execution_plan.jsonl"]
    errors: list[str] = []
    obligations: dict[tuple[str, str], dict[str, Any]] = {}
    try:
        plan_rows = load_jsonl_objects(path)
    except Exception as exc:
        return {}, [f"failed to load section execution plan: {exc}"]
    for row_index, row in enumerate(plan_rows, 1):
        plan_id = str(row.get("plan_id", f"<row:{row_index}>"))
        section_id = str(row.get("section_id", ""))
        try:
            realizations = parse_json_field(
                row.get("function_realization_plan_json"),
                f"{plan_id}.function_realization_plan_json",
                list,
            )
        except Exception as exc:
            errors.append(str(exc))
            continue
        for item_index, item in enumerate(realizations, 1):
            if not isinstance(item, dict):
                errors.append(f"{plan_id}.realization[{item_index}] must be an object")
                continue
            atom_id = str(item.get("atom_id", ""))
            function = str(item.get("function", ""))
            key = (atom_id, function)
            if key in obligations:
                errors.append(f"duplicate P05 realization obligation for {atom_id}/{function}")
                continue
            obligation = dict(item)
            obligation["_plan_id"] = plan_id
            obligation["_section_id"] = section_id
            obligations[key] = obligation
    return obligations, errors


def stage_function_reviews(
    root: Path,
    blueprint: dict[str, Any],
    atoms: list[dict[str, Any]],
    stage_id: str,
    target_file: str,
    *,
    require_all_atoms: bool,
    require_function_matrix: bool = False,
) -> tuple[dict[str, dict[str, Any]], list[str]]:
    """Validate one semantic phase's atom/function evidence.

    The function checks identity, hashes, exact evidence membership and complete
    function accounting.  It deliberately does not pretend to prove semantic
    equivalence; that verdict belongs to the phase-local Codex reviewer.
    """
    errors: list[str] = []
    target_path = root / target_file
    if not target_path.is_file():
        return {}, [f"{stage_id}: missing target file {target_file}"]
    target_text = target_path.read_text(encoding="utf-8", errors="strict")
    target_sha = sha256_file(target_path)
    target_units = split_output_units(target_text)
    units_by_text: dict[str, list[Any]] = {}
    for unit in target_units:
        units_by_text.setdefault(unit.text, []).append(unit)
    contracts, contract_errors = atom_function_contracts(
        blueprint,
        atoms,
        require_function_matrix=require_function_matrix,
    )
    errors.extend(contract_errors)
    if contract_errors:
        return {}, errors
    obligations, obligation_errors = function_realization_obligations(root)
    errors.extend(obligation_errors)
    if obligation_errors:
        return {}, errors
    from source_obligations import (
        normalize_obligation_ids,
        obligation_ids_by_pair,
        source_obligation_contracts,
    )

    source_obligations, source_obligation_errors = source_obligation_contracts(
        root, blueprint, atoms, require_ledgers=False
    )
    errors.extend(source_obligation_errors)
    if source_obligation_errors:
        return {}, errors
    obligation_ids_for_pair = obligation_ids_by_pair(source_obligations)

    raw_rows = blueprint.get("function_preservation_reviews")
    if not isinstance(raw_rows, list):
        return {}, ["publication blueprint function_preservation_reviews must be a list"]
    rows = [row for row in raw_rows if isinstance(row, dict) and row.get("stage_id") == stage_id]
    reviews: dict[str, dict[str, Any]] = {}
    evidence_spans: list[tuple[int, int, str, str, str]] = []
    for index, row in enumerate(rows, 1):
        atom_id = str(row.get("atom_id", ""))
        contract = contracts.get(atom_id)
        if contract is None:
            errors.append(f"{stage_id} review row {index} cites unknown atom {atom_id!r}")
            continue
        if atom_id in reviews:
            errors.append(f"{stage_id}: duplicate function review for {atom_id}")
            continue
        if str(row.get("target_file", "")) != target_file:
            errors.append(f"{stage_id}:{atom_id}: target_file must be {target_file}")
        if str(row.get("target_sha256", "")) != target_sha:
            errors.append(f"{stage_id}:{atom_id}: target hash is stale")
        if str(row.get("verdict", "")) != "PASS":
            errors.append(f"{stage_id}:{atom_id}: overall verdict is not PASS")
        function_results = row.get("function_results")
        if not isinstance(function_results, dict):
            errors.append(f"{stage_id}:{atom_id}: function_results must be an object")
            continue
        required = list(contract["required_functions"])
        actual = set(str(key) for key in function_results)
        missing = sorted(set(required) - actual)
        extra = sorted(actual - set(required))
        if missing:
            errors.append(
                f"{stage_id}:{atom_id}: functions not consumed: {', '.join(missing)}"
            )
        if extra:
            errors.append(
                f"{stage_id}:{atom_id}: undeclared function results: {', '.join(extra)}"
            )
        atom = next(item for item in atoms if str(item.get("atom_id")) == atom_id)
        raw_excerpt = str(atom.get("raw_excerpt", ""))
        for function in required:
            result = function_results.get(function)
            if not isinstance(result, dict):
                continue
            obligation = obligations.get((atom_id, function))
            if obligation is None:
                errors.append(
                    f"{stage_id}:{atom_id}:{function}: missing P05 realization obligation"
                )
                continue
            realization_id = str(result.get("realization_id", ""))
            expected_realization_id = str(obligation.get("realization_id", ""))
            if realization_id != expected_realization_id:
                errors.append(
                    f"{stage_id}:{atom_id}:{function}: realization_id must be "
                    f"{expected_realization_id}"
                )
            try:
                declared_obligation_ids = set(
                    normalize_obligation_ids(result.get("source_obligation_ids"))
                )
            except ValueError as exc:
                errors.append(f"{stage_id}:{atom_id}:{function}: {exc}")
                declared_obligation_ids = set()
            expected_obligation_ids = set(
                obligation_ids_for_pair.get((atom_id, function), [])
            )
            if declared_obligation_ids != expected_obligation_ids:
                errors.append(
                    f"{stage_id}:{atom_id}:{function}: source_obligation_ids must equal "
                    f"the P04 bindings {sorted(expected_obligation_ids)}"
                )
            obligation_results = result.get("source_obligation_results", {})
            if not isinstance(obligation_results, dict):
                errors.append(
                    f"{stage_id}:{atom_id}:{function}: source_obligation_results must be an object"
                )
                obligation_results = {}
            actual_obligation_result_ids = set(
                str(item) for item in obligation_results
            )
            if actual_obligation_result_ids != expected_obligation_ids:
                errors.append(
                    f"{stage_id}:{atom_id}:{function}: source_obligation_results must "
                    f"cover exactly {sorted(expected_obligation_ids)}"
                )
            status = str(result.get("status", ""))
            if status not in PASS_FUNCTION_STATUSES:
                errors.append(
                    f"{stage_id}:{atom_id}:{function}: status {status!r} is not publishable"
                )
            source_evidence = str(result.get("source_evidence", "")).strip()
            planned_source_evidence = str(obligation.get("source_evidence", "")).strip()
            raw_target_evidence = result.get("target_evidence", "")
            if isinstance(raw_target_evidence, list):
                target_evidence_items = [
                    str(item).strip() for item in raw_target_evidence if str(item).strip()
                ]
            else:
                target_evidence_items = [str(raw_target_evidence).strip()]
            if not source_evidence or source_evidence not in raw_excerpt:
                errors.append(
                    f"{stage_id}:{atom_id}:{function}: source evidence is not inside the exact atom"
                )
            elif source_evidence != planned_source_evidence:
                errors.append(
                    f"{stage_id}:{atom_id}:{function}: source evidence differs from the P05 obligation"
                )
            if not target_evidence_items or not all(target_evidence_items):
                errors.append(
                    f"{stage_id}:{atom_id}:{function}: target evidence is empty"
                )
            else:
                group_id = str(obligation.get("realization_group_id", ""))
                for item in target_evidence_items:
                    matches = units_by_text.get(item, [])
                    if len(matches) != 1:
                        errors.append(
                            f"{stage_id}:{atom_id}:{function}: target evidence must equal one unique complete output unit"
                        )
                        continue
                    if matches[0].unit_type == "heading":
                        errors.append(
                            f"{stage_id}:{atom_id}:{function}: a heading alone cannot realize a content function"
                        )
                        continue
                    start = target_text.index(item)
                    evidence_spans.append(
                        (start, start + len(item), atom_id, function, group_id)
                    )
            for obligation_id in sorted(expected_obligation_ids):
                obligation_result = obligation_results.get(obligation_id)
                if not isinstance(obligation_result, dict):
                    continue
                source_contract = source_obligations[obligation_id]
                if str(obligation_result.get("status", "")) not in PASS_FUNCTION_STATUSES:
                    errors.append(
                        f"{stage_id}:{atom_id}:{function}:{obligation_id}: status is not publishable"
                    )
                if (
                    str(obligation_result.get("obligation_identity_sha256", ""))
                    != str(source_contract.get("obligation_identity_sha256", ""))
                ):
                    errors.append(
                        f"{stage_id}:{atom_id}:{function}:{obligation_id}: obligation identity hash is stale"
                    )
                if (
                    str(obligation_result.get("fulfillment_mode", ""))
                    != str(source_contract.get("fulfillment_mode", ""))
                ):
                    errors.append(
                        f"{stage_id}:{atom_id}:{function}:{obligation_id}: fulfillment_mode differs from P04"
                    )
                if (
                    str(obligation_result.get("source_evidence", ""))
                    != str(source_contract.get("source_evidence", ""))
                ):
                    errors.append(
                        f"{stage_id}:{atom_id}:{function}:{obligation_id}: source evidence differs from the complete P03 obligation span"
                    )
                raw_obligation_target = obligation_result.get("target_evidence", "")
                obligation_target_items = (
                    raw_obligation_target
                    if isinstance(raw_obligation_target, list)
                    else [raw_obligation_target]
                )
                obligation_target_items = [
                    str(item).strip()
                    for item in obligation_target_items
                    if str(item).strip()
                ]
                if not obligation_target_items:
                    errors.append(
                        f"{stage_id}:{atom_id}:{function}:{obligation_id}: target evidence is empty"
                    )
                elif not set(obligation_target_items).issubset(set(target_evidence_items)):
                    errors.append(
                        f"{stage_id}:{atom_id}:{function}:{obligation_id}: target evidence must be part of this Atom/function realization"
                    )
                obligation_reason = str(obligation_result.get("reason", "")).strip()
                if len(obligation_reason) < 16:
                    errors.append(
                        f"{stage_id}:{atom_id}:{function}:{obligation_id}: semantic reason is too shallow"
                    )
            reason = str(result.get("reason", "")).strip()
            if len(reason) < 12:
                errors.append(
                    f"{stage_id}:{atom_id}:{function}: semantic reason is too shallow"
                )
        reviews[atom_id] = row

    evidence_spans.sort()
    for index, left in enumerate(evidence_spans):
        left_start, left_end, left_atom, left_function, left_group = left
        for right in evidence_spans[index + 1 :]:
            right_start, right_end, right_atom, right_function, right_group = right
            if right_start >= left_end:
                break
            if (left_atom, left_function) == (right_atom, right_function):
                continue
            if left_group != right_group or left_atom != right_atom:
                errors.append(
                    f"{stage_id}: overlapping target evidence reuses one passage for unmerged "
                    f"responsibilities {left_atom}/{left_function} and {right_atom}/{right_function}"
                )

    required_atom_ids = {
        atom_id
        for atom_id, contract in contracts.items()
        if require_all_atoms
        or bool(set(contract["required_functions"]) & SENSITIVE_FUNCTIONS)
    }
    missing_reviews = sorted(required_atom_ids - set(reviews))
    if missing_reviews:
        errors.append(
            f"{stage_id}: missing atom/function reviews: " + ", ".join(missing_reviews[:12])
        )
    return reviews, errors


def review_target_evidence(review: dict[str, Any]) -> list[str]:
    results = review.get("function_results", {})
    if not isinstance(results, dict):
        return []
    evidence: list[str] = []
    for value in results.values():
        if isinstance(value, dict):
            raw = value.get("target_evidence", "")
            items = raw if isinstance(raw, list) else [raw]
            for item in items:
                text = str(item).strip()
                if text and text not in evidence:
                    evidence.append(text)
    return evidence


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        value = json.loads(line)
        if not isinstance(value, dict):
            raise ValueError(f"{path.name}:{line_no} must contain a JSON object")
        rows.append(value)
    return rows
