#!/usr/bin/env python3
"""Validate source-safe headings for WeChat/publication articles."""
from pathlib import Path
import re
import sys

FLOW_TERMS = [
    "先说", "先把", "先来", "先看", "然后", "接下来", "最后", "再说", "这里先",
    "先别", "先记", "先写", "先给", "一波", "收尾", "说完", "看一下", "也可以这么看",
]
MARKETING_TERMS = [
    "偷偷", "真正", "核心", "底层逻辑", "完整闭环", "系统梳理", "全面解析",
]

def read(path):
    return Path(path).read_text(encoding="utf-8") if path and Path(path).exists() else ""

def norm(text):
    text = re.sub(r"`([^`]+)`", r"\1", text)
    text = re.sub(r"^\s*\d+(?:\.\d+)*[、.．\s-]*", "", text)
    text = re.sub(r"[\s\u3000:：，,。.!！?？；;（）()《》<>【】\[\]$`*_\\-]+", "", text)
    return text.strip().lower()

def headings(md):
    for m in re.finditer(r"^(#{1,6})\s+(.+?)\s*$", md, flags=re.M):
        yield m.group(1), m.group(2).strip(), m.start()

def allowed_by_gate(text, gate):
    n = norm(text)
    for line in gate.splitlines():
        if "ALLOW_SOURCE_EXACT" in line and n and n in norm(line):
            return True
    return False

def main():
    if len(sys.argv) < 2:
        print("Usage: validate_heading_voice.py <article.md> [source.txt] [heading_voice_gate.md]")
        return 2
    article_path = Path(sys.argv[1])
    source_path = Path(sys.argv[2]) if len(sys.argv) >= 3 else None
    gate_path = Path(sys.argv[3]) if len(sys.argv) >= 4 else None

    raw = article_path.read_text(encoding="utf-8") if article_path.exists() else ""
    source = read(source_path)
    gate = read(gate_path)
    failures = []

    if not raw.strip():
        print(f"FAILED: missing or empty {article_path}")
        return 1
    if raw.startswith("\ufeff"):
        failures.append("file starts with UTF-8 BOM; remove it before publication")
    article = raw.lstrip("\ufeff")
    hs = list(headings(article))
    if not hs:
        failures.append("no Markdown headings found")

    seen = set()
    previous = None
    for level, text, pos in hs:
        n = norm(text)
        key = (level, n)
        if key in seen:
            failures.append(f"duplicate heading: {level} {text}")
        seen.add(key)

        if "$" in text:
            failures.append(f"math delimiter in heading: {level} {text}")

        if previous:
            prev_level, prev_text, _ = previous
            pn = norm(prev_text)
            if prev_level == "##" and level == "###" and n and (n == pn or n in pn or pn in n):
                failures.append(f"adjacent H2/H3 heading repetition: {prev_level} {prev_text} -> {level} {text}")
        previous = (level, text, pos)

        for term in FLOW_TERMS:
            if term in text and not allowed_by_gate(text, gate):
                failures.append(f"process-style heading phrase: {level} {text} contains {term}")
        for term in MARKETING_TERMS:
            if term in text and term not in source and not allowed_by_gate(text, gate):
                failures.append(f"unsupported marketing/AI heading phrase: {level} {text} contains {term}")

        if gate and level in {"#", "##", "###"} and n and n not in norm(gate):
            failures.append(f"heading not audited in heading_voice_gate.md: {level} {text}")

    if failures:
        print("FAILED")
        for f in failures:
            print(f"- {f}")
        return 1
    print("OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
