#!/usr/bin/env python3
"""Validate that applied user feedback is bound to concrete trace evidence."""
from __future__ import annotations

from pathlib import Path
import json
import re
import sys


REAL_FEEDBACK_STATUSES = {"APPLIED", "CLOSED", "REJECTED"}
EVIDENCE_REQUIRED_STATUSES = {"APPLIED", "CLOSED"}
PLACEHOLDER_RE = re.compile(r"\b(TODO|TBD|pending|unknown|unclear|none)\b", re.I)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def read_jsonl(path: Path) -> tuple[list[dict], list[str]]:
    failures: list[str] = []
    rows: list[dict] = []
    if not path.exists() or not read(path).strip():
        return rows, ["missing or empty user_feedback_ledger.jsonl"]
    for n, line in enumerate(read(path).splitlines(), 1):
        if not line.strip():
            continue
        try:
            item = json.loads(line)
        except Exception as exc:
            failures.append(f"user_feedback_ledger.jsonl line {n} invalid JSON: {exc}")
            continue
        if not isinstance(item, dict):
            failures.append(f"user_feedback_ledger.jsonl line {n} is not an object")
            continue
        rows.append(item)
    return rows, failures


def evidence_paths(value: str) -> list[str]:
    paths: list[str] = []
    for part in re.split(r"[;,]\s*|\s+\+\s+", value):
        rel = part.strip().replace("\\", "/")
        if not rel or rel.lower() in {"none", "n/a", "na"}:
            continue
        rel = rel.split("#", 1)[0].split(":", 1)[0].strip()
        if rel and not rel.startswith("/") and ".." not in Path(rel).parts:
            paths.append(rel)
    return paths


def short_excerpt_tokens(text: str) -> list[str]:
    clean = re.sub(r"\s+", "", text or "")
    if not clean or clean.lower() in {"none", "n/a", "na"}:
        return []
    tokens = []
    if len(clean) >= 8:
        tokens.append(clean[:8])
    if len(clean) >= 16:
        tokens.append(clean[-8:])
    return tokens


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    root = root.resolve()
    failures: list[str] = []

    rows, errs = read_jsonl(root / "user_feedback_ledger.jsonl")
    failures.extend(errs)
    if not rows:
        failures.append("user_feedback_ledger.jsonl has no rows")

    real_rows = []
    for idx, row in enumerate(rows, 1):
        fid = str(row.get("feedback_id", "")).strip()
        status = str(row.get("status", "")).strip().upper()
        if fid == "UF0000" or status == "NO_USER_FEEDBACK":
            continue
        real_rows.append(row)
        if status not in REAL_FEEDBACK_STATUSES:
            # validate_active_state_feedback owns OPEN/ACTIVE/BLOCKED release blocking.
            continue
        for field in ["feedback_excerpt", "feedback_type", "target_scope", "correction_rule", "required_action", "verification_note"]:
            value = str(row.get(field, "")).strip()
            if not value or PLACEHOLDER_RE.fullmatch(value):
                failures.append(f"{fid} has unusable {field}")
        if status == "REJECTED":
            note = str(row.get("verification_note", "")).strip()
            if len(note) < 12 or PLACEHOLDER_RE.fullmatch(note):
                failures.append(f"{fid} rejected feedback requires a concrete verification_note")
            continue

        if status in EVIDENCE_REQUIRED_STATUSES:
            raw_evidence = str(row.get("evidence_trace", "")).strip()
            paths = evidence_paths(raw_evidence)
            if not paths:
                failures.append(f"{fid} applied/closed feedback missing evidence_trace file")
                continue
            found_fid = False
            found_excerpt_token = False
            for rel in paths:
                path = root / rel
                if not path.exists() or not read(path).strip():
                    failures.append(f"{fid} evidence_trace file missing or empty: {rel}")
                    continue
                text = read(path)
                if fid in text:
                    found_fid = True
                compact_text = re.sub(r"\s+", "", text)
                if any(tok and tok in compact_text for tok in short_excerpt_tokens(str(row.get("feedback_excerpt", "")))):
                    found_excerpt_token = True
            if not found_fid:
                failures.append(f"{fid} evidence_trace files do not mention the feedback_id")
            if not found_excerpt_token and str(row.get("feedback_type", "")).strip().upper() != "STRUCTURAL_CORRECTION":
                failures.append(f"{fid} evidence_trace files do not carry any recognizable feedback excerpt token")

    if not real_rows:
        print("OK: no real user feedback rows")
        return 0

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print(f"OK: feedback_rows={len(real_rows)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
