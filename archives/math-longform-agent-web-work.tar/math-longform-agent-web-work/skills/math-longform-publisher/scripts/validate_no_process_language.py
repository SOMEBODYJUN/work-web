#!/usr/bin/env python3
"""Reject workflow/process leakage in publication_final.md."""
from pathlib import Path
import re
import sys

HARD_BANNED = [
    "按照原文",
    "按原文",
    "根据用户意思",
    "处理痕迹",
    "补回来",
    "补回",
    "这段要表达",
    "标准写法",
    "几个原文",
    "补充几个细节",
    "遗漏内容补充",
    "现场口气",
    "收束",
    "收住",
    "不影响后面证明",
    "开头就当",
    "这段情绪",
    "处理成",
    "保留为",
    "处理者口吻",
    "source atom",
    "source_id",
    "ledger",
    "revision task",
    "AIGC 改稿层",
    "aigc_source_type_ledger",
    "足球情绪先放在这里",
    "情绪先放在这里",
    "先放在这里",
    "先放一边",
    "先搁一边",
]

PATCH_HEADING_RE = re.compile(
    r"^#{1,6}\s+.*(?:补充|补丁|原文|修订|遗漏|AIGC|处理说明).*$",
    flags=re.M,
)

SOURCE_ALLOWED = [
    "不能省",
    "后面再说",
    "这个地方要注意",
]

FAKE_COLLOQUIAL = [
    "别急",
    "说白了",
    "看见没",
    "这一步别跳",
    "交给它接住",
    "落地了",
    "别把它看神秘了",
    "不是硬塞进来的",
]

EDITORIAL_BRIDGE_PATTERNS = [
    (re.compile(r"(?:足球)?情绪.{0,8}(?:先)?放(?:在)?这[里儿]"), "情绪先放在这里 family"),
    (re.compile(r"(?:情绪|话题|足球).{0,8}先(?:放|搁).{0,6}(?:一边|这[里儿])"), "话题/情绪先放一边 family"),
]


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    final_path = root / "publication_final.md"
    source_path = root / "source.txt"
    if not final_path.exists():
        print("FAILED: missing publication_final.md")
        return 1

    final = read(final_path)
    source = read(source_path)
    failures = []

    for phrase in HARD_BANNED:
        if phrase in final:
            failures.append(f"hard banned process phrase: {phrase}")

    for phrase in SOURCE_ALLOWED + FAKE_COLLOQUIAL:
        if phrase in final and phrase not in source:
            failures.append(f"phrase lacks source support: {phrase}")

    for pattern, label in EDITORIAL_BRIDGE_PATTERNS:
        if pattern.search(final):
            failures.append(f"editorial bridge/process phrase pattern: {label}")

    patch_headings = PATCH_HEADING_RE.findall(final)
    for heading in patch_headings:
        failures.append(f"patch/process heading found: {heading.strip()}")

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1

    print("OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
