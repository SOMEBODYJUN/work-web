#!/usr/bin/env python3
"""Validate immutable original TXT, current canonical TXT, mirrors, and source spans."""
from __future__ import annotations

from pathlib import Path
import hashlib
import re
import sys

from safe_io import read_bytes_strict, read_json_strict, read_jsonl_strict
from structured_ledger import load_ledger

SPAN_RE = re.compile(r"^\s*(\d+)\s*-\s*(\d+)\s*$")
SPAN_EXCEPTION_VALUES = {"APPROVED_SOURCE_DAMAGE", "APPROVED_OCR_RECONSTRUCTION"}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def parse_span(value: str) -> tuple[int, int] | None:
    match = SPAN_RE.fullmatch(str(value).replace(":", "-"))
    return (int(match.group(1)), int(match.group(2))) if match else None


def slice_by_unit(source_text: str, source_bytes: bytes, start: int, end: int, unit: str) -> str:
    if unit == "utf8_byte_offset":
        if not (0 <= start <= end <= len(source_bytes)):
            raise ValueError(f"span {start}-{end} outside canonical byte length {len(source_bytes)}")
        try:
            return source_bytes[start:end].decode("utf-8", errors="strict")
        except UnicodeDecodeError as exc:
            raise ValueError(f"span {start}-{end} splits a UTF-8 code point") from exc
    if unit == "unicode_codepoint":
        if not (0 <= start <= end <= len(source_text)):
            raise ValueError(f"span {start}-{end} outside canonical codepoint length {len(source_text)}")
        return source_text[start:end]
    raise ValueError(f"unsupported span_unit: {unit!r}")


def explicit_exception(row: dict[str, str]) -> bool:
    status = str(row.get("span_exception_status", "")).strip().upper()
    evidence = str(row.get("span_exception_evidence", "")).strip()
    return status in SPAN_EXCEPTION_VALUES and bool(evidence and evidence.lower() not in {"none", "n/a"})


def check_span_rows(name: str, path: Path, source_text: str, source_bytes: bytes, unit: str, failures: list[str]) -> None:
    kind, _header, rows, ledger_failures = load_ledger(path)
    if kind == "missing":
        failures.append(f"{name}: authoritative JSONL/Markdown ledger is missing")
        return
    failures.extend(ledger_failures)
    for idx, row in enumerate(rows, start=1):
        row_id = row.get("atom_id") or row.get("sentence_id") or row.get("chunk_id") or f"row{idx}"
        span_value = row.get("byte_span") or row.get("char_span") or row.get("canonical_span") or ""
        if not span_value and row.get("start_byte") and row.get("end_byte"):
            span_value = f"{row['start_byte']}-{row['end_byte']}"
        if not span_value:
            failures.append(f"{name} {row_id}: missing authoritative source span")
            continue
        span = parse_span(span_value)
        if span is None:
            failures.append(f"{name} {row_id}: invalid source span {span_value!r}")
            continue
        try:
            actual = slice_by_unit(source_text, source_bytes, span[0], span[1], unit)
        except ValueError as exc:
            failures.append(f"{name} {row_id}: {exc}")
            continue
        excerpt = row.get("source_excerpt") or row.get("exact_sentence_or_line") or ""
        if excerpt and excerpt != actual and not explicit_exception(row):
            failures.append(f"{name} {row_id}: excerpt does not exactly equal source_canonical.txt span")


def main() -> int:
    root = (Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")).resolve()
    failures: list[str] = []

    original_path = root / "source_original.txt"
    canonical_path = root / "source_canonical.txt"
    mirrors = [root / "canonical_source.txt", root / "source.txt"]
    identity_path = root / "source_identity.json"
    map_path = root / "source_normalization_map.jsonl"

    try:
        original_bytes = read_bytes_strict(original_path, root=root)
        original_bytes.decode("utf-8", errors="strict")
    except Exception as exc:
        failures.append(f"source_original.txt is missing, unsafe, or invalid UTF-8: {exc}")
        original_bytes = b""

    try:
        canonical_bytes = read_bytes_strict(canonical_path, root=root)
        canonical = canonical_bytes.decode("utf-8", errors="strict")
    except Exception as exc:
        failures.append(f"source_canonical.txt is missing, unsafe, or invalid UTF-8: {exc}")
        canonical_bytes, canonical = b"", ""

    for mirror in mirrors:
        try:
            mirror_bytes = read_bytes_strict(mirror, root=root)
            if canonical_bytes and mirror_bytes != canonical_bytes:
                failures.append(f"{mirror.name} must be byte-for-byte identical to source_canonical.txt")
        except Exception as exc:
            failures.append(f"{mirror.name} is missing or unsafe: {exc}")

    try:
        identity = read_json_strict(identity_path, root=root)
        if not isinstance(identity, dict):
            raise ValueError("expected JSON object")
    except Exception as exc:
        failures.append(f"source_identity.json invalid: {exc}")
        identity = {}

    try:
        map_rows = read_jsonl_strict(map_path, root=root)
    except Exception as exc:
        failures.append(f"source_normalization_map.jsonl invalid: {exc}")
        map_rows = []

    if identity:
        if identity.get("schema_version") != "source-identity-v3":
            failures.append("source_identity schema_version must be source-identity-v3")
        if identity.get("original_file") != "source_original.txt":
            failures.append("source_identity original_file must be source_original.txt")
        if identity.get("canonical_file") != "source_canonical.txt":
            failures.append("source_identity canonical_file must be source_canonical.txt")
        if identity.get("original_sha256") != sha256_bytes(original_bytes):
            failures.append("source_identity original_sha256 mismatch")
        if identity.get("canonical_sha256") != sha256_bytes(canonical_bytes):
            failures.append("source_identity canonical_sha256 mismatch")
        if identity.get("original_length_bytes") != len(original_bytes):
            failures.append("source_identity original_length_bytes mismatch")
        if identity.get("canonical_length_bytes") != len(canonical_bytes):
            failures.append("source_identity canonical_length_bytes mismatch")
        if identity.get("canonical_length_codepoints") != len(canonical):
            failures.append("source_identity canonical_length_codepoints mismatch")
        if identity.get("span_unit") != "utf8_byte_offset":
            failures.append("source_identity span_unit must be utf8_byte_offset")
        if identity.get("canonical_transformation") == "IDENTITY" and original_bytes != canonical_bytes:
            failures.append("IDENTITY requires source_original.txt and source_canonical.txt to be identical")

    for idx, row in enumerate(map_rows, start=1):
        required = {"map_id", "operation"}
        missing = sorted(required - set(row))
        if missing:
            failures.append(f"source_normalization_map row {idx} missing: {', '.join(missing)}")
        operation = str(row.get("operation", "")).lower()
        if "nfkc" in operation or "nfkd" in operation:
            failures.append("Unicode compatibility normalization is forbidden")

    if canonical_bytes:
        for rel in ["source_chunk_index.md", "source_sentence_index.md", "source_atom_ledger.md"]:
            check_span_rows(rel, root / rel, canonical, canonical_bytes, "utf8_byte_offset", failures)
        chunk_dir = root / "chunk_ledger"
        if chunk_dir.exists():
            for path in sorted(chunk_dir.glob("*atom_ledger.md")):
                check_span_rows(path.relative_to(root).as_posix(), path, canonical, canonical_bytes, "utf8_byte_offset", failures)

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print("OK")
    print(
        f"original_sha256={sha256_bytes(original_bytes)} "
        f"canonical_sha256={sha256_bytes(canonical_bytes)} "
        f"identity={original_bytes == canonical_bytes}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
