#!/usr/bin/env python3
"""Shared in-process validator execution utilities."""
from __future__ import annotations

from contextlib import redirect_stderr, redirect_stdout
from io import StringIO
from pathlib import Path
import runpy
import sys
import time
import traceback

from pipeline_registry import ValidatorSpec


MODE_AWARE_SCRIPTS = {
    "validate_required_files.py",
    "validate_structured_ledgers.py",
    "validate_active_state_feedback.py",
}


def resolve_arg(arg: str, root: Path) -> str:
    return arg.replace("{root}", str(root))


def argv_for_spec(spec: ValidatorSpec, root: Path, mode: str) -> list[str]:
    args = [resolve_arg(arg, root) for arg in spec.args]
    if spec.pass_mode or spec.script in MODE_AWARE_SCRIPTS:
        return ["--mode", mode, *args]
    return args


OUTPUT_DIR_TOKEN = "<output_dir>"


def portable_arg(arg: str, root: Path) -> str:
    """Encode paths inside a run directory without binding evidence to one machine."""
    if arg == OUTPUT_DIR_TOKEN or arg.startswith(OUTPUT_DIR_TOKEN + "/"):
        return arg
    path = Path(arg)
    if not path.is_absolute():
        return arg
    try:
        relative = path.resolve().relative_to(root.resolve())
    except ValueError:
        return arg
    return OUTPUT_DIR_TOKEN if relative == Path(".") else f"{OUTPUT_DIR_TOKEN}/{relative.as_posix()}"


def portable_args(args: list[str], root: Path) -> list[str]:
    return [portable_arg(arg, root) for arg in args]


def normalize_recorded_args(
    args: list[str],
    current_root: Path,
    recorded_target_dir: str | None = None,
) -> list[str]:
    """Normalize current portable evidence and legacy absolute-path evidence."""
    legacy_root: Path | None = None
    if recorded_target_dir:
        candidate = Path(recorded_target_dir)
        if candidate.is_absolute():
            legacy_root = candidate.resolve()
    normalized: list[str] = []
    for arg in args:
        if arg == OUTPUT_DIR_TOKEN or arg.startswith(OUTPUT_DIR_TOKEN + "/"):
            normalized.append(arg)
            continue
        path = Path(arg)
        if path.is_absolute():
            mapped = None
            for base in (legacy_root, current_root.resolve()):
                if base is None:
                    continue
                try:
                    relative = path.resolve().relative_to(base)
                except ValueError:
                    continue
                mapped = OUTPUT_DIR_TOKEN if relative == Path(".") else f"{OUTPUT_DIR_TOKEN}/{relative.as_posix()}"
                break
            normalized.append(mapped if mapped is not None else arg)
        else:
            normalized.append(arg)
    return normalized


def run_script(script: Path, args: list[str]) -> tuple[int, str, str, int]:
    """Execute one Python validator and restore interpreter state."""
    start = time.perf_counter()
    out = StringIO()
    err = StringIO()
    old_argv = sys.argv[:]
    code = 0
    try:
        sys.argv = [str(script), *args]
        with redirect_stdout(out), redirect_stderr(err):
            try:
                runpy.run_path(str(script), run_name="__main__")
            except SystemExit as exc:
                if exc.code is None:
                    code = 0
                elif isinstance(exc.code, int):
                    code = exc.code
                else:
                    code = 1
                    print(str(exc.code), file=sys.stderr)
            except FileNotFoundError as exc:
                code = 1
                print(f"FAILED: missing file: {exc}", file=sys.stderr)
            except Exception:
                code = 1
                traceback.print_exc(file=sys.stderr)
    finally:
        sys.argv = old_argv
    duration_ms = int((time.perf_counter() - start) * 1000)
    return code, out.getvalue(), err.getvalue(), duration_ms
