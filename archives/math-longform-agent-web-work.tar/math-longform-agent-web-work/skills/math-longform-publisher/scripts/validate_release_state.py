#!/usr/bin/env python3
"""Reduce all authoritative local states to one fail-closed release decision."""
from __future__ import annotations

from pathlib import Path
import re
import sys
from typing import Any

from safe_io import read_json_strict, read_jsonl_strict, read_optional_text
from structured_ledger import md_table_rows

PASS_VALUES = {
    "PASS", "PASSED", "OK", "READY", "VERIFIED", "COMPLETE", "COMPLETED",
    "SATISFIED", "RESOLVED", "ANSWERED", "APPLIED", "REVIEWED", "SUPPORTED",
    "DERIVED_SUPPORTED", "VOICE_SUPPORTED", "METHOD_SUPPORTED", "INSIGHT_SUPPORTED",
    "ROUTE_SUPPORTED", "FORMULA_SUPPORTED", "EXACT_SURFACE_SUPPORTED", "FORMAT_ONLY",
    "NO_USER_FEEDBACK", "NO_AUTHOR_QUESTIONS", "NO_FRAGMENTED_FORMULA_BLOCKS",
    "NO_EXTERNAL_DEPENDENCY", "NONE_FOUND", "QUARANTINED", "LOCKED", "PUBLISHABLE",
    "CANONICALIZED", "RESOLVED_IN_ARTICLE", "ANSWERED_IN_EXPLANATION", "PRESERVED_AS_AUTHOR_QUESTION",
    "MATH_SEMANTIC_SCAN_COMPLETE", "NO_MATHEMATICAL_RISKS",
    "RESOLVED_WITH_JUSTIFICATION", "CONSUMED",
}
BLOCK_VALUES = {
    "BLOCK", "BLOCKED", "FAIL", "FAILED", "ERROR", "PENDING", "UNRESOLVED",
    "NEEDS_HUMAN", "UNSAFE", "REJECT", "REJECTED", "MISSING", "INVALID",
    "CONFLICT", "IGNORED", "NOT_RUN", "TODO", "TBD", "PREVIEW_ONLY",
    "C_UNSAFE", "PARTIAL", "OPEN", "ACTIVE",
}
BLOCK_PREFIXES = ("BLOCKED_", "FAILED_", "ERROR_", "PENDING_", "UNRESOLVED_", "NEEDS_HUMAN_")

JSONL_STATUS_FIELDS: dict[str, tuple[str, set[str] | None]] = {
    "user_feedback_ledger.jsonl": ("status", {"NO_USER_FEEDBACK", "APPLIED", "VERIFIED", "RESOLVED"}),
    "source_formula_block_ledger.jsonl": ("canonicalization_status", None),
    "author_question_obligation_ledger.jsonl": ("resolution_status", {"NO_AUTHOR_QUESTIONS", "SEMANTIC_SCAN_COMPLETE", "DISMISSED_NOT_AN_OBLIGATION", "ANSWERED_IN_EXPLANATION", "RESOLVED_IN_ARTICLE", "PRESERVED_AS_AUTHOR_QUESTION"}),
    "source_math_risk_ledger.jsonl": ("resolution_status", {"MATH_SEMANTIC_SCAN_COMPLETE", "NO_MATHEMATICAL_RISKS", "RESOLVED_WITH_JUSTIFICATION"}),
    "final_claim_ledger.jsonl": ("verdict", None),
    "publication_claim_ledger.jsonl": ("verdict", None),
    "publication_sentence_trace.jsonl": ("verdict", None),
    "cross_chunk_dependency_map.jsonl": ("status", {"VERIFIED", "NO_EXTERNAL_DEPENDENCY"}),
    "section_context_prefetch_plan.jsonl": ("status", {"READY", "VERIFIED", "NO_EXTERNAL_DEPENDENCY"}),
}

MARKDOWN_STATUS_FILES = [
    "math_statement_ledger.md", "proof_obligations.md", "ledger_integrity_check.md",
    "statement_completeness_check.md", "integration_report.md", "clean_final_gate.md",
    "formula_compatibility_report.md", "coverage_check.md", "attack_report.md",
    "regression_check.md", "post_aigc_regression_check.md", "post_aigc_trace_check.md",
    "post_aigc_formula_check.md", "post_aigc_clean_gate.md", "security_boundary_report.md",
    "failure_recovery_log.md", "heading_voice_gate.md", "independent_review.md",
]


def normalized(value: Any) -> str:
    return str(value).strip().upper().replace(" ", "_")


def is_blocking(value: Any) -> bool:
    token = normalized(value)
    return bool(token) and (token in BLOCK_VALUES or token.startswith(BLOCK_PREFIXES))


def check_jsonl(root: Path, rel: str, field: str, allowed: set[str] | None, failures: list[str]) -> None:
    path = root / rel
    try:
        rows = read_jsonl_strict(path, root=root)
    except Exception as exc:
        failures.append(f"{rel}: {exc}")
        return
    for idx, row in enumerate(rows, start=1):
        if field not in row:
            failures.append(f"{rel} row {idx}: missing release field {field}")
            continue
        token = normalized(row[field])
        if is_blocking(token):
            failures.append(f"{rel} row {idx}: blocking {field}={token}")
        elif allowed is not None and token not in allowed:
            failures.append(f"{rel} row {idx}: unrecognized/non-release {field}={token!r}")
        elif allowed is None and token not in PASS_VALUES and not token.startswith(("SUPPORTED", "DERIVED_", "VOICE_", "METHOD_", "INSIGHT_", "ROUTE_", "FORMULA_", "EXACT_", "FORMAT_")):
            failures.append(f"{rel} row {idx}: non-pass {field}={token!r}")


def check_active_state(root: Path, failures: list[str]) -> None:
    try:
        state = read_json_strict(root / "active_state.json", root=root)
    except Exception as exc:
        failures.append(f"active_state.json: {exc}")
        return
    if not isinstance(state, dict):
        failures.append("active_state.json must be an object")
        return
    mode = normalized(state.get("run_mode", ""))
    if mode not in {"FULL_PUBLICATION", "WECHAT_PUBLICATION"}:
        failures.append(f"active_state run_mode cannot release: {mode!r}")
    stage = normalized(state.get("current_stage", ""))
    release_stages = {"STAGE_9_PUBLICATION_RELEASE", "STAGE_9_PUBLICATION_VALIDATION", "PUBLICATION_RELEASE", "PUBLICATION_VALIDATION", "COMPLETE", "COMPLETED"}
    if stage and stage not in release_stages:
        failures.append(f"active_state current_stage is not a release terminal: {stage}")
    ids = state.get("active_feedback_ids", [])
    if ids not in ([], None) and not isinstance(ids, list):
        failures.append("active_state active_feedback_ids must be a list")


def check_markdown_statuses(root: Path, rel: str, failures: list[str]) -> None:
    path = root / rel
    if not path.exists():
        return
    try:
        text = read_optional_text(path, root=root)
    except Exception as exc:
        failures.append(f"{rel}: {exc}")
        return
    # Explicit scalar fields such as FINAL_SECURITY_VERDICT: PASS.
    for match in re.finditer(r"(?mi)^\s*([A-Z][A-Z0-9_]*(?:STATUS|STATE|VERDICT|DECISION|RESULT))\s*:\s*(\S+)\s*$", text):
        key, value = match.group(1), normalized(match.group(2))
        if is_blocking(value):
            failures.append(f"{rel}: blocking {key}={value}")
    rows = md_table_rows(text)
    for idx, row in enumerate(rows, start=1):
        for key, value in row.items():
            key_l = key.strip().lower()
            if key_l.endswith(("status", "state", "verdict", "decision", "result")):
                token = normalized(value)
                if is_blocking(token):
                    failures.append(f"{rel} row {idx}: blocking {key}={token}")


def main() -> int:
    root = (Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")).resolve()
    failures: list[str] = []
    check_active_state(root, failures)
    for rel, (field, allowed) in JSONL_STATUS_FIELDS.items():
        check_jsonl(root, rel, field, allowed, failures)
    for rel in MARKDOWN_STATUS_FILES:
        check_markdown_statuses(root, rel, failures)

    # The audit report is the declaration surface, not an exception to blockers.
    audit = read_optional_text(root / "PUBLICATION_AUDIT_REPORT.md", root=root)
    states = re.findall(r"(?mi)^\s*FINAL_STATE\s*:\s*(\S+)\s*$", audit)
    if len(states) != 1:
        failures.append(f"PUBLICATION_AUDIT_REPORT.md must contain exactly one FINAL_STATE, found {len(states)}")
    elif normalized(states[0]) != "PUBLISHABLE":
        failures.append(f"FINAL_STATE is not PUBLISHABLE: {states[0]!r}")

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print("OK: release state reduced to PUBLISHABLE with no local blockers")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
