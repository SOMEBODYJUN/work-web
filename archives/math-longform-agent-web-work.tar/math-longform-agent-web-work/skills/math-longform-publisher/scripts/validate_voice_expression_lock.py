#!/usr/bin/env python3
"""Validate that locked author expressions are traced into post-hoc maps and publication."""
from pathlib import Path
import re
import sys

LOCK_WORDS = ("exact", "preserve", "must", "保留", "原样", "口气", "节奏")

def read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""

def ledger_rows(text: str):
    for line in text.splitlines():
        if not line.startswith("| V"):
            continue
        cells = [cell.strip() for cell in line.strip("|").split("|")]
        if len(cells) >= 8:
            yield cells

def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    ledger_path = root / "voice_expression_ledger.md"
    final_trace_path = root / "final_trace_map.md"
    pub_trace_path = root / "publication_trace_map.md"
    final_path = root / "publication_final.md"

    if not ledger_path.exists():
        print("FAILED: missing voice_expression_ledger.md")
        return 1
    if not final_trace_path.exists() and not pub_trace_path.exists():
        print("FAILED: missing final_trace_map.md/publication_trace_map.md")
        return 1

    ledger = read(ledger_path)
    trace = read(final_trace_path) + "\n" + read(pub_trace_path)
    final = read(final_path)
    failures = []
    rows = list(ledger_rows(ledger))

    if not rows:
        print("FAILED: no voice rows in voice_expression_ledger.md")
        return 1

    for cells in rows:
        voice_id = cells[0]
        source_atoms = cells[1]
        excerpt = cells[2]
        requirement = cells[4].lower() if len(cells) > 4 else ""
        final_destination = cells[7] if len(cells) > 7 else ""
        must_lock = any(word in requirement for word in LOCK_WORDS)

        if must_lock and voice_id not in trace:
            failures.append(f"{voice_id}: locked expression is not referenced in trace maps")
        if must_lock and not final_destination:
            failures.append(f"{voice_id}: locked expression has no final_destination")
        atom_ids = re.findall(r"A\d+", source_atoms)
        for atom_id in atom_ids:
            if must_lock and atom_id not in trace:
                failures.append(f"{voice_id}: source atom {atom_id} not referenced in trace maps")
        if "exact" in requirement and excerpt and final and excerpt not in final:
            failures.append(f"{voice_id}: exact-preserve excerpt not found in publication_final.md")

    leaked_generic = re.findall(r"(这背后的核心|真正的核心|本质上|底层逻辑|完整闭环|系统梳理)", final)
    for phrase in leaked_generic:
        failures.append(f"generic AIGC-style phrase may have replaced author expression: {phrase}")

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1

    print("OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
