#!/usr/bin/env python3
"""Build deterministic source-model artifacts from a frozen canonical source.

This command performs lossless intake, semantic-size segmentation, chunking,
formula-damage detection, author-question capture, conservative surface
decisions, and exact JSONL/Markdown mirrors. It does not draft or publish.
"""
from __future__ import annotations

from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess
import sys
from typing import Any

from content_authority import (
    ATOM_SCHEMA,
    SURFACE_REVIEW_SCHEMA,
    canonical_json,
    detect_surface_features,
    sha256_bytes,
    surface_decision_sha256,
    surface_features_require_exact,
)
from safe_io import atomic_write_json, atomic_write_text, read_json_strict
from structured_ledger import markdown_table
from validate_author_question_obligations import detect_question_candidates
from validate_formula_block_canonicalization import detect_fragment_runs
from validate_security_boundary import source_risks

TERMINAL_RE = re.compile(r"[。！？!?；;](?:[ \t]*\n*)|\n{2,}")
CLAUSE_BOUNDARY_RE = re.compile(r"[，,：:、]|\n")
MATH_HINT_RE = re.compile(
    r"[∫∮∂∇√≈≃≅−±·⋅∈∉⊂⊆⊃⊇∪∩∀∃∅∞→←↔⇒⇔≤≥≠=∣|\\^_{}[\]()+*/]"
    r"|(?:lim|sin|cos|exp|log|Cauchy|柯西|全纯|积分|导数|公式)",
    re.I,
)
MATH_STRUCTURAL_RE = re.compile(
    r"[∫∮∂∇√≈≃≅−±·⋅∈∉⊂⊆⊃⊇∪∩∀∃∅∞→←↔⇒⇔≤≥≠=∣|\\^_{}\[\]()+*/]"
    r"|\\(?:frac|int|oint|lim|sum|prod|partial|infty|lvert|rvert|begin|end)"
    r"|(?:[A-Za-z]\s*\([^\n]{0,80}\))"
)
AUTHOR_VOICE_RE = re.compile(r"(?:我|我们|大家|你们|你要|我赌|我觉得|我发现|顺便说|好吧|早安|晚安)")
WARNING_RE = re.compile(r"(?:注意|特别注意|切记|不能|不要|问题|陷阱)")
EXAMPLE_RE = re.compile(r"(?:例如|比如|例子|展示一下|算一个|原积分)")
THEOREM_RE = re.compile(r"(?:定理|公式说|若.*则|设.*如果)")
DEFINITION_RE = re.compile(r"(?:定义|称为|记作)")
TRANSITION_RE = re.compile(r"^(?:然后|所以|因此|于是|最后|好进入|当然|接下来|现在)")
MAX_NORMAL_ATOM_CHARS = 520
TARGET_CHUNK_CHARS = 6500
TARGET_CHUNK_ATOMS = 120


def jsonl_text(rows: list[dict[str, Any]]) -> str:
    return "".join(
        json.dumps(row, ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n"
        for row in rows
    )


def write_ledger(root: Path, stem: str, rows: list[dict[str, Any]], title: str) -> None:
    atomic_write_text(root / f"{stem}.jsonl", jsonl_text(rows))
    atomic_write_text(root / f"{stem}.md", markdown_table(rows, title=title))


def byte_prefix(text: str) -> list[int]:
    out = [0]
    total = 0
    for char in text:
        total += len(char.encode("utf-8"))
        out.append(total)
    return out


def byte_to_char(prefix: list[int], byte_offset: int) -> int:
    lo, hi = 0, len(prefix) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        if prefix[mid] < byte_offset:
            lo = mid + 1
        elif prefix[mid] > byte_offset:
            hi = mid - 1
        else:
            return mid
    raise ValueError(f"byte offset {byte_offset} is not a UTF-8 boundary")


def split_long_interval(text: str, start: int, end: int) -> list[tuple[int, int]]:
    """Split ordinary prose at sentence boundaries, then cap oversized units."""
    if start >= end:
        return []

    sentence_bounds = [start]
    for match in TERMINAL_RE.finditer(text, start, end):
        cut = match.end()
        if cut > sentence_bounds[-1]:
            sentence_bounds.append(cut)
    if sentence_bounds[-1] != end:
        sentence_bounds.append(end)

    base_units = [
        (a, b) for a, b in zip(sentence_bounds, sentence_bounds[1:])
        if a < b
    ]
    units: list[tuple[int, int]] = []
    for base_start, base_end in base_units:
        cursor = base_start
        while cursor < base_end:
            hard_end = min(base_end, cursor + MAX_NORMAL_ATOM_CHARS)
            if hard_end == base_end:
                units.append((cursor, base_end))
                break
            window = text[cursor:hard_end]
            candidates = [m.end() + cursor for m in CLAUSE_BOUNDARY_RE.finditer(window)]
            cut = candidates[-1] if candidates and candidates[-1] > cursor + 80 else hard_end
            units.append((cursor, cut))
            cursor = cut
    return units


def consolidate_formula_runs(
    source: str,
    runs: list[dict[str, int | str]],
    *,
    max_gap_bytes: int = 80,
) -> list[dict[str, int | str]]:
    """Merge adjacent OCR render fragments into one formula responsibility."""
    if not runs:
        return []
    source_bytes = source.encode("utf-8")
    groups: list[dict[str, int | str]] = []
    for run in runs:
        current = dict(run)
        current["member_count"] = 1
        if not groups:
            groups.append(current)
            continue
        previous = groups[-1]
        gap_start = int(previous["byte_end"])
        gap_end = int(current["byte_start"])
        gap = source_bytes[gap_start:gap_end].decode("utf-8", errors="strict")
        cjk_count = len(re.findall(r"[\u4e00-\u9fff]", gap))
        visible = len(re.sub(r"\s+", "", gap))
        if gap_end - gap_start <= max_gap_bytes and cjk_count <= 4 and visible <= 30:
            previous["byte_end"] = current["byte_end"]
            previous["char_end"] = current["byte_end"]
            previous["line_end"] = current["line_end"]
            previous["fragment_count"] = int(previous["fragment_count"]) + int(current["fragment_count"])
            previous["member_count"] = int(previous["member_count"]) + 1
            raw = source_bytes[int(previous["byte_start"]):int(previous["byte_end"])]
            previous["raw_fragment_hash"] = hashlib.sha256(raw).hexdigest()
        else:
            groups.append(current)
    return groups

def semantic_segments(source: str, formula_runs: list[dict[str, int | str]]) -> list[tuple[int, int, bool]]:
    """Return codepoint spans covering the source exactly."""
    prefix = byte_prefix(source)
    protected: list[tuple[int, int]] = []
    for run in formula_runs:
        protected.append((
            byte_to_char(prefix, int(run["byte_start"])),
            byte_to_char(prefix, int(run["byte_end"])),
        ))
    protected.sort()

    rough: list[tuple[int, int, bool]] = []
    cursor = 0
    for p_start, p_end in protected:
        if p_start > cursor:
            rough.extend((a, b, False) for a, b in split_long_interval(source, cursor, p_start))
        rough.append((p_start, p_end, True))
        cursor = p_end
    if cursor < len(source):
        rough.extend((a, b, False) for a, b in split_long_interval(source, cursor, len(source)))

    # Merge whitespace-only and one-character layout fragments into a neighbor.
    merged: list[list[Any]] = []
    for start, end, protected_flag in rough:
        excerpt = source[start:end]
        visible = excerpt.strip()
        if merged and (not visible or (len(visible) <= 1 and not protected_flag)):
            merged[-1][1] = end
            merged[-1][2] = bool(merged[-1][2] or protected_flag)
        else:
            merged.append([start, end, protected_flag])
    if merged and merged[0][0] > 0:
        merged[0][0] = 0
    # Defensive exact coverage.
    for index in range(1, len(merged)):
        merged[index][0] = merged[index - 1][1]
    if merged:
        merged[-1][1] = len(source)
    return [(int(a), int(b), bool(flag)) for a, b, flag in merged if a < b]


def classify(excerpt: str, protected_formula: bool) -> str:
    compact = re.sub(r"\s+", " ", excerpt).strip()
    math_score = len(MATH_HINT_RE.findall(compact))
    structural_score = len(MATH_STRUCTURAL_RE.findall(compact))
    if protected_formula:
        return "OCR_FRAGMENT"
    # Mathematical vocabulary alone (for example “柯西积分公式”) is prose.
    # Classify as formula only when notation is actually present at meaningful
    # density. This prevents ordinary exposition from being routed into formula
    # normalization and exact-symbol validators.
    visible_len = max(1, len(compact))
    notation_density = structural_score / visible_len
    if structural_score >= 3 or (
        structural_score >= 1 and math_score >= 2 and notation_density >= 0.015
    ):
        return "FORMULA"
    if DEFINITION_RE.search(compact):
        return "DEFINITION"
    if THEOREM_RE.search(compact):
        return "THEOREM"
    if EXAMPLE_RE.search(compact):
        return "EXAMPLE"
    if WARNING_RE.search(compact):
        return "WARNING"
    if AUTHOR_VOICE_RE.search(compact):
        return "AUTHOR_VOICE"
    if TRANSITION_RE.search(compact):
        return "TRANSITION"
    return "PROSE"


def summary_for(excerpt: str, content_type: str) -> str:
    compact = re.sub(r"\s+", " ", excerpt).strip()
    if not compact:
        return f"{content_type} semantic unit"
    return compact[:120]


def invariant_for(
    excerpt: str, content_type: str, required_functions: list[str]
) -> dict[str, Any]:
    summary = summary_for(excerpt, content_type)
    if content_type in {"FORMULA", "OCR_FRAGMENT"}:
        canonical = re.sub(r"\s+", " ", excerpt).strip()
        return {
            "summary": summary,
            "required_functions": required_functions,
            "mathematical_object": "source mathematical statement or displayed expression",
            "canonical_formula": canonical or "source formula pending normalization",
            "symbols": ["source_notation"],
            "conditions": ["preserve the source domain, orientation, and stated hypotheses"],
        }
    if content_type in {"AUTHOR_VOICE", "READER_DIALOGUE"}:
        return {
            "summary": summary,
            "required_functions": required_functions,
            "voice_function": "preserve the author's direct explanatory relationship with the reader",
            "preserve_tone": "retain the original degree of informality and emphasis",
        }
    return {"summary": summary, "required_functions": required_functions}


def operation_for(content_type: str) -> str:
    if content_type in {"FORMULA", "OCR_FRAGMENT"}:
        return "NORMALIZE_SOURCE_FORMULA"
    if content_type == "DEFINITION":
        return "DEFINE_SOURCE_TERM"
    if content_type in {"AUTHOR_VOICE", "READER_DIALOGUE"}:
        return "RETAIN_SOURCE_ASIDE"
    if content_type in {"THEOREM", "STATEMENT", "WARNING"}:
        return "EXPLAIN_CONTENT"
    return "REORGANIZE_CONTENT"


def atom_rows_for(source: str, segments: list[tuple[int, int, bool]], revision_id: str) -> list[dict[str, Any]]:
    prefix = byte_prefix(source)
    rows: list[dict[str, Any]] = []
    for index, (char_start, char_end, protected_formula) in enumerate(segments, 1):
        excerpt = source[char_start:char_end]
        byte_start, byte_end = prefix[char_start], prefix[char_end]
        atom_id = f"A{index:04d}"
        content_type = classify(excerpt, protected_formula)
        required_functions = ["SUBSTANTIVE_CONTENT"]
        features = detect_surface_features(excerpt, content_type)
        exact = surface_features_require_exact(features, content_type)
        if exact:
            surface_mode = "BYTE_EXACT"
            operation = "COPY_SOURCE_SLICE"
            basis = features or ["DISTINCTIVE_AUTHOR_VOICE"]
            cues = [excerpt.strip()[:120] or excerpt]
            rationale = "该片段含有明显的作者表面表达特征，保留字节级原貌可避免风格身份被改写。"
            review_status = "BLOCKED_REVIEW"
        else:
            surface_mode = "CONTENT_PRESERVE"
            operation = operation_for(content_type)
            basis = [
                "FORMULA_REQUIRES_NORMALIZATION"
                if content_type in {"FORMULA", "OCR_FRAGMENT"}
                else "ORDINARY_SEMANTIC_CONTENT"
            ]
            cues = []
            rationale = "该片段的核心约束是语义与数学条件，允许在不改变内容的前提下组织表达。"
            review_status = "BLOCKED_REVIEW"
        decision = {
            "decision": surface_mode,
            "basis": basis,
            "source_cues": cues,
            "rationale": rationale,
            "confidence": "HIGH" if exact or content_type != "OCR_FRAGMENT" else "MEDIUM",
            "review_status": review_status,
        }
        row: dict[str, Any] = {
            "schema_version": ATOM_SCHEMA,
            "atom_id": atom_id,
            "source_revision_id": revision_id,
            "source_byte_start": str(byte_start),
            "source_byte_end": str(byte_end),
            "source_excerpt_sha256": sha256_bytes(excerpt.encode("utf-8")),
            "raw_excerpt": excerpt,
            "content_lock_state": "CONTENT_LOCKED",
            "content_type": content_type,
            "required_functions": ",".join(required_functions),
            "local_context_role": (
                f"语义单元{index}：机器仅完成{content_type.lower()}初始路由，P04须重读原文并进行完整语义判断"
            ),
            "global_context_role": f"文章整体中的第{index}个受控来源单元",
            "content_invariant_json": canonical_json(
                invariant_for(excerpt, content_type, required_functions)
            ),
            "p02_surface_mode": surface_mode,
            "surface_mode": surface_mode,
            "output_operation": operation,
            "consumption_status": "PLANNED",
            "duplicate_of": "",
            "surface_decision_json": canonical_json(decision),
            "surface_group_id": "",
            "surface_group_mode": "NONE",
            # Compatibility/inspection fields.
            "sentence_id": f"T{index:04d}",
            "chunk_id": "",  # filled after chunk assignment
            "char_span": f"{byte_start}-{byte_end}",
            "source_excerpt": excerpt,
            "atom_level": "semantic_unit",
            "atom_type": content_type.lower(),
            "author_intent": "P04 must infer every source function semantically from the exact atom and its context; no keyword classification is authoritative",
            "math_role": "source mathematical content" if content_type in {"FORMULA", "OCR_FRAGMENT", "THEOREM"} else "non-formula explanatory context",
            "voice_role": "P04 semantic review pending",
            "symbol_role": "preserve source notation" if content_type in {"FORMULA", "OCR_FRAGMENT", "THEOREM"} else "no special symbol obligation",
            "punctuation_boundary": "semantic boundary with exact source span",
            "ocr_state": "fragmented_formula_review_required" if content_type == "OCR_FRAGMENT" else "clear",
            "needed_action": "mathematical human review before publication" if content_type == "OCR_FRAGMENT" else "consume according to atom contract",
            "destination_status": "blocked_review" if content_type == "OCR_FRAGMENT" else "planned",
            "final_destination": "publication_final.md",
        }
        if not exact:
            row["allowed_completion"] = "clarify and reorganize only while preserving all source claims, conditions, and notation"
            row["forbidden_change"] = "do not invent claims, remove hypotheses, reverse signs, or replace the author's method"
        rows.append(row)
    return rows


def assign_chunks(source: str, atoms: list[dict[str, Any]]) -> list[dict[str, Any]]:
    chunks: list[list[dict[str, Any]]] = []
    current: list[dict[str, Any]] = []
    current_chars = 0
    for atom in atoms:
        excerpt = str(atom["raw_excerpt"])
        size = len(excerpt)
        if current and (current_chars + size > TARGET_CHUNK_CHARS or len(current) >= TARGET_CHUNK_ATOMS):
            chunks.append(current)
            current = []
            current_chars = 0
        current.append(atom)
        current_chars += size
    if current:
        chunks.append(current)

    chunk_rows: list[dict[str, Any]] = []
    for idx, members in enumerate(chunks, 1):
        cid = f"C{idx:03d}"
        for atom in members:
            atom["chunk_id"] = cid
        first, last = members[0], members[-1]
        start, end = int(first["source_byte_start"]), int(last["source_byte_end"])
        chunk_excerpt = source.encode("utf-8")[start:end].decode("utf-8")
        chunk_rows.append({
            "chunk_id": cid,
            "char_span": f"{start}-{end}",
            "source_excerpt": chunk_excerpt,
            "start_sentence_id": first["sentence_id"],
            "end_sentence_id": last["sentence_id"],
            "semantic_unit_hint": str(len(members)),
            "target_atom_budget": str(TARGET_CHUNK_ATOMS),
            "context_left": chunks[idx - 2][-1]["atom_id"] if idx > 1 else "none",
            "context_right": chunks[idx][0]["atom_id"] if idx < len(chunks) else "none",
            "ledger_file": f"chunk_ledger/chunk_{cid}_atom_ledger.md",
            "status": "complete",
        })
    return chunk_rows


def sentence_rows_for(atoms: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for atom in atoms:
        rows.append({
            "sentence_id": atom["sentence_id"],
            "chunk_id": atom["chunk_id"],
            "char_span": atom["char_span"],
            "exact_sentence_or_line": atom["raw_excerpt"],
            "sentence_role": str(atom["content_type"]).lower(),
            "atom_ids": atom["atom_id"],
            "coverage_status": "covered",
            "notes": "one semantic intake unit; may contain internal punctuation",
        })
    return rows


def formula_rows_for(source: str, runs: list[dict[str, int | str]], atoms: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not runs:
        return [{
            "formula_block_id": "FB0001",
            "source_span": "none",
            "line_span": "none",
            "fragment_count": "0",
            "raw_fragment_hash": "none",
            "canonical_formula": "none",
            "canonicalization_status": "NO_FRAGMENTED_FORMULA_BLOCKS",
            "atom_ids": "none",
            "review_status": "REVIEWED",
            "verification_note": "No fragmented formula blocks detected in the current source.",
        }]
    source_bytes = source.encode("utf-8")
    rows = []
    for idx, run in enumerate(runs, 1):
        start, end = int(run["byte_start"]), int(run["byte_end"])
        raw = source_bytes[start:end].decode("utf-8")
        overlapping = [
            str(atom["atom_id"])
            for atom in atoms
            if max(start, int(atom["source_byte_start"])) < min(end, int(atom["source_byte_end"]))
        ]
        rows.append({
            "formula_block_id": f"FB{idx:04d}",
            "source_span": f"{start}-{end}",
            "line_span": f"{run['line_start']}-{run['line_end']}",
            "fragment_count": str(run["fragment_count"]),
            "raw_fragment_hash": str(run["raw_fragment_hash"]),
            "canonical_formula": re.sub(r"\s+", " ", raw).strip() or "source fragment",
            "canonicalization_status": "BLOCKED_NEEDS_HUMAN_REVIEW",
            "atom_ids": ",".join(overlapping) or "none",
            "review_status": "BLOCKED_NEEDS_HUMAN_REVIEW",
            "verification_note": "Detected deterministically; mathematical normalization and sign/domain review are required before drafting.",
        })
    return rows


def question_rows_for(source: str) -> list[dict[str, Any]]:
    detections = detect_question_candidates(source)
    rows = []
    for idx, det in enumerate(detections, 1):
        rows.append({
            "question_id": f"AQ{idx:04d}",
            "source_span": f"{det['start']}-{det['end']}",
            "source_excerpt": str(det["excerpt"]),
            "obligation_type": "P02_SEMANTIC_CANDIDATE",
            "required_action": "P03 must reread the source context and confirm, dismiss, or reclassify this candidate",
            "destination_file": "P03_REVIEW_PENDING",
            "destination_anchor": "P03-semantic-review",
            "resolution_status": "BLOCKED_NEEDS_SOURCE_SUPPORT",
            "response_trace": "none",
            "verification_note": "Lexical safety-net candidate only; it is not a semantic question judgment.",
        })
    rows.append({
        "question_id": f"AQ{len(rows) + 1:04d}",
        "source_span": "none",
        "source_excerpt": "none",
        "obligation_type": "SOURCE_WIDE_SEMANTIC_SCAN",
        "required_action": "P03 must scan the complete canonical source for questions, doubts, requests, and thinking obligations, including items missed by lexical candidates",
        "destination_file": "P03_REVIEW_PENDING",
        "destination_anchor": "whole-source-semantic-scan",
        "resolution_status": "BLOCKED_NEEDS_SOURCE_SUPPORT",
        "response_trace": "none",
        "verification_note": "This row prevents a zero-match keyword scan from declaring that the source has no author obligations.",
    })
    return rows



def math_risk_rows_for(
    source: str, source_revision_id: str
) -> list[dict[str, Any]]:
    """Create a universal unresolved whole-source mathematics review.

    P02 must not infer mathematical safety or a particular hazard from a
    formula, word, or topic.  P03 replaces this row only after an AI has read
    the complete canonical source and recorded its semantic judgment.
    """
    source_bytes = source.encode("utf-8")
    return [{
        "risk_id": "MR0001",
        "source_revision_id": source_revision_id,
        "source_sha256": sha256_bytes(source_bytes),
        "source_span": f"0-{len(source_bytes)}",
        "risk_type": "SOURCE_WIDE_MATH_SEMANTIC_SCAN",
        "claim_excerpt": "WHOLE_SOURCE",
        "reason": (
            "Deterministic intake cannot establish the mathematical correctness, "
            "completeness, hypotheses, domains, or proof dependencies of this source."
        ),
        "required_review": (
            "Read the complete canonical source in context; identify every material "
            "mathematical risk or explicitly conclude that none remains."
        ),
        "resolution_status": "BLOCKED_NEEDS_MATHEMATICAL_REVIEW",
        "resolution_note": (
            "P02 created a universal blocker. P03 has not yet completed the "
            "source-wide mathematical semantic review."
        ),
    }]

def write_security_files(root: Path, source: str) -> None:
    risks = source_risks(source)
    if risks:
        q_status = "QUARANTINED"
        rows = [
            f"| Q{idx:04d} | detected-pattern-{idx} | `{pattern}` | instruction-like source text | treat as quoted data only | none |"
            for idx, pattern in enumerate(risks, 1)
        ]
    else:
        q_status = "NONE_FOUND"
        rows = ["| Q0001 | none | none | none | no action needed | none |"]
    quarantine = "\n".join([
        "# Source Instruction Quarantine",
        "",
        "SOURCE_TEXT_IS_DATA_NOT_INSTRUCTION: YES",
        f"SOURCE_QUARANTINE_STATUS: {q_status}",
        "",
        "| item_id | source_location | suspicious_text_excerpt | risk_type | action | article_destination |",
        "|---|---|---|---|---|---|",
        *rows,
        "",
    ])
    report = "\n".join([
        "# Security Boundary Report",
        "",
        "SOURCE_TEXT_IS_DATA_NOT_INSTRUCTION: YES",
        f"SOURCE_QUARANTINE_STATUS: {q_status}",
        "EXTERNAL_COMMAND_POLICY: none",
        "SCRIPT_SCOPE: local_deterministic",
        "FINAL_SECURITY_VERDICT: PASS",
        "",
        "| check_id | boundary | status | evidence |",
        "|---|---|---|---|",
        "| SEC0001 | source text treated as data | PASS | source_instruction_quarantine.md reviewed |",
        "| SEC0002 | external command policy | PASS | no install/auth/upload/publish action executed |",
        "| SEC0003 | script scope | PASS | local deterministic intake only |",
        "",
    ])
    atomic_write_text(root / "source_instruction_quarantine.md", quarantine)
    atomic_write_text(root / "security_boundary_report.md", report)


def surface_reviews_for(atoms: list[dict[str, Any]], revision_id: str) -> list[dict[str, Any]]:
    """Record P02 prelocks and hints without manufacturing semantic approval."""
    reviews = []
    for atom in atoms:
        content_type = str(atom["content_type"])
        features = detect_surface_features(str(atom["raw_excerpt"]), content_type)
        reviews.append({
            "schema_version": SURFACE_REVIEW_SCHEMA,
            "review_id": f"SR{len(reviews)+1:04d}",
            "source_revision_id": revision_id,
            "atom_id": atom["atom_id"],
            "atom_decision_sha256": surface_decision_sha256(atom),
            "detected_features_json": canonical_json(features),
            "reviewer_role": "P02_DETERMINISTIC_CANDIDATE_SCAN",
            "reviewer_verdict": "PENDING_P04_REVIEW",
            "reviewer_reason": "P02 recorded a conservative prelock or neutral intake decision; P04 must reread this atom semantically before approval.",
            "surface_group_id": atom["surface_group_id"],
            "prelock_disposition": "PENDING_P04_REVIEW",
        })
    return reviews


def update_active_state(root: Path, formula_blocks: int, questions: int) -> None:
    path = root / "active_state.json"
    state = read_json_strict(path)
    if not isinstance(state, dict):
        raise ValueError("active_state.json must contain one object")
    state["current_stage"] = "source_review"
    state["resume_point"] = "complete P03 formula review and whole-source author-question semantic review before planning"
    state["resume_instruction"] = (
        f"Source model is complete. Review {formula_blocks} fragmented-formula block(s), "
        f"disposition {questions} lexical author-question candidate(s), and scan the whole "
        "canonical source for missed obligations before planning or drafting."
    )
    atomic_write_json(path, state)
    constraints = list(state.get("hard_constraints", []))
    md = "\n".join([
        "# Active State",
        "",
        f"RUN_ID: {state['run_id']}",
        f"RUN_MODE: {state['run_mode']}",
        f"CURRENT_STAGE: {state['current_stage']}",
        f"RESUME_POINT: {state['resume_point']}",
        f"FEEDBACK_LEDGER_SHA256: {state['feedback_ledger_sha256']}",
        "ACTIVE_FEEDBACK_IDS: " + (",".join(state.get("active_feedback_ids", [])) or "none"),
        "",
        "## Resume Instruction",
        "",
        str(state["resume_instruction"]),
        "",
        "## Hard Constraints",
        "",
        *[f"- {item}" for item in constraints],
        "",
    ])
    atomic_write_text(root / "active_state.md", md)


def run_pre_batch_validators(package_root: Path, output: Path) -> list[tuple[str, int]]:
    names = [
        "validate_atom_semantics.py",
        "validate_source_atom_granularity.py",
        "validate_chunk_ledgers.py",
    ]
    results = []
    for name in names:
        completed = subprocess.run(
            [sys.executable, str(package_root / "scripts" / name), str(output)],
            capture_output=True,
            text=True,
            check=False,
        )
        results.append((name, int(completed.returncode)))
        if completed.returncode:
            sys.stdout.write(completed.stdout)
            sys.stderr.write(completed.stderr)
    return results


def write_chunk_log(root: Path, chunk_rows: list[dict[str, Any]], results: list[tuple[str, int]]) -> None:
    command_text = "; ".join(f"python scripts/{name}" for name, _ in results)
    exit_code = max((code for _, code in results), default=1)
    rows = [
        {
            "chunk_id": row["chunk_id"],
            "validator_commands": command_text,
            "exit_code": str(exit_code),
            "validation_status": "PASS" if exit_code == 0 else "FAIL",
            "notes": "deterministic source-model pre-batch validation",
        }
        for row in chunk_rows
    ]
    atomic_write_text(root / "chunk_processing_log.md", markdown_table(rows, title="Chunk Processing Log"))


def build(output: Path, *, overwrite: bool = False) -> int:
    source_path = output / "source_canonical.txt"
    if not source_path.exists():
        print("FAILED: initialize the output with scripts/pipeline.py init first")
        return 1
    targets = [
        output / "source_atom_ledger.jsonl",
        output / "source_sentence_index.jsonl",
        output / "source_chunk_index.jsonl",
    ]
    if any(path.exists() for path in targets) and not overwrite:
        print("FAILED: source-model artifacts already exist; use --overwrite for a deliberate rebuild")
        return 1

    source = source_path.read_bytes().decode("utf-8", errors="strict")
    revision = read_json_strict(output / "source_revision.json")
    if not isinstance(revision, dict):
        print("FAILED: source_revision.json must contain one object")
        return 1
    revision_id = str(revision.get("source_revision_id", ""))
    detected_runs = detect_fragment_runs(source)
    runs = consolidate_formula_runs(source, detected_runs)
    segments = semantic_segments(source, runs)
    atoms = atom_rows_for(source, segments, revision_id)
    chunks = assign_chunks(source, atoms)
    sentences = sentence_rows_for(atoms)
    formula_rows = formula_rows_for(source, runs, atoms)
    question_rows = question_rows_for(source)
    math_risk_rows = math_risk_rows_for(source, revision_id)

    write_ledger(output, "source_chunk_index", chunks, "Source Chunk Index")
    write_ledger(output, "source_sentence_index", sentences, "Source Sentence Index")
    write_ledger(output, "source_atom_ledger", atoms, "Source Atom Ledger")
    write_ledger(output, "source_formula_block_ledger", formula_rows, "Source Formula Block Ledger")
    write_ledger(output, "author_question_obligation_ledger", question_rows, "Author Question Obligation Ledger")
    write_ledger(output, "source_math_risk_ledger", math_risk_rows, "Source Math Risk Ledger")

    chunk_dir = output / "chunk_ledger"
    chunk_dir.mkdir(parents=True, exist_ok=True)
    for row in chunks:
        cid = str(row["chunk_id"])
        members = [atom for atom in atoms if atom["chunk_id"] == cid]
        write_ledger(chunk_dir, f"chunk_{cid}_atom_ledger", members, f"{cid} Atom Ledger")

    manifest_rows = []
    for row in chunks:
        members = [atom for atom in atoms if atom["chunk_id"] == row["chunk_id"]]
        manifest_rows.append({
            "chunk_id": row["chunk_id"],
            "char_span": row["char_span"],
            "sentence_range": f"{members[0]['sentence_id']}-{members[-1]['sentence_id']}",
            "atom_range": f"{members[0]['atom_id']}-{members[-1]['atom_id']}",
            "atom_count": str(len(members)),
            "semantic_unit_hint": str(len(members)),
            "chunk_ledger_file": row["ledger_file"],
            "validation_status": "PENDING_PRE_BATCH_VALIDATION",
            "checksum_or_lock": sha256_bytes(jsonl_text(members).encode("utf-8")),
            "notes": "lossless semantic intake",
        })
    atomic_write_text(output / "source_atom_manifest.md", markdown_table(manifest_rows, title="Source Atom Manifest"))

    reviews = surface_reviews_for(atoms, revision_id)
    review_path = output / "surface_decision_review.jsonl"
    if reviews:
        atomic_write_text(review_path, jsonl_text(reviews))
    elif review_path.exists():
        review_path.unlink()

    write_security_files(output, source)
    update_active_state(
        output,
        formula_blocks=len(runs),
        questions=sum(
            1
            for row in question_rows
            if row["obligation_type"] == "P02_SEMANTIC_CANDIDATE"
        ),
    )

    package_root = Path(__file__).resolve().parent.parent
    pre_results = run_pre_batch_validators(package_root, output)
    write_chunk_log(output, chunks, pre_results)
    if any(code for _, code in pre_results):
        print("FAILED: source model generated but pre-batch validators failed")
        return 1

    # Mark manifest only after real validator success.
    for row in manifest_rows:
        row["validation_status"] = "PASS"
    atomic_write_text(output / "source_atom_manifest.md", markdown_table(manifest_rows, title="Source Atom Manifest"))

    print("SOURCE_MODEL_BUILT")
    print(
        f"atoms={len(atoms)} chunks={len(chunks)} "
        f"detected_formula_runs={len(detected_runs)} formula_blocks={len(runs)} "
        f"math_semantic_scan_blockers=1 reviews={len(reviews)}"
    )
    print("next=python scripts/pipeline.py validate <output> --mode source_atomization")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    return build(Path(args.output).resolve(), overwrite=args.overwrite)


if __name__ == "__main__":
    raise SystemExit(main())
