#!/usr/bin/env python3
"""Validate failure recovery logging and escalation discipline."""
from __future__ import annotations

from pathlib import Path
import re
import sys

ALLOWED_ROOT = {"NOT_NEEDED", "IDENTIFIED", "UNRESOLVED"}
ALLOWED_LEVELS = {"L0_NONE", "L1_LOCAL_FIX", "L2_REBUILD_UPSTREAM", "L3_PIPELINE_ROLLBACK", "L4_BLOCKED_PUBLICATION"}
ALLOWED_FINAL = {"NOT_NEEDED", "RECOVERED", "REBUILT", "BLOCKED"}
BAD_SHORTCUTS = [
    "patch_without_root_cause", "fake pass", "invent support", "invented support",
    "ignore validator", "skip validator", "should pass", "probably pass",
]


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def field(text: str, name: str) -> str:
    m = re.search(rf"^\s*{re.escape(name)}\s*:\s*(\S+)\s*$", text, flags=re.M)
    return m.group(1).strip() if m else ""


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    path = root / "failure_recovery_log.md"
    text = read(path)
    failures: list[str] = []
    if not text.strip():
        failures.append("missing or empty failure_recovery_log.md")
    root_status = field(text, "ROOT_CAUSE_STATUS")
    level = field(text, "ESCALATION_LEVEL")
    final_state = field(text, "FINAL_RECOVERY_STATE")
    if root_status not in ALLOWED_ROOT:
        failures.append(f"ROOT_CAUSE_STATUS must be one of {sorted(ALLOWED_ROOT)}, got {root_status!r}")
    if level not in ALLOWED_LEVELS:
        failures.append(f"ESCALATION_LEVEL must be one of {sorted(ALLOWED_LEVELS)}, got {level!r}")
    if final_state not in ALLOWED_FINAL:
        failures.append(f"FINAL_RECOVERY_STATE must be one of {sorted(ALLOWED_FINAL)}, got {final_state!r}")
    if re.search(r"\b(TODO|TBD|pending|unknown|unclear)\b|待定|不清楚", text, flags=re.I):
        failures.append("failure_recovery_log.md contains unresolved placeholder text")
    low = text.lower()
    for bad in BAD_SHORTCUTS:
        if bad in low:
            failures.append(f"failure recovery shortcut forbidden: {bad}")
    if final_state == "NOT_NEEDED" and level != "L0_NONE":
        failures.append("NOT_NEEDED recovery must use ESCALATION_LEVEL: L0_NONE")
    if final_state == "BLOCKED" and level != "L4_BLOCKED_PUBLICATION":
        failures.append("BLOCKED recovery must use ESCALATION_LEVEL: L4_BLOCKED_PUBLICATION")
    if "| FR" not in text:
        failures.append("failure_recovery_log.md has no FR rows")
    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print("OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
