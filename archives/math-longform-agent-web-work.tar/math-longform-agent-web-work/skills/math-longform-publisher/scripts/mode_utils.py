#!/usr/bin/env python3
"""Run-mode resolution helpers backed by the central pipeline registry."""
from __future__ import annotations

from pathlib import Path

from safe_io import read_json_strict, read_text_strict
from pipeline_registry import (
    DIAGNOSTIC_BACKTEST,
    EVIDENCE_FILES,
    FULL_PUBLICATION,
    MODE_REQUIRED_FILES,
    MODE_STRUCTURED_JSONL,
    RELEASE_MODES,
    SOURCE_ATOMIZATION,
    SOURCE_MODES,
    VALID_MODES,
    WECHAT_PUBLICATION,
    required_files_for_mode,
    structured_jsonl_for_mode,
    validator_names_for_mode,
)


def parse_mode_args(args: list[str]) -> tuple[str | None, list[str]]:
    """Extract one trusted ``--mode`` value while preserving positional arguments."""
    mode = None
    rest: list[str] = []
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--mode":
            if i + 1 >= len(args):
                raise ValueError("--mode requires a value")
            if mode is not None:
                raise ValueError("--mode may be specified only once")
            mode = args[i + 1]
            i += 2
            continue
        if arg.startswith("--mode="):
            if mode is not None:
                raise ValueError("--mode may be specified only once")
            mode = arg.split("=", 1)[1]
            i += 1
            continue
        rest.append(arg)
        i += 1
    return mode, rest


def read_mode_file(root: Path) -> str | None:
    path = root / "run_mode.json"
    if not path.exists():
        return None
    try:
        if not read_text_strict(path, root=root).strip():
            raise ValueError("run_mode.json is empty")
        data = read_json_strict(path, root=root)
    except Exception as exc:
        raise ValueError(f"run_mode.json is invalid: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError("run_mode.json must contain a JSON object")
    mode = data.get("mode")
    if not isinstance(mode, str) or not mode.strip():
        raise ValueError("run_mode.json must contain a nonempty string field: mode")
    mode = mode.strip()
    if mode not in VALID_MODES:
        raise ValueError(
            f"unsupported run mode: {mode}. valid modes: {', '.join(sorted(VALID_MODES))}"
        )
    return mode


def resolve_mode(
    root: Path,
    explicit_mode: str | None = None,
    *,
    allow_mode_file: bool = True,
) -> str:
    """Resolve mode without allowing package content to weaken a release runner."""
    if explicit_mode is not None:
        mode = explicit_mode.strip()
    elif allow_mode_file:
        mode = read_mode_file(root) or FULL_PUBLICATION
    else:
        mode = FULL_PUBLICATION
    if mode not in VALID_MODES:
        raise ValueError(
            f"unsupported run mode: {mode}. valid modes: {', '.join(sorted(VALID_MODES))}"
        )
    return mode


def validators_for_mode(mode: str) -> set[str]:
    """Compatibility wrapper for callers that need validator names."""
    return validator_names_for_mode(mode)
