#!/usr/bin/env python3
"""Validate the frozen, machine-readable author request before writing."""
from pathlib import Path
import sys

from quality_contract import load_author_task_contract


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    try:
        contract = load_author_task_contract(root.resolve())
    except Exception as exc:
        print(f"FAILED: {exc}")
        return 1
    print("OK")
    print(f"task_id={contract['task_id']} task_mode={contract['task_mode']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
