#!/usr/bin/env python3
"""Validate the current source revision, identity source flow, and patch chain."""
from __future__ import annotations

from pathlib import Path
import base64
import json
import re
import sys

from content_authority import SOURCE_REVISION_SCHEMA, load_json_object, load_jsonl_objects, sha256_bytes, utf8_slice

REV_RE = re.compile(r"R\d{4,}")
PATCH_RE = re.compile(r"SP\d{4,}")


def fail(messages: list[str]) -> int:
    print("FAILED")
    for message in messages:
        print(f"- {message}")
    return 1


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    failures: list[str] = []

    required = [
        "source_original.txt",
        "source_canonical.txt",
        "canonical_source.txt",
        "source.txt",
        "source_identity.json",
        "source_provenance.json",
        "source_revision.json",
        "source_normalization_map.jsonl",
    ]
    for rel in required:
        if not (root / rel).exists():
            failures.append(f"missing required source-authority file: {rel}")
    if failures:
        return fail(failures)

    try:
        revision = load_json_object(root / "source_revision.json")
        identity = load_json_object(root / "source_identity.json")
        provenance = load_json_object(root / "source_provenance.json")
        normalization_rows = load_jsonl_objects(root / "source_normalization_map.jsonl")
    except Exception as exc:
        return fail([str(exc)])

    original = (root / "source_original.txt").read_bytes()
    canonical = (root / "source_canonical.txt").read_bytes()
    try:
        original.decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        failures.append(f"source_original.txt is not strict UTF-8: byte {exc.start}")
    try:
        canonical_text = canonical.decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        failures.append(f"source_canonical.txt is not strict UTF-8: byte {exc.start}")
        canonical_text = ""

    original_hash = sha256_bytes(original)
    canonical_hash = sha256_bytes(canonical)

    if revision.get("schema_version") != SOURCE_REVISION_SCHEMA:
        failures.append(f"source_revision.json schema_version must be {SOURCE_REVISION_SCHEMA}")
    revision_id = str(revision.get("source_revision_id", ""))
    if not REV_RE.fullmatch(revision_id):
        failures.append(f"invalid source_revision_id: {revision_id!r}")
    parent_id = str(revision.get("parent_revision_id", "none"))
    if parent_id != "none" and not REV_RE.fullmatch(parent_id):
        failures.append(f"invalid parent_revision_id: {parent_id!r}")

    if revision.get("original_source_file") != "source_original.txt":
        failures.append("source_revision original_source_file must be source_original.txt")
    if revision.get("original_source_sha256") != original_hash:
        failures.append("source_revision original_source_sha256 mismatch")
    if revision.get("canonical_source_file") != "source_canonical.txt":
        failures.append("source_revision canonical_source_file must be source_canonical.txt")
    if revision.get("canonical_source_sha256") != canonical_hash:
        failures.append("source_revision canonical_source_sha256 mismatch")
    if int(revision.get("canonical_source_length_bytes", -1)) != len(canonical):
        failures.append("source_revision canonical_source_length_bytes mismatch")
    if revision.get("span_unit") != "utf8_byte_offset":
        failures.append("source_revision span_unit must be utf8_byte_offset")
    if revision.get("authority") != "CURRENT_CANONICAL_SOURCE_ONLY":
        failures.append("source_revision authority must be CURRENT_CANONICAL_SOURCE_ONLY")

    if identity.get("schema_version") != "source-identity-v3":
        failures.append("source_identity schema_version must be source-identity-v3")
    if identity.get("original_file") != "source_original.txt":
        failures.append("source_identity original_file must be source_original.txt")
    if identity.get("original_sha256") != original_hash:
        failures.append("source_identity original_sha256 mismatch")
    if int(identity.get("original_length_bytes", -1)) != len(original):
        failures.append("source_identity original_length_bytes mismatch")
    if identity.get("canonical_file") != "source_canonical.txt":
        failures.append("source_identity canonical_file must be source_canonical.txt")
    if identity.get("canonical_sha256") != canonical_hash:
        failures.append("source_identity canonical_sha256 mismatch")
    if int(identity.get("canonical_length_bytes", -1)) != len(canonical):
        failures.append("source_identity canonical_length_bytes mismatch")
    if int(identity.get("canonical_length_codepoints", -1)) != len(canonical_text):
        failures.append("source_identity canonical_length_codepoints mismatch")
    if identity.get("span_unit") != "utf8_byte_offset":
        failures.append("source_identity span_unit must be utf8_byte_offset")

    if provenance.get("schema_version") != "source-provenance-v2":
        failures.append("source_provenance schema_version must be source-provenance-v2")
    if provenance.get("original_source_file") != "source_original.txt":
        failures.append("source_provenance original_source_file mismatch")
    if provenance.get("original_source_sha256") != original_hash:
        failures.append("source_provenance original source hash mismatch")
    if provenance.get("canonical_source_file") != "source_canonical.txt":
        failures.append("source_provenance canonical_source_file mismatch")
    if provenance.get("canonical_source_sha256") != canonical_hash:
        failures.append("source_provenance canonical source hash mismatch")

    for mirror in ("canonical_source.txt", "source.txt"):
        if (root / mirror).read_bytes() != canonical:
            failures.append(f"legacy mirror {mirror} differs from source_canonical.txt")

    operations = [str(row.get("operation", "")) for row in normalization_rows]
    if len(operations) != 1:
        failures.append("source_normalization_map.jsonl must contain one initial source mapping row")
    transformation = str(revision.get("canonical_transformation", ""))
    if transformation != str(identity.get("canonical_transformation", "")):
        failures.append("source revision and identity canonical_transformation differ")
    if transformation != str(provenance.get("canonical_transformation", "")):
        failures.append("source revision and provenance canonical_transformation differ")

    applied_ids = [x for x in re.split(r"[\s,;]+", str(revision.get("applied_patch_ids", ""))) if x]
    patch_path = root / "source_patch_ledger.jsonl"

    # For an untouched TXT upload, original and canonical must be the same bytes.
    if not applied_ids and transformation == "IDENTITY":
        if original != canonical:
            failures.append("IDENTITY source revision requires source_original.txt == source_canonical.txt byte-for-byte")
        if original_hash != canonical_hash:
            failures.append("IDENTITY source revision requires identical original/canonical hashes")
        if revision_id != "R0001" or parent_id != "none":
            failures.append("an unpatched IDENTITY source must remain R0001 with no parent")

    if applied_ids:
        if not patch_path.exists():
            failures.append("source_revision lists applied patches but source_patch_ledger.jsonl is missing")
        else:
            try:
                rows = load_jsonl_objects(patch_path)
            except Exception as exc:
                failures.append(str(exc))
                rows = []
            row_map = {str(row.get("patch_id", "")): row for row in rows}
            if len(row_map) != len(rows):
                failures.append("source_patch_ledger.jsonl contains duplicate or empty patch_id values")

            previous_result_revision = ""
            previous_result_hash = ""
            for index, patch_id in enumerate(applied_ids):
                if not PATCH_RE.fullmatch(patch_id):
                    failures.append(f"invalid applied patch id: {patch_id}")
                    continue
                row = row_map.get(patch_id)
                if row is None:
                    failures.append(f"applied patch not found in ledger: {patch_id}")
                    continue
                if row.get("schema_version") != "content-authority-source-patch-v2":
                    failures.append(f"{patch_id}: invalid source-patch schema_version")
                if row.get("status") != "APPLIED_CURRENT_USER_PATCH":
                    failures.append(f"{patch_id}: status must be APPLIED_CURRENT_USER_PATCH")
                if not str(row.get("user_authorization_ref", "")).strip():
                    failures.append(f"{patch_id}: current-user authorization reference is required")

                base_revision = str(row.get("base_revision_id", ""))
                result_revision = str(row.get("result_revision_id", ""))
                if not REV_RE.fullmatch(base_revision):
                    failures.append(f"{patch_id}: invalid base_revision_id")
                if not REV_RE.fullmatch(result_revision):
                    failures.append(f"{patch_id}: invalid result_revision_id")
                if index > 0:
                    if base_revision != previous_result_revision:
                        failures.append(f"{patch_id}: base revision does not chain from previous patch")
                    if row.get("base_source_sha256") != previous_result_hash:
                        failures.append(f"{patch_id}: base hash does not chain from previous patch")

                base_path = root / "source_revisions" / base_revision / "source_canonical.txt"
                if not base_path.exists():
                    failures.append(f"{patch_id}: archived base revision missing: {base_path.relative_to(root)}")
                    continue
                base = base_path.read_bytes()
                if sha256_bytes(base) != row.get("base_source_sha256"):
                    failures.append(f"{patch_id}: archived base revision hash mismatch")
                    continue
                try:
                    start = int(row.get("source_byte_start", -1))
                    end = int(row.get("source_byte_end", -1))
                    utf8_slice(base, start, end, f"{patch_id} source slice")
                    old_slice = base[start:end]
                    if sha256_bytes(old_slice) != row.get("expected_slice_sha256"):
                        failures.append(f"{patch_id}: expected source slice hash mismatch")
                    replacement = base64.b64decode(str(row.get("replacement_utf8_b64", "")), validate=True)
                    replacement.decode("utf-8", errors="strict")
                    if sha256_bytes(replacement) != row.get("replacement_sha256"):
                        failures.append(f"{patch_id}: replacement_sha256 mismatch")
                    replayed = base[:start] + replacement + base[end:]
                    replayed.decode("utf-8", errors="strict")
                    if sha256_bytes(replayed) != row.get("result_source_sha256"):
                        failures.append(f"{patch_id}: deterministic patch replay hash mismatch")
                except Exception as exc:
                    failures.append(f"{patch_id}: invalid patch row: {exc}")

                previous_result_revision = result_revision
                previous_result_hash = str(row.get("result_source_sha256", ""))

            final_row = row_map.get(applied_ids[-1]) if applied_ids else None
            if final_row is not None:
                if final_row.get("result_revision_id") != revision_id:
                    failures.append("final patch result_revision_id does not match current revision")
                if final_row.get("result_source_sha256") != canonical_hash:
                    failures.append("final patch result_source_sha256 does not match current canonical source")
                if revision.get("parent_revision_id") != final_row.get("base_revision_id"):
                    failures.append("source_revision parent_revision_id does not match final patch base revision")
            unused = sorted(set(row_map) - set(applied_ids))
            if unused:
                failures.append("source_patch_ledger.jsonl contains unapplied rows: " + ", ".join(unused))
    elif patch_path.exists() and patch_path.read_text(encoding="utf-8").strip():
        failures.append("source_patch_ledger.jsonl contains rows but current revision lists no applied_patch_ids")

    if failures:
        return fail(failures)
    print("OK")
    print(
        f"source_revision_id={revision_id} original_sha256={original_hash} "
        f"canonical_sha256={canonical_hash} transformation={transformation} patches={len(applied_ids)}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
