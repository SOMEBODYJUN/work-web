#!/usr/bin/env python3
"""Validate publication_final.md from final-to-source direction."""
from pathlib import Path
import re
import sys

def read(p):
    return p.read_text(encoding="utf-8") if p.exists() else ""

def rows(text, prefix):
    return re.findall(rf"^\|\s*({prefix}\d+)\s*\|(.+)$", text, flags=re.M)

def main():
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    article = read(root / "publication_final.md")
    trace = read(root / "publication_trace_map.md")
    claims = read(root / "publication_claim_ledger.md")
    failures = []
    if not article.strip():
        failures.append("missing publication_final.md")
    if not trace.strip():
        failures.append("missing publication_trace_map.md")
    if not claims.strip():
        failures.append("missing publication_claim_ledger.md")
    for pid, rest in rows(trace, "PP"):
        if not re.search(r"\bA\d{3,}\b|\bS\d{3,}\b|\bPR\d{3,}\b|\bEXP\d{3,}\b", rest):
            failures.append(f"{pid}: publication paragraph lacks source/math support")
        if re.search(r"\bC\b", rest) and not re.search(r"deleted|compress|math_required|source_supported|done", rest, flags=re.I):
            failures.append(f"{pid}: C-class material not resolved")
    claim_rows = rows(claims, "PCL")
    if not claim_rows:
        failures.append("publication_claim_ledger.md has no PCL rows")
    for cid, rest in claim_rows:
        if not re.search(r"\bA\d{3,}\b|\bS\d{3,}\b|\bPR\d{3,}\b", rest):
            failures.append(f"{cid}: claim lacks source/math support")
        if re.search(r"unsupported|pending|unknown|unclear|TODO|TBD|待定|不清楚", rest, flags=re.I):
            failures.append(f"{cid}: unresolved or unsupported claim")
    if failures:
        print("FAILED")
        for f in failures:
            print(f"- {f}")
        return 1
    print("OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
