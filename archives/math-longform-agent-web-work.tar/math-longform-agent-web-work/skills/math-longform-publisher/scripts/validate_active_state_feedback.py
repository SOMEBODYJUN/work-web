#!/usr/bin/env python3
"""Validate active-state and user-feedback continuity with exact mirror binding."""
from __future__ import annotations

from pathlib import Path
import re
import sys
from typing import Any

from mode_utils import FULL_PUBLICATION, WECHAT_PUBLICATION, parse_mode_args, resolve_mode
from pipeline_registry import package_version
from safe_io import read_json_strict, read_jsonl_strict, read_optional_text, sha256_file

REQUIRED_LEDGER_FIELDS = {
    "feedback_id", "source_turn", "feedback_excerpt", "feedback_type", "target_scope",
    "correction_rule", "required_action", "carry_forward", "status", "active_state_binding",
    "evidence_trace", "verification_note",
}
REQUIRED_ACTIVE_FIELDS = {
    "schema_version", "run_id", "run_mode", "source_identity_sha256", "current_stage",
    "resume_point", "feedback_ledger_sha256", "active_feedback_ids", "hard_constraints",
    "resume_instruction",
}
ALL_STATUSES = {"NO_USER_FEEDBACK", "OPEN", "ACTIVE", "APPLIED", "CLOSED", "REJECTED", "BLOCKED", "VERIFIED", "RESOLVED"}
RELEASE_BLOCKING = {"OPEN", "ACTIVE", "BLOCKED"}
CLOSED = {"NO_USER_FEEDBACK", "CLOSED", "REJECTED", "VERIFIED", "RESOLVED"}
MD_BINDINGS = {
    "RUN_ID": "run_id",
    "RUN_MODE": "run_mode",
    "CURRENT_STAGE": "current_stage",
    "RESUME_POINT": "resume_point",
    "FEEDBACK_LEDGER_SHA256": "feedback_ledger_sha256",
}
SOURCE_OBLIGATION_ID_RE = re.compile(r"(?<![A-Za-z0-9_])(?:AQ|FB|MR)\d{3,}(?![A-Za-z0-9_])")


def parse_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    token = str(value).strip().lower()
    if token in {"true", "yes", "1", "active", "carry_forward"}:
        return True
    if token in {"false", "no", "0", "none", "closed"}:
        return False
    raise ValueError(f"invalid boolean value: {value!r}")


def singleton_field(text: str, name: str, failures: list[str]) -> str:
    matches = re.findall(rf"(?mi)^\s*{re.escape(name)}\s*:\s*(.*?)\s*$", text)
    if len(matches) != 1:
        failures.append(f"active_state.md must contain exactly one {name}, found {len(matches)}")
        return ""
    return matches[0].strip()


def normalize_md_ids(value: str) -> list[str]:
    if value.strip().lower() in {"", "none", "[]"}:
        return []
    return [part for part in re.split(r"[\s,]+", value.strip()) if part]


def transcribed_source_obligation_ids(active: dict[str, Any]) -> list[str]:
    """Find stale-prone AQ/FB/MR inventories outside their authoritative ledgers."""
    texts = [
        str(active.get("resume_point", "")),
        str(active.get("resume_instruction", "")),
    ]
    constraints = active.get("hard_constraints", [])
    if isinstance(constraints, list):
        texts.extend(str(value) for value in constraints)
    return sorted(set(SOURCE_OBLIGATION_ID_RE.findall("\n".join(texts))))


def main() -> int:
    try:
        explicit_mode, args = parse_mode_args(sys.argv[1:])
    except ValueError as exc:
        print("FAILED")
        print(f"- {exc}")
        return 1
    root = (Path(args[0]) if args else Path(".")).resolve()
    try:
        mode = resolve_mode(root, explicit_mode)
    except ValueError as exc:
        print("FAILED")
        print(f"- {exc}")
        return 1
    release_mode = mode in {FULL_PUBLICATION, WECHAT_PUBLICATION}
    failures: list[str] = []

    try:
        run_mode_record = read_json_strict(root / "run_mode.json", root=root)
        if not isinstance(run_mode_record, dict):
            raise ValueError("expected JSON object")
        if run_mode_record.get("schema_version") != "run-mode-v1":
            failures.append("run_mode.json schema_version must be run-mode-v1")
        if run_mode_record.get("package_version") != package_version():
            failures.append(
                "run_mode.json package_version does not match the active Skill VERSION; "
                "run pipeline.py set-mode to refresh the run and invalidate stale evidence"
            )
    except Exception as exc:
        failures.append(f"run_mode.json invalid: {exc}")

    active_json = root / "active_state.json"
    active_md = root / "active_state.md"
    feedback_jsonl = root / "user_feedback_ledger.jsonl"
    feedback_md = root / "user_feedback_ledger.md"
    for rel, path in [
        ("active_state.json", active_json), ("active_state.md", active_md),
        ("user_feedback_ledger.jsonl", feedback_jsonl), ("user_feedback_ledger.md", feedback_md),
    ]:
        try:
            if not read_optional_text(path, root=root).strip():
                failures.append(f"missing or empty required feedback/state file: {rel}")
        except Exception as exc:
            failures.append(f"{rel}: {exc}")

    active: dict[str, Any] | None = None
    try:
        value = read_json_strict(active_json, root=root)
        if not isinstance(value, dict):
            raise ValueError("expected JSON object")
        active = value
    except Exception as exc:
        failures.append(f"active_state.json invalid: {exc}")

    active_ids: list[str] = []
    if active is not None:
        missing = sorted(REQUIRED_ACTIVE_FIELDS - set(active))
        if missing:
            failures.append("active_state.json missing fields: " + ", ".join(missing))
        if active.get("schema_version") != "active-state-v1":
            failures.append("active_state.json schema_version must be active-state-v1")
        if str(active.get("run_mode", "")) != mode:
            failures.append(f"active_state.json run_mode {active.get('run_mode')!r} does not match effective mode {mode!r}")
        raw_ids = active.get("active_feedback_ids")
        if not isinstance(raw_ids, list) or not all(isinstance(x, str) and x.strip() for x in raw_ids):
            failures.append("active_state.json active_feedback_ids must be a list of nonempty strings")
        else:
            active_ids = [x.strip() for x in raw_ids]
            if len(active_ids) != len(set(active_ids)):
                failures.append("active_state.json active_feedback_ids contains duplicates")
        constraints = active.get("hard_constraints")
        if not isinstance(constraints, list) or not constraints or not all(isinstance(x, str) and x.strip() for x in constraints):
            failures.append("active_state.json hard_constraints must be a nonempty list of strings")
        transcribed_ids = transcribed_source_obligation_ids(active)
        if transcribed_ids:
            failures.append(
                "active_state.json must not transcribe source-obligation ids; "
                "read the authoritative P03 ledgers directly: " + ", ".join(transcribed_ids)
            )
        if active_ids and str(active.get("resume_instruction", "")).strip().lower() in {"", "none", "todo", "unknown"}:
            failures.append("active_state.json resume_instruction must be actionable when feedback ids are active")

    try:
        rows = read_jsonl_strict(feedback_jsonl, root=root)
    except Exception as exc:
        failures.append(f"user_feedback_ledger.jsonl invalid: {exc}")
        rows = []

    feedback_ids: set[str] = set()
    carry_ids: set[str] = set()
    no_feedback_count = 0
    for idx, row in enumerate(rows, 1):
        missing = sorted(REQUIRED_LEDGER_FIELDS - set(row))
        if missing:
            failures.append(f"user_feedback_ledger.jsonl row {idx} missing fields: " + ", ".join(missing))
        fid = str(row.get("feedback_id", "")).strip()
        if not re.fullmatch(r"UF\d{3,}", fid):
            failures.append(f"user_feedback_ledger.jsonl row {idx} has invalid feedback_id: {fid!r}")
        elif fid in feedback_ids:
            failures.append(f"user_feedback_ledger.jsonl duplicate feedback_id: {fid}")
        else:
            feedback_ids.add(fid)
        status = str(row.get("status", "")).strip().upper()
        if status not in ALL_STATUSES:
            failures.append(f"user_feedback_ledger.jsonl row {idx} has invalid status: {status!r}")
        if status == "NO_USER_FEEDBACK":
            no_feedback_count += 1
        try:
            carry = parse_bool(row.get("carry_forward"))
        except ValueError as exc:
            failures.append(f"user_feedback_ledger.jsonl row {idx}: {exc}")
            carry = False
        if carry and status not in CLOSED and fid:
            carry_ids.add(fid)
        if release_mode and status in RELEASE_BLOCKING and fid != "UF0000":
            failures.append(f"feedback {fid} has release-blocking status in {mode}: {status}")
        if status in {"APPLIED", "VERIFIED", "RESOLVED"}:
            for field in ["target_scope", "correction_rule", "required_action", "evidence_trace", "verification_note"]:
                value = str(row.get(field, "")).strip()
                if value.lower() in {"", "none", "todo", "unknown"}:
                    failures.append(f"resolved feedback {fid} missing usable {field}")
    if rows and no_feedback_count and len(rows) > no_feedback_count:
        failures.append("NO_USER_FEEDBACK sentinel cannot be mixed with real feedback rows")

    if active is not None:
        recorded = str(active.get("feedback_ledger_sha256", "")).strip()
        try:
            actual = sha256_file(feedback_jsonl, root=root)
        except Exception as exc:
            failures.append(f"cannot hash user_feedback_ledger.jsonl: {exc}")
            actual = ""
        if not re.fullmatch(r"[0-9a-f]{64}", recorded):
            failures.append("active_state.json feedback_ledger_sha256 missing or malformed")
        elif actual and recorded != actual:
            failures.append("active_state.json feedback_ledger_sha256 does not match user_feedback_ledger.jsonl")
        missing = sorted(carry_ids - set(active_ids))
        if missing:
            failures.append("carry-forward feedback ids missing from active_state.json: " + ", ".join(missing))
        unknown = sorted(set(active_ids) - feedback_ids)
        if unknown:
            failures.append("active_state.json references feedback ids not in user_feedback_ledger.jsonl: " + ", ".join(unknown))
        if release_mode:
            blocking_ids = [
                fid for fid in active_ids
                if any(str(r.get("feedback_id")) == fid and str(r.get("status", "")).upper() in RELEASE_BLOCKING for r in rows)
            ]
            if blocking_ids:
                failures.append("release package still has blocking active feedback ids: " + ", ".join(blocking_ids))

    try:
        active_md_text = read_optional_text(active_md, root=root)
    except Exception:
        active_md_text = ""
    if active is not None and active_md_text:
        for md_name, json_name in MD_BINDINGS.items():
            md_value = singleton_field(active_md_text, md_name, failures)
            json_value = str(active.get(json_name, "")).strip()
            if md_value and md_value != json_value:
                failures.append(f"active_state.md {md_name}={md_value!r} does not match active_state.json {json_name}={json_value!r}")
        md_ids = normalize_md_ids(singleton_field(active_md_text, "ACTIVE_FEEDBACK_IDS", failures))
        if md_ids != active_ids:
            failures.append(f"active_state.md ACTIVE_FEEDBACK_IDS {md_ids!r} does not exactly match active_state.json {active_ids!r}")
        resume_section = re.search(r"(?ms)^## Resume Instruction\s*\n(.*?)(?=^## |\Z)", active_md_text)
        md_resume = " ".join(resume_section.group(1).split()) if resume_section else ""
        json_resume = " ".join(str(active.get("resume_instruction", "")).split())
        if not md_resume:
            failures.append("active_state.md missing Resume Instruction body")
        elif md_resume != json_resume:
            failures.append("active_state.md Resume Instruction does not exactly mirror active_state.json")

    try:
        feedback_md_text = read_optional_text(feedback_md, root=root)
    except Exception:
        feedback_md_text = ""
    for fid in sorted(feedback_ids):
        expected = sum(1 for row in rows if str(row.get("feedback_id", "")).strip() == fid)
        actual = len(re.findall(rf"(?<![A-Za-z0-9_]){re.escape(fid)}(?![A-Za-z0-9_])", feedback_md_text))
        if fid != "UF0000" and actual < expected:
            failures.append(f"user_feedback_ledger.md mirror does not mention feedback id {fid} enough times")

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print(f"OK: mode={mode} feedback_rows={len(rows)} carry_forward={len(carry_ids)} mirrors=exact")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
