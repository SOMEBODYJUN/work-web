#!/usr/bin/env python3
"""Validate authoritative JSONL ledgers with fail-closed parsing and key contracts."""
from __future__ import annotations

from pathlib import Path
import re
import sys
from typing import Any

from mode_utils import parse_mode_args, resolve_mode, structured_jsonl_for_mode
from safe_io import read_jsonl_strict, read_optional_text

REQUIRED_JSONL = {
    "source_chunk_index.jsonl": {"chunk_id", "char_span"},
    "source_sentence_index.jsonl": {"sentence_id", "chunk_id", "char_span", "exact_sentence_or_line", "sentence_role", "atom_ids", "coverage_status", "notes"},
    "source_atom_ledger.jsonl": {"atom_id", "sentence_id", "chunk_id", "char_span", "source_excerpt", "atom_level", "atom_type", "author_intent", "math_role", "voice_role", "symbol_role", "punctuation_boundary", "ocr_state", "needed_action", "destination_status", "final_destination"},
    "source_formula_block_ledger.jsonl": {"formula_block_id", "source_span", "line_span", "fragment_count", "raw_fragment_hash", "canonical_formula", "canonicalization_status", "atom_ids", "review_status", "verification_note"},
    "author_question_obligation_ledger.jsonl": {"question_id", "source_span", "source_excerpt", "obligation_type", "required_action", "destination_file", "destination_anchor", "resolution_status", "response_trace", "verification_note"},
    "source_math_risk_ledger.jsonl": {"risk_id", "source_revision_id", "source_sha256", "source_span", "risk_type", "claim_excerpt", "reason", "required_review", "resolution_status", "resolution_note"},
    "user_feedback_ledger.jsonl": {"feedback_id", "source_turn", "feedback_excerpt", "feedback_type", "target_scope", "correction_rule", "required_action", "carry_forward", "status", "active_state_binding", "evidence_trace", "verification_note"},
    "final_claim_ledger.jsonl": {"claim_id", "file", "location", "claim_excerpt", "claim_type", "source_atoms", "statement_ids", "proof_ids", "support_type", "source_ownership", "transformation_scope", "verdict", "allowed_new_reason", "verification_note"},
    "publication_claim_ledger.jsonl": {"claim_id", "file", "location", "claim_excerpt", "claim_type", "source_atoms", "statement_ids", "proof_ids", "support_type", "source_ownership", "transformation_scope", "verdict", "allowed_new_reason", "verification_note"},
    "publication_sentence_trace.jsonl": {"sentence_trace_id", "file", "location", "sentence_or_heading", "unit_type", "source_atoms", "statement_ids", "proof_ids", "voice_ids", "symbol_ids", "chain_ids", "source_type", "allowed_new_reason", "verdict", "verification_note"},
    "cross_chunk_dependency_map.jsonl": {"dep_id", "consumer_chunk", "consumer_ids", "dependency_type", "provider_chunk", "provider_ids", "required_for_sections", "prefetch_files", "status", "verification_note"},
    "section_context_prefetch_plan.jsonl": {"prefetch_id", "section_id", "article_target", "consumer_chunks", "must_open_chunks", "must_open_dependency_ids", "must_open_files", "covered_dependency_ids", "status", "verification_note"},
    "section_execution_plan.jsonl": {"schema_version", "plan_id", "section_id", "source_revision_id", "source_atom_ids", "atom_contract_sha256", "required_invariants_json", "transformation_contract_json", "forbidden_changes_json", "function_realization_plan_json", "status"},
}

ID_FIELDS = {
    "source_chunk_index.jsonl": ("chunk_id", "C"),
    "source_sentence_index.jsonl": ("sentence_id", "T"),
    "source_atom_ledger.jsonl": ("atom_id", "A"),
    "source_formula_block_ledger.jsonl": ("formula_block_id", "FB"),
    "author_question_obligation_ledger.jsonl": ("question_id", "AQ"),
    "source_math_risk_ledger.jsonl": ("risk_id", "MR"),
    "user_feedback_ledger.jsonl": ("feedback_id", "UF"),
    "final_claim_ledger.jsonl": ("claim_id", "CL"),
    "publication_claim_ledger.jsonl": ("claim_id", "PCL"),
    "publication_sentence_trace.jsonl": ("sentence_trace_id", "PS"),
    "cross_chunk_dependency_map.jsonl": ("dep_id", "D"),
    "section_context_prefetch_plan.jsonl": ("prefetch_id", "PF"),
    "section_execution_plan.jsonl": ("plan_id", "SEP"),
}

OPTIONAL_EMPTY_FIELDS = {"notes", "verification_note", "location", "allowed_new_reason"}
CHUNK_ATOM_REQUIRED = REQUIRED_JSONL["source_atom_ledger.jsonl"]


def scalar(value: Any) -> bool:
    return value is None or isinstance(value, (str, int, float, bool))


def read_jsonl(path: Path) -> tuple[list[dict[str, Any]], list[str]]:
    try:
        rows = read_jsonl_strict(path)
    except Exception as exc:
        return [], [f"{path.as_posix()}: {exc}"]
    return rows, []


def validate_rows(rel: str, rows: list[dict[str, Any]], required: set[str]) -> list[str]:
    failures: list[str] = []
    id_field, prefix = ID_FIELDS.get(rel, (None, None))
    seen_ids: set[str] = set()
    for idx, row in enumerate(rows, start=1):
        missing = sorted(required - set(row))
        if missing:
            failures.append(f"{rel} row {idx} missing keys: {', '.join(missing)}")
        for key, value in row.items():
            if not scalar(value):
                failures.append(f"{rel} row {idx} key {key} must be scalar, not {type(value).__name__}")
            if key in required and key not in OPTIONAL_EMPTY_FIELDS and (value is None or str(value).strip() == ""):
                failures.append(f"{rel} row {idx} required field {key} is empty")
        if id_field and prefix:
            value = str(row.get(id_field, ""))
            if not re.fullmatch(rf"{re.escape(prefix)}\d{{3,}}", value):
                failures.append(f"{rel} row {idx} invalid {id_field}: {value!r}")
            elif value in seen_ids:
                failures.append(f"{rel} duplicate primary key {id_field}={value}")
            seen_ids.add(value)
    return failures


def validate_one(root: Path, rel: str, required: set[str]) -> list[str]:
    path = root / rel
    rows, failures = read_jsonl(path)
    failures.extend(validate_rows(rel, rows, required))
    md_rel = rel[:-6] + ".md"
    md_path = root / md_rel
    if not md_path.exists():
        failures.append(f"human-readable Markdown mirror missing for {rel}: {md_rel}")
    else:
        try:
            if not read_optional_text(md_path, root=root).strip():
                failures.append(f"human-readable Markdown mirror empty for {rel}: {md_rel}")
        except Exception as exc:
            failures.append(f"human-readable Markdown mirror unsafe or invalid UTF-8: {md_rel}: {exc}")
    return failures


def main() -> int:
    try:
        explicit_mode, args = parse_mode_args(sys.argv[1:])
    except ValueError as exc:
        print("FAILED")
        print(f"- {exc}")
        return 1
    root = (Path(args[0]) if args else Path(".")).resolve()
    try:
        mode = resolve_mode(root, explicit_mode)
    except ValueError as exc:
        print("FAILED")
        print(f"- {exc}")
        return 1

    failures: list[str] = []
    required_rels = structured_jsonl_for_mode(mode)
    for rel in sorted(required_rels):
        required = REQUIRED_JSONL.get(rel)
        if required is None:
            failures.append(f"no schema registered for required JSONL ledger: {rel}")
            continue
        failures.extend(validate_one(root, rel, required))

    chunk_rows, chunk_errors = read_jsonl(root / "source_chunk_index.jsonl")
    failures.extend(chunk_errors)
    chunk_ids = [str(row.get("chunk_id", "")) for row in chunk_rows if re.fullmatch(r"C\d{3,}", str(row.get("chunk_id", "")))]
    if len(chunk_ids) != len(set(chunk_ids)):
        failures.append("source_chunk_index.jsonl contains duplicate chunk_id values")

    chunk_dir = root / "chunk_ledger"
    for chunk_id in chunk_ids:
        candidates = [chunk_dir / f"chunk_{chunk_id}_atom_ledger.jsonl", chunk_dir / f"{chunk_id}_atom_ledger.jsonl"]
        chosen = next((path for path in candidates if path.exists()), candidates[0])
        rows, errors = read_jsonl(chosen)
        failures.extend(errors)
        failures.extend(validate_rows(chosen.relative_to(root).as_posix(), rows, CHUNK_ATOM_REQUIRED))
        seen_atoms: set[str] = set()
        for idx, row in enumerate(rows, start=1):
            atom_id = str(row.get("atom_id", ""))
            if atom_id in seen_atoms:
                failures.append(f"{chosen.relative_to(root)} duplicate atom_id {atom_id}")
            seen_atoms.add(atom_id)
            if str(row.get("chunk_id", "")) != chunk_id:
                failures.append(f"{chosen.relative_to(root)} row {idx} chunk_id does not match owner {chunk_id}")
        if not chosen.with_suffix(".md").exists():
            failures.append(f"Markdown mirror missing for chunk JSONL: {chosen.with_suffix('.md').relative_to(root)}")

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print("OK")
    print(f"mode={mode} structured_ledgers={len(required_rels)} chunk_ledgers={len(chunk_ids)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
