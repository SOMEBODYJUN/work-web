#!/usr/bin/env python3
"""Validate the two-layer surface-form decision chain.

P02 may conservatively prelock likely surface-bearing text, but it cannot approve
that semantic judgment. P04 rereads every atom, confirms or extends exact locks,
and may downgrade a false-positive prelock only with an explicit semantic reason.
This validator checks identities, hashes, exact cues, and complete review; it
does not infer prose meaning from the lexical candidate scan.
"""
from __future__ import annotations

from pathlib import Path
import json
import re
import sys

from content_authority import (
    SURFACE_REVIEW_SCHEMA,
    SURFACE_REVIEW_REQUIRED_FIELDS,
    atom_source_bytes,
    canonical_json,
    detect_surface_features,
    load_jsonl_objects,
    parse_json_field,
    sha256_bytes,
    surface_decision_sha256,
    surface_features_require_exact,
)


def fail(messages: list[str]) -> int:
    print("FAILED")
    for message in messages:
        print(f"- {message}")
    return 1


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    failures: list[str] = []
    review_path = root / "surface_decision_review.jsonl"

    try:
        _source, revision, atoms = atom_source_bytes(root)
    except Exception as exc:
        return fail([str(exc)])
    revision_id = str(revision.get("source_revision_id", ""))
    atoms_by_id = {str(row.get("atom_id", "")): row for row in atoms}
    required_review_ids: set[str] = set(atoms_by_id)
    expected_features: dict[str, list[str]] = {}
    p04_reviewed = bool(atoms_by_id) and all(
        str(atom.get("function_contract_stage", "")) == "P04_MATH_LOCKS"
        for atom in atoms_by_id.values()
    )
    if any(
        str(atom.get("function_contract_stage", "")) == "P04_MATH_LOCKS"
        for atom in atoms_by_id.values()
    ) and not p04_reviewed:
        failures.append("P04 surface review is only partially materialized")

    for atom_id, atom in atoms_by_id.items():
        content_type = str(atom.get("content_type", ""))
        excerpt = str(atom.get("raw_excerpt", ""))
        features = detect_surface_features(excerpt, content_type)
        expected_features[atom_id] = features

    if not review_path.exists():
        return fail(["missing surface_decision_review.jsonl for the all-atom surface review"])
    try:
        reviews = load_jsonl_objects(review_path)
    except Exception as exc:
        return fail([str(exc)])

    seen: set[str] = set()
    for index, row in enumerate(reviews, 1):
        missing = sorted(SURFACE_REVIEW_REQUIRED_FIELDS - set(row))
        atom_id = str(row.get("atom_id", f"<row:{index}>"))
        if missing:
            failures.append(f"{atom_id}: missing review fields: {', '.join(missing)}")
            continue
        if row.get("schema_version") != SURFACE_REVIEW_SCHEMA:
            failures.append(f"{atom_id}: invalid surface review schema")
        review_id = str(row.get("review_id", ""))
        if not re.fullmatch(r"SR\d{4,}", review_id):
            failures.append(f"{atom_id}: invalid review_id {review_id!r}")
        if atom_id in seen:
            failures.append(f"{atom_id}: duplicate surface review")
        seen.add(atom_id)
        atom = atoms_by_id.get(atom_id)
        if atom is None:
            failures.append(f"{atom_id}: review references unknown atom")
            continue
        if row.get("source_revision_id") != revision_id:
            failures.append(f"{atom_id}: review source revision is stale")
        expected_hash = surface_decision_sha256(atom)
        if row.get("atom_decision_sha256") != expected_hash:
            failures.append(f"{atom_id}: review does not bind the current surface decision")
        try:
            detected = parse_json_field(row.get("detected_features_json"), f"{atom_id}.detected_features_json", list)
        except Exception as exc:
            failures.append(str(exc))
            detected = []
        if detected != expected_features[atom_id]:
            failures.append(
                f"{atom_id}: reviewer feature evidence is stale or incomplete; "
                f"expected {expected_features[atom_id]!r}, got {detected!r}"
            )
        disposition = str(row.get("prelock_disposition", ""))
        decision = json.loads(str(atom.get("surface_decision_json", "{}")))
        if p04_reviewed:
            if row.get("reviewer_role") != "P04_SEMANTIC_CONTRACT_REVIEW":
                failures.append(
                    f"{atom_id}: reviewed surface decision must come from the P04 semantic reviewer"
                )
            if row.get("reviewer_verdict") != "APPROVED":
                failures.append(f"{atom_id}: P04 surface decision is not approved")
            if disposition not in {
                "CONFIRMED_PRELOCK",
                "DOWNGRADED_FALSE_POSITIVE",
                "ADDED_BY_P04",
                "NO_PRELOCK",
            }:
                failures.append(f"{atom_id}: invalid P04 prelock disposition {disposition!r}")
            if decision.get("review_status") != "APPROVED":
                failures.append(f"{atom_id}: P04 atom decision is not approved")
            if decision.get("prelock_disposition") != disposition:
                failures.append(f"{atom_id}: surface review disposition does not match atom decision")
        else:
            if row.get("reviewer_role") != "P02_DETERMINISTIC_CANDIDATE_SCAN":
                failures.append(f"{atom_id}: P02 row is not a deterministic candidate scan")
            if row.get("reviewer_verdict") != "PENDING_P04_REVIEW":
                failures.append(f"{atom_id}: P02 candidate must remain pending P04 review")
            if disposition != "PENDING_P04_REVIEW":
                failures.append(f"{atom_id}: P02 prelock disposition must remain pending")
            if decision.get("review_status") != "BLOCKED_REVIEW":
                failures.append(f"{atom_id}: P02 cannot approve a semantic surface decision")
        reason = str(row.get("reviewer_reason", "")).strip()
        if len(reason) < 12:
            failures.append(f"{atom_id}: reviewer_reason is too weak")
        if str(row.get("surface_group_id", "")) != str(atom.get("surface_group_id", "")):
            failures.append(f"{atom_id}: review surface group does not match atom")

        features = expected_features[atom_id]
        p02_prelock = str(atom.get("p02_surface_mode", atom.get("surface_mode", ""))) == "BYTE_EXACT"
        if not p04_reviewed and p02_prelock and atom.get("surface_mode") != "BYTE_EXACT":
            failures.append(f"{atom_id}: P02 failed to apply its conservative BYTE_EXACT prelock")
        if (
            p04_reviewed
            and p02_prelock
            and atom.get("surface_mode") != "BYTE_EXACT"
            and disposition != "DOWNGRADED_FALSE_POSITIVE"
        ):
            failures.append(f"{atom_id}: P04 downgraded a prelock without an explicit disposition")

    missing_reviews = sorted(required_review_ids - seen)
    if missing_reviews:
        failures.append("missing all-atom surface review rows for: " + ", ".join(missing_reviews))
    extra_reviews = sorted(seen - required_review_ids)
    if extra_reviews:
        failures.append("surface review contains non-required/unscoped atoms: " + ", ".join(extra_reviews))

    # Group-level reviewer coherence.
    groups: dict[str, list[str]] = {}
    for atom_id, atom in atoms_by_id.items():
        group_id = str(atom.get("surface_group_id", "")).strip()
        if group_id:
            groups.setdefault(group_id, []).append(atom_id)
    for group_id, atom_ids in groups.items():
        if not set(atom_ids).issubset(seen):
            failures.append(f"{group_id}: every contiguous exact group member requires review")

    if failures:
        return fail(failures)
    print("OK")
    stage = "P04_SEMANTIC_REVIEW" if p04_reviewed else "P02_CANDIDATE_SCAN"
    print(f"source_revision_id={revision_id} reviewed_atoms={len(seen)} review_stage={stage}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
