#!/usr/bin/env python3
"""Shared, topic-independent article-volume contracts and measurements."""
from __future__ import annotations

from collections import defaultdict
from math import ceil
from pathlib import Path
from typing import Any
import hashlib
import json
import re

from content_authority import (
    atom_contract_sha256,
    load_jsonl_objects,
    split_ids,
    split_output_units,
)
from content_functions import normalize_functions, stage_function_reviews
from safe_io import atomic_write_json, read_json_strict


AUTHOR_TASK_SCHEMA = "author-task-contract-v1"
QUALITY_SCHEMA = "quality-contract-v1"
CJK_RE = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")
MATH_RE = re.compile(
    r"\$\$.*?\$\$|(?<!\\)\$(?!\$).*?(?<!\\)\$|\\\[.*?\\\]|\\\(.*?\\\)",
    re.S,
)


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cjk_count(text: str) -> int:
    return len(CJK_RE.findall(text))


def measure_prose(text: str) -> dict[str, int]:
    """Count prose CJK separately from headings, code, and displayed math."""
    units = split_output_units(text)
    prose_parts: list[str] = []
    math_parts: list[str] = []
    for unit in units:
        if unit.unit_type in {"heading", "code_block"}:
            continue
        if unit.unit_type == "formula_block":
            math_parts.append(unit.text)
            continue
        math_parts.extend(match.group(0) for match in MATH_RE.finditer(unit.text))
        prose_parts.append(MATH_RE.sub("", unit.text))
    return {
        "prose_cjk": sum(cjk_count(part) for part in prose_parts),
        "math_nonspace_chars": sum(len(re.sub(r"\s+", "", part)) for part in math_parts),
        "heading_cjk": sum(cjk_count(unit.text) for unit in units if unit.unit_type == "heading"),
    }


def validate_author_task_contract(value: Any) -> list[str]:
    errors: list[str] = []
    if not isinstance(value, dict):
        return ["author_task_contract.json must contain one JSON object"]
    required = {
        "schema_version", "task_id", "author_request", "task_mode",
        "author_confirmation", "source_preservation", "article_volume",
        "expansion_directives", "structure_requirements",
        "non_negotiable_requirements", "unresolved_author_choices",
    }
    missing = sorted(required - set(value))
    if missing:
        errors.append("author task contract missing fields: " + ", ".join(missing))
        return errors
    if value.get("schema_version") != AUTHOR_TASK_SCHEMA:
        errors.append(f"schema_version must be {AUTHOR_TASK_SCHEMA}")
    if not re.fullmatch(r"TASK-[A-Z0-9][A-Z0-9_-]{5,63}", str(value.get("task_id", ""))):
        errors.append("task_id is invalid")
    if not str(value.get("author_request", "")).strip():
        errors.append("author_request must preserve the actual author request")
    mode = str(value.get("task_mode", ""))
    if mode not in {"PRESERVE_REORGANIZE", "PRESERVE_AND_EXPAND", "AUTHORIZED_SUMMARY"}:
        errors.append(f"unsupported task_mode: {mode!r}")

    confirmation = value.get("author_confirmation")
    if not isinstance(confirmation, dict):
        errors.append("author_confirmation must be an object")
    else:
        if confirmation.get("status") not in {"DIRECT_REQUEST_SUFFICIENT", "CONFIRMED_BY_AUTHOR"}:
            errors.append("author_confirmation.status is invalid")
        if not str(confirmation.get("evidence", "")).strip():
            errors.append("author_confirmation.evidence is required")

    policy = value.get("source_preservation")
    if not isinstance(policy, dict):
        errors.append("source_preservation must be an object")
        policy = {}
    for key in (
        "summary_authorized", "minimum_source_cjk_ratio",
        "minimum_substantive_atom_cjk_ratio", "minimum_atom_source_cjk",
        "maximum_atoms_per_target_unit", "omission_policy",
    ):
        if key not in policy:
            errors.append(f"source_preservation.{key} is required")
    try:
        source_ratio = float(policy.get("minimum_source_cjk_ratio"))
        atom_ratio = float(policy.get("minimum_substantive_atom_cjk_ratio"))
        atom_floor = int(policy.get("minimum_atom_source_cjk"))
        max_atoms = int(policy.get("maximum_atoms_per_target_unit"))
    except Exception:
        errors.append("source-preservation numeric fields are invalid")
        source_ratio = atom_ratio = 0.0
        atom_floor = max_atoms = 0
    summary_authorized = policy.get("summary_authorized") is True
    if mode != "AUTHORIZED_SUMMARY" and summary_authorized:
        errors.append("summary_authorized may be true only in AUTHORIZED_SUMMARY mode")
    if mode != "AUTHORIZED_SUMMARY" and source_ratio < 1.0:
        errors.append("a non-summary task requires minimum_source_cjk_ratio >= 1.0")
    if not 0 <= atom_ratio <= 1:
        errors.append("minimum_substantive_atom_cjk_ratio must be between 0 and 1")
    if atom_floor < 1:
        errors.append("minimum_atom_source_cjk must be positive")
    if not 1 <= max_atoms <= 3:
        errors.append("maximum_atoms_per_target_unit must be between 1 and 3")
    if policy.get("omission_policy") not in {
        "NONE", "EXPLICIT_SOURCE_SPANS_ONLY", "AUTHOR_APPROVED_SOURCE_SPANS_ONLY"
    }:
        errors.append("omission_policy is invalid")

    volume = value.get("article_volume")
    if not isinstance(volume, dict):
        errors.append("article_volume must be an object")
        volume = {}
    try:
        total_ratio = float(volume.get("minimum_total_cjk_ratio"))
    except Exception:
        total_ratio = -1
        errors.append("article_volume.minimum_total_cjk_ratio is invalid")
    if volume.get("count_headings_as_explanation") is not False:
        errors.append("headings cannot count as explanatory volume")
    if volume.get("count_math_as_explanation") is not False:
        errors.append("math cannot count as explanatory volume")
    if total_ratio < source_ratio:
        errors.append("minimum_total_cjk_ratio cannot be below minimum_source_cjk_ratio")

    directives = value.get("expansion_directives")
    if not isinstance(directives, list):
        errors.append("expansion_directives must be a list")
        directives = []
    seen: set[str] = set()
    expansion_ratio = 0.0
    for index, directive in enumerate(directives, 1):
        label = f"expansion_directives[{index}]"
        if not isinstance(directive, dict):
            errors.append(f"{label} must be an object")
            continue
        directive_id = str(directive.get("directive_id", ""))
        if not re.fullmatch(r"EXP\d{3,}", directive_id) or directive_id in seen:
            errors.append(f"{label}.directive_id is invalid or duplicated")
        seen.add(directive_id)
        if len(str(directive.get("instruction", "")).strip()) < 8:
            errors.append(f"{label}.instruction is too shallow")
        try:
            ratio = float(directive.get("minimum_added_cjk_ratio_of_source"))
        except Exception:
            ratio = 0
        if ratio <= 0:
            errors.append(f"{label}.minimum_added_cjk_ratio_of_source must be positive")
        expansion_ratio += max(0.0, ratio)
        criteria = directive.get("acceptance_criteria")
        if not isinstance(criteria, list) or not criteria or any(len(str(x).strip()) < 4 for x in criteria):
            errors.append(f"{label}.acceptance_criteria must be a nonempty substantive list")
    if mode == "PRESERVE_AND_EXPAND":
        if not directives:
            errors.append("PRESERVE_AND_EXPAND requires at least one expansion directive")
        if total_ratio <= source_ratio:
            errors.append("PRESERVE_AND_EXPAND requires real total-volume growth")
        if expansion_ratio + 1e-9 < total_ratio - source_ratio:
            errors.append("expansion-directive budgets do not cover the required total growth")
    elif directives:
        errors.append("expansion directives require PRESERVE_AND_EXPAND mode")

    requirements = value.get("non_negotiable_requirements")
    if not isinstance(requirements, list) or not requirements:
        errors.append("non_negotiable_requirements must be nonempty")
    unresolved = value.get("unresolved_author_choices")
    if not isinstance(unresolved, list):
        errors.append("unresolved_author_choices must be a list")
    elif unresolved:
        errors.append("unresolved author choices block task-contract activation")
    return errors


def load_author_task_contract(root: Path) -> dict[str, Any]:
    path = root / "author_task_contract.json"
    value = read_json_strict(path, root=root)
    errors = validate_author_task_contract(value)
    if errors:
        raise ValueError("; ".join(errors))
    return value


def _directive_assignments(plan_rows: list[dict[str, Any]]) -> dict[str, str]:
    assignments: dict[str, str] = {}
    for row in plan_rows:
        section_id = str(row.get("section_id", ""))
        for directive_id in re.findall(r"\bEXP\d{3,}\b", str(row.get("expansion_directive_ids", ""))):
            if directive_id in assignments:
                raise ValueError(f"{directive_id}: expansion directive is assigned to multiple sections")
            assignments[directive_id] = section_id
    return assignments


def compile_quality_contract(root: Path) -> dict[str, Any]:
    task = load_author_task_contract(root)
    source_path = root / "source_canonical.txt"
    revision_path = root / "source_revision.json"
    atom_path = root / "source_atom_ledger.jsonl"
    plan_path = root / "section_execution_plan.jsonl"
    source = source_path.read_text(encoding="utf-8", errors="strict")
    revision = read_json_strict(revision_path, root=root)
    atoms = load_jsonl_objects(atom_path)
    plans = load_jsonl_objects(plan_path)
    assignments = _directive_assignments(plans)
    directives = {str(row["directive_id"]): row for row in task["expansion_directives"]}
    if set(assignments) != set(directives):
        missing = sorted(set(directives) - set(assignments))
        extra = sorted(set(assignments) - set(directives))
        raise ValueError(
            "section plan expansion assignments mismatch task contract; "
            f"missing={missing} extra={extra}"
        )

    source_metrics = measure_prose(source)
    source_cjk = source_metrics["prose_cjk"]
    policy = task["source_preservation"]
    volume = task["article_volume"]
    source_ratio = float(policy["minimum_source_cjk_ratio"])
    atom_ratio = float(policy["minimum_substantive_atom_cjk_ratio"])
    atom_floor = int(policy["minimum_atom_source_cjk"])

    atom_budgets: list[dict[str, Any]] = []
    atom_by_id = {str(atom["atom_id"]): atom for atom in atoms}
    for atom in atoms:
        atom_id = str(atom["atom_id"])
        atom_cjk = cjk_count(str(atom.get("raw_excerpt", "")))
        functions = normalize_functions(atom.get("required_functions"), f"{atom_id}.required_functions")
        measured = (
            "SUBSTANTIVE_CONTENT" in functions
            and str(atom.get("content_type", "")) not in {"DUPLICATE", "PLACEHOLDER"}
            and atom_cjk >= atom_floor
        )
        atom_budgets.append({
            "atom_id": atom_id,
            "source_cjk": atom_cjk,
            "measured_as_substantive": measured,
            "minimum_target_cjk": ceil(atom_cjk * atom_ratio) if measured else 0,
        })

    directive_budgets: list[dict[str, Any]] = []
    for directive_id, directive in directives.items():
        ratio = float(directive["minimum_added_cjk_ratio_of_source"])
        directive_budgets.append({
            "directive_id": directive_id,
            "section_id": assignments[directive_id],
            "instruction": directive["instruction"],
            "acceptance_criteria": directive["acceptance_criteria"],
            "minimum_added_cjk": ceil(source_cjk * ratio),
        })
    directive_budget_by_section: dict[str, int] = defaultdict(int)
    for directive in directive_budgets:
        directive_budget_by_section[directive["section_id"]] += int(directive["minimum_added_cjk"])

    section_budgets: list[dict[str, Any]] = []
    for row in plans:
        section_id = str(row["section_id"])
        atom_ids = split_ids(row.get("source_atom_ids"), "A")
        section_source_cjk = sum(
            cjk_count(str(atom_by_id[atom_id].get("raw_excerpt", "")))
            for atom_id in atom_ids
            if atom_id in atom_by_id
            and str(atom_by_id[atom_id].get("content_type", "")) != "DUPLICATE"
        )
        minimum_source = ceil(section_source_cjk * source_ratio)
        expansion = directive_budget_by_section[section_id]
        section_budgets.append({
            "section_id": section_id,
            "section_order": int(row["section_order"]),
            "section_title": str(row["section_title"]),
            "source_atom_ids": atom_ids,
            "source_cjk": section_source_cjk,
            "minimum_source_realization_cjk": minimum_source,
            "minimum_expansion_cjk": expansion,
            "minimum_total_cjk": minimum_source + expansion,
        })

    minimum_source = ceil(source_cjk * source_ratio)
    minimum_expansion = sum(int(item["minimum_added_cjk"]) for item in directive_budgets)
    minimum_total = max(
        ceil(source_cjk * float(volume["minimum_total_cjk_ratio"])),
        minimum_source + minimum_expansion,
    )
    return {
        "schema_version": QUALITY_SCHEMA,
        "compiled_from": {
            "author_task_contract_sha256": sha256_file(root / "author_task_contract.json"),
            "source_revision_id": str(revision.get("source_revision_id", "")),
            "source_sha256": sha256_file(source_path),
            "source_atom_ledger_sha256": sha256_file(atom_path),
            "atom_contract_sha256": atom_contract_sha256(atoms),
            "section_execution_plan_sha256": sha256_file(plan_path),
        },
        "measurement_policy": {
            "prose_cjk": "CJK ideographs outside headings, code blocks, and recognized math spans",
            "math_accounting": "SEPARATE_NOT_CREDITED_AS_EXPLANATION",
            "omission_credit": "NONE_WITHOUT_A_NEW_AUTHOR_TASK_CONTRACT",
        },
        "source_measurements": source_metrics,
        "thresholds": {
            "minimum_source_cjk_ratio": source_ratio,
            "minimum_substantive_atom_cjk_ratio": atom_ratio,
            "minimum_atom_source_cjk": atom_floor,
            "maximum_atoms_per_target_unit": int(policy["maximum_atoms_per_target_unit"]),
            "minimum_total_cjk_ratio": float(volume["minimum_total_cjk_ratio"]),
            "minimum_source_realization_cjk": minimum_source,
            "minimum_expansion_cjk": minimum_expansion,
            "minimum_article_cjk": minimum_total,
        },
        "atom_budgets": atom_budgets,
        "section_budgets": sorted(section_budgets, key=lambda row: row["section_order"]),
        "expansion_budgets": directive_budgets,
    }


def validate_quality_contract(root: Path, contract: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if contract.get("schema_version") != QUALITY_SCHEMA:
        return [f"quality_contract.json schema_version must be {QUALITY_SCHEMA}"]
    expected = compile_quality_contract(root)
    if contract != expected:
        errors.append("quality_contract.json is stale or differs from deterministic compilation")
    return errors


def write_quality_contract(root: Path) -> dict[str, Any]:
    contract = compile_quality_contract(root)
    atomic_write_json(root / "quality_contract.json", contract)
    return contract


def _evidence_units(review: dict[str, Any]) -> list[str]:
    found: list[str] = []
    results = review.get("function_results", {})
    if not isinstance(results, dict):
        return found
    for result in results.values():
        if not isinstance(result, dict):
            continue
        raw = result.get("target_evidence", [])
        values = raw if isinstance(raw, list) else [raw]
        for value in values:
            text = str(value).strip()
            if text and text not in found:
                found.append(text)
    return found


def evaluate_quality_stage(
    root: Path, stage_id: str, target_file: str
) -> tuple[dict[str, Any], list[str]]:
    errors: list[str] = []
    contract = read_json_strict(root / "quality_contract.json", root=root)
    if not isinstance(contract, dict):
        return {}, ["quality_contract.json must contain one object"]
    errors.extend(validate_quality_contract(root, contract))
    target_path = root / target_file
    target_text = target_path.read_text(encoding="utf-8", errors="strict")
    target_sha = sha256_file(target_path)
    target_units = split_output_units(target_text)
    unit_by_text: dict[str, list[Any]] = defaultdict(list)
    for unit in target_units:
        unit_by_text[unit.text].append(unit)

    blueprint = read_json_strict(root / "publication_blueprint.json", root=root)
    atoms = load_jsonl_objects(root / "source_atom_ledger.jsonl")
    reviews, review_errors = stage_function_reviews(
        root,
        blueprint,
        atoms,
        stage_id,
        target_file,
        require_all_atoms=True,
        require_function_matrix=True,
    )
    errors.extend(review_errors)

    atom_unit_ids: dict[str, set[str]] = defaultdict(set)
    source_unit_ids: set[str] = set()
    for atom_id, review in reviews.items():
        for evidence in _evidence_units(review):
            matches = unit_by_text.get(evidence, [])
            if len(matches) == 1:
                unit_id = matches[0].output_unit_id
                atom_unit_ids[atom_id].add(unit_id)
                source_unit_ids.add(unit_id)
    units_by_id = {unit.output_unit_id: unit for unit in target_units}

    atom_results: list[dict[str, Any]] = []
    for budget in contract.get("atom_budgets", []):
        atom_id = str(budget.get("atom_id", ""))
        actual = sum(cjk_count(units_by_id[unit_id].text) for unit_id in atom_unit_ids.get(atom_id, set()))
        minimum = int(budget.get("minimum_target_cjk", 0))
        passed = actual >= minimum
        atom_results.append({
            "atom_id": atom_id,
            "source_cjk": int(budget.get("source_cjk", 0)),
            "minimum_target_cjk": minimum,
            "actual_target_cjk": actual,
            "status": "MEASURED_PASS" if passed else "MEASURED_FAIL",
        })
        if budget.get("measured_as_substantive") and not passed:
            errors.append(f"{stage_id}:{atom_id}: target prose CJK {actual} below contract minimum {minimum}")

    expansion_rows = blueprint.get("task_requirement_reviews", [])
    if not isinstance(expansion_rows, list):
        errors.append("publication blueprint task_requirement_reviews must be a list")
        expansion_rows = []
    stage_expansion = [
        row for row in expansion_rows
        if isinstance(row, dict) and row.get("stage_id") == stage_id
    ]
    expansion_by_id: dict[str, dict[str, Any]] = {}
    expansion_unit_ids: set[str] = set()
    expansion_results: list[dict[str, Any]] = []
    for row in stage_expansion:
        directive_id = str(row.get("directive_id", ""))
        if directive_id in expansion_by_id:
            errors.append(f"{stage_id}:{directive_id}: duplicate task-requirement review")
            continue
        expansion_by_id[directive_id] = row
    expected_expansions = {
        str(row["directive_id"]): row for row in contract.get("expansion_budgets", [])
    }
    unknown = sorted(set(expansion_by_id) - set(expected_expansions))
    if unknown:
        errors.append(f"{stage_id}: unknown expansion directives: {', '.join(unknown)}")
    for directive_id, budget in expected_expansions.items():
        row = expansion_by_id.get(directive_id)
        unit_ids: set[str] = set()
        if row is None:
            errors.append(f"{stage_id}:{directive_id}: missing task-requirement review")
            row = {}
        if str(row.get("target_file", "")) != target_file:
            errors.append(f"{stage_id}:{directive_id}: target_file must be {target_file}")
        if str(row.get("target_sha256", "")) != target_sha:
            errors.append(f"{stage_id}:{directive_id}: target hash is stale")
        if str(row.get("section_id", "")) != str(budget.get("section_id", "")):
            errors.append(f"{stage_id}:{directive_id}: section assignment differs from P05")
        if str(row.get("status", "")) != "FULFILLED":
            errors.append(f"{stage_id}:{directive_id}: status must be FULFILLED")
        evidence = row.get("target_evidence", [])
        evidence = evidence if isinstance(evidence, list) else [evidence]
        for item in evidence:
            text = str(item).strip()
            matches = unit_by_text.get(text, [])
            if len(matches) != 1 or matches[0].unit_type == "heading":
                errors.append(f"{stage_id}:{directive_id}: expansion evidence must equal one unique complete non-heading output unit")
                continue
            unit_id = matches[0].output_unit_id
            if unit_id in source_unit_ids:
                errors.append(f"{stage_id}:{directive_id}: expansion evidence overlaps source-realization evidence")
            if unit_id in expansion_unit_ids:
                errors.append(f"{stage_id}:{directive_id}: expansion evidence is reused by another directive")
            unit_ids.add(unit_id)
            expansion_unit_ids.add(unit_id)
        criteria = row.get("acceptance_results")
        expected_criteria = list(budget.get("acceptance_criteria", []))
        if not isinstance(criteria, list):
            criteria = []
        criterion_map = {
            str(item.get("criterion", "")): item
            for item in criteria if isinstance(item, dict)
        }
        if set(criterion_map) != set(expected_criteria):
            errors.append(f"{stage_id}:{directive_id}: acceptance results do not exactly cover task criteria")
        for criterion, item in criterion_map.items():
            if item.get("status") != "SATISFIED" or len(str(item.get("reason", "")).strip()) < 12:
                errors.append(f"{stage_id}:{directive_id}: criterion is not substantively satisfied: {criterion}")
        if len(str(row.get("reason", "")).strip()) < 12:
            errors.append(f"{stage_id}:{directive_id}: fulfillment reason is too shallow")
        actual = sum(cjk_count(units_by_id[unit_id].text) for unit_id in unit_ids)
        minimum = int(budget.get("minimum_added_cjk", 0))
        if actual < minimum:
            errors.append(f"{stage_id}:{directive_id}: added prose CJK {actual} below contract minimum {minimum}")
        expansion_results.append({
            "directive_id": directive_id,
            "minimum_added_cjk": minimum,
            "actual_added_cjk": actual,
            "status": "MEASURED_PASS" if actual >= minimum else "MEASURED_FAIL",
        })

    section_results: list[dict[str, Any]] = []
    heading_positions: dict[str, list[int]] = defaultdict(list)
    for index, unit in enumerate(target_units):
        if unit.unit_type == "heading":
            heading_positions[re.sub(r"^#{1,6}\s*", "", unit.text).strip()].append(index)
    last_heading_position = -1
    for budget in contract.get("section_budgets", []):
        section_id = str(budget.get("section_id", ""))
        section_title = str(budget.get("section_title", ""))
        positions = heading_positions.get(section_title, [])
        if len(positions) != 1:
            errors.append(f"{stage_id}:{section_id}: planned section heading must occur exactly once: {section_title}")
        elif positions[0] <= last_heading_position:
            errors.append(f"{stage_id}:{section_id}: planned section heading order regressed")
        else:
            last_heading_position = positions[0]
        section_source_units: set[str] = set()
        for atom_id in budget.get("source_atom_ids", []):
            section_source_units.update(atom_unit_ids.get(str(atom_id), set()))
        actual_source = sum(cjk_count(units_by_id[unit_id].text) for unit_id in section_source_units)
        actual_expansion = sum(
            row["actual_added_cjk"]
            for row in expansion_results
            if expected_expansions.get(row["directive_id"], {}).get("section_id") == section_id
        )
        minimum_source = int(budget.get("minimum_source_realization_cjk", 0))
        minimum_expansion = int(budget.get("minimum_expansion_cjk", 0))
        if actual_source < minimum_source:
            errors.append(f"{stage_id}:{section_id}: source-realization CJK {actual_source} below section minimum {minimum_source}")
        if actual_expansion < minimum_expansion:
            errors.append(f"{stage_id}:{section_id}: expansion CJK {actual_expansion} below section minimum {minimum_expansion}")
        section_results.append({
            "section_id": section_id,
            "minimum_source_realization_cjk": minimum_source,
            "actual_source_realization_cjk": actual_source,
            "minimum_expansion_cjk": minimum_expansion,
            "actual_expansion_cjk": actual_expansion,
            "status": "MEASURED_PASS" if actual_source >= minimum_source and actual_expansion >= minimum_expansion else "MEASURED_FAIL",
        })

    target_metrics = measure_prose(target_text)
    thresholds = contract.get("thresholds", {})
    actual_source_realization = sum(
        cjk_count(units_by_id[unit_id].text) for unit_id in source_unit_ids
    )
    if actual_source_realization < int(thresholds.get("minimum_source_realization_cjk", 0)):
        errors.append(
            f"{stage_id}: source-realization CJK {actual_source_realization} below contract minimum "
            f"{thresholds.get('minimum_source_realization_cjk', 0)}"
        )
    if target_metrics["prose_cjk"] < int(thresholds.get("minimum_article_cjk", 0)):
        errors.append(
            f"{stage_id}: article prose CJK {target_metrics['prose_cjk']} below contract minimum "
            f"{thresholds.get('minimum_article_cjk', 0)}"
        )
    report = {
        "schema_version": "quality-measurement-v1",
        "stage_id": stage_id,
        "target_file": target_file,
        "target_sha256": target_sha,
        "quality_contract_sha256": sha256_file(root / "quality_contract.json"),
        "source_prose_cjk": int(contract.get("source_measurements", {}).get("prose_cjk", 0)),
        "target_measurements": target_metrics,
        "minimum_source_realization_cjk": int(thresholds.get("minimum_source_realization_cjk", 0)),
        "actual_source_realization_cjk": actual_source_realization,
        "minimum_expansion_cjk": int(thresholds.get("minimum_expansion_cjk", 0)),
        "actual_expansion_cjk": sum(row["actual_added_cjk"] for row in expansion_results),
        "minimum_article_cjk": int(thresholds.get("minimum_article_cjk", 0)),
        "atom_results": atom_results,
        "section_results": section_results,
        "expansion_results": expansion_results,
        "verdict": "MEASURED_PASS" if not errors else "MEASURED_FAIL",
    }
    return report, errors
