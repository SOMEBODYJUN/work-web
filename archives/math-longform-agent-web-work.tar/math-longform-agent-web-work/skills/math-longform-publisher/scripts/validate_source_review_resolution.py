#!/usr/bin/env python3
"""Require all source-intake review blockers to be resolved before publication."""
from __future__ import annotations

from pathlib import Path
import sys

from source_review_state import unresolved_source_review_counts


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    counts = unresolved_source_review_counts(root)
    failures: list[str] = []
    for name, count in counts.items():
        if count < 0:
            failures.append(f"{name}: missing or invalid")
        elif count:
            failures.append(f"{name}: unresolved blockers={count}")
    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print("OK: source review blockers resolved")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
