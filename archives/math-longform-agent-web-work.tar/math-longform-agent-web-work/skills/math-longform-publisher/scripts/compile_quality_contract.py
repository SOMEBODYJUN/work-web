#!/usr/bin/env python3
"""Compile the one authoritative per-run quality contract after P05 planning."""
from pathlib import Path
import sys

from quality_contract import write_quality_contract


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    try:
        contract = write_quality_contract(root.resolve())
    except Exception as exc:
        print(f"FAILED: {exc}")
        return 1
    thresholds = contract["thresholds"]
    print("QUALITY_CONTRACT_COMPILED")
    print(
        f"source_cjk={contract['source_measurements']['prose_cjk']} "
        f"minimum_article_cjk={thresholds['minimum_article_cjk']} "
        f"atoms={len(contract['atom_budgets'])} sections={len(contract['section_budgets'])}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
