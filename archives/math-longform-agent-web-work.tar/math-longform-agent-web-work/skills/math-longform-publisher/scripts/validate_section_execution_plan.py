#!/usr/bin/env python3
"""Validate that P05 compiles every Atom function into a writing obligation."""
from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path
from typing import Any
import re
import sys

from content_authority import (
    SECTION_PLAN_SCHEMA,
    SECTION_PLAN_REQUIRED_FIELDS,
    TRANSFORMATION_KINDS,
    atom_contract_sha256,
    atom_map,
    atom_source_bytes,
    canonical_json,
    load_jsonl_objects,
    parse_json_field,
    sha256_bytes,
    split_ids,
)
from content_functions import normalize_functions
from quality_contract import load_author_task_contract
from safe_io import read_json_strict
from source_obligations import obligation_ids_by_pair, source_obligation_contracts


def fail(messages: list[str]) -> int:
    print("FAILED")
    for message in messages:
        print(f"- {message}")
    return 1


def invariant_hash(atom: dict[str, Any]) -> str:
    parsed = parse_json_field(
        atom.get("content_invariant_json"),
        f"{atom.get('atom_id')}.content_invariant_json",
        dict,
    )
    return sha256_bytes(canonical_json(parsed).encode("utf-8"))


def expected_pairs(atoms: list[dict[str, Any]]) -> set[tuple[str, str]]:
    pairs: set[tuple[str, str]] = set()
    for atom in atoms:
        atom_id = str(atom.get("atom_id", ""))
        functions = normalize_functions(
            atom.get("required_functions"), f"{atom_id}.required_functions"
        )
        pairs.update((atom_id, function) for function in functions)
    return pairs


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    plan_path = root / "section_execution_plan.jsonl"
    failures: list[str] = []

    if not plan_path.exists():
        return fail(["missing authoritative section_execution_plan.jsonl"])
    try:
        _source, revision, atom_rows = atom_source_bytes(root)
        atoms = atom_map(atom_rows)
        plan_rows = load_jsonl_objects(plan_path)
        chunk_rows = load_jsonl_objects(root / "source_chunk_index.jsonl")
        task_contract = load_author_task_contract(root)
        if (root / "publication_blueprint.json").is_file():
            blueprint = read_json_strict(root / "publication_blueprint.json", root=root)
            if not isinstance(blueprint, dict):
                raise ValueError("publication_blueprint.json must contain one object")
            source_obligation_rows, source_obligation_errors = source_obligation_contracts(
                root, blueprint, atom_rows, require_ledgers=False
            )
            if source_obligation_errors:
                raise ValueError("; ".join(source_obligation_errors[:16]))
            expected_obligation_ids = obligation_ids_by_pair(source_obligation_rows)
        else:
            expected_obligation_ids = {}
    except Exception as exc:
        return fail([str(exc)])

    revision_id = str(revision.get("source_revision_id", ""))
    planned_atom_counts: Counter[str] = Counter()
    planned_pair_counts: Counter[tuple[str, str]] = Counter()
    seen_plan_ids: set[str] = set()
    seen_section_ids: set[str] = set()
    seen_realization_ids: set[str] = set()
    groups: dict[str, list[tuple[str, dict[str, Any]]]] = defaultdict(list)
    directive_assignments: Counter[str] = Counter()
    known_directives = {
        str(row["directive_id"]) for row in task_contract["expansion_directives"]
    }

    if len(chunk_rows) > 1 and len(plan_rows) < 2:
        failures.append(
            "multi-chunk source cannot be collapsed into one section execution row"
        )

    for index, row in enumerate(plan_rows, 1):
        plan_id = str(row.get("plan_id", f"<row:{index}>"))
        section_id = str(row.get("section_id", ""))
        missing = sorted(SECTION_PLAN_REQUIRED_FIELDS - set(row))
        if missing:
            failures.append(f"{plan_id}: missing fields: {', '.join(missing)}")
            continue
        if row.get("schema_version") != SECTION_PLAN_SCHEMA:
            failures.append(f"{plan_id}: schema_version must be {SECTION_PLAN_SCHEMA}")
        if not re.fullmatch(r"SEP\d{4,}", plan_id):
            failures.append(f"row {index}: invalid plan_id {plan_id!r}")
        elif plan_id in seen_plan_ids:
            failures.append(f"duplicate plan_id: {plan_id}")
        seen_plan_ids.add(plan_id)
        if not re.fullmatch(r"SEC\d{3,}", section_id):
            failures.append(f"{plan_id}: invalid section_id {section_id!r}")
        elif section_id in seen_section_ids:
            failures.append(f"duplicate section_id: {section_id}")
        seen_section_ids.add(section_id)
        try:
            section_order = int(row.get("section_order"))
        except Exception:
            section_order = -1
        if section_order != index:
            failures.append(f"{plan_id}: section_order must be the contiguous row order {index}")
        if len(str(row.get("section_title", "")).strip()) < 2:
            failures.append(f"{plan_id}: section_title is too shallow")
        expansion_ids = re.findall(
            r"\bEXP\d{3,}\b", str(row.get("expansion_directive_ids", ""))
        )
        if len(expansion_ids) != len(set(expansion_ids)):
            failures.append(f"{plan_id}: duplicate expansion directive IDs")
        unknown_expansions = sorted(set(expansion_ids) - known_directives)
        if unknown_expansions:
            failures.append(
                f"{plan_id}: unknown expansion directives: {', '.join(unknown_expansions)}"
            )
        directive_assignments.update(expansion_ids)
        if row.get("source_revision_id") != revision_id:
            failures.append(f"{plan_id}: source_revision_id does not match current source revision")
        if row.get("status") != "READY_FOR_DRAFT":
            failures.append(f"{plan_id}: status must be READY_FOR_DRAFT")

        atom_ids = split_ids(row.get("source_atom_ids"), "A")
        if not atom_ids:
            failures.append(f"{plan_id}: source_atom_ids must not be empty")
            continue
        if len(atom_ids) != len(set(atom_ids)):
            failures.append(f"{plan_id}: duplicate atom IDs in source_atom_ids")
        unknown = [atom_id for atom_id in atom_ids if atom_id not in atoms]
        if unknown:
            failures.append(f"{plan_id}: unknown source atoms: {', '.join(unknown)}")
            continue
        for atom_id in atom_ids:
            planned_atom_counts[atom_id] += 1

        selected = [atoms[atom_id] for atom_id in atom_ids]
        if row.get("atom_contract_sha256") != atom_contract_sha256(selected):
            failures.append(f"{plan_id}: atom_contract_sha256 is stale or incorrect")

        try:
            invariant_map = parse_json_field(
                row.get("required_invariants_json"),
                f"{plan_id}.required_invariants_json",
                dict,
            )
            transform_map = parse_json_field(
                row.get("transformation_contract_json"),
                f"{plan_id}.transformation_contract_json",
                dict,
            )
            forbidden_map = parse_json_field(
                row.get("forbidden_changes_json"),
                f"{plan_id}.forbidden_changes_json",
                dict,
            )
            realizations = parse_json_field(
                row.get("function_realization_plan_json"),
                f"{plan_id}.function_realization_plan_json",
                list,
            )
        except Exception as exc:
            failures.append(str(exc))
            continue

        expected_keys = set(atom_ids)
        for label, mapping in (
            ("required_invariants_json", invariant_map),
            ("transformation_contract_json", transform_map),
        ):
            if set(mapping) != expected_keys:
                failures.append(f"{plan_id}: {label} keys must exactly equal source_atom_ids")
        nonexact_keys = {
            atom_id
            for atom_id in atom_ids
            if atoms[atom_id].get("surface_mode") != "BYTE_EXACT"
        }
        if set(forbidden_map) != nonexact_keys:
            failures.append(
                f"{plan_id}: forbidden_changes_json must contain exactly the non-BYTE_EXACT atoms"
            )

        for atom_id in atom_ids:
            try:
                expected_inv_hash = invariant_hash(atoms[atom_id])
            except Exception as exc:
                failures.append(str(exc))
                continue
            if invariant_map.get(atom_id) != expected_inv_hash:
                failures.append(f"{plan_id}: invariant hash mismatch for {atom_id}")
            allowed = transform_map.get(atom_id)
            if not isinstance(allowed, list) or not allowed:
                failures.append(
                    f"{plan_id}: transformation contract for {atom_id} must be a non-empty list"
                )
                continue
            invalid = [kind for kind in allowed if kind not in TRANSFORMATION_KINDS]
            if invalid:
                failures.append(
                    f"{plan_id}: invalid transformation(s) for {atom_id}: "
                    + ", ".join(map(str, invalid))
                )
            atom = atoms[atom_id]
            if atom.get("surface_mode") == "BYTE_EXACT" and allowed != ["COPY_SOURCE_SLICE"]:
                failures.append(
                    f"{plan_id}: BYTE_EXACT atom {atom_id} must use only COPY_SOURCE_SLICE"
                )
            if atom.get("content_type") in {"FORMULA", "OCR_FRAGMENT"} and "FORMULA_NORMALIZATION" not in allowed:
                failures.append(f"{plan_id}: formula atom {atom_id} must allow FORMULA_NORMALIZATION")
            if atom.get("content_type") in {"PROOF_ROUTE", "PROOF_STEP"} and "SOURCE_ROUTE_COMPLETION" not in allowed:
                failures.append(f"{plan_id}: proof atom {atom_id} must allow SOURCE_ROUTE_COMPLETION")
            if atom.get("surface_mode") != "BYTE_EXACT":
                if forbidden_map.get(atom_id) != str(atom.get("forbidden_change", "")):
                    failures.append(f"{plan_id}: forbidden-change contract mismatch for {atom_id}")

        if not realizations:
            failures.append(f"{plan_id}: function_realization_plan_json must not be empty")
            continue
        section_pairs: Counter[tuple[str, str]] = Counter()
        for realization_index, realization in enumerate(realizations, 1):
            label = f"{plan_id}.realization[{realization_index}]"
            if not isinstance(realization, dict):
                failures.append(f"{label}: must be an object")
                continue
            required_fields = {
                "realization_id",
                "atom_id",
                "function",
                "source_evidence",
                "writing_instruction",
                "realization_group_id",
                "merge_justification",
            }
            missing_fields = sorted(required_fields - set(realization))
            if missing_fields:
                failures.append(f"{label}: missing fields: {', '.join(missing_fields)}")
                continue
            realization_id = str(realization.get("realization_id", ""))
            atom_id = str(realization.get("atom_id", ""))
            function = str(realization.get("function", ""))
            group_id = str(realization.get("realization_group_id", ""))
            if not re.fullmatch(r"RZ\d{5,}", realization_id):
                failures.append(f"{label}: invalid realization_id {realization_id!r}")
            elif realization_id in seen_realization_ids:
                failures.append(f"duplicate realization_id: {realization_id}")
            seen_realization_ids.add(realization_id)
            if atom_id not in expected_keys:
                failures.append(f"{label}: atom_id is outside this section")
                continue
            try:
                required_functions = normalize_functions(
                    atoms[atom_id].get("required_functions"),
                    f"{atom_id}.required_functions",
                )
            except ValueError as exc:
                failures.append(str(exc))
                continue
            if function not in required_functions:
                failures.append(
                    f"{label}: {function!r} is not a required function of {atom_id}"
                )
            raw_obligation_ids = realization.get("source_obligation_ids", "")
            if isinstance(raw_obligation_ids, list):
                actual_obligation_ids = {
                    str(item).strip() for item in raw_obligation_ids if str(item).strip()
                }
            else:
                actual_obligation_ids = {
                    item
                    for item in re.split(r"[,;\s]+", str(raw_obligation_ids or ""))
                    if item
                }
            expected_for_pair = set(
                expected_obligation_ids.get((atom_id, function), [])
            )
            if actual_obligation_ids != expected_for_pair:
                failures.append(
                    f"{label}: source_obligation_ids must equal the P04 bindings "
                    f"{sorted(expected_for_pair)}"
                )
            evidence = str(realization.get("source_evidence", ""))
            atom_excerpt = str(atoms[atom_id].get("raw_excerpt", ""))
            if evidence != atom_excerpt:
                failures.append(
                    f"{label}: source_evidence must equal the complete exact Atom slice"
                )
            instruction = str(realization.get("writing_instruction", "")).strip()
            if len(instruction) < 12:
                failures.append(f"{label}: writing_instruction is too shallow")
            if not re.fullmatch(r"RG\d{5,}", group_id):
                failures.append(f"{label}: invalid realization_group_id {group_id!r}")
            pair = (atom_id, function)
            section_pairs[pair] += 1
            planned_pair_counts[pair] += 1
            groups[group_id].append((section_id, realization))

        try:
            expected_section_pairs = expected_pairs(selected)
        except ValueError as exc:
            failures.append(str(exc))
            expected_section_pairs = set()
        actual_section_pairs = set(section_pairs)
        missing_pairs = sorted(expected_section_pairs - actual_section_pairs)
        extra_pairs = sorted(actual_section_pairs - expected_section_pairs)
        duplicate_pairs = sorted(pair for pair, count in section_pairs.items() if count > 1)
        if missing_pairs:
            failures.append(
                f"{plan_id}: Atom functions lack writing obligations: "
                + ", ".join(f"{atom_id}/{function}" for atom_id, function in missing_pairs[:16])
            )
        if extra_pairs:
            failures.append(
                f"{plan_id}: undeclared Atom functions were planned: "
                + ", ".join(f"{atom_id}/{function}" for atom_id, function in extra_pairs[:16])
            )
        if duplicate_pairs:
            failures.append(
                f"{plan_id}: each Atom function needs one canonical realization obligation: "
                + ", ".join(f"{atom_id}/{function}" for atom_id, function in duplicate_pairs[:16])
            )

    for atom_id, atom in atoms.items():
        if atom.get("content_type") == "DUPLICATE":
            if planned_atom_counts[atom_id] > 1:
                failures.append(f"{atom_id}: duplicate atom appears in more than one section plan")
            continue
        count = planned_atom_counts[atom_id]
        if count == 0:
            failures.append(f"{atom_id}: current-source atom is absent from the execution plan")
        elif count > 1:
            failures.append(f"{atom_id}: current-source atom appears in multiple execution plans")

    for group_id, members in groups.items():
        sections = {section_id for section_id, _row in members}
        if len(sections) > 1:
            failures.append(f"{group_id}: one realization group cannot cross article sections")
        if len(members) <= 1:
            continue
        atom_ids = {str(row.get("atom_id", "")) for _section, row in members}
        if len(atom_ids) > 1:
            failures.append(
                f"{group_id}: one target unit cannot merge responsibilities from different Atoms"
            )
        instructions = {
            str(row.get("writing_instruction", "")).strip() for _section, row in members
        }
        if len(instructions) != len(members):
            failures.append(
                f"{group_id}: merged responsibilities need distinct writing instructions"
            )
        justifications = {
            str(row.get("merge_justification", "")).strip() for _section, row in members
        }
        if len(justifications) != 1:
            failures.append(
                f"{group_id}: merged responsibilities need one shared merge_justification"
            )
        for justification in justifications:
            if len(justification) < 12:
                failures.append(
                    f"{group_id}: merged responsibilities need a concrete merge_justification"
                )

    missing_directives = sorted(known_directives - set(directive_assignments))
    duplicate_directives = sorted(
        directive_id for directive_id, count in directive_assignments.items() if count > 1
    )
    if missing_directives:
        failures.append(
            "author expansion directives lack one P05 section assignment: "
            + ", ".join(missing_directives)
        )
    if duplicate_directives:
        failures.append(
            "author expansion directives are assigned more than once: "
            + ", ".join(duplicate_directives)
        )

    if failures:
        return fail(failures)
    print("OK")
    print(
        f"source_revision_id={revision_id} sections={len(plan_rows)} "
        f"planned_atoms={len(planned_atom_counts)} "
        f"planned_atom_functions={len(planned_pair_counts)}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
