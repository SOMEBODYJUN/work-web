#!/usr/bin/env python3
"""Validate long-source chunk ledgers. JSONL ledgers are preferred over Markdown mirrors."""
from pathlib import Path
import re
import sys

from structured_ledger import load_ledger, read_text, id_set_from_rows


def ids_from_source(root: Path, rel: str, prefix: str) -> set[str]:
    kind, _header, rows, _errs = load_ledger(root / rel)
    if kind != "missing" and rows:
        return id_set_from_rows(rows, prefix)
    return set(re.findall(rf"\b{prefix}\d{{3,}}\b", read_text(root / rel)))


def row_count(path: Path, id_field: str, prefix: str) -> int:
    kind, _header, rows, _errs = load_ledger(path)
    if kind != "missing" and rows:
        return sum(1 for row in rows if re.fullmatch(rf"{prefix}\d{{3,}}", row.get(id_field, "")))
    return 0


def ledger_text_or_rows_contain(path: Path, needle: str) -> bool:
    kind, _header, rows, _errs = load_ledger(path)
    if kind != "missing" and rows:
        return any(needle in " ".join(row.values()) for row in rows)
    return needle in read_text(path)


def estimate_semantic_units(source: str) -> int:
    # Planning hint only: sentence/paragraph units, not a punctuation-count quota.
    pieces = [
        p for p in re.split(r"(?<=[。！？!?])|\n{2,}", source)
        if p.strip()
    ]
    return max(1, len(pieces)) if source.strip() else 0


def main():
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    source = read_text(root / "source.txt")
    chunk_ids = sorted(ids_from_source(root, "source_chunk_index.md", "C"))
    aggregate_ids = ids_from_source(root, "source_atom_ledger.md", "A")
    failures = []

    source_len = len(source)
    if source_len > 40000 and len(chunk_ids) < 4:
        failures.append(f"source length {source_len} requires at least 4 chunks; found {len(chunk_ids)}")
    elif source_len > 20000 and len(chunk_ids) < 2:
        failures.append(f"source length {source_len} requires multiple chunks; found {len(chunk_ids)}")
    elif not chunk_ids:
        failures.append("source_chunk_index.md/jsonl contains no chunk ids")

    chunk_dir = root / "chunk_ledger"
    if len(chunk_ids) > 1 or source_len > 12000:
        if not chunk_dir.exists():
            failures.append("missing chunk_ledger/ directory for multi-chunk or long source")
        for cid in chunk_ids:
            candidates = [chunk_dir / f"chunk_{cid}_atom_ledger.md", chunk_dir / f"{cid}_atom_ledger.md"]
            path = next((p for p in candidates if p.exists() or p.with_suffix('.jsonl').exists()), None)
            if path is None:
                failures.append(f"missing chunk ledger for {cid}: expected chunk_ledger/chunk_{cid}_atom_ledger.jsonl or .md")
                continue
            n = row_count(path, "atom_id", "A")
            if n < 3:
                failures.append(f"{path.name}/jsonl has too few atom rows: {n}")
            if not ledger_text_or_rows_contain(path, cid):
                failures.append(f"{path.name}/jsonl does not mention its chunk id {cid}")

    for cid in chunk_ids:
        if cid not in " ".join(sorted(aggregate_ids)) and not ledger_text_or_rows_contain(root / "source_atom_ledger.md", cid):
            failures.append(f"aggregate source_atom_ledger.md/jsonl does not include chunk id {cid}")

    atom_rows = len(aggregate_ids)
    estimated_units = estimate_semantic_units(source)
    min_atoms = max(1, min(5, estimated_units))
    if source_len > 10000:
        min_atoms = max(20, min(estimated_units, 40))
    if source_len > 40000:
        min_atoms = max(80, min(estimated_units, 120))
    if atom_rows < min_atoms:
        failures.append(f"source_atom_ledger.md/jsonl too thin for source length {source_len}: {atom_rows} rows, expected at least {min_atoms} based on semantic-unit hint {estimated_units}")

    if failures:
        print("FAILED")
        for f in failures:
            print(f"- {f}")
        return 1
    print("OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
