#!/usr/bin/env python3
"""Single source of truth for runtime modes, stage artifacts, and validator order."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

PACKAGE_ROOT = Path(__file__).resolve().parent.parent
VERSION_FILE = PACKAGE_ROOT / "VERSION"

FULL_PUBLICATION = "full_publication"
WECHAT_PUBLICATION = "wechat_publication"
DIAGNOSTIC_BACKTEST = "diagnostic_backtest"
SOURCE_ATOMIZATION = "source_atomization"

VALID_MODES = (
    FULL_PUBLICATION,
    WECHAT_PUBLICATION,
    DIAGNOSTIC_BACKTEST,
    SOURCE_ATOMIZATION,
)
RELEASE_MODES = {FULL_PUBLICATION, WECHAT_PUBLICATION}
SOURCE_MODES = {DIAGNOSTIC_BACKTEST, SOURCE_ATOMIZATION}

EVIDENCE_FILES = {
    "validator_result.json",
    "validator_result.sha256",
    "validator_result.txt",
    "release_manifest.json",
    "release_manifest.sha256",
}

STATE_AND_FEEDBACK_FILES = (
    "run_mode.json",
    "active_state.json",
    "active_state.md",
    "author_task_contract.json",
    "user_feedback_ledger.jsonl",
    "user_feedback_ledger.md",
)

SOURCE_AUTHORITY_FILES = (
    "source_original.txt",
    "source_canonical.txt",
    "canonical_source.txt",
    "source.txt",
    "source_identity.json",
    "source_provenance.json",
    "source_revision.json",
    "source_normalization_map.jsonl",
)

SOURCE_MODEL_FILES = (
    "source_chunk_index.jsonl",
    "source_chunk_index.md",
    "source_sentence_index.jsonl",
    "source_sentence_index.md",
    "source_atom_ledger.jsonl",
    "source_atom_ledger.md",
    "source_atom_manifest.md",
    "chunk_processing_log.md",
    "source_formula_block_ledger.jsonl",
    "source_formula_block_ledger.md",
    "author_question_obligation_ledger.jsonl",
    "author_question_obligation_ledger.md",
    "source_math_risk_ledger.jsonl",
    "source_math_risk_ledger.md",
    "source_instruction_quarantine.md",
    "security_boundary_report.md",
)

DEPENDENCY_AND_PLAN_FILES = (
    "quality_contract.json",
    "publication_blueprint.json",
    "cross_chunk_dependency_map.jsonl",
    "cross_chunk_dependency_map.md",
    "section_context_prefetch_plan.jsonl",
    "section_context_prefetch_plan.md",
    "section_execution_plan.jsonl",
    "section_execution_plan.md",
    "context_pack_manifest.json",
    "source_destination_ledger.md",
    "voice_expression_ledger.md",
    "symbol_ledger.md",
    "explanation_chain_ledger.md",
    "math_statement_ledger.md",
    "proof_obligations.md",
    "section_plan.md",
    "merge_plan.md",
    "pre_final_plan.md",
    "heading_voice_gate.md",
)

ARTICLE_CHAIN_FILES = (
    "draft.md",
    "final.md",
    "post_final_structure_review.md",
    "optimized_final.md",
    "standardized_final.md",
    "independent_review.md",
    "attack_report.md",
    "revision_tasks.md",
    "revised_final.md",
    "revision_changelog.md",
    "regression_check.md",
    "aigc_source_type_ledger.md",
    "aigc_rewrite_tasks.md",
    "aigc_rewritten_final.md",
    "aigc_rewrite_changelog.md",
    "post_aigc_regression_check.md",
    "post_aigc_trace_check.md",
    "post_aigc_formula_check.md",
    "post_aigc_clean_gate.md",
    "publication_final.md",
)

TRACE_AND_REVIEW_FILES = (
    "atom_consumption_candidates.jsonl",
    "final_paragraph_index.md",
    "final_trace_map.md",
    "final_claim_ledger.jsonl",
    "final_claim_ledger.md",
    "revised_trace_map.md",
    "publication_paragraph_index.md",
    "publication_trace_map.md",
    "publication_claim_ledger.jsonl",
    "publication_claim_ledger.md",
    "publication_sentence_trace.jsonl",
    "publication_sentence_trace.md",
    "heading_authorization.jsonl",
    "publication_fragment_authorization.jsonl",
    "publication_content_review.json",
    "mathematical_review.json",
    "symbol_lock_report.md",
    "integration_report.md",
    "clean_final_gate.md",
    "formula_compatibility_report.md",
    "coverage_check.md",
    "omission_ledger.md",
    "ledger_integrity_check.md",
    "statement_completeness_check.md",
    "failure_recovery_log.md",
    "PUBLICATION_AUDIT_REPORT.md",
)

WECHAT_FILES = (
    "wechat_publication_final.md",
    "wechat_publish_plan.md",
)

FULL_REQUIRED_FILES = list(dict.fromkeys(
    STATE_AND_FEEDBACK_FILES
    + SOURCE_AUTHORITY_FILES
    + SOURCE_MODEL_FILES
    + DEPENDENCY_AND_PLAN_FILES
    + ARTICLE_CHAIN_FILES
    + TRACE_AND_REVIEW_FILES
    + tuple(EVIDENCE_FILES)
))
SOURCE_ONLY_REQUIRED_FILES = list(dict.fromkeys(
    STATE_AND_FEEDBACK_FILES
    + SOURCE_AUTHORITY_FILES
    + SOURCE_MODEL_FILES
))
WECHAT_EXTRA_REQUIRED_FILES = list(WECHAT_FILES)

MODE_REQUIRED_FILES = {
    FULL_PUBLICATION: FULL_REQUIRED_FILES,
    WECHAT_PUBLICATION: FULL_REQUIRED_FILES + WECHAT_EXTRA_REQUIRED_FILES,
    DIAGNOSTIC_BACKTEST: SOURCE_ONLY_REQUIRED_FILES,
    SOURCE_ATOMIZATION: SOURCE_ONLY_REQUIRED_FILES,
}

FULL_STRUCTURED = {
    "atom_consumption_candidates.jsonl",
    "source_chunk_index.jsonl",
    "source_sentence_index.jsonl",
    "source_atom_ledger.jsonl",
    "source_formula_block_ledger.jsonl",
    "author_question_obligation_ledger.jsonl",
    "source_math_risk_ledger.jsonl",
    "user_feedback_ledger.jsonl",
    "final_claim_ledger.jsonl",
    "publication_claim_ledger.jsonl",
    "publication_sentence_trace.jsonl",
    "cross_chunk_dependency_map.jsonl",
    "section_context_prefetch_plan.jsonl",
    "section_execution_plan.jsonl",
}
SOURCE_ONLY_STRUCTURED = {
    "source_chunk_index.jsonl",
    "source_sentence_index.jsonl",
    "source_atom_ledger.jsonl",
    "source_formula_block_ledger.jsonl",
    "author_question_obligation_ledger.jsonl",
    "source_math_risk_ledger.jsonl",
    "user_feedback_ledger.jsonl",
}
MODE_STRUCTURED_JSONL = {
    FULL_PUBLICATION: FULL_STRUCTURED,
    WECHAT_PUBLICATION: FULL_STRUCTURED,
    DIAGNOSTIC_BACKTEST: SOURCE_ONLY_STRUCTURED,
    SOURCE_ATOMIZATION: SOURCE_ONLY_STRUCTURED,
}


@dataclass(frozen=True)
class ValidatorSpec:
    script: str
    args: tuple[str, ...] = ("{root}",)
    pass_mode: bool = False
    stage: str = "release"


SOURCE_VALIDATORS = (
    ValidatorSpec("validate_required_files.py", ("--pre-evidence", "{root}"), True, "source"),
    ValidatorSpec("validate_structured_ledgers.py", ("{root}",), True, "source"),
    ValidatorSpec("validate_markdown_mirror_precision.py", stage="source"),
    ValidatorSpec("validate_active_state_feedback.py", ("{root}",), True, "source"),
    ValidatorSpec("validate_author_task_contract.py", stage="source"),
    ValidatorSpec("validate_canonical_source_lock.py", stage="source"),
    ValidatorSpec("validate_source_revision.py", stage="source"),
    ValidatorSpec("validate_atom_semantics.py", stage="source"),
    ValidatorSpec("validate_surface_decisions.py", stage="source"),
    ValidatorSpec("validate_chunk_ledgers.py", stage="source"),
    ValidatorSpec("validate_chunk_batching.py", stage="source"),
    ValidatorSpec("validate_source_atom_granularity.py", stage="source"),
    ValidatorSpec("validate_formula_block_canonicalization.py", stage="source"),
    ValidatorSpec("validate_author_question_obligations.py", stage="source"),
    ValidatorSpec("validate_source_math_risks.py", stage="source"),
    ValidatorSpec("validate_security_boundary.py", stage="source"),
)

FULL_ONLY_VALIDATORS = (
    ValidatorSpec("validate_source_review_resolution.py", stage="planning"),
    ValidatorSpec("validate_source_obligation_contracts.py", stage="planning"),
    ValidatorSpec("validate_feedback_ingestion.py", stage="planning"),
    ValidatorSpec("validate_context_pack_consumption.py", stage="planning"),
    ValidatorSpec("validate_section_execution_plan.py", stage="planning"),
    ValidatorSpec("validate_cross_chunk_dependencies.py", stage="planning"),
    ValidatorSpec("validate_ledger_consumption.py", stage="article"),
    ValidatorSpec("validate_math_statement_lock.py", stage="article"),
    ValidatorSpec("validate_proof_obligations.py", stage="article"),
    ValidatorSpec("validate_trace_lock.py", stage="article"),
    ValidatorSpec(
        "validate_symbol_lock.py",
        ("{root}/symbol_ledger.md", "{root}/standardized_final.md"),
        stage="article",
    ),
    ValidatorSpec("validate_integration.py", ("{root}/integration_report.md",), stage="article"),
    ValidatorSpec("validate_voice_expression_lock.py", stage="article"),
    ValidatorSpec(
        "validate_final_article.py",
        ("--require-draft", "{root}/standardized_final.md", "{root}/source.txt"),
        stage="article",
    ),
    ValidatorSpec("validate_mdnice_math.py", ("{root}/standardized_final.md",), stage="article"),
    ValidatorSpec("validate_mdnice_math.py", ("{root}/publication_final.md",), stage="release"),
    ValidatorSpec(
        "validate_heading_voice.py",
        ("{root}/publication_final.md", "{root}/source.txt", "{root}/heading_voice_gate.md"),
        stage="release",
    ),
    ValidatorSpec("validate_heading_authorization.py", stage="release"),
    ValidatorSpec("validate_output_fragment_authorization.py", stage="release"),
    ValidatorSpec("validate_heading_gate_evidence.py", stage="release"),
    ValidatorSpec("validate_aigc_layer.py", stage="release"),
    ValidatorSpec("validate_aigc_classification_coverage.py", stage="release"),
    ValidatorSpec("validate_reverse_trace.py", stage="release"),
    ValidatorSpec("validate_claim_source_obligation.py", stage="release"),
    ValidatorSpec("validate_trace_granularity.py", stage="release"),
    ValidatorSpec("validate_publication_sentence_trace.py", stage="release"),
    ValidatorSpec(
        "validate_content_function_preservation.py",
        ("{root}", "--release-chain"),
        stage="release",
    ),
    ValidatorSpec(
        "validate_quality_gate.py",
        ("{root}", "--release-chain"),
        stage="release",
    ),
    ValidatorSpec("validate_publication_content_acceptance.py", stage="release"),
    ValidatorSpec("validate_reader_surface.py", stage="release"),
    ValidatorSpec("validate_failure_recovery.py", stage="release"),
    ValidatorSpec("validate_report_evidence_depth.py", stage="release"),
    ValidatorSpec("validate_no_process_language.py", stage="release"),
    ValidatorSpec("validate_forbidden_phrase_lock.py", stage="release"),
    ValidatorSpec(
        "validate_clean_final.py",
        ("{root}/publication_final.md", "{root}/source.txt"),
        stage="release",
    ),
    ValidatorSpec("validate_release_state.py", stage="release"),
)

WECHAT_VALIDATORS = (
    ValidatorSpec("validate_mdnice_math.py", ("{root}/wechat_publication_final.md",), stage="wechat"),
    ValidatorSpec(
        "validate_wechat_article.py",
        ("{root}/publication_final.md", "{root}/source.txt", "{root}/heading_voice_gate.md"),
        stage="wechat",
    ),
    ValidatorSpec(
        "validate_wechat_article.py",
        ("{root}/wechat_publication_final.md", "{root}/source.txt", "{root}/heading_voice_gate.md"),
        stage="wechat",
    ),
)

POST_EVIDENCE_VALIDATORS = (
    ValidatorSpec("validate_validator_result_integrity.py", stage="evidence"),
    ValidatorSpec("validate_publication_audit_report.py", stage="evidence"),
)


STAGE_ARTIFACTS = {
    "source_setup": tuple(dict.fromkeys(STATE_AND_FEEDBACK_FILES + SOURCE_AUTHORITY_FILES)),
    "source_model": SOURCE_MODEL_FILES,
    "planning": DEPENDENCY_AND_PLAN_FILES,
    "article": ARTICLE_CHAIN_FILES,
    "trace_review": TRACE_AND_REVIEW_FILES,
    "evidence": tuple(sorted(EVIDENCE_FILES)),
    "wechat": WECHAT_FILES,
}


def package_version() -> str:
    try:
        value = VERSION_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        return "UNKNOWN"
    return value or "UNKNOWN"


def required_files_for_mode(mode: str, *, pre_evidence: bool = False) -> list[str]:
    files = list(MODE_REQUIRED_FILES[mode])
    if pre_evidence:
        files = [name for name in files if name not in EVIDENCE_FILES]
    return files


def structured_jsonl_for_mode(mode: str) -> set[str]:
    return set(MODE_STRUCTURED_JSONL[mode])


def validator_specs_for_mode(
    mode: str,
    *,
    include_post_evidence: bool = False,
    include_optional_wechat: bool = False,
) -> list[ValidatorSpec]:
    specs = list(SOURCE_VALIDATORS)
    if mode in RELEASE_MODES:
        specs.extend(FULL_ONLY_VALIDATORS)
    if mode == WECHAT_PUBLICATION or include_optional_wechat:
        specs.extend(WECHAT_VALIDATORS)
    if include_post_evidence and mode in RELEASE_MODES:
        specs.extend(POST_EVIDENCE_VALIDATORS)
    return specs


def validator_names_for_mode(mode: str) -> set[str]:
    return {spec.script for spec in validator_specs_for_mode(mode)}


def stage_missing(root: Path, stage: str) -> list[str]:
    return [name for name in STAGE_ARTIFACTS[stage] if not (root / name).exists()]


def stages_for_mode(mode: str) -> tuple[str, ...]:
    if mode in SOURCE_MODES:
        return ("source_setup", "source_model")
    if mode == WECHAT_PUBLICATION:
        return ("source_setup", "source_model", "planning", "article", "trace_review", "evidence", "wechat")
    return ("source_setup", "source_model", "planning", "article", "trace_review", "evidence")
