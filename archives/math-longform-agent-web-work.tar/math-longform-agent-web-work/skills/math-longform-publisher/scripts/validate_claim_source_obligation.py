#!/usr/bin/env python3
"""Validate claim-source-obligation ledgers for final and publication outputs."""
from __future__ import annotations

from pathlib import Path
import re
import sys

from structured_ledger import load_required_ledger

REQUIRED_COLUMNS = {
    "claim_id", "file", "location", "claim_excerpt", "claim_type",
    "source_atoms", "statement_ids", "proof_ids", "support_type",
    "source_ownership", "transformation_scope", "verdict",
    "allowed_new_reason", "verification_note",
}

ALLOWED_SUPPORT = {
    "DIRECT_SOURCE", "DERIVED_MATH", "SUPPORTED_COMPLETION", "VOICE_PRESERVATION",
    "AUTHOR_METHOD_PRESERVATION", "INSIGHT_PRESERVATION", "PROOF_ROUTE_PRESERVATION",
    "FORMULA_CANONICALIZATION", "EXACT_SURFACE_PRESERVATION", "EXPLANATORY_BRIDGE",
    "HEADING_LABEL", "PLATFORM_FORMATTING",
}
ALLOWED_OWNERSHIP = {
    "SOURCE_EXACT", "SOURCE_LOCAL_REPHRASE", "SOURCE_DERIVED", "AUTHOR_VOICE",
    "AUTHOR_METHOD", "AUTHOR_INSIGHT", "SOURCE_FORMULA_OBJECT", "FORMAT_ONLY",
}
ALLOWED_VERDICTS = {
    "SUPPORTED", "DERIVED_SUPPORTED", "VOICE_SUPPORTED", "METHOD_SUPPORTED",
    "INSIGHT_SUPPORTED", "ROUTE_SUPPORTED", "FORMULA_SUPPORTED",
    "EXACT_SURFACE_SUPPORTED", "FORMAT_ONLY",
    "BLOCKED_UNSUPPORTED", "BLOCKED_SOURCE_MISMATCH", "BLOCKED_SCOPE_EXPANSION",
}
BLOCKING_VERDICTS = {"BLOCKED_UNSUPPORTED", "BLOCKED_SOURCE_MISMATCH", "BLOCKED_SCOPE_EXPANSION"}
CLAIMS_REQUIRING_SUPPORT = {
    "definition", "theorem", "proposition", "lemma", "proof_step", "example",
    "warning", "assumption", "claim", "formula", "heading", "transition",
}

PLACEHOLDER_RE = re.compile(r"\b(TBD|TODO|pending|unknown|unclear)\b|待定|未定|不清楚|^\s*$", re.I)
ID_RE = re.compile(r"\b(?:A|S|PR)\d{3,}\b")


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def parse_table(path: Path, prefix: str) -> tuple[list[str], list[dict[str, str]], list[str]]:
    kind, rows, failures = load_required_ledger(path, REQUIRED_COLUMNS, "claim_id", prefix)
    if not rows:
        failures.append(f"{path.with_suffix('.jsonl').name if kind == 'jsonl' else path.name}: no {prefix} claim rows")
    header = sorted({k for row in rows for k in row})
    return header, rows, failures

def contains_id(text: str, kind: str) -> bool:
    return bool(re.search(rf"\b{kind}\d{{3,}}\b", text or ""))


def validate_rows(path: Path, prefix: str) -> list[str]:
    _header, rows, failures = parse_table(path, prefix)
    for row in rows:
        cid = row.get("claim_id", "<unknown>")
        joined = " | ".join(row.values())
        claim_type = row.get("claim_type", "").strip().lower()
        support_type = row.get("support_type", "").strip().upper()
        ownership = row.get("source_ownership", "").strip().upper()
        verdict = row.get("verdict", "").strip().upper()
        source_atoms = row.get("source_atoms", "")
        statement_ids = row.get("statement_ids", "")
        proof_ids = row.get("proof_ids", "")
        excerpt = row.get("claim_excerpt", "")
        verification = row.get("verification_note", "")

        if PLACEHOLDER_RE.search(excerpt):
            failures.append(f"{path.name}:{cid}: claim_excerpt is empty or placeholder")
        if support_type not in ALLOWED_SUPPORT:
            failures.append(f"{path.name}:{cid}: invalid support_type {support_type!r}")
        if ownership not in ALLOWED_OWNERSHIP:
            failures.append(f"{path.name}:{cid}: invalid source_ownership {ownership!r}")
        if verdict not in ALLOWED_VERDICTS:
            failures.append(f"{path.name}:{cid}: invalid verdict {verdict!r}")
        if verdict in BLOCKING_VERDICTS:
            failures.append(f"{path.name}:{cid}: blocking verdict {verdict}")
        if re.search(r"unsupported", joined, flags=re.I) and verdict not in BLOCKING_VERDICTS:
            failures.append(f"{path.name}:{cid}: text says unsupported but verdict is not BLOCKED_*")
        if re.search(r"\b(TODO|TBD|pending|unknown|unclear)\b|待定|不清楚", joined, flags=re.I):
            failures.append(f"{path.name}:{cid}: unresolved placeholder text")

        requires_support = any(t in claim_type for t in CLAIMS_REQUIRING_SUPPORT)
        if support_type != "PLATFORM_FORMATTING" and ownership != "FORMAT_ONLY":
            requires_support = True
        if requires_support and not (contains_id(source_atoms, "A") or contains_id(statement_ids, "S") or contains_id(proof_ids, "PR")):
            failures.append(f"{path.name}:{cid}: lacks atom/statement/proof support")
        if support_type in {"DERIVED_MATH", "SUPPORTED_COMPLETION"} and not (contains_id(statement_ids, "S") or contains_id(proof_ids, "PR")):
            failures.append(f"{path.name}:{cid}: {support_type} requires statement_ids or proof_ids")
        if support_type == "VOICE_PRESERVATION" and ownership != "AUTHOR_VOICE":
            failures.append(f"{path.name}:{cid}: VOICE_PRESERVATION should use AUTHOR_VOICE ownership")
        if support_type == "AUTHOR_METHOD_PRESERVATION" and ownership != "AUTHOR_METHOD":
            failures.append(f"{path.name}:{cid}: AUTHOR_METHOD_PRESERVATION should use AUTHOR_METHOD ownership")
        if support_type == "INSIGHT_PRESERVATION" and ownership != "AUTHOR_INSIGHT":
            failures.append(f"{path.name}:{cid}: INSIGHT_PRESERVATION should use AUTHOR_INSIGHT ownership")
        if support_type == "FORMULA_CANONICALIZATION" and ownership != "SOURCE_FORMULA_OBJECT":
            failures.append(f"{path.name}:{cid}: FORMULA_CANONICALIZATION should use SOURCE_FORMULA_OBJECT ownership")
        if support_type == "EXACT_SURFACE_PRESERVATION" and ownership != "SOURCE_EXACT":
            failures.append(f"{path.name}:{cid}: EXACT_SURFACE_PRESERVATION should use SOURCE_EXACT ownership")
        if support_type == "PLATFORM_FORMATTING" and verdict != "FORMAT_ONLY":
            failures.append(f"{path.name}:{cid}: PLATFORM_FORMATTING should have FORMAT_ONLY verdict")
        if not verification.strip():
            failures.append(f"{path.name}:{cid}: missing verification_note")
    return failures


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    failures: list[str] = []
    pairs = [
        (root / "final_claim_ledger.md", "CL"),
        (root / "publication_claim_ledger.md", "PCL"),
    ]
    for path, prefix in pairs:
        if not path.exists() or not read(path).strip():
            failures.append(f"missing or empty {path.name}")
            continue
        failures.extend(validate_rows(path, prefix))

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print("OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
