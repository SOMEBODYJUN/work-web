#!/usr/bin/env python3
"""Build or refresh the deterministic business context manifest."""
from __future__ import annotations

from pathlib import Path
import argparse
import hashlib

from safe_io import atomic_write_json


REQUIRED_CONTEXT_FILES = {
    "author_task_contract.json",
    "quality_contract.json",
    "active_state.json",
    "user_feedback_ledger.jsonl",
    "source_canonical.txt",
    "source_identity.json",
    "source_provenance.json",
    "source_revision.json",
    "source_normalization_map.jsonl",
    "source.txt",
    "source_chunk_index.jsonl",
    "source_sentence_index.jsonl",
    "source_atom_ledger.jsonl",
    "source_atom_ledger.md",
    "publication_blueprint.json",
    "source_formula_block_ledger.jsonl",
    "author_question_obligation_ledger.jsonl",
    "source_math_risk_ledger.jsonl",
    "cross_chunk_dependency_map.jsonl",
    "section_context_prefetch_plan.jsonl",
    "section_execution_plan.jsonl",
    "section_execution_plan.md",
    "source_destination_ledger.md",
    "voice_expression_ledger.md",
    "symbol_ledger.md",
    "explanation_chain_ledger.md",
    "math_statement_ledger.md",
    "proof_obligations.md",
    "section_plan.md",
    "merge_plan.md",
    "pre_final_plan.md",
    "heading_voice_gate.md",
}

OPTIONAL_IF_PRESENT = {
    "run_mode.json",
    "active_state.md",
    "user_feedback_ledger.md",
    "source_chunk_index.md",
    "source_sentence_index.md",
    "source_formula_block_ledger.md",
    "author_question_obligation_ledger.md",
    "cross_chunk_dependency_map.md",
    "section_context_prefetch_plan.md",
    "source_atom_manifest.md",
    "chunk_processing_log.md",
}

WRITE_TARGETS = {"draft.md", "standardized_final.md", "publication_final.md"}
CONSUMERS = {
    "section_execution_plan.jsonl",
    "section_plan.md",
    "pre_final_plan.md",
    "final_trace_map.md",
    "publication_trace_map.md",
    "publication_claim_ledger.md",
    "publication_sentence_trace.md",
}


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def context_files(root: Path) -> set[str]:
    dynamic = set()
    chunk_root = root / "chunk_ledger"
    if chunk_root.is_dir():
        dynamic = {
            path.relative_to(root).as_posix()
            for path in chunk_root.iterdir()
            if path.is_file()
        }
    return REQUIRED_CONTEXT_FILES | {
        rel for rel in OPTIONAL_IF_PRESENT if (root / rel).is_file()
    } | dynamic


def build_context_pack(root: Path) -> dict[str, object]:
    missing = sorted(rel for rel in REQUIRED_CONTEXT_FILES if not (root / rel).is_file())
    if missing:
        raise ValueError("context-pack inputs are missing: " + ", ".join(missing))
    rows = [
        {
            "path": rel,
            "sha256": sha256_file(root / rel),
            "role": "current source, reviewed semantic contract, or accepted pre-writing plan",
        }
        for rel in sorted(context_files(root))
    ]
    manifest: dict[str, object] = {
        "schema_version": "context-pack-manifest-v2",
        "prepared_before_writing": True,
        "context_files": rows,
        "write_targets": sorted(WRITE_TARGETS),
        "consumed_by": sorted(CONSUMERS),
    }
    atomic_write_json(root / "context_pack_manifest.json", manifest)
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output")
    args = parser.parse_args()
    try:
        manifest = build_context_pack(Path(args.output).resolve())
    except Exception as exc:
        print(f"FAILED: {exc}")
        return 1
    print(f"CONTEXT_PACK_WRITTEN files={len(manifest['context_files'])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
