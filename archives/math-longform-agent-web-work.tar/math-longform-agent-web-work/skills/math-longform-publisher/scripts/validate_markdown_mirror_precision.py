#!/usr/bin/env python3
"""Validate lossless, ordered Markdown mirrors of authoritative JSONL ledgers."""
from __future__ import annotations

from pathlib import Path
import re
import sys
from typing import Any

from mode_utils import parse_mode_args, resolve_mode, structured_jsonl_for_mode
from safe_io import read_jsonl_strict, read_optional_text
from structured_ledger import md_table_rows
from validate_structured_ledgers import ID_FIELDS, REQUIRED_JSONL


def scalar(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        raise ValueError("nested JSON is not mirrorable as a scalar Markdown cell")
    return str(value).strip()


def normalize_rows(rows: list[dict[str, Any]]) -> list[dict[str, str]]:
    return [{str(key): scalar(value) for key, value in row.items()} for row in rows]


def compare_pair(root: Path, rel: str, *, id_field_override: str | None = None) -> list[str]:
    failures: list[str] = []
    json_path = root / rel
    md_path = root / (rel[:-6] + ".md")
    if not json_path.exists() or not md_path.exists():
        return failures
    try:
        json_rows = normalize_rows(read_jsonl_strict(json_path, root=root))
        md_rows = md_table_rows(read_optional_text(md_path, root=root))
    except Exception as exc:
        return [f"{rel}: cannot compare mirror: {exc}"]
    if len(json_rows) != len(md_rows):
        failures.append(f"{md_path.name} row count {len(md_rows)} differs from {rel} row count {len(json_rows)}")
        return failures

    id_info = ID_FIELDS.get(rel)
    id_field = id_field_override or (id_info[0] if id_info else "")
    if not id_field:
        return failures
    json_ids = [row.get(id_field, "") for row in json_rows]
    md_ids = [row.get(id_field, "") for row in md_rows]
    if len(json_ids) != len(set(json_ids)):
        failures.append(f"{rel} contains duplicate {id_field} values")
    if len(md_ids) != len(set(md_ids)):
        failures.append(f"{md_path.name} contains duplicate {id_field} values")
    if json_ids != md_ids:
        failures.append(f"{md_path.name} row order/identity differs from {rel}: jsonl={json_ids[:20]} md={md_ids[:20]}")
        return failures

    required = REQUIRED_JSONL.get(rel, REQUIRED_JSONL.get("source_atom_ledger.jsonl", set()))
    for idx, (json_row, md_row) in enumerate(zip(json_rows, md_rows), start=1):
        missing_columns = sorted(required - set(md_row))
        if missing_columns:
            failures.append(f"{md_path.name} missing columns at row {idx}: {', '.join(missing_columns)}")
            continue
        for key in sorted(required):
            if scalar(json_row.get(key, "")) != scalar(md_row.get(key, "")):
                failures.append(
                    f"{md_path.name} row {idx} ({json_row.get(id_field, '')}) field {key} differs: "
                    f"md={md_row.get(key, '')!r} jsonl={json_row.get(key, '')!r}"
                )
                break
    return failures


def chunk_jsonl_files(root: Path) -> list[str]:
    chunk_dir = root / "chunk_ledger"
    if not chunk_dir.exists():
        return []
    return [path.relative_to(root).as_posix() for path in sorted(chunk_dir.glob("*.jsonl")) if path.is_file()]


def main() -> int:
    try:
        explicit_mode, args = parse_mode_args(sys.argv[1:])
    except ValueError as exc:
        print("FAILED")
        print(f"- {exc}")
        return 1
    root = (Path(args[0]) if args else Path(".")).resolve()
    try:
        mode = resolve_mode(root, explicit_mode)
    except ValueError as exc:
        print("FAILED")
        print(f"- {exc}")
        return 1

    failures: list[str] = []
    rels = set(structured_jsonl_for_mode(mode)) | {"user_feedback_ledger.jsonl"}
    checked = 0
    for rel in sorted(rels):
        if (root / rel).exists():
            checked += 1
            failures.extend(compare_pair(root, rel))
    for rel in chunk_jsonl_files(root):
        checked += 1
        failures.extend(compare_pair(root, rel, id_field_override="atom_id"))
    if checked == 0:
        failures.append("no JSONL ledgers found for Markdown mirror check")

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print(f"OK: markdown_mirrors_checked={checked}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
