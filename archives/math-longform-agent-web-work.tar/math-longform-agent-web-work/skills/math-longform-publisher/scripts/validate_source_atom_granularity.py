#!/usr/bin/env python3
"""Validate semantic atom granularity without enforcing one atom per punctuation mark."""
from __future__ import annotations

from pathlib import Path
import json
import re
import statistics
import sys

from structured_ledger import load_required_ledger, read_text

REQUIRED_ATOM_COLUMNS = {
    "atom_id", "sentence_id", "chunk_id", "char_span", "source_excerpt",
    "atom_level", "atom_type", "author_intent", "math_role", "voice_role",
    "symbol_role", "punctuation_boundary", "ocr_state", "needed_action",
    "destination_status", "final_destination",
}
REQUIRED_SENTENCE_COLUMNS = {
    "sentence_id", "chunk_id", "char_span", "exact_sentence_or_line",
    "sentence_role", "atom_ids", "coverage_status", "notes",
}
SPAN_RE = re.compile(r"^\s*(\d+)\s*-\s*(\d+)\s*$")
CLAUSE_RE = re.compile(r"[，,；;：。！？!?]")
FORMULA_HINT_RE = re.compile(r"formula|ocr|math|display|equation", re.I)


def parse_span(value: str) -> tuple[int, int] | None:
    match = SPAN_RE.fullmatch(value or "")
    if not match:
        return None
    start, end = int(match.group(1)), int(match.group(2))
    return (start, end) if start <= end else None


def split_ids(value: str) -> set[str]:
    return set(re.findall(r"\bA\d{3,}\b", value or ""))


def semantic_unit_estimate(source: str) -> int:
    """A planning hint only; never a hard atom-count target."""
    prose = re.sub(r"\$\$.*?\$\$", " FORMULA ", source, flags=re.S)
    units = [
        item.strip()
        for item in re.split(r"(?<=[。！？!?])|\n{2,}", prose)
        if item.strip()
    ]
    return max(1, len(units))


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    source_path = root / "source_canonical.txt"
    if not source_path.exists():
        source_path = root / "source.txt"
    source = read_text(source_path)
    source_bytes = source.encode("utf-8")
    failures: list[str] = []
    warnings: list[str] = []

    atom_kind, atom_rows, atom_errors = load_required_ledger(
        root / "source_atom_ledger.md", REQUIRED_ATOM_COLUMNS, "atom_id", "A"
    )
    sent_kind, sent_rows, sent_errors = load_required_ledger(
        root / "source_sentence_index.md", REQUIRED_SENTENCE_COLUMNS, "sentence_id", "T"
    )
    failures.extend(atom_errors)
    failures.extend(sent_errors)
    if not source.strip():
        failures.append("source_canonical.txt/source.txt is missing or empty")
    if failures:
        print("FAILED")
        for item in failures:
            print(f"- {item}")
        return 1

    sentence_ids = {row.get("sentence_id", "") for row in sent_rows}
    atom_ids = {row.get("atom_id", "") for row in atom_rows}
    atom_ids_by_sentence: dict[str, set[str]] = {}
    lengths: list[int] = []
    very_short = 0

    for row in atom_rows:
        atom_id = row.get("atom_id", "")
        sentence_id = row.get("sentence_id", "")
        if sentence_id not in sentence_ids:
            failures.append(f"{atom_id}: sentence_id {sentence_id!r} is not in source_sentence_index")
        atom_ids_by_sentence.setdefault(sentence_id, set()).add(atom_id)

        span = parse_span(row.get("char_span", ""))
        if span is None:
            failures.append(f"{atom_id}: char_span must be a UTF-8 byte range")
            continue
        start, end = span
        if not (0 <= start < end <= len(source_bytes)):
            failures.append(f"{atom_id}: char_span out of range: {start}-{end}")
            continue
        try:
            excerpt = source_bytes[start:end].decode("utf-8", errors="strict")
        except UnicodeDecodeError:
            failures.append(f"{atom_id}: char_span splits UTF-8")
            continue

        recorded = row.get("source_excerpt", "")
        if recorded != excerpt:
            status = " ".join(
                row.get(key, "")
                for key in ("atom_type", "atom_level", "ocr_state", "needed_action")
            )
            if not re.search(r"canonicalized|restored|ocr", status, re.I):
                failures.append(f"{atom_id}: source_excerpt does not match the canonical byte slice")

        visible_len = len(excerpt.strip())
        lengths.append(visible_len)
        if visible_len <= 1:
            very_short += 1
        status_blob = " ".join(
            row.get(key, "")
            for key in ("atom_type", "atom_level", "ocr_state", "math_role")
        )
        formula_like = bool(FORMULA_HINT_RE.search(status_blob))
        boundary_count = len(CLAUSE_RE.findall(excerpt))

        # Semantic atoms may contain internal punctuation. Only genuinely coarse,
        # multi-purpose prose blocks are rejected.
        if not formula_like and visible_len > 700:
            failures.append(f"{atom_id}: prose atom is too large ({visible_len} characters)")
        elif not formula_like and visible_len > 260 and boundary_count > 5:
            failures.append(
                f"{atom_id}: coarse prose atom ({visible_len} chars, "
                f"{boundary_count} clause boundaries); split by semantic role"
            )
        elif formula_like and visible_len > 2400:
            failures.append(f"{atom_id}: formula/OCR atom is too large ({visible_len} characters)")

        source_start = row.get("source_byte_start")
        source_end = row.get("source_byte_end")
        if source_start not in {None, ""} and str(source_start) != str(start):
            failures.append(f"{atom_id}: char_span start disagrees with source_byte_start")
        if source_end not in {None, ""} and str(source_end) != str(end):
            failures.append(f"{atom_id}: char_span end disagrees with source_byte_end")

    for row in sent_rows:
        sentence_id = row.get("sentence_id", "")
        declared = split_ids(row.get("atom_ids", ""))
        actual = atom_ids_by_sentence.get(sentence_id, set())
        status = row.get("coverage_status", "")
        exempt = bool(re.search(r"duplicate|ocr_artifact|placeholder|future_preview", status, re.I))
        if not actual and not exempt:
            failures.append(f"{sentence_id}: no atoms and no explicit exemption")
        unknown = declared - atom_ids
        if unknown:
            failures.append(f"{sentence_id}: atom_ids contains unknown ids: {', '.join(sorted(unknown))}")
        if actual and declared != actual:
            failures.append(
                f"{sentence_id}: atom_ids mirror mismatch; declared={sorted(declared)} "
                f"actual={sorted(actual)}"
            )

    if lengths and len(lengths) >= 40:
        short_ratio = very_short / len(lengths)
        median_len = statistics.median(lengths)
        if short_ratio > 0.35:
            failures.append(
                f"atomization is over-fragmented: {short_ratio:.0%} of atoms contain "
                "one visible character or less"
            )
        if median_len < 3:
            failures.append(
                f"atomization is over-fragmented: median visible atom length is {median_len}"
            )

    estimate = semantic_unit_estimate(source)
    if failures:
        print("FAILED")
        print(
            f"ledger_source_atoms={atom_kind} ledger_source_sentences={sent_kind} "
            f"semantic_unit_hint={estimate} sentence_rows={len(sent_rows)} atom_rows={len(atom_rows)}"
        )
        for item in failures:
            print(f"- {item}")
        for warning in warnings:
            print(f"WARNING: {warning}")
        return 1

    print("OK")
    print(
        f"ledger_source_atoms={atom_kind} ledger_source_sentences={sent_kind} "
        f"semantic_unit_hint={estimate} sentence_rows={len(sent_rows)} atom_rows={len(atom_rows)}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
