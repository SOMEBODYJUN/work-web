#!/usr/bin/env python3
"""Validate final output units against current source atoms and their invariants."""
from __future__ import annotations

from collections import defaultdict
from pathlib import Path
import json
import re
import sys

from content_authority import (
    TRACE_REQUIRED_FIELDS,
    OUTPUT_TRACE_SCHEMA,
    TRANSFORMATION_KINDS,
    NEW_CONTENT_BASES,
    atom_source_bytes,
    atom_map,
    load_jsonl_objects,
    normalize_visible,
    parse_int,
    parse_json_field,
    sha256_bytes,
    split_ids,
    split_output_units,
)
from content_functions import atom_function_contracts, normalize_functions


GOOD_VERDICTS = {"SUPPORTED", "DERIVED_SUPPORTED", "FORMAT_ONLY"}


def fail(messages: list[str]) -> int:
    print("FAILED")
    for message in messages:
        print(f"- {message}")
    return 1


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    publication = root / "publication_final.md"
    trace_path = root / "publication_sentence_trace.jsonl"
    failures: list[str] = []

    if not publication.exists():
        return fail(["missing publication_final.md"])
    if not trace_path.exists():
        return fail(["missing authoritative publication_sentence_trace.jsonl"])

    try:
        source, revision, atom_rows = atom_source_bytes(root)
        atoms = atom_map(atom_rows)
        trace_rows = load_jsonl_objects(trace_path)
        blueprint = json.loads((root / "publication_blueprint.json").read_text(encoding="utf-8"))
        quality_contract = json.loads((root / "quality_contract.json").read_text(encoding="utf-8"))
        max_atoms_per_unit = int(
            quality_contract.get("thresholds", {}).get("maximum_atoms_per_target_unit", 0)
        )
        if not 1 <= max_atoms_per_unit <= 3:
            raise ValueError("quality contract maximum_atoms_per_target_unit must be between 1 and 3")
        known_directives = {
            str(item.get("directive_id", ""))
            for item in quality_contract.get("expansion_budgets", [])
        }
        contracts, contract_errors = atom_function_contracts(
            blueprint, atom_rows, require_function_matrix=True
        )
        failures.extend(contract_errors)
    except Exception as exc:
        return fail([str(exc)])

    text = publication.read_text(encoding="utf-8")
    actual_units = split_output_units(text)
    if len(trace_rows) != len(actual_units):
        failures.append(f"trace row count {len(trace_rows)} does not equal deterministic output-unit count {len(actual_units)}")

    cited_by_atom: dict[str, list[tuple[int, str]]] = defaultdict(list)
    functions_by_atom: dict[str, set[str]] = defaultdict(set)
    row_by_unit: dict[str, dict] = {}
    all_output_ids: set[str] = set()

    for index, row in enumerate(trace_rows, 1):
        unit_id = str(row.get("output_unit_id", f"<row:{index}>"))
        missing = sorted(TRACE_REQUIRED_FIELDS - set(row))
        if missing:
            failures.append(f"{unit_id}: missing fields: {', '.join(missing)}")
            continue
        if row.get("schema_version") != OUTPUT_TRACE_SCHEMA:
            failures.append(f"{unit_id}: schema_version must be {OUTPUT_TRACE_SCHEMA}")
        expected_id = f"OU{index:04d}"
        if unit_id != expected_id:
            failures.append(f"row {index}: output_unit_id must be {expected_id}, got {unit_id}")
        if unit_id in all_output_ids:
            failures.append(f"duplicate output_unit_id: {unit_id}")
        all_output_ids.add(unit_id)
        row_by_unit[unit_id] = row
        if row.get("file") != "publication_final.md":
            failures.append(f"{unit_id}: file must be publication_final.md")

        if index <= len(actual_units):
            actual = actual_units[index - 1]
            try:
                start = parse_int(row.get("output_byte_start"), f"{unit_id}.output_byte_start")
                end = parse_int(row.get("output_byte_end"), f"{unit_id}.output_byte_end")
            except Exception as exc:
                failures.append(str(exc))
                continue
            if (start, end) != (actual.byte_start, actual.byte_end):
                failures.append(f"{unit_id}: output byte span does not match deterministic split")
            if row.get("output_text") != actual.text:
                failures.append(f"{unit_id}: output_text is not the exact final-file byte slice")
            if row.get("output_text_sha256") != actual.sha256:
                failures.append(f"{unit_id}: output_text_sha256 mismatch")
            if row.get("unit_type") != actual.unit_type:
                failures.append(f"{unit_id}: unit_type must be {actual.unit_type}")

        atom_ids = split_ids(row.get("source_atom_ids"), "A")
        directive_ids = re.findall(r"\bEXP\d{3,}\b", str(row.get("task_directive_ids", "")))
        unknown_directives = sorted(set(directive_ids) - known_directives)
        if unknown_directives:
            failures.append(f"{unit_id}: unknown author task directives: {', '.join(unknown_directives)}")
        if atom_ids and directive_ids:
            failures.append(f"{unit_id}: cannot receive both source and expansion volume credit")
        invariant_ids = split_ids(row.get("preserved_invariants"), "A")
        unknown = [aid for aid in atom_ids if aid not in atoms]
        if unknown:
            failures.append(f"{unit_id}: unknown source atoms: {', '.join(unknown)}")
        if set(invariant_ids) != set(atom_ids):
            failures.append(f"{unit_id}: preserved_invariants must list exactly the cited source atom IDs")
        try:
            function_map = parse_json_field(
                row.get("preserved_functions_json"),
                f"{unit_id}.preserved_functions_json",
                dict,
            )
        except Exception as exc:
            failures.append(str(exc))
            function_map = {}
        if set(function_map) != set(atom_ids):
            failures.append(
                f"{unit_id}: preserved_functions_json must cover exactly the cited source atoms"
            )
        if atom_ids and row.get("function_review_stage") != "P11_AIGC":
            failures.append(f"{unit_id}: atom mappings must be grounded in P11_AIGC review")
        for aid in atom_ids:
            cited_by_atom[aid].append((index, str(row.get("output_text", ""))))
            try:
                functions_by_atom[aid].update(
                    normalize_functions(
                        function_map.get(aid), f"{unit_id}.{aid}.preserved_functions"
                    )
                )
            except ValueError as exc:
                failures.append(str(exc))

        transformation = str(row.get("transformation_kind", ""))
        basis = str(row.get("new_content_basis", ""))
        verdict = str(row.get("verdict", ""))
        if transformation not in TRANSFORMATION_KINDS:
            failures.append(f"{unit_id}: invalid transformation_kind {transformation!r}")
        if basis not in NEW_CONTENT_BASES:
            failures.append(f"{unit_id}: invalid new_content_basis {basis!r}")
        if verdict not in GOOD_VERDICTS:
            failures.append(f"{unit_id}: non-publishable verdict {verdict!r}")

        if not atom_ids:
            allowed_source_free = {"LOCAL_CONNECTIVE", "STRUCTURAL_HEADING"}
            if directive_ids:
                allowed_source_free.add("TASK_DIRECTIVE_EXPANSION")
            if transformation not in allowed_source_free:
                failures.append(f"{unit_id}: source-free output lacks a permitted structural or author-task basis")
            if basis not in allowed_source_free:
                failures.append(f"{unit_id}: source-free output requires a matching basis")
        elif basis == "NONE" and transformation in {"LOCAL_CONNECTIVE", "STRUCTURAL_HEADING"}:
            failures.append(f"{unit_id}: structural transformation requires matching new_content_basis")

        if len(atom_ids) > max_atoms_per_unit:
            failures.append(
                f"{unit_id}: cites {len(atom_ids)} atoms; contract limit is {max_atoms_per_unit}"
            )
        if atom_ids:
            starts = [int(atoms[aid]["source_byte_start"]) for aid in atom_ids if aid in atoms]
            ends = [int(atoms[aid]["source_byte_end"]) for aid in atom_ids if aid in atoms]
            if starts and ends and index <= len(actual_units):
                source_width = max(ends) - min(starts)
                output_width = max(1, actual_units[index - 1].byte_end - actual_units[index - 1].byte_start)
                if source_width > max(4096, output_width * 12):
                    failures.append(f"{unit_id}: source citation range is too broad for the output unit")

    # Every atom has a real final destination.
    for atom_id, atom in atoms.items():
        status = str(atom.get("consumption_status", ""))
        refs = cited_by_atom.get(atom_id, [])
        if status == "CONSUMED" and not refs:
            failures.append(f"{atom_id}: marked CONSUMED but has no output unit")
        try:
            required_functions = set(
                normalize_functions(
                    contracts.get(atom_id, {}).get("required_functions"),
                    f"{atom_id}.P04_required_functions",
                )
            )
        except ValueError as exc:
            failures.append(str(exc))
            required_functions = set()
        missing_functions = sorted(required_functions - functions_by_atom.get(atom_id, set()))
        if status == "CONSUMED" and missing_functions:
            failures.append(
                f"{atom_id}: marked CONSUMED but functions are not mapped: "
                + ", ".join(missing_functions)
            )
        if status == "CONSUMED" and atom.get("consumption_review_stage") != "P13_PUBLICATION":
            failures.append(
                f"{atom_id}: CONSUMED lacks full P13_PUBLICATION function-review basis"
            )
        if status == "PLANNED":
            failures.append(f"{atom_id}: remains PLANNED in a publication release")
        if status == "BLOCKED":
            failures.append(f"{atom_id}: remains BLOCKED in a publication release")
        if status == "DUPLICATE_CONSUMED" and atom.get("content_type") != "DUPLICATE":
            failures.append(f"{atom_id}: DUPLICATE_CONSUMED is only valid for DUPLICATE atoms")

        if str(atom.get("surface_mode", "")) == "BYTE_EXACT":
            if atom.get("output_operation") != "COPY_SOURCE_SLICE":
                failures.append(f"{atom_id}: BYTE_EXACT atom contract is not COPY_SOURCE_SLICE")
            if not refs:
                failures.append(f"{atom_id}: BYTE_EXACT atom is not mapped to output")
            else:
                mapped = "".join(text for _idx, text in sorted(refs))
                raw_excerpt = str(atom.get("raw_excerpt", ""))
                if raw_excerpt not in mapped:
                    failures.append(f"{atom_id}: canonical source slice is not reproduced byte-for-byte in mapped output")
                for idx, _text in refs:
                    row = trace_rows[idx - 1]
                    if row.get("transformation_kind") != "COPY_SOURCE_SLICE":
                        failures.append(f"{atom_id}: BYTE_EXACT mapping must use COPY_SOURCE_SLICE")

    # Continuous exact groups protect the entire current-source slice, including
    # order, punctuation, and whitespace between atoms. Independent atom matches
    # are insufficient because they could be scattered or reordered.
    groups: dict[str, list[dict]] = defaultdict(list)
    for atom in atoms.values():
        group_id = str(atom.get("surface_group_id", "")).strip()
        if group_id and str(atom.get("surface_group_mode", "")) == "CONTIGUOUS_BYTE_EXACT":
            groups[group_id].append(atom)
    publication_bytes = text.encode("utf-8")
    for group_id, members in sorted(groups.items()):
        members.sort(key=lambda item: int(item.get("source_byte_start", 0)))
        start = int(members[0]["source_byte_start"])
        end = int(members[-1]["source_byte_end"])
        required_slice = source[start:end]
        occurrences = publication_bytes.count(required_slice)
        if occurrences != 1:
            failures.append(
                f"{group_id}: contiguous canonical-source slice must occur exactly once in publication_final.md; found {occurrences}"
            )
        mapped_indices: list[int] = []
        for atom in members:
            atom_id = str(atom.get("atom_id", ""))
            mapped_indices.extend(idx for idx, _text in cited_by_atom.get(atom_id, []))
        if mapped_indices:
            unique_indices = sorted(set(mapped_indices))
            if unique_indices != list(range(unique_indices[0], unique_indices[-1] + 1)):
                failures.append(f"{group_id}: mapped output units are not contiguous")
            for idx in unique_indices:
                if trace_rows[idx - 1].get("transformation_kind") != "COPY_SOURCE_SLICE":
                    failures.append(f"{group_id}: every mapped output unit must be COPY_SOURCE_SLICE")

    # Atom invariants are authoritative. Legacy proof/formula ledgers cannot override them.
    for atom_id, atom in atoms.items():
        refs = cited_by_atom.get(atom_id, [])
        if not refs:
            continue
        mapped_text = "\n".join(text for _idx, text in sorted(refs))
        mapped_norm = normalize_visible(mapped_text)
        try:
            inv = parse_json_field(atom.get("content_invariant_json"), f"{atom_id}.content_invariant_json", dict)
        except Exception as exc:
            failures.append(str(exc))
            continue

        content_type = str(atom.get("content_type", ""))
        required_fragments = inv.get("required_output_fragments", [])
        if required_fragments:
            if not isinstance(required_fragments, list):
                failures.append(f"{atom_id}: required_output_fragments must be a list")
            else:
                for fragment in required_fragments:
                    if not isinstance(fragment, str) or not fragment.strip():
                        failures.append(f"{atom_id}: invalid required output fragment")
                    elif normalize_visible(fragment) not in mapped_norm:
                        failures.append(f"{atom_id}: required invariant fragment missing from mapped output: {fragment}")

        forbidden_fragments = inv.get("forbidden_output_fragments", [])
        if forbidden_fragments:
            if not isinstance(forbidden_fragments, list):
                failures.append(f"{atom_id}: forbidden_output_fragments must be a list")
            else:
                for fragment in forbidden_fragments:
                    if isinstance(fragment, str) and fragment and normalize_visible(fragment) in mapped_norm:
                        failures.append(f"{atom_id}: forbidden invariant fragment appears in mapped output: {fragment}")

        if content_type in {"FORMULA", "OCR_FRAGMENT"}:
            # Raw OCR text in an atom is not a canonical mathematical expression.
            # Formula fidelity is governed by the reviewed formula-block ledger,
            # mathematical_review.json, and FORMULA_NORMALIZATION trace kinds.
            mapped_rows = [trace_rows[idx - 1] for idx, _text in refs]
            allowed_formula_kinds = {
                "FORMULA_NORMALIZATION",
                "CONTENT_PRESERVING_REWRITE",
                "SOURCE_ROUTE_COMPLETION",
                "READER_CLARIFICATION",
            }
            if not any(str(row.get("transformation_kind", "")) in allowed_formula_kinds for row in mapped_rows):
                failures.append(
                    f"{atom_id}: formula/OCR atom must map through a reviewed normalization or content-preserving trace"
                )

        if content_type in {"PROOF_ROUTE", "PROOF_STEP"}:
            for key in ("premises", "required_steps", "forbidden_alternatives"):
                if not isinstance(inv.get(key), list) or not inv.get(key):
                    failures.append(f"{atom_id}: proof invariant {key} is missing/empty")
            if not str(inv.get("conclusion", "")).strip():
                failures.append(f"{atom_id}: proof conclusion invariant is missing")

    if failures:
        return fail(failures)
    print("OK")
    print(f"output_units={len(actual_units)} traced_atoms={len(cited_by_atom)} source_revision_id={revision.get('source_revision_id')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
