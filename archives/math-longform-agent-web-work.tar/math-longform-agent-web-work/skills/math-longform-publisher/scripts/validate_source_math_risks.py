#!/usr/bin/env python3
"""Validate the AI-owned whole-source mathematical-risk review lifecycle.

This validator never infers mathematical risk from source vocabulary.  It
checks only current-source identity, exact UTF-8 spans, lifecycle shape, and the
presence of one completed or explicitly blocked whole-source semantic scan.
"""
from __future__ import annotations

from pathlib import Path
import hashlib
import re
import sys

from safe_io import read_json_strict
from structured_ledger import load_required_ledger


REQUIRED = {
    "risk_id",
    "source_revision_id",
    "source_sha256",
    "source_span",
    "risk_type",
    "claim_excerpt",
    "reason",
    "required_review",
    "resolution_status",
    "resolution_note",
}
SCAN_TYPE = "SOURCE_WIDE_MATH_SEMANTIC_SCAN"
NO_RISK_TYPE = "NO_MATHEMATICAL_RISKS"
SCAN_STATUSES = {
    "BLOCKED_NEEDS_MATHEMATICAL_REVIEW",
    "MATH_SEMANTIC_SCAN_COMPLETE",
}
RISK_STATUSES = {
    "BLOCKED_NEEDS_MATHEMATICAL_REVIEW",
    "RESOLVED_WITH_JUSTIFICATION",
}
SPAN_RE = re.compile(r"^(\d+)-(\d+)$")
SHA_RE = re.compile(r"^[0-9a-f]{64}$")


def weak(value: object, minimum: int = 16) -> bool:
    text = str(value or "").strip()
    return len(text) < minimum or text.lower() in {
        "none", "todo", "unknown", "pending", "no risks", "no risk",
    }


def main() -> int:
    root = (Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")).resolve()
    source_path = root / "source_canonical.txt"
    revision_path = root / "source_revision.json"
    failures: list[str] = []
    try:
        source_bytes = source_path.read_bytes()
        source_bytes.decode("utf-8", errors="strict")
        revision = read_json_strict(revision_path, root=root)
    except Exception as exc:
        print("FAILED")
        print(f"- cannot load current source authority: {exc}")
        return 1
    if not isinstance(revision, dict):
        print("FAILED")
        print("- source_revision.json must contain one object")
        return 1
    source_sha = hashlib.sha256(source_bytes).hexdigest()
    revision_id = str(revision.get("source_revision_id", ""))

    kind, rows, errors = load_required_ledger(
        root / "source_math_risk_ledger.md", REQUIRED, "risk_id", "MR"
    )
    failures.extend(errors)
    if not rows:
        failures.append("source_math_risk_ledger has no rows")

    scan_rows = [row for row in rows if str(row.get("risk_type", "")).upper() == SCAN_TYPE]
    no_risk_rows = [row for row in rows if str(row.get("risk_type", "")).upper() == NO_RISK_TYPE]
    risk_rows = [
        row for row in rows
        if str(row.get("risk_type", "")).upper() not in {SCAN_TYPE, NO_RISK_TYPE}
    ]
    if len(scan_rows) != 1:
        failures.append("exactly one SOURCE_WIDE_MATH_SEMANTIC_SCAN row is required")

    scan_complete = False
    if scan_rows:
        scan_status = str(scan_rows[0].get("resolution_status", "")).upper()
        if scan_status not in SCAN_STATUSES:
            failures.append(f"source-wide mathematical scan has invalid status {scan_status!r}")
        scan_complete = scan_status == "MATH_SEMANTIC_SCAN_COMPLETE"
    if scan_complete and not risk_rows and len(no_risk_rows) != 1:
        failures.append(
            "a completed mathematical scan with no concrete risks requires exactly one NO_MATHEMATICAL_RISKS row"
        )
    if scan_complete and risk_rows and no_risk_rows:
        failures.append("NO_MATHEMATICAL_RISKS conflicts with concrete mathematical-risk rows")
    if not scan_complete and (no_risk_rows or risk_rows):
        failures.append("P03 conclusions cannot exist before the whole-source mathematical scan is complete")
    if len(no_risk_rows) > 1:
        failures.append("at most one NO_MATHEMATICAL_RISKS row is allowed")

    whole_span = f"0-{len(source_bytes)}"
    for index, row in enumerate(rows, 1):
        rid = str(row.get("risk_id", ""))
        typ = str(row.get("risk_type", "")).upper()
        status = str(row.get("resolution_status", "")).upper()
        if str(row.get("source_revision_id", "")) != revision_id:
            failures.append(f"row {index} {rid}: source_revision_id is stale")
        row_sha = str(row.get("source_sha256", ""))
        if not SHA_RE.fullmatch(row_sha) or row_sha != source_sha:
            failures.append(f"row {index} {rid}: source_sha256 is stale or invalid")
        span_text = str(row.get("source_span", ""))
        match = SPAN_RE.fullmatch(span_text)
        if not match:
            failures.append(f"row {index} {rid}: invalid UTF-8 byte source_span")
            continue
        start, end = int(match.group(1)), int(match.group(2))
        if not (0 <= start < end <= len(source_bytes)):
            failures.append(f"row {index} {rid}: source_span is outside source_canonical.txt")
            continue
        try:
            excerpt = source_bytes[start:end].decode("utf-8", errors="strict")
        except UnicodeDecodeError:
            failures.append(f"row {index} {rid}: source_span splits UTF-8")
            continue

        claim = str(row.get("claim_excerpt", "")).strip()
        if typ in {SCAN_TYPE, NO_RISK_TYPE}:
            if span_text != whole_span:
                failures.append(f"row {index} {rid}: whole-source row must bind {whole_span}")
            if claim != "WHOLE_SOURCE":
                failures.append(f"row {index} {rid}: whole-source row claim_excerpt must be WHOLE_SOURCE")
        elif not claim or claim not in excerpt:
            failures.append(f"row {index} {rid}: claim_excerpt is not inside its exact source span")

        if weak(row.get("reason")):
            failures.append(f"row {index} {rid}: reason is too weak")
        if weak(row.get("required_review")):
            failures.append(f"row {index} {rid}: required_review is too weak")
        if weak(row.get("resolution_note"), 24):
            failures.append(f"row {index} {rid}: resolution_note is too weak")

        if typ == SCAN_TYPE:
            if status not in SCAN_STATUSES:
                failures.append(f"row {index} {rid}: invalid scan status {status!r}")
        elif typ == NO_RISK_TYPE:
            if status != "NO_MATHEMATICAL_RISKS":
                failures.append(f"row {index} {rid}: no-risk conclusion has invalid status")
        elif status not in RISK_STATUSES:
            failures.append(f"row {index} {rid}: concrete risk has invalid status {status!r}")

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    blocked = sum(
        str(row.get("resolution_status", "")).upper()
        == "BLOCKED_NEEDS_MATHEMATICAL_REVIEW"
        for row in rows
    )
    print(
        f"OK: ledger_source={kind} rows={len(rows)} "
        f"scan_complete={str(scan_complete).lower()} concrete_risks={len(risk_rows)} blocked={blocked}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
