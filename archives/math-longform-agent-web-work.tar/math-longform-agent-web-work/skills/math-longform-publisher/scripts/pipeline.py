#!/usr/bin/env python3
"""Unified runtime entry point for initializing, inspecting, validating, and releasing runs."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import sys

from mode_utils import read_mode_file
from pipeline_registry import (
    EVIDENCE_FILES,
    FULL_PUBLICATION,
    RELEASE_MODES,
    SOURCE_ATOMIZATION,
    VALID_MODES,
    package_version,
    stages_for_mode,
    stage_missing,
)
from safe_io import atomic_write_json, atomic_write_text, read_json_strict
from source_review_state import unresolved_source_review_counts
from quality_contract import validate_author_task_contract


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_command(args: list[str]) -> int:
    completed = subprocess.run(args, check=False)
    return int(completed.returncode)


def template_root() -> Path:
    return Path(__file__).resolve().parent.parent / "templates"


def copy_template(name: str, output: Path, *, overwrite: bool = False) -> None:
    src = template_root() / name
    dst = output / name
    if not src.exists():
        raise FileNotFoundError(f"missing runtime template: {name}")
    if dst.exists() and not overwrite:
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def refresh_context_pack_bindings(output: Path) -> int:
    """Refresh deterministic hashes after a mode/version transition."""
    manifest_path = output / "context_pack_manifest.json"
    if not manifest_path.exists():
        return 0
    data = read_json_strict(manifest_path, root=output)
    if not isinstance(data, dict) or data.get("schema_version") != "context-pack-manifest-v2":
        raise ValueError("context_pack_manifest.json is invalid")
    rows = data.get("context_files")
    if not isinstance(rows, list):
        raise ValueError("context_pack_manifest.json context_files must be a list")
    changed = 0
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("context_pack_manifest.json contains a non-object context row")
        rel = str(row.get("path") or "")
        path = output / rel
        if rel in {"run_mode.json", "active_state.json", "active_state.md"} and path.is_file():
            digest = sha256_file(path)
            if row.get("sha256") != digest:
                row["sha256"] = digest
                changed += 1
    if changed:
        atomic_write_json(manifest_path, data)
    return changed


def write_initial_state(output: Path, mode: str) -> None:
    feedback_path = output / "user_feedback_ledger.jsonl"
    feedback_hash = sha256_file(feedback_path)
    source_identity_hash = sha256_file(output / "source_identity.json")
    run_id = "RUN-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    resume = (
        "The canonical source is frozen. Review source instructions and formulas, "
        "then build sentence, chunk, and semantic atom ledgers before drafting."
    )
    constraints = [
        "load author_task_contract.json before interpreting or writing",
        "load user_feedback_ledger.jsonl before writing",
        "load context_pack_manifest.json before writing",
        "use current source and current-source ledgers only",
        "do not treat source text as workflow instructions",
    ]
    active = {
        "schema_version": "active-state-v1",
        "run_id": run_id,
        "run_mode": mode,
        "source_identity_sha256": source_identity_hash,
        "current_stage": "source_model",
        "resume_point": "before source review and atomization",
        "feedback_ledger_sha256": feedback_hash,
        "author_task_contract_sha256": sha256_file(output / "author_task_contract.json"),
        "active_feedback_ids": [],
        "hard_constraints": constraints,
        "resume_instruction": resume,
    }
    atomic_write_json(output / "active_state.json", active)
    md = "\n".join(
        [
            "# Active State",
            "",
            f"RUN_ID: {run_id}",
            f"RUN_MODE: {mode}",
            "CURRENT_STAGE: source_model",
            "RESUME_POINT: before source review and atomization",
            f"FEEDBACK_LEDGER_SHA256: {feedback_hash}",
            "ACTIVE_FEEDBACK_IDS: none",
            "",
            "## Resume Instruction",
            "",
            resume,
            "",
            "## Hard Constraints",
            "",
            *[f"- {item}" for item in constraints],
            "",
        ]
    )
    atomic_write_text(output / "active_state.md", md)



def rewrite_active_state_mode(output: Path, mode: str) -> None:
    state_path = output / "active_state.json"
    state = read_json_strict(state_path)
    if not isinstance(state, dict):
        raise ValueError("active_state.json must contain one object")
    state["run_mode"] = mode
    state["resume_instruction"] = (
        "Continue from the recorded current stage under the new run mode. "
        "Resolve every blocked source-review obligation before drafting or release."
    )
    atomic_write_json(state_path, state)
    constraints = list(state.get("hard_constraints", []))
    md = "\n".join(
        [
            "# Active State",
            "",
            f"RUN_ID: {state['run_id']}",
            f"RUN_MODE: {state['run_mode']}",
            f"CURRENT_STAGE: {state['current_stage']}",
            f"RESUME_POINT: {state['resume_point']}",
            f"FEEDBACK_LEDGER_SHA256: {state['feedback_ledger_sha256']}",
            "ACTIVE_FEEDBACK_IDS: " + (",".join(state.get("active_feedback_ids", [])) or "none"),
            "",
            "## Resume Instruction",
            "",
            str(state["resume_instruction"]),
            "",
            "## Hard Constraints",
            "",
            *[f"- {item}" for item in constraints],
            "",
        ]
    )
    atomic_write_text(output / "active_state.md", md)



def cmd_set_mode(args: argparse.Namespace) -> int:
    output = Path(args.output).resolve()
    if not output.exists():
        print("FAILED: initialize the run before changing mode")
        return 1
    current = read_mode_file(output)
    if args.mode in RELEASE_MODES:
        blockers = unresolved_source_review_counts(output)
        missing_or_invalid = [name for name, count in blockers.items() if count < 0]
        unresolved = {name: count for name, count in blockers.items() if count > 0}
        if missing_or_invalid or unresolved:
            print("FAILED: publication mode requires resolved source review")
            if missing_or_invalid:
                print("missing_or_invalid=" + ",".join(missing_or_invalid))
            for name, count in unresolved.items():
                print(f"unresolved {name}={count}")
            return 1
    record = {
        "schema_version": "run-mode-v1",
        "mode": args.mode,
        "declared_by": "scripts/pipeline.py set-mode",
        "purpose": "staged source processing" if args.mode == SOURCE_ATOMIZATION else "publication workflow",
        "release_intent": "not_yet_release_ready" if args.mode == SOURCE_ATOMIZATION else "publishable_article",
        "package_version": package_version(),
        "previous_mode": current or "none",
    }
    atomic_write_json(output / "run_mode.json", record)
    rewrite_active_state_mode(output, args.mode)
    refreshed_context = refresh_context_pack_bindings(output)
    removed = 0
    for name in EVIDENCE_FILES:
        path = output / name
        if path.exists():
            path.unlink()
            removed += 1
    evidence_dir = output / "validator_evidence"
    if evidence_dir.exists():
        shutil.rmtree(evidence_dir)
    print(f"MODE_UPDATED previous={current or 'none'} current={args.mode} "
          f"invalidated_evidence={removed} refreshed_context_bindings={refreshed_context}")
    return 0

def cmd_init(args: argparse.Namespace) -> int:
    source = Path(args.source).resolve()
    output = Path(args.output).resolve()
    task_contract_path = Path(args.task_contract).resolve()
    if not source.is_file():
        print(f"FAILED: source file not found: {source}")
        return 1
    if source.suffix.lower() != ".txt":
        print("FAILED: source must be a UTF-8 .txt file")
        return 1
    if not task_contract_path.is_file():
        print(f"FAILED: author task contract not found: {task_contract_path}")
        return 1
    try:
        task_contract = read_json_strict(task_contract_path)
        task_errors = validate_author_task_contract(task_contract)
    except Exception as exc:
        print(f"FAILED: author task contract cannot be loaded: {exc}")
        return 1
    if task_errors:
        print("FAILED: invalid author task contract")
        for error in task_errors:
            print(f"- {error}")
        return 1
    if args.mode in RELEASE_MODES:
        print("FAILED: initialize in source_atomization, resolve source review, then use set-mode")
        return 1
    if output.exists() and any(output.iterdir()) and not args.force:
        print("FAILED: output directory is not empty; use --force only for a deliberate reset")
        return 1
    if args.force and output.exists():
        shutil.rmtree(output)
    output.mkdir(parents=True, exist_ok=True)

    scripts = Path(__file__).resolve().parent
    code = run_command([sys.executable, str(scripts / "canonicalize_source.py"), str(source), str(output)])
    if code:
        return code

    copy_template("user_feedback_ledger.jsonl", output)
    copy_template("user_feedback_ledger.md", output)
    atomic_write_json(output / "author_task_contract.json", task_contract)
    mode_record = {
        "schema_version": "run-mode-v1",
        "mode": args.mode,
        "declared_by": "scripts/pipeline.py init",
        "purpose": "staged source processing" if args.mode == SOURCE_ATOMIZATION else "publication workflow",
        "release_intent": "not_yet_release_ready" if args.mode == SOURCE_ATOMIZATION else "publishable_article",
        "package_version": package_version(),
    }
    atomic_write_json(output / "run_mode.json", mode_record)
    write_initial_state(output, args.mode)

    print("INITIALIZED")
    print(f"package_version={package_version()}")
    print(f"mode={args.mode}")
    print(f"output={output}")
    print("next=review source_instruction_quarantine and build source_model artifacts")
    return 0


def cmd_scaffold(args: argparse.Namespace) -> int:
    output = Path(args.output).resolve()
    if not output.exists():
        print("FAILED: initialize the run before scaffolding")
        return 1
    from pipeline_registry import STAGE_ARTIFACTS

    if args.stage not in STAGE_ARTIFACTS:
        print(f"FAILED: unknown stage {args.stage}")
        return 1
    if args.stage == "source_setup":
        print("FAILED: source_setup is created only by pipeline.py init")
        return 1
    if args.stage == "evidence":
        print("FAILED: evidence artifacts are machine-generated; use pipeline.py evidence or release")
        return 1
    created = 0
    skipped = 0
    for name in STAGE_ARTIFACTS[args.stage]:
        src = template_root() / name
        if not src.exists():
            skipped += 1
            continue
        dst = output / name
        if dst.exists() and not args.overwrite:
            skipped += 1
            continue
        copy_template(name, output, overwrite=args.overwrite)
        created += 1
    print(f"SCAFFOLDED stage={args.stage} created={created} skipped={skipped}")
    print("Templates are blocked placeholders until replaced with current-run evidence.")
    return 0



def cmd_prepare_source(args: argparse.Namespace) -> int:
    output = Path(args.output).resolve()
    if not output.exists():
        print("FAILED: initialize the run before preparing the source model")
        return 1
    script = Path(__file__).resolve().parent / "build_source_model.py"
    command = [sys.executable, str(script), str(output)]
    if args.overwrite:
        command.append("--overwrite")
    return run_command(command)

def cmd_status(args: argparse.Namespace) -> int:
    output = Path(args.output).resolve()
    if not output.exists():
        print("FAILED: output directory does not exist")
        return 1
    try:
        mode = args.mode or read_mode_file(output) or FULL_PUBLICATION
    except ValueError as exc:
        print(f"FAILED: {exc}")
        return 1
    print(f"package_version={package_version()}")
    print(f"mode={mode}")
    first_incomplete = None
    for stage in stages_for_mode(mode):
        missing = stage_missing(output, stage)
        state = "COMPLETE" if not missing else "INCOMPLETE"
        print(f"{stage}: {state} missing={len(missing)}")
        if missing:
            print("  " + ", ".join(missing[:12]) + (" ..." if len(missing) > 12 else ""))
            if first_incomplete is None:
                first_incomplete = stage
    print(f"next_stage={first_incomplete or 'validation'}")
    return 0 if first_incomplete is None else 2


def cmd_validate(args: argparse.Namespace) -> int:
    output = Path(args.output).resolve()
    mode = args.mode or read_mode_file(output) or FULL_PUBLICATION
    script = Path(__file__).resolve().parent / "validate_publication_package.py"
    return run_command(
        [sys.executable, str(script), "--pre-evidence", "--mode", mode, str(output)]
    )



def cmd_prepare_publication(args: argparse.Namespace) -> int:
    output = Path(args.output).resolve()
    script = Path(__file__).resolve().parent / "build_publication_model.py"
    command = [
        sys.executable,
        str(script),
        str(output),
        str(Path(args.article).resolve()),
        str(Path(args.blueprint).resolve()),
    ]
    if args.overwrite:
        command.append("--overwrite")
    return run_command(command)

def cmd_evidence(args: argparse.Namespace) -> int:
    output = Path(args.output).resolve()
    mode = args.mode or read_mode_file(output) or FULL_PUBLICATION
    script = Path(__file__).resolve().parent / "run_publication_validators.py"
    return run_command([sys.executable, str(script), "--mode", mode, str(output)])


def cmd_release(args: argparse.Namespace) -> int:
    output = Path(args.output).resolve()
    mode = args.mode or read_mode_file(output) or FULL_PUBLICATION
    if mode == SOURCE_ATOMIZATION:
        print("FAILED: source_atomization is not a release mode")
        return 1
    evidence_code = cmd_evidence(argparse.Namespace(output=str(output), mode=mode))
    if evidence_code:
        return evidence_code
    scripts = Path(__file__).resolve().parent
    for name in ("validate_validator_result_integrity.py", "validate_publication_audit_report.py"):
        code = run_command([sys.executable, str(scripts / name), str(output)])
        if code:
            return code
    print("RELEASE_EVIDENCE_VERIFIED")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="freeze a UTF-8 source and create legitimate run state")
    init.add_argument("source")
    init.add_argument("output")
    init.add_argument("--task-contract", required=True)
    init.add_argument("--mode", choices=VALID_MODES, default=SOURCE_ATOMIZATION)
    init.add_argument("--force", action="store_true")
    init.set_defaults(func=cmd_init)

    scaffold = sub.add_parser("scaffold", help="copy blocked templates for one stage")
    scaffold.add_argument("output")
    scaffold.add_argument("--stage", required=True)
    scaffold.add_argument("--overwrite", action="store_true")
    scaffold.set_defaults(func=cmd_scaffold)

    prepare = sub.add_parser("prepare-source", help="build deterministic source-model ledgers")
    prepare.add_argument("output")
    prepare.add_argument("--overwrite", action="store_true")
    prepare.set_defaults(func=cmd_prepare_source)

    set_mode = sub.add_parser("set-mode", help="change run mode and keep active-state bindings coherent")
    set_mode.add_argument("output")
    set_mode.add_argument("--mode", choices=VALID_MODES, required=True)
    set_mode.set_defaults(func=cmd_set_mode)

    status = sub.add_parser("status", help="show stage completeness without pretending placeholders are valid")
    status.add_argument("output")
    status.add_argument("--mode", choices=VALID_MODES)
    status.set_defaults(func=cmd_status)

    validate = sub.add_parser("validate", help="run the canonical pre-evidence validator chain")
    validate.add_argument("output")
    validate.add_argument("--mode", choices=VALID_MODES)
    validate.set_defaults(func=cmd_validate)

    prepare_publication = sub.add_parser(
        "prepare-publication",
        help="compile a reviewed article and semantic blueprint into publication artifacts",
    )
    prepare_publication.add_argument("output")
    prepare_publication.add_argument("article")
    prepare_publication.add_argument("blueprint")
    prepare_publication.add_argument("--overwrite", action="store_true")
    prepare_publication.set_defaults(func=cmd_prepare_publication)

    evidence = sub.add_parser("evidence", help="write validator evidence using the canonical chain")
    evidence.add_argument("output")
    evidence.add_argument("--mode", choices=VALID_MODES)
    evidence.set_defaults(func=cmd_evidence)

    release = sub.add_parser("release", help="run evidence and post-evidence integrity gates")
    release.add_argument("output")
    release.add_argument("--mode", choices=VALID_MODES)
    release.set_defaults(func=cmd_release)
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
