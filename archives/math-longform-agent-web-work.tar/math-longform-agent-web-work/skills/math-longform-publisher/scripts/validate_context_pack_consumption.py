#!/usr/bin/env python3
"""Validate that the pre-writing context pack is a real input contract."""
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import re
import sys

from context_pack import (
    CONSUMERS as REQUIRED_CONSUMERS,
    OPTIONAL_IF_PRESENT,
    REQUIRED_CONTEXT_FILES,
    WRITE_TARGETS as REQUIRED_WRITE_TARGETS,
)


PLACEHOLDER_RE = re.compile(r"\b(TODO|TBD|pending|unknown|unclear)\b", re.I)
ID_RE = re.compile(r"\b(?:A|S|PR|V|SYM|CH|SEP|SEC)\d{3,}\b")


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else ""


def safe_rel(value: object) -> str:
    rel = str(value or "").strip().replace("\\", "/")
    if not rel or rel.startswith("/") or rel.startswith("../") or "/../" in rel or rel == "..":
        return ""
    return rel


def load_manifest(path: Path, failures: list[str]) -> dict:
    if not path.exists() or not read(path).strip():
        failures.append("missing or empty context_pack_manifest.json")
        return {}
    try:
        data = json.loads(read(path))
    except Exception as exc:
        failures.append(f"context_pack_manifest.json invalid JSON: {exc}")
        return {}
    if not isinstance(data, dict):
        failures.append("context_pack_manifest.json must be a JSON object")
        return {}
    return data


def dynamic_chunk_files(root: Path) -> set[str]:
    chunk_dir = root / "chunk_ledger"
    if not chunk_dir.exists():
        return set()
    return {p.relative_to(root).as_posix() for p in chunk_dir.glob("*") if p.is_file()}


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    root = root.resolve()
    failures: list[str] = []

    data = load_manifest(root / "context_pack_manifest.json", failures)
    entries = data.get("context_files") if isinstance(data, dict) else None
    if data:
        if data.get("schema_version") != "context-pack-manifest-v2":
            failures.append("context_pack_manifest.json schema_version must be context-pack-manifest-v2")
        if data.get("prepared_before_writing") is not True:
            failures.append("context_pack_manifest.json prepared_before_writing must be true")
        if PLACEHOLDER_RE.search(json.dumps(data, ensure_ascii=False)):
            failures.append("context_pack_manifest.json contains placeholder wording")
    if not isinstance(entries, list) or not entries:
        failures.append("context_pack_manifest.json context_files must be a nonempty list")
        entries = []

    by_path: dict[str, dict] = {}
    for idx, item in enumerate(entries, 1):
        if not isinstance(item, dict):
            failures.append(f"context_files row {idx} is not an object")
            continue
        rel = safe_rel(item.get("path"))
        if not rel:
            failures.append(f"context_files row {idx} has unsafe or empty path")
            continue
        if rel in by_path:
            failures.append(f"context_files duplicates path: {rel}")
        by_path[rel] = item
        path = root / rel
        if not path.exists() or not path.is_file():
            failures.append(f"context file listed but missing: {rel}")
            continue
        recorded = str(item.get("sha256", "")).strip()
        if not re.fullmatch(r"[0-9a-f]{64}", recorded):
            failures.append(f"context file {rel} missing valid sha256")
        elif recorded != sha256(path):
            failures.append(f"context file {rel} sha256 is stale")
        role = str(item.get("role", "")).strip()
        if not role or PLACEHOLDER_RE.search(role):
            failures.append(f"context file {rel} missing usable role")

    required = set(REQUIRED_CONTEXT_FILES)
    required |= {rel for rel in OPTIONAL_IF_PRESENT if (root / rel).exists()}
    required |= dynamic_chunk_files(root)
    missing_from_manifest = sorted(rel for rel in required if rel not in by_path)
    if missing_from_manifest:
        failures.append("context pack missing required input files: " + ", ".join(missing_from_manifest[:30]))

    missing_on_disk = sorted(rel for rel in REQUIRED_CONTEXT_FILES if not (root / rel).exists())
    if missing_on_disk:
        failures.append("required context input files missing on disk: " + ", ".join(missing_on_disk[:30]))

    write_targets = {safe_rel(x) for x in data.get("write_targets", [])} if isinstance(data.get("write_targets"), list) else set()
    if not write_targets:
        failures.append("context_pack_manifest.json write_targets must be a nonempty list")
    missing_targets = sorted(REQUIRED_WRITE_TARGETS - write_targets)
    if missing_targets:
        failures.append("context pack write_targets missing release article chain files: " + ", ".join(missing_targets))
    for rel in sorted(write_targets):
        if rel and not (root / rel).exists():
            failures.append(f"context pack write target missing on disk: {rel}")

    consumers = {safe_rel(x) for x in data.get("consumed_by", [])} if isinstance(data.get("consumed_by"), list) else set()
    if not consumers:
        failures.append("context_pack_manifest.json consumed_by must be a nonempty list")
    missing_consumers = sorted(REQUIRED_CONSUMERS - consumers)
    if missing_consumers:
        failures.append("context pack consumed_by missing downstream proof files: " + ", ".join(missing_consumers))
    for rel in sorted(REQUIRED_CONSUMERS):
        text = read(root / rel)
        if not text.strip():
            failures.append(f"context consumer missing or empty: {rel}")
        elif rel in {"section_execution_plan.jsonl", "section_plan.md", "pre_final_plan.md", "final_trace_map.md", "publication_trace_map.md", "publication_claim_ledger.md", "publication_sentence_trace.md"} and not ID_RE.search(text):
            failures.append(f"context consumer has no source/proof ids: {rel}")

    active = None
    active_path = root / "active_state.json"
    if active_path.exists():
        try:
            active = json.loads(read(active_path))
        except Exception as exc:
            failures.append(f"active_state.json invalid JSON while checking context pack: {exc}")
    if isinstance(active, dict):
        constraints = " ".join(str(x) for x in active.get("hard_constraints", [])).lower()
        if "context_pack_manifest.json" not in constraints and "context pack" not in constraints:
            failures.append("active_state.json hard_constraints must bind context_pack_manifest.json or context pack loading")

    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print(f"OK: context_files={len(by_path)} write_targets={len(write_targets)} consumers={len(consumers)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
