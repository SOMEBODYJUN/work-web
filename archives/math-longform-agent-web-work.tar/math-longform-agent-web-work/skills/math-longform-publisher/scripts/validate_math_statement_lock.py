#!/usr/bin/env python3
"""Validate math_statement_ledger.md as a real upstream lock."""
from pathlib import Path
import re
import sys

BAD_STATUS = re.compile(r"\b(draft|needs_proof|pending|unknown|unclear|TODO|TBD)\b|待定|不清楚", re.I)

def read(p):
    return p.read_text(encoding="utf-8") if p.exists() else ""

def table_rows(text, prefix):
    for line in text.splitlines():
        if not re.match(rf"^\|\s*{prefix}\d+\s*\|", line):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        yield cells

def ids(text, prefix):
    return set(re.findall(rf"\b{prefix}\d{{3,}}\b", text))

def empty(x):
    return not x or x.lower() in {"none", "n/a", "na", "无", "-"}

def main():
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    ledger = read(root / "math_statement_ledger.md")
    trace = read(root / "final_trace_map.md") + read(root / "publication_trace_map.md") + read(root / "section_plan.md")
    proofs = read(root / "proof_obligations.md")
    failures = []

    rows = list(table_rows(ledger, "S"))
    if not rows:
        failures.append("no S rows in math_statement_ledger.md")

    for cells in rows:
        sid = cells[0]
        row = " | ".join(cells)
        if len(cells) < 11:
            failures.append(f"{sid}: row has too few columns")
            continue
        source_atoms = cells[2] if len(cells) > 2 else ""
        obj = cells[3] if len(cells) > 3 else ""
        conclusion = cells[5] if len(cells) > 5 else ""
        symbols = cells[6] if len(cells) > 6 else ""
        proof_ids = cells[9] if len(cells) > 9 else ""
        status = cells[-1]
        if not re.search(r"\bA\d{3,}\b", source_atoms):
            failures.append(f"{sid}: missing source atom support")
        if empty(obj):
            failures.append(f"{sid}: missing mathematical object")
        if empty(conclusion) and "definition" not in row.lower():
            failures.append(f"{sid}: missing conclusion")
        if empty(symbols):
            failures.append(f"{sid}: missing symbols_used")
        if BAD_STATUS.search(status):
            failures.append(f"{sid}: unresolved status {status!r}")
        if proof_ids and not all(pid in proofs for pid in re.findall(r"PR\d+", proof_ids)):
            failures.append(f"{sid}: proof obligation id not present in proof_obligations.md")
        if sid not in trace:
            failures.append(f"{sid}: not referenced by section/trace/publication maps")

    used = ids(trace, "S")
    defined = ids(ledger, "S")
    unknown = sorted(used - defined)
    if unknown:
        failures.append("trace/section uses undefined statement ids: " + ", ".join(unknown[:20]))

    if failures:
        print("FAILED")
        for f in failures:
            print(f"- {f}")
        return 1
    print("OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
