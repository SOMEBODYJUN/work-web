#!/usr/bin/env python3
"""Validate the two-layer author-question review ledger.

Lexical patterns create conservative P02 candidates only. P03 must read the
whole source, disposition every candidate, add missed obligations, and record a
completed source-wide semantic scan. The validator checks spans and workflow
completeness; it does not decide from words whether a passage is a question.
"""
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import re
import sys

from structured_ledger import load_required_ledger

QUESTION_CANDIDATE_PATTERNS = [
    re.compile(r"[^。！？\n]{0,30}(?:对不对|是不是|可不可以|能不能|如何|为什么|怎么|有没有|什么方法|更好的方法)[^。！？\n]{0,30}[？?]?"),
    re.compile(r"[^。！？\n]{0,30}(?:告诉我|你应该|希望你|仔细琢磨|琢磨一下|找.*应用|更深入的理解|几何解释)[^。！？\n]{0,40}"),
    re.compile(r"[^。！？\n]{0,30}(?:我突然想问|我想问|我希望|如果你有|此处你应该)[^。！？\n]{0,50}"),
]
BAD_STATUS = {"", "TODO", "UNKNOWN", "PENDING", "TBD", "UNRESOLVED"}
VALID_STATUS = {"RESOLVED_IN_ARTICLE", "PRESERVED_AS_AUTHOR_QUESTION", "ANSWERED_IN_EXPLANATION", "CONFIRMED_ACTIVE_OBLIGATION", "BLOCKED_NEEDS_SOURCE_SUPPORT", "DISMISSED_NOT_AN_OBLIGATION", "SEMANTIC_SCAN_COMPLETE", "NO_AUTHOR_QUESTIONS"}
VALID_TYPES = {"P02_SEMANTIC_CANDIDATE", "SOURCE_WIDE_SEMANTIC_SCAN", "DISMISSED_P02_CANDIDATE", "UNDERSTANDING_CHECK", "REQUEST_FOR_BETTER_METHOD", "REQUEST_FOR_APPLICATION", "REQUEST_FOR_DEEPER_EXPLANATION", "REQUEST_FOR_GEOMETRIC_INTERPRETATION", "UNCERTAINTY_TO_RESOLVE", "VOICE_INTENT_TO_PRESERVE", "NO_AUTHOR_QUESTIONS"}
ARTICLE_FULFILLMENT_STATUS = {
    "RESOLVED_IN_ARTICLE",
    "PRESERVED_AS_AUTHOR_QUESTION",
    "ANSWERED_IN_EXPLANATION",
}


def read(path: Path) -> str:
    return path.read_bytes().decode("utf-8", errors="strict") if path.exists() else ""


def parse_span(span: str) -> tuple[int, int] | None:
    m = re.match(r"^\s*(\d+)\s*-\s*(\d+)\s*$", span or "")
    if not m:
        return None
    a, b = int(m.group(1)), int(m.group(2))
    return (a, b) if a <= b else None


def detect_question_candidates(source: str) -> list[dict[str, str | int]]:
    """Locate lexical candidates without assigning a semantic question type."""
    out: list[dict[str, str | int]] = []
    seen: set[tuple[int, int]] = set()
    prefix = [0]
    total = 0
    for ch in source:
        total += len(ch.encode("utf-8"))
        prefix.append(total)
    for pattern in QUESTION_CANDIDATE_PATTERNS:
        for match in pattern.finditer(source):
            char_start, char_end = match.span()
            text = match.group(0).strip()
            if len(text) < 3:
                continue
            byte_start, byte_end = prefix[char_start], prefix[char_end]
            key = (byte_start, byte_end)
            if key in seen:
                continue
            seen.add(key)
            out.append({
                "start": byte_start,
                "end": byte_end,
                "excerpt": text,
            })
    out.sort(key=lambda item: (int(item["start"]), int(item["end"])))
    filtered: list[dict[str, str | int]] = []
    for item in out:
        start, end = int(item["start"]), int(item["end"])
        if any(int(prev["start"]) <= start and end <= int(prev["end"]) for prev in filtered):
            continue
        filtered.append(item)
    return filtered


def detect_questions(source: str) -> list[dict[str, str | int]]:
    """Compatibility alias: results are candidates, never semantic truth."""
    return detect_question_candidates(source)


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    source_path = root / "source_canonical.txt"
    if not source_path.exists():
        source_path = root / "source.txt"
    source = read(source_path)
    ledger = root / "author_question_obligation_ledger.md"
    failures: list[str] = []
    rows_kind, rows, row_failures = load_required_ledger(ledger, {'destination_anchor', 'destination_file', 'obligation_type', 'question_id', 'required_action', 'resolution_status', 'response_trace', 'source_excerpt', 'source_span', 'verification_note'})
    failures.extend(row_failures)
    if rows_kind == "missing":
        failures.append("missing or empty author_question_obligation_ledger.jsonl/author_question_obligation_ledger.md")

    candidates = detect_question_candidates(source)
    if not rows:
        failures.append("author_question_obligation_ledger has no parseable rows")

    no_question_rows = [r for r in rows if r.get("resolution_status", "").upper() == "NO_AUTHOR_QUESTIONS" or r.get("obligation_type", "").upper() == "NO_AUTHOR_QUESTIONS"]
    scan_rows = [
        r for r in rows if r.get("obligation_type", "").upper() == "SOURCE_WIDE_SEMANTIC_SCAN"
    ]
    if len(scan_rows) != 1:
        failures.append("exactly one SOURCE_WIDE_SEMANTIC_SCAN row is required")
    scan_complete = bool(
        scan_rows
        and scan_rows[0].get("resolution_status", "").upper() == "SEMANTIC_SCAN_COMPLETE"
    )
    excluded_types = {
        "P02_SEMANTIC_CANDIDATE",
        "SOURCE_WIDE_SEMANTIC_SCAN",
        "DISMISSED_P02_CANDIDATE",
        "NO_AUTHOR_QUESTIONS",
    }
    action_rows = [
        r for r in rows if r.get("obligation_type", "").upper() not in excluded_types
    ]
    if scan_complete and not action_rows and not no_question_rows:
        failures.append(
            "a completed semantic scan with no obligations requires an explicit NO_AUTHOR_QUESTIONS row"
        )
    if scan_complete and action_rows and no_question_rows:
        failures.append("NO_AUTHOR_QUESTIONS conflicts with reviewed author-question obligations")

    source_bytes = source.encode("utf-8")
    source_len = len(source_bytes)
    covered_candidates: set[int] = set()
    for idx, row in enumerate(rows, 1):
        qid = row.get("question_id", "").strip()
        typ = row.get("obligation_type", "").upper().strip()
        status = row.get("resolution_status", "").upper().strip()
        if typ in BAD_STATUS:
            failures.append(f"row {idx} {qid} has unresolved obligation_type: {typ or '<blank>'}")
        if typ and typ not in VALID_TYPES:
            failures.append(f"row {idx} {qid} has invalid obligation_type: {typ}")
        if status in BAD_STATUS:
            failures.append(f"row {idx} {qid} has unresolved resolution_status: {status or '<blank>'}")
        if status and status not in VALID_STATUS:
            failures.append(f"row {idx} {qid} has invalid resolution_status: {status}")
        if status == "NO_AUTHOR_QUESTIONS" or typ == "NO_AUTHOR_QUESTIONS":
            continue
        if typ == "SOURCE_WIDE_SEMANTIC_SCAN":
            if status not in {"BLOCKED_NEEDS_SOURCE_SUPPORT", "SEMANTIC_SCAN_COMPLETE"}:
                failures.append(f"row {idx} {qid} has invalid source-wide scan status")
            trace = row.get("response_trace", "").strip()
            if status == "SEMANTIC_SCAN_COMPLETE" and (
                not trace or trace.lower() in {"none", "todo", "unknown"}
            ):
                failures.append(f"row {idx} {qid} lacks P03 source-wide scan evidence")
            continue
        span = parse_span(row.get("source_span", ""))
        if span is None:
            failures.append(f"row {idx} {qid} missing valid source_span")
            continue
        a, b = span
        if b > source_len:
            failures.append(f"row {idx} {qid} source_span out of canonical source range")
            continue
        excerpt = row.get("source_excerpt", "").strip()
        if not excerpt or excerpt.lower() in {"none", "todo", "unknown"}:
            failures.append(f"row {idx} {qid} missing source_excerpt")
        else:
            try:
                span_text = source_bytes[a:b].decode("utf-8", errors="strict")
            except UnicodeDecodeError:
                failures.append(f"row {idx} {qid} source_span splits UTF-8")
                span_text = ""
            if excerpt not in span_text and excerpt not in source:
                failures.append(f"row {idx} {qid} source_excerpt not found in canonical source")
        required_action = row.get("required_action", "").strip()
        if not required_action or required_action.lower() in {"none", "todo", "unknown"}:
            failures.append(f"row {idx} {qid} missing required_action")
        if typ not in {"P02_SEMANTIC_CANDIDATE", "DISMISSED_P02_CANDIDATE"}:
            destination = row.get("destination_file", "").strip()
            if not destination or destination.lower() in {"none", "todo", "unknown"}:
                failures.append(f"row {idx} {qid} missing destination_file")
        trace = row.get("response_trace", "").strip()
        if status != "BLOCKED_NEEDS_SOURCE_SUPPORT" and (not trace or trace.lower() in {"none", "todo", "unknown"}):
            failures.append(f"row {idx} {qid} missing response_trace for resolved obligation")
        if status in ARTICLE_FULFILLMENT_STATUS:
            destination = root / "publication_final.md"
            if not destination.is_file():
                failures.append(
                    f"row {idx} {qid} claims article fulfillment before publication_final.md exists"
                )
            else:
                try:
                    response = json.loads(trace)
                except Exception:
                    failures.append(
                        f"row {idx} {qid} final response_trace must be current P13 JSON evidence"
                    )
                    response = {}
                if response.get("stage_id") != "P13_PUBLICATION":
                    failures.append(f"row {idx} {qid} final response_trace is not P13")
                if response.get("target_file") != "publication_final.md":
                    failures.append(f"row {idx} {qid} final response_trace targets the wrong file")
                expected_target_hash = hashlib.sha256(destination.read_bytes()).hexdigest()
                if response.get("target_sha256") != expected_target_hash:
                    failures.append(f"row {idx} {qid} final response_trace hash is stale")
        # Every lexical safety-net candidate must retain a reviewed disposition.
        for candidate_index, det in enumerate(candidates):
            ds, de = int(det["start"]), int(det["end"])
            if max(a, ds) < min(b, de) or excerpt and excerpt in str(det["excerpt"]):
                covered_candidates.add(candidate_index)

    missing_candidates = sorted(set(range(len(candidates))) - covered_candidates)
    if missing_candidates:
        failures.append(
            f"{len(missing_candidates)} P02 lexical candidate(s) lack a retained P03 disposition"
        )

    if failures:
        print("FAILED")
        for f in failures:
            print(f"- {f}")
        if candidates:
            print("p02_lexical_candidates:")
            for det in candidates[:10]:
                print(f"- span {det['start']}-{det['end']} excerpt={det['excerpt']}")
        return 1
    stage = "P03_SEMANTIC_SCAN" if scan_complete else "P02_CANDIDATE_SCAN"
    print(f"OK: author question ledger structurally valid; ledger_source={rows_kind} lexical_candidates={len(candidates)} rows={len(rows)} review_stage={stage}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
