#!/usr/bin/env python3
"""Validate the exact reader-visible publication surface, not raw Markdown only."""
from __future__ import annotations

from pathlib import Path
import html
import re
import sys
import unicodedata
from urllib.parse import urlsplit

from reader_surface import (
    HTML_COMMENT_RE,
    INVISIBLE_CODEPOINTS,
    code_fence_fraction,
    fence_ranges,
    normalized_visible_text,
)
from safe_io import read_text_strict

DANGEROUS_TAGS = {"script", "style", "iframe", "object", "embed", "form", "input", "button", "details", "summary", "svg", "math", "video", "audio", "meta", "link"}
TEX_DANGEROUS = re.compile(
    r"\\(?:def|gdef|edef|xdef|let|futurelet|newcommand|renewcommand|providecommand|"
    r"DeclareMathOperator|catcode|csname|endcsname|phantom|hphantom|vphantom|smash|"
    r"htmlClass|htmlId|href|url|includegraphics|unicode)\b",
    re.I,
)
COMBINING_OVERLAYS = {"\u0334", "\u0335", "\u0336", "\u0337", "\u0338", "\u20d2", "\u20e5"}
LINK_TARGET_RE = re.compile(r"!?\[[^\]]*\]\(([^)]+)\)")
RAW_TAG_RE = re.compile(r"</?\s*([A-Za-z][A-Za-z0-9:-]*)\b[^>]*>")


def target_scheme(target: str) -> str:
    target = html.unescape(target.strip().strip("<>"))
    # Optional Markdown title follows the URL; inspect the first token.
    target = target.split()[0] if target else ""
    return urlsplit(target).scheme.lower()


def validate_one(path: Path) -> list[str]:
    failures: list[str] = []
    try:
        text = read_text_strict(path)
    except Exception as exc:
        return [f"{path.name}: unsafe or invalid UTF-8: {exc}"]
    if "\x00" in text:
        failures.append(f"{path.name}: NUL character is forbidden")
    for idx, ch in enumerate(text):
        if ch in INVISIBLE_CODEPOINTS or unicodedata.category(ch) == "Cf":
            failures.append(f"{path.name}: invisible/format control U+{ord(ch):04X} at codepoint {idx}")
            if len(failures) >= 25:
                break
        if ch in COMBINING_OVERLAYS:
            failures.append(f"{path.name}: combining overlay U+{ord(ch):04X} can visually change a relation")
    if HTML_COMMENT_RE.search(text):
        failures.append(f"{path.name}: HTML comments are forbidden on the release surface")
    ranges, unclosed = fence_ranges(text)
    if unclosed:
        failures.append(f"{path.name}: unclosed Markdown code fence")
    fraction = code_fence_fraction(text)
    if fraction > 0.40:
        failures.append(f"{path.name}: {fraction:.1%} of the article is inside code fences")
    for match in RAW_TAG_RE.finditer(text):
        tag = match.group(1).lower()
        if tag in DANGEROUS_TAGS:
            failures.append(f"{path.name}: raw HTML <{tag}> is forbidden")
    for match in LINK_TARGET_RE.finditer(text):
        target = match.group(1)
        scheme = target_scheme(target)
        is_image = match.group(0).lstrip().startswith("!")
        if scheme in {"javascript", "data", "file", "vbscript"}:
            failures.append(f"{path.name}: unsafe URL scheme {scheme!r}")
        if is_image and scheme in {"http", "https"}:
            failures.append(f"{path.name}: remote images/tracking pixels are forbidden in the frozen release surface")
    if TEX_DANGEROUS.search(text):
        failures.append(f"{path.name}: TeX macro/visibility primitive is forbidden")
    visible = normalized_visible_text(text)
    if not visible:
        failures.append(f"{path.name}: reader-visible surface is empty")
    if len(visible) < 0.25 * max(1, len(text)):
        failures.append(f"{path.name}: reader-visible surface is suspiciously small relative to raw Markdown")
    return failures


def main() -> int:
    root = (Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")).resolve()
    targets = [root / "publication_final.md"]
    if (root / "wechat_publication_final.md").exists():
        targets.append(root / "wechat_publication_final.md")
    failures: list[str] = []
    for target in targets:
        if not target.exists():
            failures.append(f"missing release surface: {target.name}")
        else:
            failures.extend(validate_one(target))
    if len(targets) == 2 and not failures:
        pub = normalized_visible_text(read_text_strict(targets[0]))
        wechat = normalized_visible_text(read_text_strict(targets[1]))
        if pub != wechat:
            failures.append("wechat_publication_final.md reader-visible text differs from publication_final.md")
    if failures:
        print("FAILED")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print("OK: reader-visible release surface is safe and stable")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
