#!/usr/bin/env python3
"""Mechanically assemble reviewed P11 bytes into P12 publication candidates.

This module owns no semantic verdict. It copies the accepted article exactly,
locates already-reviewed P11 evidence, and writes trace/authorization candidates
for P13. It never writes PASS reports, review files, planning files, or
CONSUMED atom states.
"""
from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable
import argparse
import hashlib
import json
import re

from content_authority import (
    OUTPUT_TRACE_SCHEMA,
    normalize_visible,
    split_output_units,
)
from content_functions import (
    INTERMEDIATE_STAGE_TARGETS,
    atom_function_contracts,
    review_target_evidence,
    stage_function_reviews,
)
from mode_utils import FULL_PUBLICATION, WECHAT_PUBLICATION, resolve_mode
from safe_io import atomic_write_text, read_json_strict


ARTICLE_HISTORY = (
    "draft.md",
    "independent_review.md",
    "final.md",
    "post_final_structure_review.md",
    "optimized_final.md",
    "standardized_final.md",
    "attack_report.md",
    "revision_tasks.md",
    "revised_final.md",
    "revision_changelog.md",
    "regression_check.md",
    "revised_trace_map.md",
    "aigc_source_type_ledger.md",
    "aigc_rewrite_tasks.md",
    "aigc_rewritten_final.md",
    "aigc_rewrite_changelog.md",
    "post_aigc_regression_check.md",
    "post_aigc_trace_check.md",
    "post_aigc_formula_check.md",
    "post_aigc_clean_gate.md",
    "clean_final_gate.md",
)

REQUIRED_BLUEPRINT_LISTS = (
    "voices",
    "symbols",
    "chains",
    "statements",
    "proofs",
    "atom_function_contracts",
    "function_preservation_reviews",
    "claims",
    "heading_authorizations",
)

MECHANICAL_OUTPUTS = frozenset(
    {
        "publication_final.md",
        "atom_consumption_candidates.jsonl",
        "publication_sentence_trace.jsonl",
        "publication_sentence_trace.md",
        "publication_paragraph_index.md",
        "publication_trace_map.md",
        "publication_claim_ledger.jsonl",
        "publication_claim_ledger.md",
        "heading_authorization.jsonl",
        "publication_fragment_authorization.jsonl",
    }
)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        value = json.loads(line)
        if not isinstance(value, dict):
            raise ValueError(f"{path.name}:{line_no} must contain one JSON object")
        rows.append(value)
    return rows


def write_jsonl(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    atomic_write_text(
        path,
        "".join(
            json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n"
            for row in rows
        ),
    )


def md_cell(value: Any) -> str:
    if isinstance(value, (list, dict)):
        value = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return (
        str(value)
        .replace("\\", "\\\\")
        .replace("|", "\\|")
        .replace("\r", "\\r")
        .replace("\n", "\\n")
        .replace("\t", "\\t")
    )


def markdown_table(rows: list[dict[str, Any]], title: str) -> str:
    if not rows:
        raise ValueError(f"{title} cannot be empty")
    columns: list[str] = []
    for row in rows:
        for key in row:
            if key not in columns:
                columns.append(key)
    ids = [key for key in columns if key == "id" or key.endswith("_id")]
    columns = ids + [key for key in columns if key not in ids]
    header = "| " + " | ".join(columns) + " |"
    divider = "|" + "|".join("---" for _ in columns) + "|"
    body = [
        "| " + " | ".join(md_cell(row.get(column, "")) for column in columns) + " |"
        for row in rows
    ]
    return f"# {title}\n\n" + "\n".join([header, divider, *body]) + "\n"


def write_jsonl_mirror(root: Path, stem: str, rows: list[dict[str, Any]], title: str) -> None:
    write_jsonl(root / f"{stem}.jsonl", rows)
    atomic_write_text(root / f"{stem}.md", markdown_table(rows, title))


def split_ids(value: Any, prefix: str) -> list[str]:
    raw = value if isinstance(value, list) else re.split(r"[,;\s]+", str(value or ""))
    result: list[str] = []
    pattern = re.compile(rf"^{re.escape(prefix)}(\d+)-{re.escape(prefix)}(\d+)$")
    for item in raw:
        token = str(item).strip()
        if not token:
            continue
        match = pattern.fullmatch(token)
        if match:
            start, end = int(match.group(1)), int(match.group(2))
            if end < start or end - start > 10000:
                raise ValueError(f"invalid id range: {token}")
            width = max(len(match.group(1)), len(match.group(2)))
            result.extend(f"{prefix}{number:0{width}d}" for number in range(start, end + 1))
        elif token.startswith(prefix):
            result.append(token)
    return list(dict.fromkeys(result))


def ensure_blueprint(blueprint: dict[str, Any]) -> None:
    if blueprint.get("schema_version") != "publication-blueprint-v1":
        raise ValueError("blueprint schema_version must be publication-blueprint-v1")
    for key in REQUIRED_BLUEPRINT_LISTS:
        if not isinstance(blueprint.get(key), list) or not blueprint[key]:
            raise ValueError(f"blueprint {key} must be a nonempty list before P12")


def ensure_history(root: Path) -> None:
    missing = [
        name
        for name in ARTICLE_HISTORY
        if not (root / name).is_file()
        or not (root / name).read_text(encoding="utf-8").strip()
    ]
    if missing:
        raise ValueError(
            "P12 cannot fabricate missing semantic history: " + ", ".join(missing)
        )


def explicit_unit_mapping(
    atoms: list[dict[str, Any]],
    units: list[Any],
    reviews: dict[str, dict[str, Any]],
    article_bytes: bytes,
    max_atoms_per_unit: int,
) -> dict[int, list[str]]:
    unit_atoms: dict[int, list[str]] = {index: [] for index in range(len(units))}
    for atom in atoms:
        atom_id = str(atom["atom_id"])
        review = reviews.get(atom_id)
        if review is None:
            raise ValueError(f"{atom_id}: P11 review is missing; position fallback is forbidden")
        destinations: list[int] = []
        if str(atom.get("surface_mode", "")) == "BYTE_EXACT":
            source_slice = str(atom.get("raw_excerpt", "")).encode("utf-8")
            start = article_bytes.find(source_slice)
            if not source_slice or start < 0 or article_bytes.find(source_slice, start + 1) >= 0:
                raise ValueError(f"{atom_id}: BYTE_EXACT slice must occur exactly once")
            end = start + len(source_slice)
            destinations = [
                index
                for index, unit in enumerate(units)
                if unit.byte_start < end and unit.byte_end > start
            ]
        else:
            for evidence in review_target_evidence(review):
                normalized = normalize_visible(evidence)
                matches = [
                    index
                    for index, unit in enumerate(units)
                    if unit.unit_type != "heading"
                    and normalized
                    and normalized in normalize_visible(unit.text)
                ]
                if not matches:
                    raise ValueError(
                        f"{atom_id}: reviewed evidence is absent from every output unit: "
                        + evidence[:100]
                    )
                chosen = min(matches, key=lambda index: len(units[index].text))
                if chosen not in destinations:
                    destinations.append(chosen)
        if not destinations:
            raise ValueError(f"{atom_id}: reviewed evidence has no concrete output destination")
        for index in destinations:
            if atom_id not in unit_atoms[index]:
                unit_atoms[index].append(atom_id)
            if len(unit_atoms[index]) > max_atoms_per_unit:
                raise ValueError(
                    f"{units[index].output_unit_id}: cites more than the contract limit of "
                    f"{max_atoms_per_unit} atoms"
                )
    return unit_atoms


def explicit_expansion_mapping(
    blueprint: dict[str, Any], units: list[Any], article_sha256: str, known_directives: set[str]
) -> dict[int, list[str]]:
    unit_directives: dict[int, list[str]] = {index: [] for index in range(len(units))}
    rows = [
        row for row in blueprint.get("task_requirement_reviews", [])
        if isinstance(row, dict) and row.get("stage_id") == "P11_AIGC"
    ]
    seen: set[str] = set()
    for row in rows:
        directive_id = str(row.get("directive_id", ""))
        if directive_id not in known_directives or directive_id in seen:
            raise ValueError(f"invalid or duplicate P11 expansion review: {directive_id!r}")
        seen.add(directive_id)
        if row.get("target_file") != "aigc_rewritten_final.md":
            raise ValueError(f"{directive_id}: P11 expansion target_file is invalid")
        if row.get("target_sha256") != article_sha256:
            raise ValueError(f"{directive_id}: P11 expansion target hash is stale")
        evidence = row.get("target_evidence", [])
        evidence = evidence if isinstance(evidence, list) else [evidence]
        if not evidence:
            raise ValueError(f"{directive_id}: P11 expansion evidence is empty")
        for raw in evidence:
            text = str(raw).strip()
            matches = [
                index for index, unit in enumerate(units)
                if unit.unit_type != "heading" and unit.text == text
            ]
            if len(matches) != 1:
                raise ValueError(
                    f"{directive_id}: expansion evidence must equal one unique complete output unit"
                )
            index = matches[0]
            if directive_id not in unit_directives[index]:
                unit_directives[index].append(directive_id)
    if seen != known_directives:
        raise ValueError(
            "P11 expansion reviews do not cover every author directive: "
            + ", ".join(sorted(known_directives - seen))
        )
    return unit_directives


def semantic_ids_for_atoms(
    blueprint: dict[str, Any], atom_ids: list[str]
) -> dict[str, list[str]]:
    wanted = set(atom_ids)
    groups = (
        ("statements", "statement_id", "S"),
        ("proofs", "proof_id", "PR"),
        ("voices", "voice_id", "V"),
        ("symbols", "symbol_id", "SYM"),
        ("chains", "chain_id", "CH"),
    )
    result: dict[str, list[str]] = {}
    for key, id_key, _prefix in groups:
        result[key] = [
            str(row[id_key])
            for row in blueprint[key]
            if wanted.intersection(split_ids(row.get("source_atoms"), "A"))
        ]
    return result


def heading_candidates(
    blueprint: dict[str, Any], units: list[Any], known_atoms: set[str]
) -> tuple[list[dict[str, Any]], dict[str, list[str]]]:
    headings = [unit for unit in units if unit.unit_type == "heading"]
    supplied = blueprint["heading_authorizations"]
    if len(supplied) != len(headings):
        raise ValueError(
            f"heading_authorizations count {len(supplied)} != article headings {len(headings)}"
        )
    rows: list[dict[str, Any]] = []
    atoms_by_heading: dict[str, list[str]] = {}
    for index, (unit, item) in enumerate(zip(headings, supplied), 1):
        heading_text = re.sub(r"^#+\s*", "", unit.text).strip()
        level_match = re.match(r"^#+", unit.text)
        if not isinstance(item, dict) or str(item.get("heading_text", "")) != heading_text:
            raise ValueError(f"heading authorization {index} does not match exact article heading")
        source_atoms = split_ids(item.get("source_atoms"), "A")
        if not source_atoms or any(atom_id not in known_atoms for atom_id in source_atoms):
            raise ValueError(f"heading authorization {index} lacks valid source atoms")
        segments = item.get("segments")
        if not isinstance(segments, list) or not segments:
            raise ValueError(f"heading authorization {index} lacks reviewed segments")
        if "".join(str(segment.get("text", "")) for segment in segments) != heading_text:
            raise ValueError(f"heading authorization {index} segments do not reconstruct heading")
        heading_id = f"H{index:04d}"
        atoms_by_heading[heading_text] = source_atoms
        rows.append(
            {
                "heading_id": heading_id,
                "heading_level": len(level_match.group()) if level_match else 0,
                "heading_text": heading_text,
                "heading_text_sha256": sha256_bytes(heading_text.encode("utf-8")),
                "source_atoms": source_atoms,
                "review_status": "PENDING_P13_REVIEW",
                "segments": segments,
                "verification_note": "P12 reconstructed exact bytes; P13 must approve semantic authorization.",
            }
        )
    return rows, atoms_by_heading


def enrich_heading_units(
    units: list[Any], unit_atoms: dict[int, list[str]], atoms_by_heading: dict[str, list[str]]
) -> None:
    for index, unit in enumerate(units):
        if unit.unit_type != "heading":
            continue
        heading_text = re.sub(r"^#+\s*", "", unit.text).strip()
        unit_atoms[index] = list(atoms_by_heading[heading_text])


def trace_rows(
    units: list[Any],
    unit_atoms: dict[int, list[str]],
    unit_directives: dict[int, list[str]],
    contracts: dict[str, dict[str, Any]],
    atoms_by_id: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for index, unit in enumerate(units, 1):
        atom_ids = unit_atoms[index - 1]
        directive_ids = unit_directives[index - 1]
        exact = bool(atom_ids) and all(
            str(atoms_by_id[atom_id].get("surface_mode", "")) == "BYTE_EXACT"
            for atom_id in atom_ids
        )
        if unit.unit_type == "heading":
            transformation, basis, verdict = "STRUCTURAL_HEADING", "STRUCTURAL_HEADING", "FORMAT_ONLY"
        elif directive_ids and not atom_ids:
            transformation, basis, verdict = "TASK_DIRECTIVE_EXPANSION", "TASK_DIRECTIVE_EXPANSION", "DERIVED_SUPPORTED"
        elif exact:
            transformation, basis, verdict = "COPY_SOURCE_SLICE", "NONE", "SUPPORTED"
        elif unit.unit_type == "formula_block":
            transformation, basis, verdict = "FORMULA_NORMALIZATION", "FORMULA_NORMALIZATION", "DERIVED_SUPPORTED"
        else:
            transformation, basis, verdict = "CONTENT_PRESERVING_REWRITE", "NONE", "SUPPORTED"
        preserved = {
            atom_id: contracts[atom_id]["required_functions"] for atom_id in atom_ids
        }
        rows.append(
            {
                "schema_version": OUTPUT_TRACE_SCHEMA,
                "output_unit_id": unit.output_unit_id,
                "file": "publication_final.md",
                "output_byte_start": unit.byte_start,
                "output_byte_end": unit.byte_end,
                "output_text_sha256": unit.sha256,
                "output_text": unit.text,
                "unit_type": unit.unit_type,
                "source_atom_ids": ",".join(atom_ids),
                "task_directive_ids": ",".join(directive_ids),
                "transformation_kind": transformation,
                "preserved_invariants": ",".join(atom_ids),
                "preserved_functions_json": json.dumps(
                    preserved, ensure_ascii=False, sort_keys=True, separators=(",", ":")
                ),
                "function_review_stage": "P11_AIGC",
                "new_content_basis": basis,
                "verdict": verdict,
                "verification_note": (
                    "P12 verified exact output bytes and mapped only explicit P11 atom/function evidence."
                ),
                "sentence_trace_id": f"PS{index:04d}",
                "location": f"output-unit-{index}",
                "sentence_or_heading": unit.text,
                "source_atoms": ",".join(atom_ids),
            }
        )
    return rows


def char_byte_prefix(text: str) -> list[int]:
    prefix = [0]
    for char in text:
        prefix.append(prefix[-1] + len(char.encode("utf-8")))
    return prefix


def article_blocks(text: str) -> list[tuple[int, int, str, str]]:
    prefix = char_byte_prefix(text)
    blocks: list[tuple[int, int, str, str]] = []
    cursor = 0
    heading = ""
    for raw in re.split(r"\n\s*\n", text):
        block = raw.strip()
        if not block:
            continue
        start = text.find(block, cursor)
        if start < 0:
            raise ValueError("cannot locate deterministic article block")
        end = start + len(block)
        cursor = end
        if block.startswith("#"):
            heading = re.sub(r"^#+\s*", "", block.splitlines()[0]).strip()
        blocks.append((prefix[start], prefix[end], block, heading))
    return blocks


def paragraph_artifacts(
    text: str,
    units: list[Any],
    unit_atoms: dict[int, list[str]],
    unit_directives: dict[int, list[str]],
    blueprint: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    indexes: list[dict[str, Any]] = []
    traces: list[dict[str, Any]] = []
    for index, (start, end, block, heading) in enumerate(article_blocks(text), 1):
        atom_ids: list[str] = []
        directive_ids: list[str] = []
        for unit_index, unit in enumerate(units):
            if unit.byte_start < end and unit.byte_end > start:
                for atom_id in unit_atoms[unit_index]:
                    if atom_id not in atom_ids:
                        atom_ids.append(atom_id)
                for directive_id in unit_directives[unit_index]:
                    if directive_id not in directive_ids:
                        directive_ids.append(directive_id)
        if not atom_ids and not directive_ids:
            raise ValueError(f"publication block {index} lacks Atom or author-task support")
        refs = semantic_ids_for_atoms(blueprint, atom_ids)
        excerpt = re.sub(r"\s+", " ", block).strip()
        indexes.append(
            {
                "para_id": f"PP{index:04d}",
                "file": "publication_final.md",
                "paragraph_number": index,
                "heading_context": heading,
                "first_40_chars": excerpt[:40],
            }
        )
        traces.append(
            {
                "para_id": f"PP{index:04d}",
                "file": "publication_final.md",
                "publication_location": f"bytes-{start}-{end}",
                "heading_context": heading,
                "paragraph_or_block_excerpt": excerpt[:180],
                "source_atoms": ",".join(atom_ids),
                "task_directive_ids": ",".join(directive_ids),
                "statement_ids": ",".join(refs["statements"]),
                "proof_ids": ",".join(refs["proofs"]),
                "voice_ids": ",".join(refs["voices"]),
                "symbol_ids": ",".join(refs["symbols"]),
                "chain_ids": ",".join(refs["chains"]),
                "aigc_sentence_ids": "explicit P11 unit mapping",
                "source_type_mix": "explicit Atom/function and author-task evidence",
                "allowed_new_reason": "reviewed P11 transformation or author-requested expansion",
                "verification_note": "No position-based or modulo semantic IDs were assigned.",
            }
        )
    return indexes, traces


def claim_rows(
    blueprint: dict[str, Any], article: str, known_atoms: set[str]
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for index, spec in enumerate(blueprint["claims"], 1):
        if not isinstance(spec, dict):
            raise ValueError(f"claim {index} must be an object")
        excerpt = str(spec.get("claim_excerpt", "")).strip()
        if not excerpt or excerpt not in article:
            raise ValueError(f"claim {index} excerpt is absent from the P11 article")
        atoms = split_ids(spec.get("source_atoms"), "A")
        if not atoms or any(atom_id not in known_atoms for atom_id in atoms):
            raise ValueError(f"claim {index} lacks valid explicit source atoms")
        required = (
            "claim_type",
            "support_type",
            "source_ownership",
            "transformation_scope",
            "verdict",
            "allowed_new_reason",
            "verification_note",
        )
        missing = [key for key in required if not str(spec.get(key, "")).strip()]
        if missing:
            raise ValueError(f"claim {index} missing explicit fields: {', '.join(missing)}")
        rows.append(
            {
                "claim_id": f"PCL{index:04d}",
                "file": "publication_final.md",
                "location": f"exact-excerpt-{index}",
                "claim_excerpt": excerpt,
                "claim_type": spec["claim_type"],
                "source_atoms": ",".join(atoms),
                "statement_ids": ",".join(split_ids(spec.get("statement_ids"), "S")),
                "proof_ids": ",".join(split_ids(spec.get("proof_ids"), "PR")),
                "support_type": spec["support_type"],
                "source_ownership": spec["source_ownership"],
                "transformation_scope": spec["transformation_scope"],
                "verdict": spec["verdict"],
                "allowed_new_reason": spec["allowed_new_reason"],
                "verification_note": spec["verification_note"],
            }
        )
    return rows


def utf8_chunks(data: bytes, start: int, end: int, limit: int = 420) -> list[tuple[int, int]]:
    if end - start <= limit:
        return [(start, end)]
    text = data[start:end].decode("utf-8", errors="strict")
    spans: list[tuple[int, int]] = []
    chunk_start = start
    cursor = start
    for char in text:
        width = len(char.encode("utf-8"))
        if cursor + width - chunk_start > limit:
            spans.append((chunk_start, cursor))
            chunk_start = cursor
        cursor += width
    if chunk_start < end:
        spans.append((chunk_start, end))
    return spans


def fragment_candidates(
    article_bytes: bytes,
    units: list[Any],
    unit_atoms: dict[int, list[str]],
    unit_directives: dict[int, list[str]],
    heading_rows: list[dict[str, Any]],
    atoms_by_id: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    cursor = 0
    heading_ids = {row["heading_text"]: row["heading_id"] for row in heading_rows}

    def add(
        start: int,
        end: int,
        auth: str,
        atom_ids: list[str],
        directive_ids: list[str],
        **extra: Any,
    ) -> None:
        for chunk_start, chunk_end in utf8_chunks(article_bytes, start, end):
            raw = article_bytes[chunk_start:chunk_end]
            row: dict[str, Any] = {
                "fragment_id": f"F{len(rows) + 1:04d}",
                "output_file": "publication_final.md",
                "output_byte_start": chunk_start,
                "output_byte_end": chunk_end,
                "output_text_sha256": sha256_bytes(raw),
                "authorization_type": auth,
                "source_atom_ids": atom_ids,
                "task_directive_ids": directive_ids,
                "review_status": "PENDING_P13_REVIEW",
                "verification_note": "P12 computed exact bytes; P13 must review this authorization.",
            }
            row.update(extra)
            rows.append(row)

    for index, unit in enumerate(units):
        if unit.byte_start > cursor:
            add(cursor, unit.byte_start, "FORMAT_SYNTAX", [], [])
        atom_ids = unit_atoms[index]
        directive_ids = unit_directives[index]
        if unit.unit_type == "heading":
            heading = re.sub(r"^#+\s*", "", unit.text).strip()
            add(
                unit.byte_start,
                unit.byte_end,
                "STRUCTURAL_LABEL",
                atom_ids,
                directive_ids,
                heading_id=heading_ids[heading],
                label_function="section navigation",
            )
        elif directive_ids and not atom_ids:
            add(
                unit.byte_start,
                unit.byte_end,
                "TASK_DIRECTIVE_EXPANSION",
                [],
                directive_ids,
                completion_basis="TASK_DIRECTIVE_EXPANSION",
            )
        elif unit.unit_type == "formula_block":
            add(
                unit.byte_start,
                unit.byte_end,
                "FORMULA_NORMALIZATION",
                atom_ids,
                directive_ids,
                completion_basis="FORMULA_NORMALIZATION",
                preserved_invariants=atom_ids,
            )
        else:
            add(
                unit.byte_start,
                unit.byte_end,
                "SOURCE_REORGANIZATION",
                atom_ids,
                directive_ids,
                preserved_invariants=atom_ids,
            )
        cursor = unit.byte_end
    if cursor < len(article_bytes):
        add(cursor, len(article_bytes), "FORMAT_SYNTAX", [], [])
    return rows


def consumption_candidates(
    atoms: list[dict[str, Any]], unit_atoms: dict[int, list[str]], units: list[Any]
) -> list[dict[str, Any]]:
    destinations: dict[str, list[str]] = defaultdict(list)
    for index, atom_ids in unit_atoms.items():
        for atom_id in atom_ids:
            destinations[atom_id].append(units[index].output_unit_id)
    rows: list[dict[str, Any]] = []
    for atom in atoms:
        atom_id = str(atom["atom_id"])
        if not destinations.get(atom_id):
            raise ValueError(f"{atom_id}: no P12 destination candidate")
        rows.append(
            {
                "schema_version": "atom-consumption-candidate-v1",
                "atom_id": atom_id,
                "candidate_status": "MAPPED_PENDING_P13_REVIEW",
                "destination_file": "publication_final.md",
                "output_unit_ids": destinations[atom_id],
                "mapping_review_stage": "P11_AIGC",
                "consumption_status": "NOT_YET_CONSUMED",
            }
        )
    return rows


def assemble(root: Path, article_path: Path, blueprint_path: Path, overwrite: bool) -> None:
    mode = resolve_mode(root, None, allow_mode_file=False)
    if mode not in {FULL_PUBLICATION, WECHAT_PUBLICATION}:
        raise ValueError("prepare-publication requires a publication mode")
    ensure_history(root)

    article_bytes = article_path.read_bytes()
    article = article_bytes.decode("utf-8", errors="strict")
    if not article.strip() or not re.search(r"(?m)^#\s+\S", article):
        raise ValueError("P11 article must be nonempty Markdown with one level-1 title")
    p11 = root / "aigc_rewritten_final.md"
    if p11.read_bytes() != article_bytes:
        raise ValueError("P12 input must be byte-identical to aigc_rewritten_final.md")

    blueprint = read_json_strict(blueprint_path)
    if not isinstance(blueprint, dict):
        raise ValueError("publication blueprint must be a JSON object")
    ensure_blueprint(blueprint)
    quality_contract = read_json_strict(root / "quality_contract.json")
    if not isinstance(quality_contract, dict):
        raise ValueError("quality_contract.json must contain one object")
    max_atoms_per_unit = int(
        quality_contract.get("thresholds", {}).get("maximum_atoms_per_target_unit", 0)
    )
    known_directives = {
        str(row.get("directive_id", ""))
        for row in quality_contract.get("expansion_budgets", [])
    }
    if not 1 <= max_atoms_per_unit <= 3:
        raise ValueError("quality contract maximum_atoms_per_target_unit must be between 1 and 3")
    future_reviews = [
        row
        for row in blueprint.get("function_preservation_reviews", [])
        if isinstance(row, dict) and row.get("stage_id") == "P13_PUBLICATION"
    ]
    if future_reviews:
        raise ValueError(
            "P13_PUBLICATION review rows cannot exist before P12 materializes publication_final.md"
        )
    atoms = read_jsonl(root / "source_atom_ledger.jsonl")
    atoms_by_id = {str(atom["atom_id"]): atom for atom in atoms}
    contracts, errors = atom_function_contracts(
        blueprint, atoms, require_function_matrix=True
    )
    from source_obligations import source_obligation_contracts

    _source_obligations, source_obligation_errors = source_obligation_contracts(
        root, blueprint, atoms, require_ledgers=False
    )
    errors.extend(source_obligation_errors)
    if errors:
        raise ValueError("invalid atom function contracts: " + "; ".join(errors[:12]))
    reviews_by_stage: dict[str, dict[str, dict[str, Any]]] = {}
    for stage_id, target_file, require_all in INTERMEDIATE_STAGE_TARGETS:
        reviews, stage_errors = stage_function_reviews(
            root,
            blueprint,
            atoms,
            stage_id,
            target_file,
            require_all_atoms=require_all,
            require_function_matrix=True,
        )
        if stage_errors:
            raise ValueError(
                f"{stage_id} function preservation failed: " + "; ".join(stage_errors[:12])
            )
        reviews_by_stage[stage_id] = reviews

    publication = root / "publication_final.md"
    if publication.exists() and not overwrite and publication.read_bytes() != article_bytes:
        raise ValueError("publication artifacts exist; use --overwrite for a deliberate rebuild")
    atomic_write_text(publication, article)
    units = split_output_units(article)
    unit_atoms = explicit_unit_mapping(
        atoms, units, reviews_by_stage["P11_AIGC"], article_bytes, max_atoms_per_unit
    )
    unit_directives = explicit_expansion_mapping(
        blueprint, units, sha256_bytes(article_bytes), known_directives
    )
    overlapping_units = [
        units[index].output_unit_id
        for index in range(len(units))
        if unit_atoms[index] and unit_directives[index]
    ]
    if overlapping_units:
        raise ValueError(
            "expansion evidence cannot also receive source-realization credit: "
            + ", ".join(overlapping_units[:12])
        )
    missing_units = [
        unit.output_unit_id
        for index, unit in enumerate(units)
        if unit.unit_type != "heading" and not unit_atoms[index] and not unit_directives[index]
    ]
    if missing_units:
        raise ValueError(
            "non-heading output units lack explicit P11 Atom or author-task evidence: "
            + ", ".join(missing_units[:12])
        )
    headings, atoms_by_heading = heading_candidates(
        blueprint, units, set(atoms_by_id)
    )
    enrich_heading_units(units, unit_atoms, atoms_by_heading)

    traces = trace_rows(units, unit_atoms, unit_directives, contracts, atoms_by_id)
    write_jsonl_mirror(
        root, "publication_sentence_trace", traces, "Publication Sentence Trace"
    )
    indexes, paragraph_traces = paragraph_artifacts(
        article, units, unit_atoms, unit_directives, blueprint
    )
    atomic_write_text(
        root / "publication_paragraph_index.md",
        markdown_table(indexes, "Publication Paragraph Index"),
    )
    atomic_write_text(
        root / "publication_trace_map.md",
        markdown_table(paragraph_traces, "Publication Trace Map"),
    )
    write_jsonl_mirror(
        root,
        "publication_claim_ledger",
        claim_rows(blueprint, article, set(atoms_by_id)),
        "Publication Claim Ledger",
    )
    write_jsonl(root / "heading_authorization.jsonl", headings)
    write_jsonl(
        root / "publication_fragment_authorization.jsonl",
        fragment_candidates(
            article_bytes, units, unit_atoms, unit_directives, headings, atoms_by_id
        ),
    )
    write_jsonl(
        root / "atom_consumption_candidates.jsonl",
        consumption_candidates(atoms, unit_atoms, units),
    )

    print("PUBLICATION_CANDIDATES_ASSEMBLED")
    print(f"article_sha256={sha256_bytes(article_bytes)}")
    print(f"atoms={len(atoms)} output_units={len(units)}")
    print("semantic_verdict=PENDING_P13")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output")
    parser.add_argument("article")
    parser.add_argument("blueprint")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    try:
        assemble(
            Path(args.output).resolve(),
            Path(args.article).resolve(),
            Path(args.blueprint).resolve(),
            bool(args.overwrite),
        )
    except Exception as exc:
        print(f"FAILED: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
