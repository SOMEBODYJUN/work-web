#!/usr/bin/env python3
"""Run the validator chain defined by ``pipeline_registry.py``."""
from __future__ import annotations

from pathlib import Path
import sys

from mode_utils import parse_mode_args, resolve_mode
from pipeline_registry import (
    DIAGNOSTIC_BACKTEST,
    FULL_PUBLICATION,
    SOURCE_ATOMIZATION,
    WECHAT_PUBLICATION,
    validator_specs_for_mode,
)
from validator_runner import argv_for_spec, run_script

for stream in (sys.stdout, sys.stderr):
    if hasattr(stream, "reconfigure"):
        stream.reconfigure(encoding="utf-8", errors="replace")


def success_label(mode: str) -> str:
    if mode == DIAGNOSTIC_BACKTEST:
        return "DIAGNOSTIC_BACKTEST_READY"
    if mode == SOURCE_ATOMIZATION:
        return "SOURCE_ATOMIZATION_READY"
    if mode == WECHAT_PUBLICATION:
        return "WECHAT_PUBLISHABLE"
    return "PUBLISHABLE"


def main() -> int:
    raw_args = sys.argv[1:]
    pre_evidence = False
    if "--pre-evidence" in raw_args:
        raw_args = [arg for arg in raw_args if arg != "--pre-evidence"]
        pre_evidence = True
    try:
        explicit_mode, args = parse_mode_args(raw_args)
    except ValueError as exc:
        print("FAILED")
        print(f"- {exc}")
        return 1

    root = (Path(args[0]) if args else Path(".")).resolve()
    try:
        mode = resolve_mode(root, explicit_mode, allow_mode_file=False)
    except ValueError as exc:
        print("FAILED")
        print(f"- {exc}")
        return 1

    scripts = Path(__file__).resolve().parent
    include_wechat = mode == FULL_PUBLICATION and (root / "wechat_publication_final.md").exists()
    specs = validator_specs_for_mode(
        mode,
        include_post_evidence=not pre_evidence,
        include_optional_wechat=include_wechat,
    )

    failed: list[str] = []
    for spec in specs:
        script = scripts / spec.script
        check_args = argv_for_spec(spec, root, mode)
        print(f"== {spec.script} ==")
        code, stdout, stderr, _duration = run_script(script, check_args)
        output = stdout.strip()
        error = stderr.strip()
        print(output or "(no output)")
        if error:
            print(error)
        print(f"exit {code}")
        if code != 0:
            failed.append(spec.script)

    if failed:
        print("\nREBUILD_BEFORE_PUBLISH")
        print(f"mode={mode}")
        print("failed:", ", ".join(failed))
        return 1

    print(f"\n{success_label(mode)}")
    print(f"mode={mode}")
    print(f"evidence_checked={'no' if pre_evidence else 'yes'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
