"""Machine-verifiable P16-P21 artifact contracts.

The publication skill remains the authority for P00-P15.  This module only
describes the files consumed and produced by the author-directed Obsidian
extension, then seals each concrete attempt with immutable manifests.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from runtime_support import (
    canonical_json_bytes,
    safe_relative_target,
    sha256_bytes,
    sha256_file,
    strict_load_json,
    validate_bare_sha256_sidecar,
    validate_json_schema,
    validate_named_sha256_sidecar,
    write_hashed_json,
)


INPUT_SCHEMA_VERSION = "phase-input-manifest-v1"
OUTPUT_SCHEMA_VERSION = "phase-output-manifest-v1"
OBSIDIAN_PHASES = {f"P{i:02d}" for i in range(16, 22)}
SEMANTIC_ARTIFACT_SCHEMAS = {
    "semantic/author_intent_contract.json": "author-intent-contract-v2.schema.json",
    "semantic/copy_first_page_plan.json": "copy-first-page-plan-v1.schema.json",
    "semantic/page_patch_bundle.json": "page-patch-bundle-v1.schema.json",
}


@dataclass(frozen=True)
class ArtifactSpec:
    artifact_id: str
    domain: str
    symbolic_root: str
    relative_path: str
    consumers: tuple[str, ...]
    producer: str
    access: str
    required: bool = True
    schema_name: str | None = None
    sidecar_mode: str = "NONE"
    expected_sha256: str | None = None
    expected_size: int | None = None


def _spec(
    artifact_id: str,
    root: str,
    relative_path: str,
    *,
    consumers: Iterable[str],
    producer: str,
    access: str = "READ",
    required: bool = True,
    schema_name: str | None = None,
    sidecar_mode: str = "NONE",
    expected_sha256: str | None = None,
    expected_size: int | None = None,
) -> ArtifactSpec:
    domain = {
        "BUSINESS": "BUSINESS",
        "RUNTIME": "RUNTIME_CONTROL",
        "OBSIDIAN": "OBSIDIAN_RUNTIME",
        "VAULT": "FORMAL_VAULT",
    }[root]
    return ArtifactSpec(
        artifact_id=artifact_id,
        domain=domain,
        symbolic_root=root,
        relative_path=relative_path,
        consumers=tuple(consumers),
        producer=producer,
        access=access,
        required=required,
        schema_name=schema_name,
        sidecar_mode=sidecar_mode,
        expected_sha256=expected_sha256,
        expected_size=expected_size,
    )


STATIC_INPUTS: dict[str, tuple[ArtifactSpec, ...]] = {
    "P16": (
        _spec("p16.handoff", "OBSIDIAN", "handoff/publication_handoff_manifest.json", consumers=("RUNTIME",), producer="P14", schema_name="publication-handoff-v1.schema.json", sidecar_mode="BARE"),
        _spec("p16.vault_binding", "RUNTIME", "bindings/formal-vault.json", consumers=("RUNTIME",), producer="BOOTSTRAP", sidecar_mode="BARE"),
    ),
    "P17": (
        _spec("p17.questions", "OBSIDIAN", "author-input/AUTHOR_INTENT_QUESTIONS.md", consumers=("LLM", "RUNTIME"), producer="P17", sidecar_mode="BARE"),
        _spec("p17.author_response", "OBSIDIAN", "author-input/AUTHOR_RESPONSE.md", consumers=("LLM", "RUNTIME"), producer="AUTHOR", sidecar_mode="BARE"),
        _spec("p17.author_response_receipt", "OBSIDIAN", "author-input/author_response_receipt.json", consumers=("LLM", "RUNTIME"), producer="RUNTIME", sidecar_mode="BARE"),
        _spec("p17.article", "OBSIDIAN", "evidence/publication_final.md", consumers=("LLM", "RUNTIME"), producer="P16", sidecar_mode="BARE"),
        _spec("p17.vault_profile", "OBSIDIAN", "index/vault_profile.json", consumers=("LLM", "RUNTIME"), producer="P16", sidecar_mode="BARE"),
        _spec("p17.intent_contract", "OBSIDIAN", "semantic/author_intent_contract.json", consumers=("RUNTIME",), producer="P17", required=False, schema_name="author-intent-contract-v2.schema.json", sidecar_mode="BARE"),
    ),
    "P18": (
        _spec("p18.intent_contract", "OBSIDIAN", "semantic/author_intent_contract.json", consumers=("LLM", "RUNTIME"), producer="P17", schema_name="author-intent-contract-v2.schema.json", sidecar_mode="BARE"),
        _spec("p18.article", "OBSIDIAN", "evidence/publication_final.md", consumers=("LLM", "RUNTIME"), producer="P16", sidecar_mode="BARE"),
        _spec("p18.vault_profile", "OBSIDIAN", "index/vault_profile.json", consumers=("LLM", "RUNTIME"), producer="P16", sidecar_mode="BARE"),
        _spec("p18.vault_index", "OBSIDIAN", "index/vault_note_index.json", consumers=("LLM", "RUNTIME"), producer="P16", sidecar_mode="BARE"),
        _spec("p18.page_plan", "OBSIDIAN", "semantic/copy_first_page_plan.json", consumers=("RUNTIME",), producer="P18", required=False, schema_name="copy-first-page-plan-v1.schema.json", sidecar_mode="BARE"),
    ),
    "P19": (
        _spec("p19.page_plan", "OBSIDIAN", "semantic/copy_first_page_plan.json", consumers=("LLM", "RUNTIME"), producer="P18", schema_name="copy-first-page-plan-v1.schema.json", sidecar_mode="BARE"),
        _spec("p19.seed_manifest", "OBSIDIAN", "page_seed_manifest.json", consumers=("LLM", "RUNTIME"), producer="P18", schema_name="page-seed-manifest-v1.schema.json", sidecar_mode="BARE"),
        _spec("p19.patch_bundle", "OBSIDIAN", "semantic/page_patch_bundle.json", consumers=("RUNTIME",), producer="P19", required=False, schema_name="page-patch-bundle-v1.schema.json", sidecar_mode="BARE"),
    ),
    "P20": (
        _spec("p20.page_plan", "OBSIDIAN", "semantic/copy_first_page_plan.json", consumers=("RUNTIME",), producer="P18", schema_name="copy-first-page-plan-v1.schema.json", sidecar_mode="BARE"),
        _spec("p20.seed_manifest", "OBSIDIAN", "page_seed_manifest.json", consumers=("RUNTIME",), producer="P18", schema_name="page-seed-manifest-v1.schema.json", sidecar_mode="BARE"),
        _spec("p20.patch_bundle", "OBSIDIAN", "semantic/page_patch_bundle.json", consumers=("RUNTIME",), producer="P19", schema_name="page-patch-bundle-v1.schema.json", sidecar_mode="BARE"),
        _spec("p20.patch_application", "OBSIDIAN", "page_patch_application.json", consumers=("RUNTIME",), producer="P19", schema_name="page-patch-application-v1.schema.json", sidecar_mode="BARE"),
        _spec("p20.article", "OBSIDIAN", "evidence/publication_final.md", consumers=("RUNTIME",), producer="P16", sidecar_mode="BARE"),
        _spec("p20.vault_index", "OBSIDIAN", "index/vault_note_index.json", consumers=("RUNTIME",), producer="P16", sidecar_mode="BARE"),
    ),
    "P21": (
        _spec("p21.staging_manifest", "OBSIDIAN", "staging/staging_manifest.json", consumers=("RUNTIME",), producer="P20", schema_name="obsidian-staging-manifest-v2.schema.json", sidecar_mode="BARE"),
        _spec("p21.patch_application", "OBSIDIAN", "page_patch_application.json", consumers=("RUNTIME",), producer="P19", schema_name="page-patch-application-v1.schema.json", sidecar_mode="BARE"),
        _spec("p21.vault_binding", "RUNTIME", "bindings/formal-vault.json", consumers=("RUNTIME",), producer="BOOTSTRAP", sidecar_mode="BARE"),
    ),
}


STATIC_OUTPUTS: dict[str, tuple[ArtifactSpec, ...]] = {
    "P16": tuple(
        _spec(f"p16.output.{Path(path).stem}", "OBSIDIAN", path, consumers=("P17", "RUNTIME"), producer="P16", access="CREATE", schema_name=schema, sidecar_mode="BARE")
        for path, schema in (
            ("index/vault_note_index.json", None),
            ("index/vault_link_graph.json", None),
            ("index/vault_profile.json", None),
            ("index/p16_index_manifest.json", None),
        )
    ),
    "P17": (
        _spec("p17.output.intent_contract", "OBSIDIAN", "semantic/author_intent_contract.json", consumers=("P18",), producer="P17", access="CREATE", required=False, schema_name="author-intent-contract-v2.schema.json", sidecar_mode="BARE"),
        _spec("p17.output.questions", "OBSIDIAN", "author-input/AUTHOR_INTENT_QUESTIONS.md", consumers=("AUTHOR", "P17"), producer="P17", access="CREATE", required=False, sidecar_mode="BARE"),
        _spec("p17.output.response", "OBSIDIAN", "author-input/AUTHOR_RESPONSE.md", consumers=("P17",), producer="AUTHOR", access="CREATE", required=False, sidecar_mode="BARE"),
        _spec("p17.output.receipt", "OBSIDIAN", "author-input/author_response_receipt.json", consumers=("P17",), producer="RUNTIME", access="CREATE", required=False, sidecar_mode="BARE"),
    ),
    "P18": (
        _spec("p18.output.page_plan", "OBSIDIAN", "semantic/copy_first_page_plan.json", consumers=("P19", "RUNTIME"), producer="P18", access="CREATE", required=False, schema_name="copy-first-page-plan-v1.schema.json", sidecar_mode="BARE"),
        _spec("p18.output.seed_manifest", "OBSIDIAN", "page_seed_manifest.json", consumers=("P19", "RUNTIME"), producer="RUNTIME", access="CREATE", required=False, schema_name="page-seed-manifest-v1.schema.json", sidecar_mode="BARE"),
    ),
    "P19": (
        _spec("p19.output.patch_bundle", "OBSIDIAN", "semantic/page_patch_bundle.json", consumers=("P20", "RUNTIME"), producer="P19", access="CREATE", required=False, schema_name="page-patch-bundle-v1.schema.json", sidecar_mode="BARE"),
        _spec("p19.output.patch_application", "OBSIDIAN", "page_patch_application.json", consumers=("P20", "RUNTIME"), producer="RUNTIME", access="CREATE", required=False, schema_name="page-patch-application-v1.schema.json", sidecar_mode="BARE"),
    ),
    "P20": (
        _spec("p20.output.staging_manifest", "OBSIDIAN", "staging/staging_manifest.json", consumers=("P21",), producer="P20", access="CREATE", schema_name="obsidian-staging-manifest-v2.schema.json", sidecar_mode="BARE"),
        _spec("p20.output.staging_review", "OBSIDIAN", "staging/STAGING_REVIEW.md", consumers=("AUTHOR",), producer="P20", access="CREATE", sidecar_mode="BARE"),
    ),
    "P21": tuple(
        _spec(f"p21.output.{Path(path).stem}", "OBSIDIAN", path, consumers=("APPLY",), producer="P21", access="CREATE", sidecar_mode="BARE")
        for path in (
            "validation/obsidian_validation_report.json",
            "validation/import_manifest.json",
            "validation/p21_import_commit.json",
        )
    ),
}


def semantic_schema_for(relative_path: str) -> str | None:
    return SEMANTIC_ARTIFACT_SCHEMAS.get(relative_path)


def _binding_record(state: dict[str, Any]) -> dict[str, Any]:
    reference = state["roots"].get("formal_vault_binding")
    if not isinstance(reference, dict):
        raise ValueError("formal Vault binding is missing")
    runtime = Path(state["roots"]["runtime_root"]).resolve()
    path = safe_relative_target(runtime, str(reference["binding_record_relative_path"]))
    if sha256_file(path) != reference["binding_record_sha256"]:
        raise ValueError("formal Vault binding record changed")
    return strict_load_json(path)


def resolve_roots(state: dict[str, Any]) -> dict[str, Path]:
    roots = {
        "BUSINESS": Path(state["roots"]["business_root"]).resolve(),
        "RUNTIME": Path(state["roots"]["runtime_root"]).resolve(),
        "OBSIDIAN": Path(state["roots"]["obsidian_run_root"]).resolve(),
    }
    binding = _binding_record(state)
    vault = Path(binding["canonical_root"]).resolve(strict=True)
    if not vault.is_dir() or vault.is_symlink():
        raise ValueError("formal Vault root is unavailable or unsafe")
    roots["VAULT"] = vault
    return roots


def _root_manifest(state: dict[str, Any], roots: dict[str, Path]) -> dict[str, Any]:
    reference = state["roots"]["formal_vault_binding"]
    return {
        name: {
            "canonical_root": str(path),
            "canonical_root_sha256": sha256_bytes(str(path).encode("utf-8")),
            "root_fingerprint": reference["root_fingerprint"] if name == "VAULT" else None,
        }
        for name, path in sorted(roots.items())
    }


def _artifact_entry(
    spec: ArtifactSpec,
    roots: dict[str, Path],
    overrides: dict[tuple[str, str], bytes] | None = None,
    access_overrides: dict[tuple[str, str], str] | None = None,
) -> dict[str, Any]:
    path = safe_relative_target(roots[spec.symbolic_root], spec.relative_path)
    override = (overrides or {}).get((spec.symbolic_root, spec.relative_path))
    exists = override is not None or (path.is_file() and not path.is_symlink())
    if spec.required and not exists:
        raise ValueError(f"required {spec.artifact_id} is missing: {path}")
    if path.exists() and (path.is_symlink() or not path.is_file()) and override is None:
        raise ValueError(f"artifact path is unsafe: {path}")
    size = len(override) if override is not None else (path.stat().st_size if exists else None)
    digest = sha256_bytes(override) if override is not None else (sha256_file(path) if exists else None)
    if spec.expected_sha256 is not None and digest != spec.expected_sha256:
        raise ValueError(f"artifact hash differs from its declared handoff: {spec.relative_path}")
    if spec.expected_size is not None and size != spec.expected_size:
        raise ValueError(f"artifact size differs from its declared handoff: {spec.relative_path}")
    sidecar: dict[str, Any] | None = None
    if exists and spec.sidecar_mode != "NONE" and override is None:
        sidecar_digest = (
            validate_bare_sha256_sidecar(path)
            if spec.sidecar_mode == "BARE"
            else validate_named_sha256_sidecar(path)
        )
        if sidecar_digest != digest:
            raise ValueError(f"artifact sidecar does not bind content: {path}")
        sidecar_path = path.with_suffix(".sha256")
        sidecar = {
            "mode": spec.sidecar_mode,
            "relative_path": sidecar_path.relative_to(roots[spec.symbolic_root]).as_posix(),
            "sha256": sha256_file(sidecar_path),
        }
    elif exists and spec.sidecar_mode != "NONE" and override is not None:
        sidecar = {
            "mode": spec.sidecar_mode,
            "relative_path": path.with_suffix(".sha256").relative_to(roots[spec.symbolic_root]).as_posix(),
            "sha256": sha256_bytes((digest + "\n").encode("utf-8")),
        }
    return {
        "artifact_id": spec.artifact_id,
        "domain": spec.domain,
        "symbolic_root": spec.symbolic_root,
        "relative_path": spec.relative_path,
        "producer": spec.producer,
        "consumers": sorted(set(spec.consumers)),
        "access": (access_overrides or {}).get(
            (spec.symbolic_root, spec.relative_path), spec.access
        ),
        "required": spec.required,
        "exists": exists,
        "size": size,
        "sha256": digest,
        "schema_name": spec.schema_name,
        "sidecar": sidecar,
    }


def _p16_dynamic_inputs(state: dict[str, Any], roots: dict[str, Path]) -> list[ArtifactSpec]:
    handoff_path = roots["OBSIDIAN"] / "handoff" / "publication_handoff_manifest.json"
    validate_bare_sha256_sidecar(handoff_path)
    handoff = strict_load_json(handoff_path)
    validate_json_schema(handoff, "publication-handoff-v1.schema.json")
    specs: list[ArtifactSpec] = []
    seen: set[str] = set()
    for item in handoff["required_artifacts"]:
        relative = str(item["business_relative_path"])
        if relative in seen:
            raise ValueError(f"duplicate publication handoff path: {relative}")
        seen.add(relative)
        sidecar_mode = "NAMED" if relative in {"release_manifest.json", "validator_result.json"} else "NONE"
        specs.append(_spec(
            f"p16.business.{item['artifact_role']}",
            "BUSINESS",
            relative,
            consumers=("RUNTIME",),
            producer="P00-P15",
            expected_sha256=str(item["sha256"]),
            expected_size=int(item["size"]),
            sidecar_mode=sidecar_mode,
        ))
    binding = _binding_record(state)
    config = binding.get("config") or {}
    indexing = config.get("indexing") or {}
    excludes = [str(item).rstrip("/") for item in indexing.get("exclude_paths", [])]
    max_notes = int(indexing.get("max_notes", 20000))
    max_bytes = int(indexing.get("max_note_bytes", 2_000_000))
    count = 0
    for path in sorted(roots["VAULT"].rglob("*.md"), key=lambda item: item.relative_to(roots["VAULT"]).as_posix().casefold()):
        rel_path = path.relative_to(roots["VAULT"])
        rel = rel_path.as_posix()
        hidden = any(part.startswith(".") for part in rel_path.parts)
        excluded = any(rel == item or rel.startswith(item + "/") for item in excludes)
        if hidden or excluded or path.is_symlink() or not path.is_file() or path.stat().st_size > max_bytes:
            continue
        count += 1
        if count > max_notes:
            raise ValueError(f"Vault note limit exceeded: {max_notes}")
        specs.append(_spec(f"p16.vault.note.{count:05d}", "VAULT", rel, consumers=("RUNTIME",), producer="VAULT"))
    return specs


def _packet_specs(state: dict[str, Any], *, phase_id: str) -> list[ArtifactSpec]:
    root = Path(state["roots"]["obsidian_run_root"]).resolve()
    packet_path = root / "retrieval" / "vault_retrieval_packet.json"
    if not packet_path.is_file():
        return []
    packet = strict_load_json(packet_path)
    result: list[ArtifactSpec] = []
    for item in packet.get("selected_notes", []):
        packet_rel = str(item["packet_path"])
        vault_rel = str(item["vault_path"])
        result.append(_spec(f"{phase_id.lower()}.packet.{item['packet_id']}", "OBSIDIAN", packet_rel, consumers=("LLM", "RUNTIME"), producer="P17", sidecar_mode="BARE", expected_sha256=str(item["packet_sha256"])))
        result.append(_spec(f"{phase_id.lower()}.vault.{item['packet_id']}", "VAULT", vault_rel, consumers=("RUNTIME",), producer="VAULT", expected_sha256=str(item["vault_sha256"])))
    return result


def _p17_retrieval_source_specs(state: dict[str, Any]) -> list[ArtifactSpec]:
    root = Path(state["roots"]["obsidian_run_root"]).resolve()
    if not (root / "semantic" / "author_intent_contract.json").is_file():
        return []
    from obsidian_author_directed import select_retrieval_records

    return [
        _spec(
            f"p17.vault.selection.{index:04d}",
            "VAULT",
            str(row["path"]),
            consumers=("RUNTIME",),
            producer="VAULT",
            expected_sha256=str(row["sha256"]),
        )
        for index, row in enumerate(select_retrieval_records(state), 1)
    ]


def _plan_vault_specs(state: dict[str, Any], phase_id: str) -> list[ArtifactSpec]:
    root = Path(state["roots"]["obsidian_run_root"]).resolve()
    plan_path = root / "semantic" / "copy_first_page_plan.json"
    if not plan_path.is_file():
        return []
    plan = strict_load_json(plan_path)
    paths: dict[str, str] = {}
    for page in plan.get("pages", []):
        if page.get("operation_kind") == "UPDATE":
            paths[str(page["target_path"])] = str(page["expected_target_sha256"])
    return [
        _spec(f"{phase_id.lower()}.vault.precondition.{index:04d}", "VAULT", rel, consumers=("RUNTIME",), producer="VAULT", expected_sha256=digest)
        for index, (rel, digest) in enumerate(sorted(paths.items()), 1)
    ]


def _staging_specs(state: dict[str, Any], *, consumers: tuple[str, ...]) -> list[ArtifactSpec]:
    root = Path(state["roots"]["obsidian_run_root"]).resolve()
    manifest_path = root / "staging" / "staging_manifest.json"
    if not manifest_path.is_file():
        return []
    manifest = strict_load_json(manifest_path)
    result: list[ArtifactSpec] = []
    for item in manifest.get("operations", []):
        for kind, field in (("after", "candidate_relative_path"), ("diff", "diff_relative_path")):
            relative = item.get(field)
            if relative:
                expected = str(item["after_sha256"]) if kind == "after" else None
                result.append(_spec(f"staging.{item['operation_id']}.{kind}", "OBSIDIAN", str(relative), consumers=consumers, producer="P19", expected_sha256=expected))
    return result


def _seed_specs(state: dict[str, Any], *, phase_id: str) -> list[ArtifactSpec]:
    root = Path(state["roots"]["obsidian_run_root"]).resolve()
    path = root / "page_seed_manifest.json"
    if not path.is_file():
        return []
    manifest = strict_load_json(path)
    return [
        _spec(
            f"{phase_id.lower()}.seed.{item['page_id']}", "OBSIDIAN",
            str(item["seed_relative_path"]), consumers=("LLM", "RUNTIME"),
            producer="P18", sidecar_mode="BARE", expected_sha256=str(item["seed_sha256"]),
        )
        for item in manifest.get("pages", [])
    ]


def _candidate_specs(state: dict[str, Any], *, phase_id: str) -> list[ArtifactSpec]:
    root = Path(state["roots"]["obsidian_run_root"]).resolve()
    path = root / "page_patch_application.json"
    if not path.is_file():
        return []
    value = strict_load_json(path)
    return [
        _spec(
            f"{phase_id.lower()}.candidate.{item['page_id']}", "OBSIDIAN",
            f"page-candidates/{item['page_id']}.md", consumers=("RUNTIME",),
            producer="P19", sidecar_mode="BARE", expected_sha256=str(item["candidate_sha256"]),
        )
        for item in value.get("pages", [])
    ]


def _all_vault_markdown_specs(state: dict[str, Any]) -> list[ArtifactSpec]:
    roots = resolve_roots(state)
    result = []
    for index, path in enumerate(sorted(roots["VAULT"].rglob("*.md"), key=lambda item: item.relative_to(roots["VAULT"]).as_posix().casefold()), 1):
        if path.is_symlink() or not path.is_file():
            continue
        result.append(_spec(f"p21.vault.snapshot.{index:05d}", "VAULT", path.relative_to(roots["VAULT"]).as_posix(), consumers=("RUNTIME",), producer="VAULT"))
    return result


def _dedupe_specs(specs: list[ArtifactSpec]) -> list[ArtifactSpec]:
    merged: dict[tuple[str, str], ArtifactSpec] = {}
    for item in specs:
        key = (item.symbolic_root, item.relative_path)
        previous = merged.get(key)
        if previous is None:
            merged[key] = item
            continue
        if previous.access != item.access or previous.sidecar_mode != item.sidecar_mode:
            raise ValueError(f"conflicting Phase I/O declarations for {key}")
        expected_hashes = {value for value in (previous.expected_sha256, item.expected_sha256) if value}
        expected_sizes = {value for value in (previous.expected_size, item.expected_size) if value is not None}
        if len(expected_hashes) > 1 or len(expected_sizes) > 1:
            raise ValueError(f"conflicting Phase I/O preconditions for {key}")
        merged[key] = ArtifactSpec(
            artifact_id=previous.artifact_id,
            domain=previous.domain,
            symbolic_root=previous.symbolic_root,
            relative_path=previous.relative_path,
            consumers=tuple(sorted(set(previous.consumers) | set(item.consumers))),
            producer=previous.producer,
            access=previous.access,
            required=previous.required or item.required,
            schema_name=previous.schema_name or item.schema_name,
            sidecar_mode=previous.sidecar_mode,
            expected_sha256=next(iter(expected_hashes), None),
            expected_size=next(iter(expected_sizes), None),
        )
    return list(merged.values())


def input_specs(state: dict[str, Any], phase_id: str) -> list[ArtifactSpec]:
    if phase_id not in OBSIDIAN_PHASES:
        raise ValueError(f"Phase I/O registry does not own {phase_id}")
    specs = list(STATIC_INPUTS[phase_id])
    roots = resolve_roots(state)
    if phase_id == "P16":
        specs.extend(_p16_dynamic_inputs(state, roots))
    if phase_id == "P19":
        specs.extend(_seed_specs(state, phase_id=phase_id))
        specs.extend(_plan_vault_specs(state, phase_id))
    if phase_id == "P20":
        specs.extend(_candidate_specs(state, phase_id=phase_id))
    if phase_id == "P21":
        specs.extend(_staging_specs(state, consumers=("RUNTIME",)))
        specs.extend(_candidate_specs(state, phase_id=phase_id))
        specs.extend(_plan_vault_specs(state, phase_id))
        specs.extend(_all_vault_markdown_specs(state))
    return _dedupe_specs(specs)


def output_specs(state: dict[str, Any], phase_id: str) -> list[ArtifactSpec]:
    specs = list(STATIC_OUTPUTS[phase_id])
    root = Path(state["roots"]["obsidian_run_root"]).resolve()
    if phase_id == "P16":
        handoff = strict_load_json(root / "handoff" / "publication_handoff_manifest.json")
        for item in handoff["required_artifacts"]:
            relative = f"evidence/{str(item['business_relative_path'])}"
            specs.append(_spec(f"p16.output.evidence.{item['artifact_role']}", "OBSIDIAN", relative, consumers=("P17", "P18", "RUNTIME"), producer="P16", access="CREATE", sidecar_mode="BARE"))
    dynamic_roots = {
        "P18": (("page-seeds", ("P19",), "P18"),),
        "P19": (("page-candidates", ("P20", "P21"), "P19"), ("diffs", ("P20",), "P19")),
        "P20": (("staging", ("P21",), "P20"), ("delivery", ("AUTHOR",), "P20")),
    }
    for folder, consumers, producer in dynamic_roots.get(phase_id, ()):
        base = root / folder
        if not base.is_dir():
            continue
        known = {item.relative_path for item in specs}
        for index, path in enumerate(sorted(base.rglob("*")), 1):
            relative = path.relative_to(root).as_posix()
            if path.is_file() and not path.is_symlink() and path.suffix != ".sha256" and relative not in known:
                specs.append(_spec(f"{phase_id.lower()}.output.{folder}.{index:04d}", "OBSIDIAN", relative, consumers=consumers, producer=producer, access="CREATE", sidecar_mode=("NONE" if folder == "delivery" else "BARE")))
    return specs


def _manifest_base(state: dict[str, Any], phase_id: str, attempt: int, roots: dict[str, Path]) -> dict[str, Any]:
    return {
        "job_id": state["identity"]["job_id"],
        "run_id": state["identity"]["run_id"],
        "phase_id": phase_id,
        "phase_attempt": attempt,
        "phase_plan_revision": state["route"]["phase_plan_revision"],
        "root_bindings": _root_manifest(state, roots),
    }


def build_input_manifest(state: dict[str, Any], phase_id: str, attempt: int) -> dict[str, Any]:
    roots = resolve_roots(state)
    entries = [_artifact_entry(item, roots) for item in input_specs(state, phase_id)]
    manifest = {
        "schema_version": INPUT_SCHEMA_VERSION,
        **_manifest_base(state, phase_id, attempt, roots),
        "artifacts": sorted(entries, key=lambda item: (item["symbolic_root"], item["relative_path"], item["artifact_id"])),
    }
    validate_json_schema(manifest, "phase-input-manifest-v1.schema.json")
    return manifest


def build_output_manifest(
    state: dict[str, Any],
    phase_id: str,
    attempt: int,
    *,
    overrides: dict[tuple[str, str], bytes] | None = None,
    access_overrides: dict[tuple[str, str], str] | None = None,
) -> dict[str, Any]:
    roots = resolve_roots(state)
    entries = [
        _artifact_entry(item, roots, overrides, access_overrides)
        for item in output_specs(state, phase_id)
    ]
    manifest = {
        "schema_version": OUTPUT_SCHEMA_VERSION,
        **_manifest_base(state, phase_id, attempt, roots),
        "artifacts": sorted(entries, key=lambda item: (item["symbolic_root"], item["relative_path"], item["artifact_id"])),
    }
    validate_json_schema(manifest, "phase-output-manifest-v1.schema.json")
    return manifest


def phase_manifest_path(state: dict[str, Any], phase_id: str, attempt: int, kind: str) -> Path:
    if kind not in {"input", "output"}:
        raise ValueError(f"unknown Phase I/O manifest kind: {kind}")
    runtime = Path(state["roots"]["runtime_root"]).resolve()
    return runtime / "phase-io" / phase_id / f"attempt-{attempt}" / f"{kind}-manifest.json"


def _write_once(path: Path, value: dict[str, Any]) -> str:
    content = canonical_json_bytes(value)
    digest = sha256_bytes(content)
    if path.exists():
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"immutable manifest path is unsafe: {path}")
        validate_bare_sha256_sidecar(path)
        if path.read_bytes() != content:
            raise ValueError(f"attempt manifest content changed after binding: {path}")
        return digest
    actual = write_hashed_json(path, value)
    if actual != digest:
        raise RuntimeError("Phase I/O manifest digest mismatch")
    return actual


def ensure_input_manifest(state: dict[str, Any], phase_id: str, attempt: int) -> tuple[Path, dict[str, Any], str]:
    manifest = build_input_manifest(state, phase_id, attempt)
    path = phase_manifest_path(state, phase_id, attempt, "input")
    digest = _write_once(path, manifest)
    return path, manifest, digest


def ensure_output_manifest(state: dict[str, Any], phase_id: str, attempt: int) -> tuple[Path, dict[str, Any], str]:
    manifest = build_output_manifest(state, phase_id, attempt)
    path = phase_manifest_path(state, phase_id, attempt, "output")
    digest = _write_once(path, manifest)
    return path, manifest, digest


def output_manifest_transition_payloads(
    state: dict[str, Any],
    phase_id: str,
    attempt: int,
    overrides: dict[tuple[str, str], bytes],
    access_overrides: dict[tuple[str, str], str],
) -> tuple[Path, bytes, bytes, str]:
    manifest = build_output_manifest(
        state,
        phase_id,
        attempt,
        overrides=overrides,
        access_overrides=access_overrides,
    )
    path = phase_manifest_path(state, phase_id, attempt, "output")
    content = canonical_json_bytes(manifest)
    digest = sha256_bytes(content)
    return path, content, (digest + "\n").encode("utf-8"), digest


def validate_input_manifest_binding(state: dict[str, Any], phase_id: str, attempt: int, expected_sha256: str) -> dict[str, Any]:
    path = phase_manifest_path(state, phase_id, attempt, "input")
    actual = validate_bare_sha256_sidecar(path)
    if actual != expected_sha256:
        raise ValueError("input manifest hash differs from Runtime binding")
    stored = strict_load_json(path)
    validate_json_schema(stored, "phase-input-manifest-v1.schema.json")
    rebuilt = build_input_manifest(state, phase_id, attempt)
    if canonical_json_bytes(stored) != canonical_json_bytes(rebuilt):
        raise ValueError("phase inputs changed after the attempt was bound")
    return stored


def resolve_manifest_artifact(state: dict[str, Any], entry: dict[str, Any]) -> Path:
    roots = resolve_roots(state)
    return safe_relative_target(roots[str(entry["symbolic_root"])], str(entry["relative_path"]))
