#!/usr/bin/env python3
"""Author-directed Obsidian compilation for the Math Longform Agent.

The author chooses what to preserve.  The Agent performs every knowledge-
engineering task: evidence location, Vault retrieval, destination choice,
bidirectional linking, MOC decisions, adversarial review, staging, validation,
and reviewed deterministic application.

This module never changes P00-P15 business artifacts.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import shutil
import tempfile
import uuid
from typing import Any, Iterable

from runtime_support import (
    atomic_write_bytes,
    atomic_write_text,
    canonical_json_bytes,
    safe_relative_target,
    sha256_bytes,
    sha256_file,
    strict_load_json,
    validate_bare_sha256_sidecar,
    validate_json_schema,
    write_hashed_json,
)

SCHEMA_VERSION = "author-directed-obsidian-v1"
CONTRACT_VERSION = "obsidian-business-contract-v1.0"
P21_IMPORT_COMMIT_FILENAME = "p21_import_commit.json"
IMPORT_TRANSACTION_FILENAME = "import_transaction.json"
FORBIDDEN_READER_SURFACE = (
    "managed_payload_sha256",
    "managed_contract_version",
    "object_id:",
    "operation_id:",
    "<!-- mla:",
    "<!-- agent-managed",
    "`supports`",
    "`contrasts-with`",
    "`computed-with`",
)
WIKILINK_RE = re.compile(r"(?<!!)\[\[([^\]#|]+)(?:#[^\]|]+)?(?:\|[^\]]+)?\]\]")
TAG_RE = re.compile(r"(?<![\w/])#([\w\u3400-\u9fff][\w\u3400-\u9fff/-]*)")
HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*$", re.M)
CJK_RE = re.compile(r"[\u3400-\u9fff]")
WORD_RE = re.compile(r"[A-Za-z0-9_]{2,}|[\u3400-\u9fff]")
TAG_SEGMENT_RE = re.compile(r"^[A-Za-z0-9_\-\u3400-\u9fff]+$")
FRONTMATTER_START_RE = re.compile(r"^---\r?\n")
FENCED_CODE_RE = re.compile(r"```.*?```", re.S)

DEFAULT_DESTINATION_POLICY = {
    "learn_from_vault": True,
    "fallback_folder": "Agent Inbox",
    "allow_invented_taxonomy": False,
}
DEFAULT_TAG_POLICY = {
    "approved_tags": [],
    "max_depth": 2,
}
VAGUE_RESPONSIBILITIES = {
    "concept",
    "method",
    "knowledge",
    "review",
    "todo",
    "概念",
    "方法",
    "知识点",
    "待整理",
    "待补充",
    "用于复习",
    "一个笔记",
    "保存内容",
    "保留内容",
    "暂定",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def normalize_vault_folder(value: Any) -> str:
    """Return a portable, safe Vault-relative directory path."""
    if not isinstance(value, str) or not value.strip():
        raise ValueError("destination_policy.fallback_folder must be a non-empty relative folder")
    raw = value.strip().replace("\\", "/")
    posix = PurePosixPath(raw)
    if (
        posix.is_absolute()
        or PureWindowsPath(raw).is_absolute()
        or PureWindowsPath(raw).drive
        or any(part in {"", ".", ".."} or ":" in part for part in posix.parts)
    ):
        raise ValueError("destination_policy.fallback_folder must be a safe relative folder")
    return posix.as_posix()


def _canonical_tag(value: Any, *, max_depth: int, context: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{context} must be a string")
    tag = value.strip()
    if not tag or tag != value or tag.startswith("#"):
        raise ValueError(f"{context} must be a canonical tag without a leading #")
    segments = tag.split("/")
    if len(segments) > max_depth or any(not TAG_SEGMENT_RE.fullmatch(part) for part in segments):
        raise ValueError(
            f"{context} must use slash hierarchy of at most {max_depth} levels"
        )
    return tag


def normalize_destination_policy(value: Any | None) -> dict[str, Any]:
    if value is None:
        value = {}
    if not isinstance(value, dict):
        raise ValueError("destination_policy must be an object")
    unknown = set(value) - set(DEFAULT_DESTINATION_POLICY)
    if unknown:
        raise ValueError(f"unknown destination_policy fields: {sorted(unknown)}")
    merged = {**DEFAULT_DESTINATION_POLICY, **value}
    if merged["learn_from_vault"] is not True:
        raise ValueError("author-directed mode must learn destinations from the Vault")
    if merged["allow_invented_taxonomy"] is not False:
        raise ValueError("invented folder taxonomies are forbidden")
    return {
        "learn_from_vault": True,
        "fallback_folder": normalize_vault_folder(merged["fallback_folder"]),
        "allow_invented_taxonomy": False,
    }


def normalize_tag_policy(value: Any | None) -> dict[str, Any]:
    """Validate the conservative tag policy stored in the formal Vault binding."""
    if value is None:
        value = {}
    if not isinstance(value, dict):
        raise ValueError("tag_policy must be an object")
    unknown = set(value) - set(DEFAULT_TAG_POLICY)
    if unknown:
        raise ValueError(f"unknown tag_policy fields: {sorted(unknown)}")
    merged = {**DEFAULT_TAG_POLICY, **value}
    max_depth = merged["max_depth"]
    if isinstance(max_depth, bool) or not isinstance(max_depth, int) or not 1 <= max_depth <= 4:
        raise ValueError("tag_policy.max_depth must be an integer from 1 through 4")
    approved = merged["approved_tags"]
    if not isinstance(approved, list):
        raise ValueError("tag_policy.approved_tags must be an array")
    normalized: list[str] = []
    seen: set[str] = set()
    for item in approved:
        tag = _canonical_tag(
            item,
            max_depth=max_depth,
            context="tag_policy.approved_tags entry",
        )
        key = tag.casefold()
        if key in seen:
            raise ValueError("tag_policy.approved_tags must not contain duplicates")
        seen.add(key)
        normalized.append(tag)
    return {
        "approved_tags": normalized,
        "max_depth": max_depth,
    }


def root_fingerprint(path: Path) -> str:
    stat = path.stat()
    return sha256_bytes(
        canonical_json_bytes(
            {
                "canonical_root": str(path),
                "device": getattr(stat, "st_dev", None),
                "inode": getattr(stat, "st_ino", None),
            }
        )
    )


def _read_text(path: Path) -> str:
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"regular file required: {path}")
    return path.read_text(encoding="utf-8", errors="strict")


def _write_hashed_text(path: Path, text: str) -> str:
    if not text.endswith("\n"):
        text += "\n"
    atomic_write_text(path, text)
    digest = sha256_file(path)
    atomic_write_text(path.with_suffix(".sha256"), digest + "\n")
    return digest


def _write_hashed_bytes(path: Path, content: bytes) -> str:
    atomic_write_bytes(path, content)
    digest = sha256_file(path)
    atomic_write_text(path.with_suffix(".sha256"), digest + "\n")
    return digest


def runtime_root_from(state: dict[str, Any]) -> Path:
    return Path(state["roots"]["runtime_root"]).resolve()


def obsidian_root_from(state: dict[str, Any]) -> Path:
    raw = state["roots"].get("obsidian_run_root")
    if not raw:
        raise ValueError("Obsidian run root is not configured")
    root = Path(raw).resolve()
    root.mkdir(parents=True, exist_ok=True)
    return root


def business_root_from(state: dict[str, Any]) -> Path:
    return Path(state["roots"]["business_root"]).resolve()


def load_binding(state: dict[str, Any]) -> tuple[dict[str, Any], Path]:
    ref = state["roots"].get("formal_vault_binding")
    if not isinstance(ref, dict):
        raise ValueError("formal Vault binding is missing")
    path = safe_relative_target(
        runtime_root_from(state), str(ref["binding_record_relative_path"])
    )
    binding = strict_load_json(path)
    if sha256_file(path) != ref["binding_record_sha256"]:
        raise ValueError("formal Vault binding hash changed")
    vault = Path(binding["canonical_root"]).resolve(strict=True)
    if not vault.is_dir() or vault.is_symlink():
        raise ValueError("bound Vault is unavailable or unsafe")
    actual_fingerprint = root_fingerprint(vault)
    if actual_fingerprint != binding.get("root_fingerprint"):
        raise ValueError("bound Vault root fingerprint changed")
    if actual_fingerprint != ref.get("root_fingerprint"):
        raise ValueError("Vault binding reference fingerprint changed")
    return binding, vault


def _split_frontmatter(text: str) -> tuple[dict[str, Any], str, str]:
    """Return parsed simple frontmatter, raw frontmatter, and body."""
    if not text.startswith("---\n"):
        return {}, "", text
    end = text.find("\n---\n", 4)
    if end < 0:
        return {}, "", text
    raw = text[4:end]
    body = text[end + 5 :]
    data: dict[str, Any] = {}
    current_list: str | None = None
    for line in raw.splitlines():
        list_match = re.match(r"^\s*-\s*(.+?)\s*$", line)
        if list_match and current_list:
            data.setdefault(current_list, []).append(list_match.group(1).strip(" \"'"))
            continue
        match = re.match(r"^([A-Za-z0-9_-]+):\s*(.*?)\s*$", line)
        if not match:
            current_list = None
            continue
        key, value = match.groups()
        if value == "":
            data[key] = []
            current_list = key
        elif value.startswith("[") and value.endswith("]"):
            items = [
                item.strip().strip(" \"'")
                for item in value[1:-1].split(",")
                if item.strip()
            ]
            data[key] = items
            current_list = None
        else:
            data[key] = value.strip(" \"'")
            current_list = None
    return data, raw, body


def _as_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item) for item in value if str(item).strip()]
    if isinstance(value, str):
        return [value] if value.strip() else []
    return [str(value)]


def _tags_from_markdown(text: str) -> list[str]:
    """Extract frontmatter and reader-visible inline tags from Markdown."""
    normalized = text.replace("\r\n", "\n")
    frontmatter, _, body = _split_frontmatter(normalized)
    inline_surface = FENCED_CODE_RE.sub("", body)
    return _as_list(frontmatter.get("tags")) + [
        match.group(1) for match in TAG_RE.finditer(inline_surface)
    ]


def _learned_tag_values(profile: dict[str, Any]) -> list[str]:
    catalog = profile.get("tag_catalog")
    if isinstance(catalog, list):
        return [str(item.get("tag", "")) for item in catalog if isinstance(item, dict)]
    return [str(item) for item in profile.get("common_tags", [])]


def _validate_tag_values(
    values: Iterable[Any],
    *,
    policy: dict[str, Any],
    learned_values: Iterable[Any],
    context: str,
) -> list[str]:
    """Allow only canonical tags observed in the Vault or explicitly approved."""
    max_depth = int(policy["max_depth"])
    allowed: set[str] = set()
    for raw in [*learned_values, *policy["approved_tags"]]:
        try:
            allowed.add(
                _canonical_tag(raw, max_depth=max_depth, context="learned Vault tag").casefold()
            )
        except ValueError:
            # Legacy or malformed Vault tags remain readable but are not a
            # precedent for newly generated metadata.
            continue

    normalized: list[str] = []
    seen: set[str] = set()
    for raw in values:
        tag = _canonical_tag(raw, max_depth=max_depth, context=context)
        key = tag.casefold()
        if key in seen:
            raise ValueError(f"{context} contains duplicate tag: {tag}")
        if key not in allowed:
            raise ValueError(
                f"{context} uses unapproved tag: {tag}; use a learned Vault tag or tag_policy.approved_tags"
            )
        seen.add(key)
        normalized.append(tag)
    return normalized


def _validate_operation_metadata(
    op: dict[str, Any],
    *,
    root: Path,
    profile: dict[str, Any],
    retrieved: dict[str, dict[str, Any]],
    configured_tag_policy: Any,
) -> None:
    """Prevent a plan from smuggling ungoverned tags through rendered Markdown."""
    policy = normalize_tag_policy(configured_tag_policy)
    learned = _learned_tag_values(profile)
    declared_tags = op.get("tags") or []
    _validate_tag_values(
        declared_tags,
        policy=policy,
        learned_values=learned,
        context=f"operation {op['operation_id']} declared tags",
    )

    content = str(op["rendered_markdown"])
    if op["operation_kind"] == "CREATE":
        if FRONTMATTER_START_RE.match(content.replace("\r\n", "\n")):
            raise ValueError(
                f"CREATE operation {op['operation_id']} must not provide frontmatter; use controlled aliases, tags, and source_note fields"
            )
        rendered_tags = _tags_from_markdown(_render_new_note(op))
        _validate_tag_values(
            rendered_tags,
            policy=policy,
            learned_values=learned,
            context=f"operation {op['operation_id']} rendered tags",
        )
        return

    retrieved_note = retrieved.get(str(op["target_path"]))
    if not retrieved_note:
        # _validate_operation_common produces the authoritative missing-retrieval error.
        return
    packet_path = safe_relative_target(root, str(retrieved_note["packet_path"]))
    before_tags = {
        value.casefold()
        for value in _tags_from_markdown(_read_text(packet_path))
        if isinstance(value, str)
    }
    after_tags = _tags_from_markdown(content)
    introduced = [tag for tag in after_tags if tag.casefold() not in before_tags]
    _validate_tag_values(
        introduced,
        policy=policy,
        learned_values=learned,
        context=f"operation {op['operation_id']} newly introduced tags",
    )


def _responsibility_key(value: str) -> str:
    return re.sub(r"[\W_]+", "", value.casefold(), flags=re.UNICODE)


def _validate_permanent_note_responsibility(
    op: dict[str, Any], seen: dict[str, str]
) -> None:
    responsibility = str(op["knowledge_responsibility"]).strip()
    compact = _responsibility_key(responsibility)
    title_key = _responsibility_key(str(op["title"]))
    if len(compact) < 10:
        raise ValueError(
            f"permanent note {op['operation_id']} knowledge responsibility is too short"
        )
    if compact in VAGUE_RESPONSIBILITIES or compact == title_key:
        raise ValueError(
            f"permanent note {op['operation_id']} knowledge responsibility is too vague"
        )
    prior = seen.get(compact)
    if prior:
        raise ValueError(
            f"permanent notes {prior} and {op['operation_id']} duplicate a knowledge responsibility"
        )
    seen[compact] = str(op["operation_id"])


def _title_for(path: Path, body: str, frontmatter: dict[str, Any]) -> str:
    if isinstance(frontmatter.get("title"), str) and frontmatter["title"].strip():
        return frontmatter["title"].strip()
    match = re.search(r"^#\s+(.+?)\s*$", body, re.M)
    return match.group(1).strip() if match else path.stem


def _tokens(text: str) -> set[str]:
    lower = text.casefold()
    latin = {
        token
        for token in re.findall(r"[a-z0-9_]{2,}", lower)
        if token not in {"the", "and", "for", "with", "that", "this"}
    }
    chars = [char for char in lower if CJK_RE.match(char)]
    cjk = set(chars)
    cjk.update("".join(chars[i : i + 2]) for i in range(max(0, len(chars) - 1)))
    return latin | cjk


def _is_hidden_or_ignored(relative: Path, excludes: list[str]) -> bool:
    parts = relative.parts
    if any(part.startswith(".") for part in parts):
        return True
    posix = relative.as_posix()
    return any(posix == item.rstrip("/") or posix.startswith(item.rstrip("/") + "/") for item in excludes)


def _note_record(vault: Path, path: Path) -> dict[str, Any]:
    relative = path.relative_to(vault).as_posix()
    text = _read_text(path)
    fm, _, body = _split_frontmatter(text)
    title = _title_for(path, body, fm)
    aliases = _as_list(fm.get("aliases") or fm.get("alias"))
    tags = _as_list(fm.get("tags"))
    tags += [m.group(1) for m in TAG_RE.finditer(body)]
    links = sorted({m.group(1).strip() for m in WIKILINK_RE.finditer(text) if m.group(1).strip()})
    headings = [m.group(2).strip() for m in HEADING_RE.finditer(body)]
    sample = re.sub(r"\s+", " ", body).strip()[:1800]
    moc_signal = (
        "moc" in path.stem.casefold()
        or "map of content" in body.casefold()
        or "知识地图" in body
        or len(links) >= 8 and len(headings) >= 2
    )
    return {
        "path": relative,
        "sha256": sha256_file(path),
        "size": path.stat().st_size,
        "title": title,
        "aliases": sorted(set(aliases)),
        "tags": sorted(set(tags)),
        "frontmatter_keys": sorted(fm.keys()),
        "headings": headings[:40],
        "outgoing_links": links,
        "word_count": len(WORD_RE.findall(body)),
        "moc_signal": bool(moc_signal),
        "sample": sample,
        "search_tokens": sorted(_tokens(" ".join([title, *aliases, *tags, *headings, sample]))),
    }


def _vault_profile(records: list[dict[str, Any]], config: dict[str, Any]) -> dict[str, Any]:
    folder_counter: Counter[str] = Counter()
    fm_counter: Counter[str] = Counter()
    tag_counter: Counter[str] = Counter()
    suffix_counter: Counter[str] = Counter()
    lengths: list[int] = []
    for row in records:
        parent = Path(row["path"]).parent.as_posix()
        folder_counter[parent if parent != "." else ""] += 1
        fm_counter.update(row["frontmatter_keys"])
        tag_counter.update(row["tags"])
        lengths.append(int(row["word_count"]))
        name = Path(row["path"]).stem
        if " - " in name:
            suffix_counter["spaced-dash"] += 1
        elif "_" in name:
            suffix_counter["underscore"] += 1
        elif re.match(r"^\d{4}-\d{2}-\d{2}", name):
            suffix_counter["date-prefix"] += 1
        else:
            suffix_counter["plain-title"] += 1
    lengths.sort()
    median = lengths[len(lengths) // 2] if lengths else 0
    folder_counter.setdefault("", 0)
    folders = [
        {"path": key, "count": value}
        for key, value in sorted(folder_counter.items(), key=lambda item: (-item[1], item[0].casefold()))[:30]
    ]
    destination_policy = normalize_destination_policy(config.get("destination_policy"))
    tag_policy = normalize_tag_policy(config.get("tag_policy"))
    mocs = [row["path"] for row in records if row["moc_signal"]]
    return {
        "profile_schema_version": "vault-profile-v2",
        "note_count": len(records),
        "observed_folders": folders,
        "known_folders": sorted(folder_counter, key=str.casefold),
        "common_frontmatter_keys": [key for key, _ in fm_counter.most_common(20)],
        "common_tags": [key for key, _ in tag_counter.most_common(50)],
        "tag_catalog": [
            {"tag": key, "count": value}
            for key, value in sorted(tag_counter.items(), key=lambda item: (-item[1], item[0].casefold()))
        ],
        "naming_style": suffix_counter.most_common(1)[0][0] if suffix_counter else "plain-title",
        "median_word_count": median,
        "moc_candidates": mocs[:100],
        "fallback_destination": destination_policy["fallback_folder"],
        "tag_policy": tag_policy,
        "policy": {
            "learn_before_classify": True,
            "no_invented_folder_taxonomy": True,
            "reader_surface_machine_metadata": False,
        },
    }


def _validated_publication_handoff(
    state: dict[str, Any], root: Path
) -> tuple[str, list[tuple[str, Path]]]:
    handoff = root / "handoff" / "publication_handoff_manifest.json"
    if not handoff.is_file():
        raise ValueError("P16 publication handoff is missing")
    handoff_sha = validate_bare_sha256_sidecar(handoff)
    handoff_value = strict_load_json(handoff)
    validate_json_schema(handoff_value, "publication-handoff-v1.schema.json")
    active_handoff = (
        ((state.get("outputs") or {}).get("obsidian") or {}).get(
            "active_manifest_sha256"
        )
    )
    if active_handoff and active_handoff != handoff_sha:
        raise ValueError("P16 publication handoff differs from the Runtime binding")

    business = business_root_from(state)
    authorized: list[tuple[str, Path]] = []
    seen_sources: set[str] = set()
    for item in handoff_value["required_artifacts"]:
        relative = str(item["business_relative_path"])
        if relative in seen_sources:
            raise ValueError(f"duplicate publication handoff path: {relative}")
        seen_sources.add(relative)
        source = safe_relative_target(business, relative)
        if not source.is_file() or source.is_symlink():
            raise ValueError(f"authorized publication evidence is missing or unsafe: {relative}")
        if source.stat().st_size != int(item["size"]):
            raise ValueError(f"authorized publication evidence size changed: {relative}")
        if sha256_file(source) != str(item["sha256"]):
            raise ValueError(f"authorized publication evidence hash changed: {relative}")
        authorized.append((relative, source))
    if "publication_final.md" not in seen_sources:
        raise ValueError("P16 handoff did not authorize publication_final.md")
    return handoff_sha, authorized


def index_vault(state: dict[str, Any]) -> dict[str, Any]:
    """P16: deterministic read-only Vault index and evidence handoff."""
    binding, vault = load_binding(state)
    root = obsidian_root_from(state)
    handoff_sha, authorized_sources = _validated_publication_handoff(state, root)
    config = binding.get("config") or {}
    indexing = config.get("indexing") or {}
    excludes = [str(item) for item in indexing.get("exclude_paths", [])]
    max_notes = int(indexing.get("max_notes", 20000))
    max_bytes = int(indexing.get("max_note_bytes", 2_000_000))
    records: list[dict[str, Any]] = []
    for path in sorted(vault.rglob("*.md"), key=lambda p: p.relative_to(vault).as_posix().casefold()):
        rel = path.relative_to(vault)
        if _is_hidden_or_ignored(rel, excludes):
            continue
        if path.is_symlink() or not path.is_file():
            continue
        if path.stat().st_size > max_bytes:
            continue
        records.append(_note_record(vault, path))
        if len(records) > max_notes:
            raise ValueError(f"Vault note limit exceeded: {max_notes}")

    title_map: dict[str, list[str]] = {}
    for row in records:
        for key in [row["title"], Path(row["path"]).stem, *row["aliases"]]:
            title_map.setdefault(str(key).casefold(), []).append(row["path"])
    edges: list[dict[str, str]] = []
    backlinks: dict[str, list[str]] = {}
    for row in records:
        for link in row["outgoing_links"]:
            candidates = title_map.get(link.casefold(), [])
            target = candidates[0] if len(candidates) == 1 else ""
            edges.append({"source_path": row["path"], "wikilink": link, "resolved_target_path": target})
            if target:
                backlinks.setdefault(target, []).append(row["path"])

    index_dir = root / "index"
    index_dir.mkdir(parents=True, exist_ok=True)
    index_path = index_dir / "vault_note_index.json"
    graph_path = index_dir / "vault_link_graph.json"
    profile_path = index_dir / "vault_profile.json"
    write_hashed_json(index_path, {"schema_version": "vault-note-index-v1", "notes": records})
    write_hashed_json(
        graph_path,
        {
            "schema_version": "vault-link-graph-v1",
            "edges": edges,
            "backlinks": {key: sorted(set(value)) for key, value in sorted(backlinks.items())},
        },
    )
    write_hashed_json(profile_path, _vault_profile(records, config))

    evidence_dir = root / "evidence"
    evidence_dir.mkdir(parents=True, exist_ok=True)
    copied: list[dict[str, Any]] = []
    seen_targets: set[str] = set()
    for relative, source in authorized_sources:
        target = safe_relative_target(evidence_dir, relative)
        target_relative = target.relative_to(root).as_posix()
        if target_relative in seen_targets:
            raise ValueError(f"publication evidence target collision: {target_relative}")
        seen_targets.add(target_relative)
        digest = _write_hashed_bytes(target, source.read_bytes())
        copied.append({"path": target_relative, "sha256": digest, "size": target.stat().st_size})
    manifest = {
        "manifest_schema_version": "author-directed-vault-index-manifest-v1",
        "contract_version": CONTRACT_VERSION,
        "vault_binding_id": binding["binding_id"],
        "vault_root_fingerprint": binding["root_fingerprint"],
        "publication_handoff_sha256": handoff_sha,
        "note_count": len(records),
        "index_sha256": sha256_file(index_path),
        "graph_sha256": sha256_file(graph_path),
        "profile_sha256": sha256_file(profile_path),
        "evidence": copied,
        "access_mode": "READ_ONLY_DURING_ANALYSIS",
        "created_at": utc_now(),
    }
    manifest_path = index_dir / "p16_index_manifest.json"
    digest = write_hashed_json(manifest_path, manifest)
    return {"outcome": "INDEXED", "manifest_path": str(manifest_path), "manifest_sha256": digest, "note_count": len(records)}


AUTHOR_QUESTIONS = (
    "这篇文章准备沉淀哪几个分块？",
    "其中哪些思想值得成为独立永久笔记？",
    "你是否想围绕某个问题建立一组笔记？若不需要，请直接说“不需要”。",
)


def write_author_intent_question(state: dict[str, Any]) -> dict[str, Any]:
    """Create the only three author-choice questions allowed after P15."""
    root = obsidian_root_from(state)
    question_path = root / "author-input" / "AUTHOR_INTENT_QUESTIONS.md"
    article = _read_text(root / "evidence" / "publication_final.md")
    title_match = re.search(r"^#\s+(.+?)\s*$", article, re.M)
    title = title_match.group(1).strip() if title_match else "当前文章"
    content = "\n".join(
        [
            "# Obsidian 沉淀取舍",
            "",
            f"文章：**{title}**",
            "",
            "请只回答下面三个知识取舍问题。你不需要指定原文段落、已有笔记、文件夹、双向链接或 MOC；这些由 Agent 自主完成。",
            "",
            *[f"{i}. {question}" for i, question in enumerate(AUTHOR_QUESTIONS, 1)],
            "",
        ]
    )
    digest = _write_hashed_text(question_path, content)
    return {"question_path": str(question_path), "question_sha256": digest, "questions": list(AUTHOR_QUESTIONS)}


def submit_author_response(state: dict[str, Any], response_path: Path) -> dict[str, Any]:
    root = obsidian_root_from(state)
    source = response_path.resolve()
    text = _read_text(source).strip()
    if not text:
        raise ValueError("author response must not be empty")
    if len(text) > 100_000:
        raise ValueError("author response is unexpectedly large")
    target = root / "author-input" / "AUTHOR_RESPONSE.md"
    if target.exists():
        raise ValueError("author response is already bound; recover to P17 to replace it")
    digest = _write_hashed_text(target, text)
    receipt = {
        "schema_version": "author-response-receipt-v1",
        "questions_sha256": sha256_file(root / "author-input" / "AUTHOR_INTENT_QUESTIONS.md"),
        "response_sha256": digest,
        "response_path": "author-input/AUTHOR_RESPONSE.md",
        "received_at": utc_now(),
    }
    receipt_digest = write_hashed_json(root / "author-input" / "author_response_receipt.json", receipt)
    return {"response_sha256": digest, "receipt_sha256": receipt_digest, "target": str(target)}


def validate_author_intent_contract(state: dict[str, Any]) -> dict[str, Any]:
    root = obsidian_root_from(state)
    path = root / "semantic" / "author_intent_contract.json"
    value = strict_load_json(path)
    validate_json_schema(value, "author-intent-contract-v1.schema.json")
    response_path = root / "author-input" / "AUTHOR_RESPONSE.md"
    response = _read_text(response_path)
    response_sha = sha256_file(response_path)
    if value["author_response_sha256"] != response_sha:
        raise ValueError("author intent contract is not bound to the current author response")
    article_sha = sha256_file(root / "evidence" / "publication_final.md")
    if value["publication_final_sha256"] != article_sha:
        raise ValueError("author intent contract is not bound to the released article")
    answers = value["answers"]
    if set(answers) != {"requested_blocks", "permanent_notes", "problem_cluster"}:
        raise ValueError("author intent contract must answer exactly the three authorized questions")
    for key, item in answers.items():
        quote = str(item["author_quote"]).strip()
        if not quote or quote not in response:
            raise ValueError(f"{key} must contain an exact quote from the author response")
    directives = value["directives"]
    ids = [item["directive_id"] for item in directives]
    if len(ids) != len(set(ids)):
        raise ValueError("author directive ids must be unique")
    for item in directives:
        quote = item["author_quote"]
        if quote not in response:
            raise ValueError(f"directive {item['directive_id']} lacks an exact author-response anchor")
        if item["kind"] == "PERMANENT_NOTE" and item["disposition"] != "REQUIRED":
            raise ValueError("author-selected permanent notes are REQUIRED")
    if value["autonomous_scope"] != {
        "find_existing_connections": True,
        "design_bidirectional_links": True,
        "choose_destinations": True,
        "decide_moc_and_routes": True,
        "attack_and_revise": True,
    }:
        raise ValueError("Agent autonomous knowledge-engineering scope was weakened or expanded")
    digest = sha256_file(path)
    return {"outcome": "AUTHOR_INTENT_BOUND", "contract_sha256": digest, "directive_count": len(directives)}


def _score_note(query_tokens: set[str], row: dict[str, Any]) -> float:
    tokens = set(row.get("search_tokens") or [])
    overlap = query_tokens & tokens
    if not overlap:
        return 0.0
    title_tokens = _tokens(str(row.get("title", "")))
    return len(overlap) + 3.0 * len(query_tokens & title_tokens) + (1.0 if row.get("moc_signal") else 0.0)


def select_retrieval_records(state: dict[str, Any]) -> list[dict[str, Any]]:
    """Return the exact Vault rows selected by the deterministic P17 query."""
    root = obsidian_root_from(state)
    contract = strict_load_json(root / "semantic" / "author_intent_contract.json")
    index = strict_load_json(root / "index" / "vault_note_index.json")
    query_text = " ".join(
        [
            contract["answers"]["requested_blocks"]["normalized_intent"],
            contract["answers"]["permanent_notes"]["normalized_intent"],
            contract["answers"]["problem_cluster"]["normalized_intent"],
            *[item["title"] + " " + item["knowledge_responsibility"] for item in contract["directives"]],
        ]
    )
    query_tokens = _tokens(query_text)
    scored = [
        (_score_note(query_tokens, row), row)
        for row in index["notes"]
    ]
    selected = [row for score, row in sorted(scored, key=lambda item: (-item[0], item[1]["path"].casefold())) if score > 0][:24]
    # Always include likely MOCs among the top profile candidates when they have any overlap.
    selected_paths = {row["path"] for row in selected}
    for score, row in sorted(scored, key=lambda item: (-item[0], item[1]["path"].casefold())):
        if row.get("moc_signal") and score > 0 and row["path"] not in selected_paths and len(selected) < 30:
            selected.append(row)
            selected_paths.add(row["path"])
    return selected


def build_retrieval_packet(state: dict[str, Any]) -> dict[str, Any]:
    """Deterministic Vault retrieval after the author has chosen knowledge goals."""
    root = obsidian_root_from(state)
    contract = strict_load_json(root / "semantic" / "author_intent_contract.json")
    graph = strict_load_json(root / "index" / "vault_link_graph.json")
    binding, vault = load_binding(state)
    selected = select_retrieval_records(state)
    query_text = " ".join(
        [
            contract["answers"]["requested_blocks"]["normalized_intent"],
            contract["answers"]["permanent_notes"]["normalized_intent"],
            contract["answers"]["problem_cluster"]["normalized_intent"],
            *[item["title"] + " " + item["knowledge_responsibility"] for item in contract["directives"]],
        ]
    )
    query_tokens = _tokens(query_text)

    packet_dir = root / "retrieval"
    notes_dir = packet_dir / "notes"
    notes_dir.mkdir(parents=True, exist_ok=True)
    packet_notes: list[dict[str, Any]] = []
    for i, row in enumerate(selected, 1):
        source = safe_relative_target(vault, row["path"])
        if sha256_file(source) != row["sha256"]:
            raise ValueError(f"Vault changed after P16 index: {row['path']}")
        local_name = f"N{i:03d}.md"
        local = notes_dir / local_name
        local_digest = _write_hashed_bytes(local, source.read_bytes())
        packet_notes.append(
            {
                "packet_id": f"N{i:03d}",
                "vault_path": row["path"],
                "title": row["title"],
                "vault_sha256": row["sha256"],
                "packet_path": f"retrieval/notes/{local_name}",
                "packet_sha256": local_digest,
                "moc_signal": row["moc_signal"],
                "outgoing_links": row["outgoing_links"],
                "backlinks": graph.get("backlinks", {}).get(row["path"], []),
            }
        )
    packet = {
        "packet_schema_version": "vault-retrieval-packet-v1",
        "author_intent_contract_sha256": sha256_file(root / "semantic" / "author_intent_contract.json"),
        "vault_index_sha256": sha256_file(root / "index" / "vault_note_index.json"),
        "vault_profile_sha256": sha256_file(root / "index" / "vault_profile.json"),
        "query_tokens": sorted(query_tokens),
        "selected_notes": packet_notes,
        "selection_rule": "deterministic lexical overlap; score desc then vault path",
        "created_at": utc_now(),
    }
    digest = write_hashed_json(packet_dir / "vault_retrieval_packet.json", packet)
    overview = [
        "# Vault Retrieval Packet",
        "",
        "These notes were selected deterministically from the author's three knowledge choices. The Agent must decide which connections are real; retrieval is not permission to link.",
        "",
    ]
    for row in packet_notes:
        overview.extend(
            [
                f"## {row['packet_id']} · {row['title']}",
                f"- Vault path: `{row['vault_path']}`",
                f"- Current SHA-256: `{row['vault_sha256']}`",
                f"- MOC signal: `{str(row['moc_signal']).lower()}`",
                f"- Local evidence: `{row['packet_path']}`",
                "",
            ]
        )
    _write_hashed_text(packet_dir / "VAULT_RETRIEVAL_OVERVIEW.md", "\n".join(overview))
    return {"outcome": "RETRIEVAL_READY", "packet_sha256": digest, "selected_notes": len(packet_notes)}


def _validate_operation_common(op: dict[str, Any], directive_ids: set[str], retrieved: dict[str, dict[str, Any]]) -> None:
    target = str(op["target_path"])
    if Path(target).is_absolute() or ".." in Path(target).parts or not target.endswith(".md"):
        raise ValueError(f"unsafe operation target path: {target}")
    role = op["artifact_role"]
    refs = set(op["author_directive_ids"])
    if role == "PERMANENT_NOTE" and (not refs or not refs <= directive_ids):
        raise ValueError(f"permanent note {op['operation_id']} is not authorized by an author directive")
    if role not in {"PERMANENT_NOTE", "ARTICLE", "MOC", "EXISTING_NOTE_BACKLINK"}:
        raise ValueError(f"unknown artifact role: {role}")
    if role in {"MOC", "EXISTING_NOTE_BACKLINK"} and op["operation_kind"] == "CREATE" and role == "EXISTING_NOTE_BACKLINK":
        raise ValueError("backlink operations must update an existing note")
    expected = op.get("expected_target_sha256")
    if op["operation_kind"] == "UPDATE":
        if target not in retrieved:
            raise ValueError(f"UPDATE target was not retrieved for inspection: {target}")
        if expected != retrieved[target]["vault_sha256"]:
            raise ValueError(f"UPDATE precondition does not match retrieved Vault note: {target}")
    elif expected is not None:
        raise ValueError("CREATE operations must not carry an expected target hash")
    content = str(op["rendered_markdown"])
    if not content.strip():
        raise ValueError(f"empty rendered content: {op['operation_id']}")
    for marker in FORBIDDEN_READER_SURFACE:
        if marker.casefold() in content.casefold():
            raise ValueError(f"reader-surface machine metadata or coded relation detected: {marker}")
    if "<!--" in content:
        raise ValueError("HTML management comments are forbidden in reader-surface notes")


def validate_architecture_bundle(state: dict[str, Any]) -> dict[str, Any]:
    root = obsidian_root_from(state)
    architect_path = root / "semantic" / "knowledge_architecture_plan.json"
    attack_path = root / "semantic" / "knowledge_architecture_attack.json"
    revised_path = root / "semantic" / "knowledge_architecture_revised.json"
    architect = strict_load_json(architect_path)
    attack = strict_load_json(attack_path)
    revised = strict_load_json(revised_path)
    validate_json_schema(architect, "knowledge-architecture-plan-v1.schema.json")
    validate_json_schema(attack, "knowledge-architecture-attack-v1.schema.json")
    validate_json_schema(revised, "knowledge-architecture-revised-v1.schema.json")

    intent_path = root / "semantic" / "author_intent_contract.json"
    retrieval_path = root / "retrieval" / "vault_retrieval_packet.json"
    if architect["author_intent_contract_sha256"] != sha256_file(intent_path):
        raise ValueError("architecture plan is not bound to the author intent")
    if architect["vault_retrieval_packet_sha256"] != sha256_file(retrieval_path):
        raise ValueError("architecture plan is not bound to the retrieval packet")
    if attack["attacked_plan_sha256"] != sha256_file(architect_path):
        raise ValueError("attacker did not inspect the current architecture plan")
    if revised["base_plan_sha256"] != sha256_file(architect_path):
        raise ValueError("revised plan is not bound to the architect plan")
    if revised["attack_report_sha256"] != sha256_file(attack_path):
        raise ValueError("revised plan is not bound to the attack report")
    if attack["verdict"] not in {"PASS", "REVISE"}:
        raise ValueError("invalid attack verdict")
    open_issues = [item for item in attack["issues"] if item["severity"] in {"BLOCKING", "MAJOR"}]
    closures = {item["issue_id"]: item for item in revised["issue_resolutions"]}
    for issue in open_issues:
        resolution = closures.get(issue["issue_id"])
        if not resolution or resolution["status"] != "CLOSED":
            raise ValueError(f"blocking architecture issue not closed: {issue['issue_id']}")

    intent = strict_load_json(intent_path)
    required_directives = {
        item["directive_id"]
        for item in intent["directives"]
        if item["kind"] == "PERMANENT_NOTE" and item["disposition"] == "REQUIRED"
    }
    retrieval = strict_load_json(retrieval_path)
    index_path = root / "index" / "vault_note_index.json"
    profile_path = root / "index" / "vault_profile.json"
    profile = strict_load_json(profile_path)
    if retrieval.get("vault_index_sha256") != sha256_file(index_path):
        raise ValueError("retrieval packet is not bound to the current Vault index")
    if retrieval.get("vault_profile_sha256") != sha256_file(profile_path):
        raise ValueError("retrieval packet is not bound to the current Vault profile")
    retrieved = {item["vault_path"]: item for item in retrieval["selected_notes"]}
    binding, vault = load_binding(state)
    covered: Counter[str] = Counter()
    operation_ids: set[str] = set()
    responsibilities: dict[str, str] = {}
    for op in revised["operations"]:
        if op["operation_id"] in operation_ids:
            raise ValueError("duplicate operation id")
        operation_ids.add(op["operation_id"])
        _validate_operation_common(op, required_directives, retrieved)
        _validate_operation_metadata(
            op,
            root=root,
            profile=profile,
            retrieved=retrieved,
            configured_tag_policy=(binding.get("config") or {}).get("tag_policy"),
        )
        if op["artifact_role"] == "PERMANENT_NOTE":
            _validate_permanent_note_responsibility(op, responsibilities)
            for directive in op["author_directive_ids"]:
                covered[directive] += 1
    missing = sorted(required_directives - set(covered))
    duplicate = sorted(key for key, count in covered.items() if count > 1)
    if missing or duplicate:
        raise ValueError(f"author-selected permanent notes must map exactly once; missing={missing}, duplicate={duplicate}")

    moc = revised["moc_decision"]
    if moc["decision"] not in {"CREATE", "UPDATE", "REUSE", "NONE"}:
        raise ValueError("MOC decision is mandatory")
    if not moc["reasoning"].strip() or not moc["route_value"].strip():
        raise ValueError("MOC decision requires a professional rationale and route value")
    inspected_moc_evidence = {
        value
        for item in retrieval["selected_notes"]
        for value in (item["packet_id"], item["packet_path"], item["vault_path"])
    }
    empty_vault_none = moc["decision"] == "NONE" and int(profile.get("note_count", -1)) == 0
    allowed_moc_evidence = (
        {"index/vault_profile.json"} if empty_vault_none else inspected_moc_evidence
    )
    if not moc["evidence"] or any(item not in allowed_moc_evidence for item in moc["evidence"]):
        raise ValueError("MOC decision must cite inspected Vault evidence")
    moc_operations = [item for item in revised["operations"] if item["artifact_role"] == "MOC"]
    moc_target = moc["target_path"]
    moc_target_sha = moc["target_sha256"]
    if moc["decision"] == "NONE":
        if moc_target is not None or moc_target_sha is not None or moc_operations:
            raise ValueError("MOC NONE must not name or create an MOC")
    elif moc["decision"] == "CREATE":
        if not moc_target or moc_target_sha is not None:
            raise ValueError("MOC CREATE requires a new target path and no prior hash")
        if len(moc_operations) != 1 or moc_operations[0]["operation_kind"] != "CREATE" or moc_operations[0]["target_path"] != moc_target:
            raise ValueError("MOC CREATE must close with exactly one matching CREATE operation")
        if safe_relative_target(vault, moc_target).exists():
            raise ValueError("MOC CREATE target already exists in the Vault")
    else:
        if not moc_target or not moc_target_sha:
            raise ValueError(f"MOC {moc['decision']} requires a target path and inspected hash")
        retrieved_moc = retrieved.get(moc_target)
        if not retrieved_moc or retrieved_moc["vault_sha256"] != moc_target_sha:
            raise ValueError("MOC target was not retrieved with the declared hash")
        target = safe_relative_target(vault, moc_target)
        if not target.is_file() or target.is_symlink() or sha256_file(target) != moc_target_sha:
            raise ValueError("MOC target changed after retrieval")
        if moc["decision"] == "REUSE":
            if moc_operations:
                raise ValueError("MOC REUSE must not carry an MOC write operation")
        elif len(moc_operations) != 1 or moc_operations[0]["operation_kind"] != "UPDATE" or moc_operations[0]["target_path"] != moc_target:
            raise ValueError("MOC UPDATE must close with exactly one matching UPDATE operation")

    # Every link connection must have a real reciprocal plan or inspected existing backlink evidence.
    op_by_id = {op["operation_id"]: op for op in revised["operations"]}
    operation_targets = {op["target_path"] for op in revised["operations"]}
    connection_ids: set[str] = set()
    for op in revised["operations"]:
        for connection in op["connections"]:
            cid = connection["connection_id"]
            if cid in connection_ids:
                raise ValueError(f"duplicate connection id: {cid}")
            connection_ids.add(cid)
            if not connection["why_this_connection"].strip():
                raise ValueError(f"connection {cid} lacks a knowledge judgment")
            reciprocal = connection.get("reciprocal_operation_id")
            evidence = connection.get("existing_reciprocal_evidence")
            if bool(reciprocal) == bool(evidence):
                raise ValueError(f"connection {cid} must use exactly one reciprocal closure method")
            if reciprocal:
                reciprocal_op = op_by_id.get(reciprocal)
                if not reciprocal_op:
                    raise ValueError(f"connection {cid} references missing reciprocal operation")
                if reciprocal_op["operation_id"] == op["operation_id"] or reciprocal_op["target_path"] != connection["target_path"]:
                    raise ValueError(f"connection {cid} reciprocal operation does not edit its declared target")
            else:
                if not isinstance(evidence, dict):
                    raise ValueError(f"connection {cid} has malformed reciprocal evidence")
                if evidence["target_path"] != connection["target_path"]:
                    raise ValueError(f"connection {cid} evidence targets a different note")
                if evidence["exact_sentence"] != connection["backlink_sentence"]:
                    raise ValueError(f"connection {cid} evidence must quote the declared backlink sentence exactly")
                if evidence["target_path"] in operation_targets:
                    raise ValueError(f"connection {cid} must use a reciprocal operation for a staged target")
                retrieved_target = retrieved.get(evidence["target_path"])
                if not retrieved_target or retrieved_target["vault_sha256"] != evidence["target_sha256"]:
                    raise ValueError(f"connection {cid} evidence is not bound to an inspected Vault note")
                target = safe_relative_target(vault, evidence["target_path"])
                if not target.is_file() or target.is_symlink() or sha256_file(target) != evidence["target_sha256"]:
                    raise ValueError(f"connection {cid} reciprocal Vault note changed after retrieval")
                if evidence["exact_sentence"] not in _read_text(target):
                    raise ValueError(f"connection {cid} reciprocal sentence is absent from the Vault note")
            for sentence_key in ("outbound_sentence", "backlink_sentence"):
                sentence = connection[sentence_key].strip()
                if "[[" not in sentence or "]]" not in sentence:
                    raise ValueError(f"connection {cid} {sentence_key} must be a natural sentence containing a WikiLink")
                if re.fullmatch(r"[-* ]*\[\[[^\]]+\]\][.;。]?", sentence):
                    raise ValueError(f"connection {cid} is a naked link, not an explained judgment")
            source_names = {
                op["title"].casefold(),
                Path(op["target_path"]).stem.casefold(),
                *[str(alias).casefold() for alias in op.get("aliases") or []],
            }
            backlink_names = {name.casefold() for name in _wikilinks(connection["backlink_sentence"])}
            if not source_names & backlink_names:
                raise ValueError(f"connection {cid} backlink sentence does not link back to its source note")

    digest = sha256_file(revised_path)
    return {
        "outcome": "KNOWLEDGE_ARCHITECTURE_ACCEPTED",
        "revised_plan_sha256": digest,
        "operation_count": len(revised["operations"]),
        "connection_count": len(connection_ids),
        "required_directive_count": len(required_directives),
    }


def _yaml_scalar(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def _render_new_note(op: dict[str, Any]) -> str:
    content = str(op["rendered_markdown"]).strip()
    if content.startswith("---\n"):
        return content + ("\n" if not content.endswith("\n") else "")
    lines = ["---"]
    aliases = op.get("aliases") or []
    tags = op.get("tags") or []
    if aliases:
        lines.append("aliases:")
        lines.extend(f"  - {_yaml_scalar(str(item))}" for item in aliases)
    if tags:
        lines.append("tags:")
        lines.extend(f"  - {_yaml_scalar(str(item))}" for item in tags)
    source = op.get("source_note")
    if source:
        lines.append(f"source: {_yaml_scalar(str(source))}")
    lines.extend(["---", "", content, ""])
    return "\n".join(lines)


def _wikilinks(text: str) -> set[str]:
    return {m.group(1).strip() for m in WIKILINK_RE.finditer(text)}


def _staging_manifest(root: Path) -> tuple[Path, dict[str, Any]]:
    path = root / "staging" / "staging_manifest.json"
    manifest = strict_load_json(path)
    validate_json_schema(manifest, "obsidian-staging-manifest-v1.schema.json")
    return path, manifest


def _p21_import_commit(root: Path) -> tuple[Path, dict[str, Any]]:
    path = root / "validation" / P21_IMPORT_COMMIT_FILENAME
    value = strict_load_json(path)
    validate_json_schema(value, "obsidian-import-commit-v1.schema.json")
    return path, value


def assemble_staging(state: dict[str, Any]) -> dict[str, Any]:
    root = obsidian_root_from(state)
    # P19 is deterministic, but it must not render an architecture bundle that
    # has not passed the same author-bound metadata and graph gates as P18.
    validate_architecture_bundle(state)
    plan_path = root / "semantic" / "knowledge_architecture_revised.json"
    plan = strict_load_json(plan_path)
    binding, vault = load_binding(state)
    generation_id = f"GEN-{uuid.uuid4().hex[:16].upper()}"
    staging = root / "staging"
    if staging.exists():
        shutil.rmtree(staging)
    files_root = staging / "files"
    proposals_root = staging / "review-proposals"
    files_root.mkdir(parents=True, exist_ok=True)
    proposals_root.mkdir(parents=True, exist_ok=True)

    manifest_ops: list[dict[str, Any]] = []
    for op in plan["operations"]:
        target = safe_relative_target(vault, op["target_path"])
        rendered = _render_new_note(op)
        if op["operation_kind"] == "CREATE":
            if target.exists():
                raise ValueError(f"CREATE target already exists: {op['target_path']}")
            stage_path = safe_relative_target(files_root, op["target_path"])
            atomic_write_text(stage_path, rendered)
            manifest_ops.append(
                {
                    "operation_id": op["operation_id"],
                    "operation_kind": "CREATE",
                    "artifact_role": op["artifact_role"],
                    "target_path": op["target_path"],
                    "expected_target_sha256": None,
                    "staged_relative_path": stage_path.relative_to(root).as_posix(),
                    "after_sha256": sha256_file(stage_path),
                    "author_directive_ids": op["author_directive_ids"],
                    "connection_ids": [item["connection_id"] for item in op["connections"]],
                    "human_approval_required": True,
                }
            )
        else:
            if not target.is_file() or target.is_symlink():
                raise ValueError(f"UPDATE target is unavailable: {op['target_path']}")
            before_sha = sha256_file(target)
            if before_sha != op["expected_target_sha256"]:
                raise ValueError(f"UPDATE target changed after retrieval: {op['target_path']}")
            proposal = proposals_root / op["operation_id"]
            proposal.mkdir(parents=True, exist_ok=False)
            before_path = proposal / "before.md"
            after_path = proposal / "after.md"
            diff_path = proposal / "change.diff"
            atomic_write_bytes(before_path, target.read_bytes())
            atomic_write_text(after_path, rendered)
            diff = "".join(
                difflib.unified_diff(
                    _read_text(before_path).splitlines(keepends=True),
                    _read_text(after_path).splitlines(keepends=True),
                    fromfile=f"a/{op['target_path']}",
                    tofile=f"b/{op['target_path']}",
                )
            )
            atomic_write_text(diff_path, diff)
            manifest_ops.append(
                {
                    "operation_id": op["operation_id"],
                    "operation_kind": "UPDATE",
                    "artifact_role": op["artifact_role"],
                    "target_path": op["target_path"],
                    "expected_target_sha256": before_sha,
                    "staged_relative_path": after_path.relative_to(root).as_posix(),
                    "before_relative_path": before_path.relative_to(root).as_posix(),
                    "diff_relative_path": diff_path.relative_to(root).as_posix(),
                    "after_sha256": sha256_file(after_path),
                    "author_directive_ids": op["author_directive_ids"],
                    "connection_ids": [item["connection_id"] for item in op["connections"]],
                    "human_approval_required": True,
                }
            )

    manifest = {
        "manifest_schema_version": "author-directed-staging-manifest-v1",
        "generation_id": generation_id,
        "contract_version": CONTRACT_VERSION,
        "execution_mode": "REVIEWED_APPLY",
        "revised_plan_sha256": sha256_file(plan_path),
        "vault_binding_id": binding["binding_id"],
        "vault_root_fingerprint": binding["root_fingerprint"],
        "operations": manifest_ops,
        "moc_decision": plan["moc_decision"],
        "commit_capability": False,
        "created_at": utc_now(),
    }
    validate_json_schema(manifest, "obsidian-staging-manifest-v1.schema.json")
    manifest_path = staging / "staging_manifest.json"
    digest = write_hashed_json(manifest_path, manifest)

    review_lines = [
        "# Obsidian Staging Review",
        "",
        "Review the actual reader-facing pages below. Runtime hashes and ownership evidence remain outside the Vault.",
        "",
        f"- Generation: `{generation_id}`",
        f"- Manifest SHA-256: `{digest}`",
        f"- MOC decision: **{plan['moc_decision']['decision']}** — {plan['moc_decision']['reasoning']}",
        "",
        "## Operations",
        "",
    ]
    for op in manifest_ops:
        review_lines.extend(
            [
                f"### {op['operation_id']} · {op['operation_kind']} · {op['artifact_role']}",
                f"- Target: `{op['target_path']}`",
                f"- Preview: `{op['staged_relative_path']}`",
                f"- Connections: {', '.join(op['connection_ids']) or 'none'}",
                "",
            ]
        )
    _write_hashed_text(staging / "STAGING_REVIEW.md", "\n".join(review_lines))
    return {"outcome": "STAGED", "manifest_sha256": digest, "generation_id": generation_id, "operation_count": len(manifest_ops)}


def validate_content_review(state: dict[str, Any]) -> dict[str, Any]:
    root = obsidian_root_from(state)
    review_path = root / "validation" / "obsidian_content_review.json"
    review = strict_load_json(review_path)
    validate_json_schema(review, "obsidian-content-review-v1.schema.json")
    manifest_path = root / "staging" / "staging_manifest.json"
    manifest = strict_load_json(manifest_path)
    if review["staging_manifest_sha256"] != sha256_file(manifest_path):
        raise ValueError("content review is not bound to the current staging manifest")
    operation_ids = {item["operation_id"] for item in manifest["operations"]}
    reviewed_ids = {item["operation_id"] for item in review["page_reviews"]}
    if operation_ids != reviewed_ids:
        raise ValueError("P20 must review every actual staged page and proposal")
    if review["decision"] == "ACCEPT":
        open_issues = [item for item in review["issues"] if item["status"] == "OPEN"]
        if open_issues:
            raise ValueError("ACCEPT review cannot contain open issues")
        for item in review["page_reviews"]:
            for dimension in (
                "verdict",
                "independent_value",
                "natural_voice",
                "source_fidelity",
                "connection_quality",
            ):
                if item[dimension] != "PASS":
                    raise ValueError(f"ACCEPT requires every page dimension to pass: {item['operation_id']} {dimension}")
        for key, value in review["graph_review"].items():
            if key.endswith("_pass") and value is not True:
                raise ValueError(f"ACCEPT requires graph review pass: {key}")
        for key, value in review["author_intent_review"].items():
            if key != "assessment" and value is not True:
                raise ValueError(f"ACCEPT requires author-intent review pass: {key}")
    digest = sha256_file(review_path)
    return {"outcome": review["decision"], "review_sha256": digest, "page_count": len(reviewed_ids)}


def _resolve_target_name_map(vault: Path, manifest: dict[str, Any]) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for path in vault.rglob("*.md"):
        if path.is_symlink():
            continue
        rel = path.relative_to(vault).as_posix()
        mapping.setdefault(path.stem.casefold(), rel)
        text = _read_text(path)
        fm, _, body = _split_frontmatter(text)
        title = _title_for(path, body, fm)
        mapping.setdefault(title.casefold(), rel)
        for alias in _as_list(fm.get("aliases") or fm.get("alias")):
            mapping.setdefault(alias.casefold(), rel)
    for op in manifest["operations"]:
        mapping.setdefault(Path(op["target_path"]).stem.casefold(), op["target_path"])
    return mapping


def validate_staging(state: dict[str, Any]) -> dict[str, Any]:
    """P21: deterministic contract, graph, snapshot, and reader-surface validation."""
    root = obsidian_root_from(state)
    binding, vault = load_binding(state)
    manifest_path, manifest = _staging_manifest(root)
    review_path = root / "validation" / "obsidian_content_review.json"
    review_result = validate_content_review(state)
    if review_result["outcome"] != "ACCEPT":
        raise ValueError("P21 requires an accepted P20 content review")

    plan_path = root / "semantic" / "knowledge_architecture_revised.json"
    plan = strict_load_json(plan_path)
    validate_json_schema(plan, "knowledge-architecture-revised-v1.schema.json")
    validate_architecture_bundle(state)
    if manifest["revised_plan_sha256"] != sha256_file(plan_path):
        raise ValueError("staging manifest is not bound to the current revised plan")
    intent = strict_load_json(root / "semantic" / "author_intent_contract.json")
    plan_ops = {item["operation_id"]: item for item in plan["operations"]}
    manifest_ops = {item["operation_id"]: item for item in manifest["operations"]}
    required = {
        item["directive_id"]
        for item in intent["directives"]
        if item["kind"] == "PERMANENT_NOTE" and item["disposition"] == "REQUIRED"
    }
    coverage: Counter[str] = Counter()
    contents: dict[str, str] = {}
    errors: list[str] = []
    if len(plan_ops) != len(plan["operations"]):
        errors.append("revised plan contains duplicate operation ids")
    if len(manifest_ops) != len(manifest["operations"]):
        errors.append("staging manifest contains duplicate operation ids")
    if set(plan_ops) != set(manifest_ops):
        errors.append("staging operation set does not exactly match the revised plan")
    for item in manifest["operations"]:
        op_id = item["operation_id"]
        if op_id not in plan_ops:
            errors.append(f"manifest operation absent from plan: {op_id}")
            continue
        plan_op = plan_ops[op_id]
        for field in ("operation_kind", "artifact_role", "target_path", "expected_target_sha256", "author_directive_ids"):
            if item.get(field) != plan_op.get(field):
                errors.append(f"manifest operation differs from revised plan: {op_id} {field}")
        if item.get("connection_ids") != [entry["connection_id"] for entry in plan_op["connections"]]:
            errors.append(f"manifest connection ids differ from revised plan: {op_id}")
        staged = safe_relative_target(root, item["staged_relative_path"])
        if sha256_file(staged) != item["after_sha256"]:
            errors.append(f"staged content hash mismatch: {op_id}")
            continue
        content = _read_text(staged)
        expected_rendered = _render_new_note(plan_op)
        if sha256_bytes(expected_rendered.encode("utf-8")) != item["after_sha256"]:
            errors.append(f"staged content does not match deterministic rendering: {op_id}")
        contents[item["target_path"]] = content
        for marker in FORBIDDEN_READER_SURFACE:
            if marker.casefold() in content.casefold():
                errors.append(f"reader-surface forbidden marker in {op_id}: {marker}")
        if "<!--" in content:
            errors.append(f"HTML management comment in {op_id}")
        if plan_ops[op_id]["artifact_role"] == "PERMANENT_NOTE":
            if len(re.sub(r"---.*?---", "", content, count=1, flags=re.S).strip()) < 220:
                errors.append(f"permanent note is too thin to carry independent responsibility: {op_id}")
            for directive in item["author_directive_ids"]:
                coverage[directive] += 1
        target = safe_relative_target(vault, item["target_path"])
        if item["operation_kind"] == "CREATE":
            if target.exists() and sha256_file(target) != item["after_sha256"]:
                errors.append(f"CREATE collision: {item['target_path']}")
        else:
            if not target.is_file() or target.is_symlink():
                errors.append(f"UPDATE target missing: {item['target_path']}")
            elif sha256_file(target) != item["expected_target_sha256"] and sha256_file(target) != item["after_sha256"]:
                errors.append(f"UPDATE precondition changed: {item['target_path']}")

    if set(coverage) != required or any(count != 1 for count in coverage.values()):
        errors.append(f"author permanent-note coverage mismatch: required={sorted(required)}, coverage={dict(coverage)}")

    article_ops = [item for item in plan["operations"] if item["artifact_role"] == "ARTICLE"]
    if len(article_ops) != 1:
        errors.append(f"exactly one released article operation is required, found {len(article_ops)}")
    else:
        released_article = _read_text(root / "evidence" / "publication_final.md").strip()
        staged_article = contents.get(article_ops[0]["target_path"], "")
        if released_article not in staged_article:
            errors.append("staged ARTICLE does not preserve publication_final.md verbatim")

    # Verify every planned connection is represented on both reader surfaces.
    for op in plan["operations"]:
        source_content = contents.get(op["target_path"], "")
        for connection in op["connections"]:
            if connection["outbound_sentence"] not in source_content:
                errors.append(f"outbound connection sentence missing: {connection['connection_id']}")
            reciprocal_id = connection.get("reciprocal_operation_id")
            if reciprocal_id:
                reciprocal_op = plan_ops.get(reciprocal_id)
                reciprocal_content = contents.get(reciprocal_op["target_path"], "") if reciprocal_op else ""
                if not reciprocal_op or connection["backlink_sentence"] not in reciprocal_content:
                    errors.append(f"backlink sentence missing: {connection['connection_id']}")
            else:
                evidence = connection.get("existing_reciprocal_evidence")
                if not isinstance(evidence, dict):
                    errors.append(f"connection lacks reciprocal closure: {connection['connection_id']}")
                    continue
                if evidence["target_path"] != connection["target_path"]:
                    errors.append(f"reciprocal evidence targets the wrong note: {connection['connection_id']}")
                if evidence["exact_sentence"] != connection["backlink_sentence"]:
                    errors.append(f"reciprocal evidence sentence differs from plan: {connection['connection_id']}")
                if evidence["target_path"] in contents:
                    errors.append(f"reciprocal evidence points at a staged note: {connection['connection_id']}")
                    continue
                target = safe_relative_target(vault, evidence["target_path"])
                if not target.is_file() or target.is_symlink():
                    errors.append(f"reciprocal evidence target missing: {connection['connection_id']}")
                elif sha256_file(target) != evidence["target_sha256"]:
                    errors.append(f"reciprocal evidence target changed: {connection['connection_id']}")
                elif evidence["exact_sentence"] not in _read_text(target):
                    errors.append(f"reciprocal evidence sentence missing: {connection['connection_id']}")

    # Verify links resolve to current or staged titles/filenames; unresolved links already present
    # in preserved UPDATE pages are not rejected, only newly planned connection links.
    name_map = _resolve_target_name_map(vault, manifest)
    for op in plan["operations"]:
        for connection in op["connections"]:
            for sentence in (connection["outbound_sentence"], connection["backlink_sentence"]):
                for link in _wikilinks(sentence):
                    if link.casefold() not in name_map:
                        errors.append(f"planned WikiLink does not resolve: [[{link}]]")

    # Folder policy uses the complete P16 catalog, not only the compact summary
    # shown to the model. This prevents a real but infrequent Vault folder from
    # being rejected merely because it was outside the top thirty.
    profile = strict_load_json(root / "index" / "vault_profile.json")
    known = set(profile.get("known_folders") or [])
    if not known:  # Compatibility with pre-optimization P16 profile records.
        known = {item["path"] for item in profile.get("observed_folders", [])}
    fallback = normalize_destination_policy(
        (binding.get("config") or {}).get("destination_policy")
    )["fallback_folder"]
    for item in manifest["operations"]:
        parent = Path(item["target_path"]).parent.as_posix()
        parent = "" if parent == "." else parent
        if item["operation_kind"] == "CREATE" and parent not in known and parent != fallback:
            errors.append(f"destination invents an unlearned folder taxonomy: {item['target_path']}")

    # A MOC decision is only complete when its declared route has the matching
    # staged operation, or when the reused route is still the inspected note.
    moc = plan["moc_decision"]
    moc_ops = [item for item in plan["operations"] if item["artifact_role"] == "MOC"]
    decision = moc["decision"]
    if decision == "NONE":
        if moc_ops or moc["target_path"] is not None or moc["target_sha256"] is not None:
            errors.append("MOC NONE does not close with an empty route decision")
    elif decision in {"CREATE", "UPDATE"}:
        expected_kind = decision
        if len(moc_ops) != 1 or moc_ops[0]["operation_kind"] != expected_kind or moc_ops[0]["target_path"] != moc["target_path"]:
            errors.append(f"MOC {decision} does not have a matching staged operation")
        elif moc_ops[0]["operation_id"] not in manifest_ops:
            errors.append(f"MOC {decision} operation is absent from staging")
    else:  # REUSE
        target = safe_relative_target(vault, str(moc["target_path"]))
        if moc_ops:
            errors.append("MOC REUSE must not stage an MOC write")
        elif not target.is_file() or target.is_symlink() or sha256_file(target) != moc["target_sha256"]:
            errors.append("reused MOC changed after architecture review")

    report = {
        "report_schema_version": "author-directed-obsidian-validation-v1",
        "verdict": "READY_FOR_IMPORT" if not errors else "BLOCKED",
        "staging_manifest_sha256": sha256_file(manifest_path),
        "content_review_sha256": sha256_file(review_path),
        "author_intent_contract_sha256": sha256_file(root / "semantic" / "author_intent_contract.json"),
        "revised_plan_sha256": sha256_file(root / "semantic" / "knowledge_architecture_revised.json"),
        "operation_count": len(manifest["operations"]),
        "errors": errors,
        "checks": {
            "author_choice_boundary": not any("coverage" in item for item in errors),
            "reader_surface_clean": not any("reader-surface" in item or "HTML" in item for item in errors),
            "bidirectional_graph_closed": not any("connection" in item or "backlink" in item for item in errors),
            "snapshot_preconditions_current": not any("precondition" in item or "collision" in item for item in errors),
            "destination_learned_from_vault": not any("folder taxonomy" in item for item in errors),
            "moc_route_closed": not any(item.startswith("MOC") or "MOC " in item or "MOC changed" in item for item in errors),
        },
        "created_at": utc_now(),
    }
    validation_dir = root / "validation"
    validation_dir.mkdir(parents=True, exist_ok=True)
    report_path = validation_dir / "obsidian_validation_report.json"
    report_sha = write_hashed_json(report_path, report)
    if errors:
        raise ValueError("P21 staging validation failed: " + "; ".join(errors[:8]))

    import_manifest = {
        "manifest_schema_version": "reviewed-obsidian-import-manifest-v1",
        "generation_id": manifest["generation_id"],
        "vault_binding_id": binding["binding_id"],
        "vault_root_fingerprint": binding["root_fingerprint"],
        "staging_manifest_sha256": sha256_file(manifest_path),
        "content_review_sha256": sha256_file(review_path),
        "validation_report_sha256": report_sha,
        "revised_plan_sha256": sha256_file(plan_path),
        "operations": manifest["operations"],
        "approval_contract": "Human approval binds the exact SHA-256 of this manifest after reviewing actual staged pages.",
        "created_at": utc_now(),
    }
    import_path = validation_dir / "import_manifest.json"
    import_sha = write_hashed_json(import_path, import_manifest)
    p21_commit = {
        "commit_schema_version": "obsidian-import-commit-v1",
        "import_manifest_sha256": import_sha,
        "staging_manifest_sha256": sha256_file(manifest_path),
        "content_review_sha256": sha256_file(review_path),
        "validation_report_sha256": report_sha,
        "revised_plan_sha256": sha256_file(plan_path),
        "vault_binding_id": binding["binding_id"],
        "vault_root_fingerprint": binding["root_fingerprint"],
        "operations": manifest["operations"],
        "created_at": utc_now(),
    }
    validate_json_schema(p21_commit, "obsidian-import-commit-v1.schema.json")
    p21_commit_path = validation_dir / P21_IMPORT_COMMIT_FILENAME
    p21_commit_sha = write_hashed_json(p21_commit_path, p21_commit)
    return {
        "outcome": "READY_FOR_IMPORT",
        "validation_sha256": report_sha,
        "import_manifest_sha256": import_sha,
        "p21_import_commit_sha256": p21_commit_sha,
        "operation_count": len(manifest["operations"]),
    }


def _bound_p21_import_commit_sha(state: dict[str, Any]) -> str:
    record = (state.get("phase_records") or {}).get("P21")
    if not isinstance(record, dict) or record.get("status") != "COMMITTED":
        raise ValueError("P21 must be committed before Obsidian application")
    digest = record.get("output_manifest_sha256")
    if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise ValueError("P21 has no immutable import commit marker")
    return digest


def _target_sha256_or_none(target: Path) -> str | None:
    """Return a target digest, rejecting non-file and symlink targets."""
    if target.is_symlink():
        raise ValueError(f"Vault target is a symlink: {target}")
    if not target.exists():
        return None
    if not target.is_file():
        raise ValueError(f"Vault target is not a regular file: {target}")
    return sha256_file(target)


def _assert_target_preimage(op: dict[str, Any], target: Path) -> str | None:
    """Check the precise preimage immediately before a Vault write."""
    current = _target_sha256_or_none(target)
    if op["operation_kind"] == "CREATE":
        if current is not None or target.exists():
            raise ValueError(f"CREATE target appeared after validation: {op['target_path']}")
        return None
    if current != op["expected_target_sha256"]:
        raise ValueError(f"UPDATE target changed after validation: {op['target_path']}")
    return current


def _write_import_transaction(path: Path, transaction: dict[str, Any]) -> str:
    transaction["updated_at"] = utc_now()
    validate_json_schema(transaction, "obsidian-import-transaction-v1.schema.json")
    return write_hashed_json(path, transaction)


def _rollback_import_transaction(
    transaction_path: Path,
    transaction: dict[str, Any],
    vault: Path,
    *,
    recovery_reason: str,
) -> None:
    """Restore a pre-commit Vault image using only durable transaction data."""
    import_dir = transaction_path.parent
    restored: list[str] = []
    for op in reversed(transaction["operations"]):
        target = safe_relative_target(vault, op["target_path"])
        current = _target_sha256_or_none(target)
        before_sha = op["before_sha256"]
        if current == before_sha:
            continue
        if current != op["after_sha256"]:
            raise ValueError(
                "cannot recover interrupted import because a Vault target changed externally: "
                f"{op['target_path']}"
            )
        if before_sha is None:
            target.unlink()
        else:
            backup = safe_relative_target(import_dir, op["backup_relative_path"])
            if sha256_file(backup) != before_sha:
                raise ValueError(f"interrupted-import backup changed: {op['target_path']}")
            atomic_write_bytes(target, backup.read_bytes())
            if sha256_file(target) != before_sha:
                raise RuntimeError(f"rollback verification failed: {op['target_path']}")
        restored.append(op["operation_id"])
    transaction["status"] = "ROLLED_BACK"
    transaction["recovery_reason"] = recovery_reason
    transaction["recovered_operation_ids"] = restored
    transaction["recovered_at"] = utc_now()
    _write_import_transaction(transaction_path, transaction)


def _recover_interrupted_imports(
    root: Path,
    binding: dict[str, Any],
    vault: Path,
) -> list[str]:
    """Recover unfinished reviewed imports before any new Vault mutation.

    A process can die between individual atomic file replacements.  The durable
    transaction record makes the next explicit apply action restore the exact
    preimage before it considers a new import.
    """
    imports_root = root / "imports"
    if not imports_root.exists():
        return []
    if imports_root.is_symlink() or not imports_root.is_dir():
        raise ValueError("Obsidian import root is unavailable or unsafe")
    recovered: list[str] = []
    for import_dir in sorted(imports_root.iterdir(), key=lambda item: item.name):
        if import_dir.is_symlink() or not import_dir.is_dir():
            raise ValueError(f"unsafe import record directory: {import_dir}")
        transaction_path = import_dir / IMPORT_TRANSACTION_FILENAME
        if not transaction_path.exists():
            continue
        validate_bare_sha256_sidecar(transaction_path)
        transaction = strict_load_json(transaction_path)
        validate_json_schema(transaction, "obsidian-import-transaction-v1.schema.json")
        if (
            transaction["vault_binding_id"] != binding["binding_id"]
            or transaction["vault_root_fingerprint"] != binding["root_fingerprint"]
        ):
            raise ValueError(
                "unfinished import belongs to another Vault binding: "
                f"{transaction['import_id']}"
            )
        if transaction["status"] in {"PREPARED", "APPLYING"}:
            _rollback_import_transaction(
                transaction_path,
                transaction,
                vault,
                recovery_reason="RECOVERED_BEFORE_NEW_APPLY",
            )
            recovered.append(transaction["import_id"])
    return recovered


def apply_import(state: dict[str, Any], approval_manifest_sha256: str) -> dict[str, Any]:
    """Apply only the immutable P21-validated manifest after human approval."""
    root = obsidian_root_from(state)
    binding, vault = load_binding(state)
    config = binding.get("config") or {}
    review_cfg = config.get("human_review") or {}
    if review_cfg.get("vault_commit") is not True:
        raise ValueError("Vault commit is disabled by configuration")
    recovered_import_ids = _recover_interrupted_imports(root, binding, vault)
    import_path = root / "validation" / "import_manifest.json"
    manifest = strict_load_json(import_path)
    actual_manifest_sha = sha256_file(import_path)
    expected_commit_sha = _bound_p21_import_commit_sha(state)
    commit_path, commit = _p21_import_commit(root)
    if sha256_file(commit_path) != expected_commit_sha:
        raise ValueError("P21 import commit marker changed after Runtime commit")
    if commit["import_manifest_sha256"] != actual_manifest_sha:
        raise ValueError("current import manifest differs from the P21-committed manifest")
    if commit["staging_manifest_sha256"] != sha256_file(root / "staging" / "staging_manifest.json"):
        raise ValueError("staging manifest differs from the P21-committed manifest")
    if commit["content_review_sha256"] != sha256_file(root / "validation" / "obsidian_content_review.json"):
        raise ValueError("content review differs from the P21-committed review")
    if commit["validation_report_sha256"] != sha256_file(root / "validation" / "obsidian_validation_report.json"):
        raise ValueError("validation report differs from the P21-committed report")
    if commit["revised_plan_sha256"] != sha256_file(root / "semantic" / "knowledge_architecture_revised.json"):
        raise ValueError("revised plan differs from the P21-committed plan")
    if commit["vault_binding_id"] != binding["binding_id"] or commit["vault_root_fingerprint"] != binding["root_fingerprint"]:
        raise ValueError("P21 import commit belongs to another Vault binding")
    if commit["operations"] != manifest.get("operations"):
        raise ValueError("import operations differ from the P21-committed operations")
    if approval_manifest_sha256 != actual_manifest_sha:
        raise ValueError("approval hash does not bind the current import manifest")
    report = strict_load_json(root / "validation" / "obsidian_validation_report.json")
    if report["verdict"] != "READY_FOR_IMPORT":
        raise ValueError("P21 did not authorize import")
    if manifest["validation_report_sha256"] != sha256_file(root / "validation" / "obsidian_validation_report.json"):
        raise ValueError("import manifest is stale")
    if manifest["vault_binding_id"] != binding["binding_id"]:
        raise ValueError("import manifest belongs to another Vault binding")

    import_id = f"IMP-{uuid.uuid4().hex[:16].upper()}"
    import_dir = root / "imports" / import_id
    backup_root = import_dir / "backups"
    import_dir.mkdir(parents=True, exist_ok=False)
    applied: list[dict[str, Any]] = []
    transaction_path = import_dir / IMPORT_TRANSACTION_FILENAME
    transaction_operations: list[dict[str, Any]] = []
    try:
        # Recheck every target before the first mutation.
        for op in manifest["operations"]:
            target = safe_relative_target(vault, op["target_path"])
            current = _target_sha256_or_none(target)
            if current == op["after_sha256"]:
                applied.append({
                    "operation_id": op["operation_id"],
                    "target_path": op["target_path"],
                    "status": "IDEMPOTENT_ALREADY_APPLIED",
                    "after_sha256": current,
                })
                continue
            if op["operation_kind"] == "CREATE":
                if target.exists():
                    raise ValueError(f"CREATE target appeared after validation: {op['target_path']}")
            elif current != op["expected_target_sha256"]:
                raise ValueError(f"UPDATE target changed after validation: {op['target_path']}")
            backup_relative_path: str | None = None
            if current is not None:
                before_bytes = target.read_bytes()
                if sha256_bytes(before_bytes) != current:
                    raise ValueError(f"UPDATE target changed while preparing import: {op['target_path']}")
                backup = safe_relative_target(backup_root, op["target_path"])
                atomic_write_bytes(backup, before_bytes)
                backup_relative_path = backup.relative_to(import_dir).as_posix()
            transaction_operations.append({
                "operation_id": op["operation_id"],
                "operation_kind": op["operation_kind"],
                "target_path": op["target_path"],
                "before_sha256": current,
                "after_sha256": op["after_sha256"],
                "backup_relative_path": backup_relative_path,
            })

        transaction: dict[str, Any] | None = None
        if transaction_operations:
            transaction = {
                "transaction_schema_version": "obsidian-import-transaction-v1",
                "import_id": import_id,
                "status": "PREPARED",
                "p21_import_commit_sha256": expected_commit_sha,
                "approved_manifest_sha256": actual_manifest_sha,
                "vault_binding_id": binding["binding_id"],
                "vault_root_fingerprint": binding["root_fingerprint"],
                "operations": transaction_operations,
                "applied_operation_ids": [],
                "created_at": utc_now(),
                "updated_at": utc_now(),
            }
            _write_import_transaction(transaction_path, transaction)
        # Apply deterministically.  Store exact backups outside the Vault.
        for op in manifest["operations"]:
            target = safe_relative_target(vault, op["target_path"])
            current = _target_sha256_or_none(target)
            if current == op["after_sha256"]:
                continue
            staged = safe_relative_target(root, op["staged_relative_path"])
            if sha256_file(staged) != op["after_sha256"]:
                raise ValueError(f"staged payload changed: {op['operation_id']}")
            _assert_target_preimage(op, target)
            atomic_write_bytes(target, staged.read_bytes())
            if sha256_file(target) != op["after_sha256"]:
                raise RuntimeError(f"post-write verification failed: {op['target_path']}")
            applied.append({
                "operation_id": op["operation_id"],
                "target_path": op["target_path"],
                "status": "APPLIED",
                "before_sha256": current,
                "after_sha256": op["after_sha256"],
            })
            if transaction is not None:
                transaction["status"] = "APPLYING"
                transaction["applied_operation_ids"].append(op["operation_id"])
                _write_import_transaction(transaction_path, transaction)
        if transaction is not None:
            transaction["status"] = "COMMITTED"
            transaction["committed_at"] = utc_now()
            _write_import_transaction(transaction_path, transaction)
    except Exception as error:
        if transaction_path.exists():
            transaction = strict_load_json(transaction_path)
            validate_json_schema(transaction, "obsidian-import-transaction-v1.schema.json")
            _rollback_import_transaction(
                transaction_path,
                transaction,
                vault,
                recovery_reason="ROLLBACK_AFTER_APPLY_ERROR",
            )
        elif transaction_operations:
            raise RuntimeError("import preparation failed after backup creation") from error
        raise

    receipt = {
        "receipt_schema_version": "reviewed-obsidian-import-receipt-v1",
        "import_id": import_id,
        "approved_manifest_sha256": actual_manifest_sha,
        "p21_import_commit_sha256": expected_commit_sha,
        "vault_binding_id": binding["binding_id"],
        "operations": applied,
        "status": "IMPORTED",
        "applied_at": utc_now(),
    }
    receipt_path = import_dir / "import_receipt.json"
    receipt_sha = write_hashed_json(receipt_path, receipt)
    return {
        "outcome": "IMPORTED",
        "import_id": import_id,
        "receipt_sha256": receipt_sha,
        "applied": applied,
        "receipt_path": str(receipt_path),
        "recovered_import_ids": recovered_import_ids,
    }
