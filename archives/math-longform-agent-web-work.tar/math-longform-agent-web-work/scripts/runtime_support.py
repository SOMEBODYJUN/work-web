"""Strict I/O, schema validation, path binding, and CLI errors for Runtime v2."""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import hashlib
import json
import os
import re
from pathlib import Path
import uuid
from typing import Any

try:
    import yaml
except ImportError:  # pragma: no cover - fail closed when configuration is requested
    yaml = None

try:
    from jsonschema import Draft202012Validator
except ImportError:  # pragma: no cover
    Draft202012Validator = None


HEX64_RE = r"^[0-9a-f]{64}$"


@dataclass
class RuntimeCliError(Exception):
    code: str
    message: str
    exit_code: int = 1
    details: dict[str, Any] | None = None
    state_changed: bool = False

    def __str__(self) -> str:
        return self.message


def reject_constant(value: str) -> None:
    raise ValueError(f"non-standard JSON constant is forbidden: {value}")


def strict_json_loads(text: str) -> Any:
    def pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for key, value in items:
            if key in out:
                raise ValueError(f"duplicate JSON key: {key}")
            out[key] = value
        return out

    return json.loads(
        text,
        object_pairs_hook=pairs,
        parse_constant=reject_constant,
    )


def strict_load_json(path: Path) -> Any:
    if path.is_symlink():
        raise ValueError(f"symlink JSON input is forbidden: {path}")
    if not path.is_file():
        raise ValueError(f"JSON input is missing: {path}")
    return strict_json_loads(path.read_text(encoding="utf-8", errors="strict"))


def canonical_json_bytes(value: Any) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"regular file required for hashing: {path}")
    return sha256_bytes(path.read_bytes())


def fsync_directory(path: Path) -> None:
    if os.name == "nt":
        return
    try:
        fd = os.open(path, os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def atomic_write_bytes(path: Path, content: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        with temp.open("wb") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
        fsync_directory(path.parent)
    finally:
        if temp.exists():
            temp.unlink()


def atomic_write_text(path: Path, content: str) -> None:
    atomic_write_bytes(path, content.encode("utf-8"))


def atomic_write_json(path: Path, value: Any) -> None:
    atomic_write_bytes(path, json.dumps(
        value, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False
    ).encode("utf-8") + b"\n")


def write_hashed_json(path: Path, value: Any) -> str:
    data = canonical_json_bytes(value)
    atomic_write_bytes(path, data)
    digest = sha256_bytes(data)
    atomic_write_text(path.with_suffix(".sha256"), digest + "\n")
    return digest


def _strict_sidecar_line(sidecar: Path) -> str:
    if sidecar.is_symlink() or not sidecar.is_file():
        raise ValueError(f"SHA-256 sidecar is missing or unsafe: {sidecar}")
    text = sidecar.read_text(encoding="utf-8", errors="strict")
    if "\r" in text or not text.endswith("\n") or text.count("\n") != 1:
        raise ValueError(f"SHA-256 sidecar must contain exactly one LF-terminated line: {sidecar}")
    return text[:-1]


def validate_bare_sha256_sidecar(path: Path) -> str:
    """Validate Runtime-owned ``<digest>\n`` sidecars."""
    sidecar = path.with_suffix(".sha256")
    line = _strict_sidecar_line(sidecar)
    if re.fullmatch(r"[0-9a-f]{64}", line) is None:
        raise ValueError(f"bare SHA-256 sidecar has invalid format: {sidecar}")
    actual = sha256_file(path)
    if line != actual:
        raise ValueError(f"SHA-256 sidecar mismatch: {path}")
    return actual


def validate_named_sha256_sidecar(path: Path) -> str:
    """Validate production ``<digest>  <exact basename>\n`` sidecars."""
    sidecar = path.with_suffix(".sha256")
    line = _strict_sidecar_line(sidecar)
    expected_suffix = f"  {path.name}"
    if len(line) != 64 + len(expected_suffix):
        raise ValueError(f"named SHA-256 sidecar has invalid format: {sidecar}")
    digest, suffix = line[:64], line[64:]
    if re.fullmatch(r"[0-9a-f]{64}", digest) is None or suffix != expected_suffix:
        raise ValueError(f"named SHA-256 sidecar does not bind exact basename: {sidecar}")
    actual = sha256_file(path)
    if digest != actual:
        raise ValueError(f"SHA-256 sidecar mismatch: {path}")
    return actual


def schema_root() -> Path:
    return Path(__file__).resolve().parents[1] / "schemas"


@lru_cache(maxsize=None)
def _schema_validator(schema_name: str) -> Any:
    if Draft202012Validator is None:
        raise RuntimeError("jsonschema is required by Runtime v2")
    schema = strict_load_json(schema_root() / schema_name)
    Draft202012Validator.check_schema(schema)
    return Draft202012Validator(schema)


def validate_json_schema(value: Any, schema_name: str) -> None:
    errors = sorted(
        _schema_validator(schema_name).iter_errors(value),
        key=lambda e: list(e.absolute_path),
    )
    if errors:
        first = errors[0]
        where = "/".join(str(item) for item in first.absolute_path) or "$"
        raise ValueError(f"{schema_name} validation failed at {where}: {first.message}")


def load_yaml(path: Path) -> Any:
    if yaml is None:
        raise RuntimeError("PyYAML is required when Obsidian configuration is used")
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"configuration file is missing or unsafe: {path}")
    value = yaml.safe_load(path.read_text(encoding="utf-8", errors="strict"))
    return value


def is_relative_to(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def require_disjoint_roots(*roots: Path | None) -> None:
    resolved = [item.resolve() for item in roots if item is not None]
    for i, left in enumerate(resolved):
        for right in resolved[i + 1 :]:
            if left == right or is_relative_to(left, right) or is_relative_to(right, left):
                raise ValueError(f"runtime domains must not overlap: {left} and {right}")


def safe_relative_target(root: Path, relative: str) -> Path:
    rel = Path(relative)
    if rel.is_absolute() or ".." in rel.parts:
        raise ValueError(f"unsafe relative path: {relative}")
    target = root / rel
    resolved_root = root.resolve()
    # Resolve parent only; the leaf may not exist yet.
    parent = target.parent.resolve()
    if not is_relative_to(parent, resolved_root):
        raise ValueError(f"path escapes its artifact domain: {relative}")
    cursor = resolved_root
    for part in rel.parts[:-1]:
        cursor = cursor / part
        if cursor.is_symlink():
            raise ValueError(f"symlink directory is forbidden in artifact path: {relative}")
    if target.exists() and target.is_symlink():
        raise ValueError(f"symlink target is forbidden: {relative}")
    return target


def emit_cli_error(error: RuntimeCliError, command: str) -> dict[str, Any]:
    return {
        "schema_version": "runtime-cli-result-v1",
        "ok": False,
        "command": command,
        "error": {
            "code": error.code,
            "message": error.message,
            "details": error.details or {},
        },
        "state_changed": bool(error.state_changed),
    }
