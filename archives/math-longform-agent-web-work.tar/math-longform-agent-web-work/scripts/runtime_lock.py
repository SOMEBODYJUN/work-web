"""Cross-platform non-blocking file lock for a single Runtime root."""
from __future__ import annotations

from contextlib import contextmanager
import os
from pathlib import Path
from typing import Iterator

from runtime_support import RuntimeCliError

if os.name == "nt":  # pragma: no cover - exercised on Windows CI
    import msvcrt
else:
    import fcntl


@contextmanager
def exclusive_runtime_lock(runtime_root: Path) -> Iterator[None]:
    lock_dir = runtime_root / "locks"
    lock_dir.mkdir(parents=True, exist_ok=True)
    lock_path = lock_dir / "runtime.lock"
    handle = lock_path.open("a+b")
    try:
        try:
            if os.name == "nt":  # pragma: no cover
                if lock_path.stat().st_size == 0:
                    handle.write(b"\0")
                    handle.flush()
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (BlockingIOError, OSError) as exc:
            handle.close()
            raise RuntimeCliError(
                "RUNTIME_LOCK_HELD",
                "The Runtime root is locked by another process.",
                exit_code=75,
                details={"runtime_root": str(runtime_root), "cause": str(exc)},
            ) from exc
        yield
    finally:
        try:
            if not handle.closed:
                if os.name == "nt":  # pragma: no cover
                    handle.seek(0)
                    msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        finally:
            if not handle.closed:
                handle.close()
