"""Source-bound repair handoffs for semantic phase recovery."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from runtime_support import (
    canonical_json_bytes,
    safe_relative_target,
    sha256_bytes,
    sha256_file,
    strict_load_json,
    validate_bare_sha256_sidecar,
    validate_json_schema,
    write_hashed_json,
)


HANDOFF_SCHEMA = "repair-handoff-v1.schema.json"
HANDOFF_DIR = "recovery/handoffs"


def handoff_relative_path(handoff_id: str) -> str:
    return f"{HANDOFF_DIR}/{handoff_id}.json"


def handoff_path(runtime_root: Path, handoff_id: str) -> Path:
    return safe_relative_target(runtime_root, handoff_relative_path(handoff_id))


def _without_fingerprint(value: dict[str, Any]) -> bytes:
    copy = json.loads(canonical_json_bytes(value))
    copy["failure_fingerprint"] = None
    return canonical_json_bytes(copy)


def failure_fingerprint(value: dict[str, Any]) -> str:
    return sha256_bytes(_without_fingerprint(value))


def validate_handoff_shape(value: dict[str, Any]) -> None:
    validate_json_schema(value, HANDOFF_SCHEMA)
    if value.get("failure_fingerprint") != failure_fingerprint(value):
        raise ValueError("repair handoff failure_fingerprint does not match its contents")
    if value["return_to_phase"] == "P00":
        raise ValueError("repair handoff cannot return to P00")
    if value["acceptance_state"] not in {"OPEN", "IN_REPAIR", "RESOLVED", "BLOCKED"}:
        raise ValueError("repair handoff has an invalid acceptance_state")


def _binding(
    envelope: dict[str, Any],
    relative_path: str,
    *,
    target: bool,
) -> tuple[Path, str]:
    for row in envelope.get("required_reads", []):
        if not isinstance(row, dict) or str(row.get("relative_path") or "") != relative_path:
            continue
        if target and row.get("binding_role") not in {"PHASE_OUTPUT_CANDIDATE", None}:
            continue
        if not target and row.get("binding_role") == "PHASE_OUTPUT_CANDIDATE":
            continue
        path = Path(str(row.get("path") or ""))
        digest = str(row.get("sha256") or "")
        if not path.is_file() or path.is_symlink():
            raise ValueError(f"repair handoff binding is missing or unsafe: {relative_path}")
        if sha256_file(path) != digest:
            raise ValueError(f"repair handoff binding is stale: {relative_path}")
        return path, digest
    raise ValueError(
        f"repair handoff path is not a bound {'target' if target else 'source'}: {relative_path}"
    )


def validate_claim(
    claim: dict[str, Any],
    *,
    state: dict[str, Any],
    envelope: dict[str, Any],
    phase_id: str,
    ordered_phase_ids: Iterable[str],
    phase_outputs: Iterable[str],
    response_sha256: str,
) -> dict[str, Any]:
    """Validate a PARTIAL/BLOCK review and enrich it with run bindings."""
    if claim.get("ready") is not False:
        raise ValueError("a repair handoff requires ready=false")
    verdict = str(claim.get("verdict") or "")
    if verdict not in {"PARTIAL", "BLOCK"}:
        raise ValueError("a repair handoff requires PARTIAL or BLOCK verdict")
    supplied = claim.get("repair_handoff")
    if not isinstance(supplied, dict):
        raise ValueError("PARTIAL/BLOCK completion must include repair_handoff")
    handoff = dict(supplied)
    handoff["schema_version"] = "repair-handoff-v1"
    handoff.setdefault(
        "handoff_id",
        f"RH-{sha256_bytes(canonical_json_bytes(supplied))[:16].upper()}",
    )
    handoff["job_id"] = str(state["identity"]["job_id"])
    handoff["run_id"] = str(state["identity"]["run_id"])
    handoff["phase_plan_revision"] = int(state["route"]["phase_plan_revision"])
    handoff["review_verdict"] = verdict
    if claim.get("first_loss_boundary") and handoff.get("first_loss_boundary") != claim.get("first_loss_boundary"):
        raise ValueError("claim first_loss_boundary differs from the Repair Handoff")
    if not handoff.get("first_loss_boundary"):
        raise ValueError("Repair Handoff must state first_loss_boundary")
    handoff["unresolved_items"] = list(claim.get("unresolved_items") or handoff.get("unresolved_items") or [])
    handoff["created_at"] = str(handoff.get("created_at") or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"))
    handoff["acceptance_state"] = "OPEN"
    handoff["repair_attempt"] = int(handoff.get("repair_attempt") or 1)
    handoff["prior_handoff_id"] = handoff.get("prior_handoff_id")
    prior_pointer = state.get("active", {}).get("repair_handoff")
    if isinstance(prior_pointer, dict):
        expected_attempt = int(prior_pointer.get("repair_attempt", 0)) + 1
        if handoff["repair_attempt"] != expected_attempt:
            raise ValueError("a subsequent Repair Handoff must increment repair_attempt")
        if handoff["prior_handoff_id"] != prior_pointer.get("handoff_id"):
            raise ValueError("a subsequent Repair Handoff must link prior_handoff_id")
    elif handoff["repair_attempt"] != 1 or handoff["prior_handoff_id"] is not None:
        raise ValueError("the first Repair Handoff must use repair_attempt=1 and prior_handoff_id=null")
    handoff["created_from"] = {
        "failed_phase": phase_id,
        "failed_attempt": int(state["cursor"]["attempt"]),
        "recovery_epoch": int(state["cursor"].get("recovery_epoch", 0)),
        "state_revision": int(state["state_revision"]),
        "context_pack_sha256": str(state["active"].get("context_pack_sha256") or ""),
        "response_sha256": response_sha256,
    }

    return_phase = str(handoff.get("return_to_phase") or "")
    plan = list(ordered_phase_ids)
    if return_phase not in plan:
        raise ValueError(f"repair handoff return_to_phase is not in the active route: {return_phase}")
    current_index = plan.index(phase_id)
    if plan.index(return_phase) > current_index:
        raise ValueError("repair handoff must return to the failed phase or an earlier phase")
    if return_phase == "P00":
        raise ValueError("repair handoff cannot return to P00")
    if not handoff["unresolved_items"]:
        raise ValueError("repair handoff must retain unresolved_items")

    output_set = set(str(item) for item in phase_outputs)
    semantic_targets = {
        "draft.md", "final.md", "optimized_final.md", "standardized_final.md",
        "revised_final.md", "aigc_rewritten_final.md", "publication_final.md",
    }
    defects = handoff.get("defects")
    if not isinstance(defects, list) or not defects:
        raise ValueError("repair handoff must contain at least one defect")
    for index, defect in enumerate(defects, 1):
        if not isinstance(defect, dict):
            raise ValueError(f"repair handoff defect {index} must be an object")
        source = defect.get("source_evidence")
        target = defect.get("target_evidence")
        first_loss_phase = str(defect.get("first_loss_phase") or "")
        if first_loss_phase not in plan:
            raise ValueError(f"repair handoff defect {index} has an unknown first_loss_phase")
        if plan.index(first_loss_phase) > current_index:
            raise ValueError(f"repair handoff defect {index} first_loss_phase is later than the review phase")
        if plan.index(return_phase) > plan.index(first_loss_phase):
            raise ValueError(f"repair handoff defect {index} returns after its first_loss_phase")
        if not isinstance(source, dict) or not isinstance(target, dict):
            raise ValueError(f"repair handoff defect {index} lacks source/target evidence")
        source_rel = str(source.get("path") or "")
        target_rel = str(target.get("path") or "")
        source_path, source_sha = _binding(envelope, source_rel, target=False)
        if target_rel not in output_set and target_rel not in semantic_targets:
            raise ValueError(f"repair handoff defect {index} target is not a current output: {target_rel}")
        target_path: Path | None = None
        target_sha: str | None = None
        target_rows = [
            row
            for row in envelope.get("required_reads", [])
            if isinstance(row, dict)
            and str(row.get("relative_path") or "") == target_rel
            and row.get("binding_role") in {"PHASE_OUTPUT_CANDIDATE", None}
        ]
        # If a target is bound, a stale hash is a hard failure.  Only an
        # entirely unbound/nonexistent target may use the explicit-missing
        # representation; do not catch a stale binding and misreport it as a
        # missing file.
        if target_rows:
            try:
                target_path, target_sha = _binding(envelope, target_rel, target=True)
            except ValueError as exc:
                # Keep the handoff-level diagnostic stable and distinguish a
                # changed target from a missing/unsafe binding.  Callers and
                # recovery reports rely on this boundary to identify the
                # first stale evidence rather than treating it as a missing
                # target.
                if "binding is stale" in str(exc):
                    raise ValueError(
                        f"repair handoff defect {index} target hash is stale"
                    ) from exc
                raise
        else:
            artifact_root = Path(str(envelope.get("artifact_domain_root") or "")).resolve()
            candidate = safe_relative_target(artifact_root, target_rel)
            if candidate.exists():
                raise ValueError(
                    f"repair handoff defect {index} target exists but is not a bound phase output: {target_rel}"
                )
            if target.get("exists") is not False or target.get("sha256") is not None or target.get("excerpt") is not None:
                raise ValueError(f"repair handoff defect {index} missing target must be explicit")
        if source.get("sha256") != source_sha:
            raise ValueError(f"repair handoff defect {index} source hash is stale")
        source_excerpt = str(source.get("excerpt") or "")
        if source_excerpt not in source_path.read_text(encoding="utf-8", errors="strict"):
            raise ValueError(f"repair handoff defect {index} source excerpt is absent")
        if target_path is not None:
            if target.get("exists") is not True or target.get("sha256") != target_sha:
                raise ValueError(f"repair handoff defect {index} target hash/existence is stale")
            target_excerpt = str(target.get("excerpt") or "")
            if target_excerpt not in target_path.read_text(encoding="utf-8", errors="strict"):
                raise ValueError(f"repair handoff defect {index} target excerpt is absent")

    handoff["failure_fingerprint"] = failure_fingerprint({**handoff, "failure_fingerprint": None})
    validate_handoff_shape(handoff)
    return handoff


def handoff_artifact_payload(handoff: dict[str, Any]) -> tuple[bytes, str]:
    validate_handoff_shape(handoff)
    content = canonical_json_bytes(handoff) + b"\n"
    return content, sha256_bytes(content)


def load_handoff(runtime_root: Path, reference: dict[str, Any]) -> dict[str, Any]:
    handoff_id = str(reference.get("handoff_id") or "")
    if not handoff_id:
        raise ValueError("active repair handoff pointer has no handoff_id")
    expected_rel = handoff_relative_path(handoff_id)
    if str(reference.get("path") or "") != expected_rel:
        raise ValueError("active repair handoff path is invalid")
    path = handoff_path(runtime_root, handoff_id)
    if not path.is_file() or path.is_symlink():
        raise ValueError("active repair handoff file is missing or unsafe")
    digest = validate_bare_sha256_sidecar(path)
    if digest != reference.get("sha256"):
        raise ValueError("active repair handoff hash is stale")
    value = strict_load_json(path)
    validate_handoff_shape(value)
    # The pointer chooses the file name.  Binding only the sidecar/hash is not
    # enough: a valid handoff payload with a different internal identity must
    # never be accepted through a swapped file.  This check also makes the
    # immutable handoff lineage unambiguous when several repair attempts exist.
    if value.get("handoff_id") != handoff_id:
        raise ValueError("active repair handoff ID does not match its pointer/path")
    created = value["created_from"]
    if created["failed_phase"] != reference.get("origin_phase"):
        raise ValueError("active repair handoff origin_phase does not match its file")
    if created["failed_phase"] != reference.get("recheck_phase"):
        raise ValueError("active repair handoff recheck_phase does not match its file")
    if value["return_to_phase"] != reference.get("return_phase"):
        raise ValueError("active repair handoff return_phase does not match its file")
    if value["repair_attempt"] != reference.get("repair_attempt"):
        raise ValueError("active repair handoff repair_attempt does not match its file")
    if created["context_pack_sha256"] != reference.get("context_pack_sha256"):
        raise ValueError("active repair handoff context hash does not match its pointer")
    return value
