#!/usr/bin/env python3
"""Runtime v2 control plane for the Math Longform single-thread Codex Agent.

P00-P15 preserve the frozen publication workflow. P16-P21 implement
author-directed Obsidian compilation, and formal Vault mutation is available
only through an exact P21 manifest approval.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid
from typing import Any

from phase_registry import (
    TERMINAL_PHASE,
    PHASE_CATALOG_VERSION,
    get_phase,
    phase_brief_for,
    routable_phase_ids,
    rules_for_phase,
)
from route_compiler import CORE_PHASES, OBSIDIAN_PHASES, RouteRequest, compile_route
from runtime_lock import exclusive_runtime_lock
from runtime_support import (
    RuntimeCliError,
    atomic_write_json,
    atomic_write_text,
    canonical_json_bytes,
    emit_cli_error,
    load_yaml,
    require_disjoint_roots,
    safe_relative_target,
    sha256_bytes,
    sha256_file,
    strict_load_json,
    strict_json_loads,
    validate_json_schema,
    validate_bare_sha256_sidecar,
    validate_named_sha256_sidecar,
    write_hashed_json,
)
from runtime_transitions import (
    apply_transition,
    inspect_recovery,
    repair_recovery,
    state_digest,
)
from repair_handoff import (
    HANDOFF_DIR,
    handoff_path,
    handoff_relative_path,
    load_handoff,
    validate_claim as validate_repair_handoff_claim,
    validate_handoff_shape,
    failure_fingerprint,
)
from obsidian_author_directed import (
    index_vault as index_author_directed_vault,
    normalize_destination_policy,
    normalize_tag_policy,
)
from obsidian_copy_first import (
    apply_import as apply_author_directed_import,
    apply_page_patch_bundle,
    build_staging_and_delivery,
    materialize_page_seeds,
    submit_author_response as bind_author_response,
    validate_author_intent_contract as validate_bound_author_intent,
    validate_staging as validate_author_directed_staging,
    write_author_intent_question,
)
from phase_io_registry import (
    ensure_input_manifest,
    ensure_output_manifest,
    output_manifest_transition_payloads,
    phase_manifest_path,
    resolve_manifest_artifact,
    semantic_schema_for,
    validate_input_manifest_binding,
)
from source_atom_resegmentation import prepare_resegmentation


STATE_SCHEMA = "math-longform-agent-runtime-v2"
RUNTIME_CONTRACT_VERSION = "r0.2"
STATE_FILE = "runtime_state.json"
JOURNAL_FILE = "runtime_journal.jsonl"
ACTION_SCHEMA_RELATIVE_PATH = "schemas/action-response.schema.json"
PHASE_ORDER = CORE_PHASES
SUPERVISED_SEMANTIC_PHASES = {
    "P03",
    "P04",
    "P05",
    "P06",
    "P07",
    "P08",
    "P09",
    "P10",
    "P11",
    "P13",
    "P17",
    "P18",
    "P19",
}

ALLOWED_ACTION_TYPES = {
    "READ_REGISTERED_FILE",
    "READ_SOURCE_SPAN",
    "READ_STRUCTURED_ROWS",
    "WRITE_PHASE_ARTIFACT",
    "UPDATE_PHASE_ARTIFACT",
    "PROPOSE_SOURCE_PATCH",
    "RUN_PHASE_VALIDATOR",
    "INSPECT_VALIDATION_FAILURE",
    "DECLARE_BLOCKER",
    "REQUEST_PHASE_VALIDATION",
}

MACHINE_EVIDENCE_TARGETS = {
    "validator_result.json",
    "validator_result.sha256",
    "validator_result.txt",
    "release_manifest.json",
    "release_manifest.sha256",
}

DEFAULT_COLLECTION_MAP = {
    "articles": "10 Articles/",
    "concepts": "20 Concepts/",
    "theorems": "30 Theorems/",
    "techniques": "40 Techniques/",
    "problems": "50 Problems/",
    "examples": "50 Problems/Examples/",
    "insights": "60 Insights/",
    "questions": "70 Questions/",
    "mocs": "80 MOCs/",
    "sources": "90 Sources/",
}

HANDOFF_ARTIFACTS = (
    ("publication_final", "publication_final.md", True),
    ("release_manifest", "release_manifest.json", True),
    ("validator_result", "validator_result.json", True),
    ("publication_blueprint", "publication_blueprint.json", True),
    ("voice_expression_ledger", "voice_expression_ledger.md", True),
    ("explanation_chain_ledger", "explanation_chain_ledger.md", True),
    ("source_atom_ledger", "source_atom_ledger.jsonl", False),
    ("math_statement_ledger", "math_statement_ledger.md", False),
    ("proof_obligations", "proof_obligations.md", False),
    ("publication_claim_ledger", "publication_claim_ledger.jsonl", False),
    ("publication_sentence_trace", "publication_sentence_trace.jsonl", False),
    ("mathematical_review", "mathematical_review.json", False),
    ("publication_content_review", "publication_content_review.json", False),
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def skill_root() -> Path:
    root = Path(__file__).resolve().parents[1] / "skills" / "math-longform-publisher"
    if not (root / "scripts" / "pipeline.py").is_file():
        raise ValueError(f"bundled skill is incomplete: {root}")
    return root


def plugin_version() -> str:
    plugin = strict_load_json(Path(__file__).resolve().parents[1] / ".codex-plugin" / "plugin.json")
    return str(plugin["version"])


def business_root(state: dict[str, Any]) -> Path:
    return Path(state["roots"]["business_root"])


def runtime_root_from(state: dict[str, Any]) -> Path:
    return Path(state["roots"]["runtime_root"])


def current_phase_id(state: dict[str, Any]) -> str:
    return str(state["cursor"]["current_phase"])


def current_phase_attempt(state: dict[str, Any]) -> int:
    return int(state["cursor"]["attempt"])


def current_context_hash(state: dict[str, Any]) -> str | None:
    return state["active"]["context_pack_sha256"]


def validate_state_invariants(state: dict[str, Any]) -> None:
    validate_json_schema(state, "runtime-state-v2.schema.json")
    active_handoff = state.get("active", {}).get("repair_handoff")
    active_status = state.get("active", {}).get("status")
    if active_status == "REPAIR_REQUIRED":
        if not isinstance(active_handoff, dict) or active_handoff.get("status") != "ACTIVE":
            raise ValueError(
                "REPAIR_REQUIRED state must retain an ACTIVE repair handoff pointer"
            )
    if active_handoff is not None:
        expected_path = handoff_relative_path(str(active_handoff.get("handoff_id") or ""))
        if active_handoff.get("path") != expected_path:
            raise ValueError("active repair handoff pointer path is not canonical")
        if active_handoff.get("status") == "ACTIVE" and active_status != "REPAIR_REQUIRED":
            raise ValueError("ACTIVE repair handoff requires active.status=REPAIR_REQUIRED")
        if active_handoff.get("status") == "IN_PROGRESS" and state.get("active", {}).get("status") not in {"RECOVERY_READY", "AWAITING_ACTION", "ACTION_VALIDATED", "READY"}:
            raise ValueError("IN_PROGRESS repair handoff has an invalid active status")
    plan = list(state["route"]["ordered_phase_ids"])
    current = current_phase_id(state)
    if current == TERMINAL_PHASE:
        if state["workflow"]["status"] != "COMPLETED":
            raise ValueError("TERMINAL requires workflow.status=COMPLETED")
        if state["cursor"]["phase_index"] != len(plan):
            raise ValueError("TERMINAL phase_index must equal phase-plan length")
    else:
        if current not in plan:
            raise ValueError("current phase is not in the frozen phase plan")
        if plan[state["cursor"]["phase_index"]] != current:
            raise ValueError("phase cursor does not match the frozen phase plan")
    committed = list(state["execution"]["committed_phase_ids"])
    if current == TERMINAL_PHASE:
        expected_committed = plan
        if state["active"]["status"] == "RECOVERY_READY":
            raise ValueError("TERMINAL cannot be a recovery-ready state")
    else:
        expected_committed = plan[: state["cursor"]["phase_index"]]
        if state["workflow"]["status"] == "SUSPENDED":
            resume = state["workflow"].get("resume_phase")
            if resume is not None and resume != current:
                raise ValueError("SUSPENDED resume_phase must equal the current phase")
        if state["active"]["status"] == "RECOVERY_READY":
            if state["workflow"]["status"] != "RUNNING":
                raise ValueError("RECOVERY_READY requires workflow.status=RUNNING")
            if state["phase_records"][current]["status"] != "ACTIVE":
                raise ValueError("RECOVERY_READY requires an ACTIVE current phase record")
    if committed != expected_committed:
        raise ValueError(
            "committed_phase_ids must equal the exact frozen-plan prefix "
            f"{expected_committed!r}, got {committed!r}"
        )
    if state["route"]["obsidian_enabled"]:
        if state["route"]["post_release_targets"] != ["obsidian"]:
            raise ValueError("R0 supports exactly the default Obsidian target")
    elif state["route"]["post_release_targets"]:
        raise ValueError("publication-only route cannot contain post-release targets")
    if state["outputs"]["obsidian"]["status"] == "CONFIGURATION_REQUIRED":
        if current != "P16":
            raise ValueError("configuration-required state must resume at P16")
    if state["publication_release"]["verdict"] == "PUBLISHABLE":
        if "P14" not in committed:
            raise ValueError("PUBLISHABLE requires committed P14")


def load_state(runtime_root: Path) -> dict[str, Any]:
    state = strict_load_json(runtime_root / STATE_FILE)
    # Backward-compatible state migration: pre-handoff runs had no pointer.
    state.setdefault("active", {}).setdefault("repair_handoff", None)
    validate_state_invariants(state)
    return state


def write_state(runtime_root: Path, state: dict[str, Any]) -> None:
    validate_state_invariants(state)
    atomic_write_json(runtime_root / STATE_FILE, state)


def save_state(runtime_root: Path, state: dict[str, Any]) -> None:
    """Direct writer retained only for deterministic test-fixture setup."""
    state["updated_at"] = utc_now()
    write_state(runtime_root, state)


def append_journal(
    runtime_root: Path,
    event: str,
    *,
    journal_event_id: str | None = None,
    event_at: str | None = None,
    **details: Any,
) -> str:
    """Append one uniquely identified journal event.

    When ``journal_event_id`` already exists with the same event and
    transition binding, return its digest instead of appending a duplicate.
    """
    path = runtime_root / JOURNAL_FILE
    path.parent.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, Any]] = []
    if path.is_file():
        for line in path.read_text(encoding="utf-8", errors="strict").splitlines():
            if line.strip():
                value = strict_json_loads(line)
                if not isinstance(value, dict):
                    raise ValueError("Runtime journal row must be a JSON object")
                rows.append(value)
    event_id = journal_event_id or f"JE-{uuid.uuid4().hex.upper()}"
    matches = [row for row in rows if row.get("journal_event_id") == event_id]
    if len(matches) > 1:
        raise ValueError(f"duplicate Runtime journal event ID: {event_id}")
    if matches:
        existing = matches[0]
        if (
            existing.get("event") != event
            or existing.get("transition_id") != details.get("transition_id")
        ):
            raise ValueError(f"Runtime journal event ID conflict: {event_id}")
        return str(existing["event_sha256"])

    previous = rows[-1].get("event_sha256") if rows else None
    payload = {
        "event": event,
        "journal_event_id": event_id,
        "at": event_at or utc_now(),
        "previous_event_sha256": previous,
        **details,
    }
    digest = sha256_bytes(canonical_json_bytes(payload))
    row = {**payload, "event_sha256": digest}
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(
            json.dumps(row, ensure_ascii=False, sort_keys=True, allow_nan=False)
            + "\n"
        )
        handle.flush()
        os.fsync(handle.fileno())
    return digest


def require_phase(state: dict[str, Any], phase_id: str) -> None:
    current = current_phase_id(state)
    if current != phase_id:
        raise ValueError(f"expected {phase_id}, current phase is {current}")
    if state["workflow"]["status"] in {"SUSPENDED", "BLOCKED", "COMPLETED"}:
        raise ValueError(f"workflow is not runnable: {state['workflow']['status']}")
    if state.get("active", {}).get("status") == "REPAIR_REQUIRED":
        raise ValueError("semantic repair handoff must be recovered before continuing")


def command_result(command: list[str], *, cwd: Path) -> dict[str, Any]:
    completed = subprocess.run(command, cwd=cwd, text=True, capture_output=True, check=False)
    return {
        "command": command,
        "exit_code": int(completed.returncode),
        "stdout": completed.stdout,
        "stderr": completed.stderr,
    }


def read_jsonl_objects(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line_no, line in enumerate(
        path.read_text(encoding="utf-8", errors="strict").splitlines(), 1
    ):
        if not line.strip():
            continue
        value = json.loads(line)
        if not isinstance(value, dict):
            raise ValueError(f"{path.name}:{line_no} must contain one JSON object")
        rows.append(value)
    return rows


def run_or_raise(result: dict[str, Any]) -> None:
    if result["exit_code"]:
        message = str(result["stderr"] or result["stdout"]).strip()
        raise RuntimeError(message or f"command failed: {result['command']}")


def emit_json(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False))


def phase_record(attempt: int = 1, status: str = "PENDING") -> dict[str, Any]:
    return {
        "attempt": attempt,
        "status": status,
        "output_manifest_sha256": None,
        "io_output_manifest_sha256": None,
        "input_fingerprint": None,
        "recovery_epoch": 0,
        "written_targets": [],
        "last_validation": None,
    }


def initial_phase_records(plan: list[str]) -> dict[str, Any]:
    records = {phase_id: phase_record() for phase_id in plan}
    records["P00"]["status"] = "COMMITTED"
    records["P01"]["status"] = "ACTIVE"
    return records

def resolve_business_arg(args: argparse.Namespace) -> Path:
    old = getattr(args, "business_output", None)
    new = getattr(args, "business_root", None)
    if old and new:
        raise RuntimeCliError(
            "CONFLICTING_CLI_OPTIONS",
            "--business-output and --business-root cannot be used together.",
            exit_code=64,
        )
    raw = new or old
    if not raw:
        raise RuntimeCliError(
            "MISSING_BUSINESS_ROOT",
            "One of --business-root or --business-output is required.",
            exit_code=64,
        )
    return Path(raw).resolve()


def validate_obsidian_config_shape(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError("Obsidian configuration must be a YAML object")
    merged = dict(value)
    merged.setdefault("config_schema_version", "obsidian-target-config-v1.0")
    merged.setdefault("mode", "STAGING_ONLY")
    merged.setdefault("obsidian_run_root", None)
    merged.setdefault("indexing", {
        "exclude_paths": [],
        "max_notes": 20000,
        "max_note_bytes": 2000000,
    })
    merged.setdefault("destination_policy", {
        "learn_from_vault": True,
        "fallback_folder": "Agent Inbox",
        "allow_invented_taxonomy": False,
    })
    merged.setdefault("tag_policy", {
        "approved_tags": [],
        "max_depth": 2,
    })
    merged.setdefault("attachments", {
        "mode": "TEXT_REFERENCES_ONLY",
        "copy_binary_files": False,
        "validate_binary_targets": False,
    })
    merged.setdefault("human_review", {
        "mode": "ACTUAL_PAGES_AND_DIFFS",
        "vault_commit": False,
        "approval_hash_required": True,
    })
    validate_json_schema(merged, "obsidian-target-config-v0.1.schema.json")
    if merged["mode"] not in {"STAGING_ONLY", "REVIEWED_APPLY"}:
        raise ValueError("mode must be STAGING_ONLY or REVIEWED_APPLY")
    if merged["attachments"].get("copy_binary_files") is not False:
        raise ValueError("binary attachment copying is not implemented")
    if merged["human_review"].get("approval_hash_required") is not True:
        raise ValueError("reviewed application always requires an exact approval hash")
    if merged["mode"] == "STAGING_ONLY" and merged["human_review"].get("vault_commit") is True:
        raise ValueError("STAGING_ONLY cannot enable Vault commit")
    if merged["mode"] == "REVIEWED_APPLY" and merged["human_review"].get("vault_commit") is not True:
        raise ValueError("REVIEWED_APPLY requires human_review.vault_commit=true")
    merged["destination_policy"] = normalize_destination_policy(
        merged["destination_policy"]
    )
    merged["tag_policy"] = normalize_tag_policy(merged["tag_policy"])
    return merged


def root_fingerprint(path: Path) -> str:
    stat = path.stat()
    payload = {
        "canonical_root": str(path),
        "device": getattr(stat, "st_dev", None),
        "inode": getattr(stat, "st_ino", None),
    }
    return sha256_bytes(canonical_json_bytes(payload))


def prepare_obsidian_binding(
    runtime_root: Path,
    business_root_path: Path,
    config_path: Path,
    *,
    authorized_by: str,
    authorization_event_id: str,
) -> tuple[dict[str, Any], Path, dict[str, Any]]:
    config_path = config_path.resolve()
    config = validate_obsidian_config_shape(load_yaml(config_path))
    requested_vault = Path(str(config["authorized_vault_root"]))
    if requested_vault.is_symlink():
        raise ValueError("authorized Vault root cannot be a symlink")
    vault = requested_vault.resolve(strict=True)
    if not vault.is_dir():
        raise ValueError("authorized Vault root must be an existing directory")

    configured_run = config.get("obsidian_run_root")
    obsidian_root = (
        Path(str(configured_run)).resolve()
        if configured_run
        else (runtime_root / "obsidian").resolve()
    )
    runtime_resolved = runtime_root.resolve()
    business_resolved = business_root_path.resolve()
    # Obsidian output may be nested under Runtime, but never under BUSINESS or Vault.
    require_disjoint_roots(runtime_resolved, business_resolved, vault)
    if obsidian_root == business_resolved or obsidian_root == vault:
        raise ValueError("Obsidian run root conflicts with a protected root")
    try:
        obsidian_root.relative_to(runtime_resolved)
    except ValueError:
        require_disjoint_roots(obsidian_root, runtime_resolved, business_resolved, vault)
    else:
        if obsidian_root == runtime_resolved:
            raise ValueError("Obsidian run root cannot equal Runtime root")
    try:
        obsidian_root.relative_to(business_resolved)
        raise ValueError("Obsidian run root cannot be inside BUSINESS")
    except ValueError as exc:
        if str(exc).startswith("Obsidian"):
            raise
    try:
        obsidian_root.relative_to(vault)
        raise ValueError("Obsidian run root cannot be inside the formal Vault")
    except ValueError as exc:
        if str(exc).startswith("Obsidian"):
            raise

    obsidian_root.mkdir(parents=True, exist_ok=True)
    binding_id = f"VAULT-{uuid.uuid4().hex[:16].upper()}"
    record = {
        "schema_version": "formal-vault-binding-v1",
        "binding_id": binding_id,
        "requested_root": str(requested_vault),
        "canonical_root": str(vault),
        "canonical_root_sha256": sha256_bytes(str(vault).encode("utf-8")),
        "root_fingerprint": root_fingerprint(vault),
        "config_path": str(config_path),
        "config_sha256": sha256_file(config_path),
        "config": config,
        "access_mode": "READ_ONLY_DURING_ANALYSIS_WRITE_ONLY_AFTER_APPROVAL",
        "authorized_by": authorized_by,
        "authorization_event_id": authorization_event_id,
        "created_at": utc_now(),
    }
    binding_path = runtime_root / "bindings" / "formal-vault.json"
    binding_sha = write_hashed_json(binding_path, record)
    reference = {
        "binding_id": binding_id,
        "binding_record_relative_path": binding_path.relative_to(runtime_root).as_posix(),
        "binding_record_sha256": binding_sha,
        "canonical_root_sha256": record["canonical_root_sha256"],
        "root_fingerprint": record["root_fingerprint"],
        "access_mode": "READ_ONLY_DURING_ANALYSIS_WRITE_ONLY_AFTER_APPROVAL",
        "mode": config["mode"],
    }
    return reference, obsidian_root, config


def load_binding_record(runtime_root: Path, reference: dict[str, Any]) -> dict[str, Any]:
    path = safe_relative_target(runtime_root, reference["binding_record_relative_path"])
    if sha256_file(path) != reference["binding_record_sha256"]:
        raise ValueError("formal Vault binding record is stale")
    record = strict_load_json(path)
    vault = Path(record["canonical_root"])
    if not vault.is_dir() or vault.is_symlink():
        raise ValueError("authorized Vault binding is no longer valid")
    if root_fingerprint(vault) != reference["root_fingerprint"]:
        raise ValueError("authorized Vault root fingerprint changed")
    if record.get("access_mode") not in {
        "READ_ONLY",
        "READ_ONLY_DURING_ANALYSIS_WRITE_ONLY_AFTER_APPROVAL",
    }:
        raise ValueError("Vault binding access mode is not recognized")
    return record


SNAPSHOT_EXCLUDED_BASENAMES = {
    "validator_result.json",
    "validator_result.sha256",
    "validator_result.txt",
    "release_manifest.json",
    "release_manifest.sha256",
    "PUBLICATION_AUDIT_REPORT.md",
}


def snapshot_business(root: Path) -> str:
    items: list[dict[str, Any]] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.is_symlink():
            continue
        if path.name in SNAPSHOT_EXCLUDED_BASENAMES:
            continue
        if "__pycache__" in path.parts or "validator_evidence" in path.parts:
            continue
        rel = path.relative_to(root).as_posix()
        items.append({"path": rel, "size": path.stat().st_size, "sha256": sha256_file(path)})
    return sha256_bytes(json.dumps(
        items, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8"))


def verify_publication_release_binding(state: dict[str, Any] | None, business: Path) -> dict[str, Any]:
    manifest_path = business / "release_manifest.json"
    result_path = business / "validator_result.json"
    publication_path = business / "publication_final.md"
    manifest_sha = validate_named_sha256_sidecar(manifest_path)
    result_sha = validate_named_sha256_sidecar(result_path)
    manifest = strict_load_json(manifest_path)
    result = strict_load_json(result_path)
    verdict = str(manifest.get("overall_verdict") or manifest.get("verdict") or "")
    result_verdict = str(result.get("overall_verdict") or result.get("verdict") or "")
    if verdict not in {"PASS", "PUBLISHABLE"}:
        raise ValueError("release manifest verdict is not PASS")
    if result_verdict and result_verdict not in {"PASS", "PUBLISHABLE"}:
        raise ValueError("validator result verdict is not PASS")
    publication_sha = sha256_file(publication_path)
    expected_publication = manifest.get("publication_final_sha256")
    if expected_publication and expected_publication != publication_sha:
        raise ValueError("publication_final hash does not match release manifest")
    target_snapshot = snapshot_business(business)
    expected_snapshot = manifest.get("target_snapshot_sha256")
    if not isinstance(expected_snapshot, str) or expected_snapshot != target_snapshot:
        raise ValueError("business target snapshot is stale")
    binding = {
        "verdict": "PUBLISHABLE",
        "integrity_status": "CURRENT",
        "release_manifest_sha256": manifest_sha,
        "validator_result_sha256": result_sha,
        "target_snapshot_sha256": target_snapshot,
        "publication_final_sha256": publication_sha,
    }
    if state and state["publication_release"]["verdict"] == "PUBLISHABLE":
        previous = state["publication_release"]
        for key in (
            "release_manifest_sha256",
            "validator_result_sha256",
            "target_snapshot_sha256",
            "publication_final_sha256",
        ):
            if previous[key] != binding[key]:
                raise ValueError(f"publication release binding changed: {key}")
    return binding


def build_publication_handoff(
    state: dict[str, Any],
) -> tuple[Path, bytes, str]:
    """Build, but do not write, the deterministic P14→P16 handoff."""
    if not state["route"]["obsidian_enabled"]:
        raise ValueError("publication handoff is not valid for publication-only route")
    reference = state["roots"]["formal_vault_binding"]
    if not reference:
        raise ValueError("formal Vault configuration is required before handoff")
    runtime_root = runtime_root_from(state)
    load_binding_record(runtime_root, reference)
    obsidian_root = Path(state["roots"]["obsidian_run_root"])
    business = business_root(state)
    release = verify_publication_release_binding(state, business)
    seal_payload = {
        "business_root": str(business.resolve()),
        "target_snapshot_sha256": release["target_snapshot_sha256"],
        "release_manifest_sha256": release["release_manifest_sha256"],
    }
    seal_sha = sha256_bytes(canonical_json_bytes(seal_payload))
    artifacts = []
    for role, relative, required in HANDOFF_ARTIFACTS:
        artifact_path = business / relative
        if not artifact_path.is_file():
            if required:
                raise ValueError(
                    f"required publication handoff artifact is missing: {relative}"
                )
            continue
        artifacts.append({
            "artifact_role": role,
            "business_relative_path": relative,
            "sha256": sha256_file(artifact_path),
            "size": artifact_path.stat().st_size,
            "required": required,
        })
    manifest = {
        "handoff_schema_version": "publication-handoff-v1",
        "business_contract_version": (
            state["versions"]["obsidian_business_contract_version"]
            or "obsidian-business-contract-v0.1"
        ),
        **{
            key: release[key]
            for key in (
                "release_manifest_sha256",
                "validator_result_sha256",
                "target_snapshot_sha256",
                "publication_final_sha256",
            )
        },
        "business_domain_seal_sha256": seal_sha,
        "required_artifacts": artifacts,
        "created_from_phase_plan_revision": state["route"]["phase_plan_revision"],
        "created_by_handler": "prepare_publication_handoff",
    }
    validate_json_schema(manifest, "publication-handoff-v1.schema.json")
    path = obsidian_root / "handoff" / "publication_handoff_manifest.json"
    content = canonical_json_bytes(manifest)
    return path, content, sha256_bytes(content)


def prepare_publication_handoff(state: dict[str, Any]) -> tuple[Path, str]:
    """Compatibility wrapper for deterministic fixture/setup use."""
    path, content, digest = build_publication_handoff(state)
    atomic_write_text(path, content.decode("utf-8"))
    atomic_write_text(path.with_suffix(".sha256"), digest + "\n")
    return path, digest

def build_initial_state(
    runtime_root: Path,
    business: Path,
    source: Path,
    goal: str,
    route: dict[str, Any],
    *,
    vault_reference: dict[str, Any] | None,
    obsidian_root: Path | None,
) -> dict[str, Any]:
    now = utc_now()
    plan = list(route["ordered_phase_ids"])
    records = {phase_id: phase_record() for phase_id in plan}
    records["P00"]["status"] = "ACTIVE"
    return {
        "schema_version": STATE_SCHEMA,
        "runtime_contract_version": RUNTIME_CONTRACT_VERSION,
        "state_revision": 0,
        "created_at": now,
        "updated_at": now,
        "transition_head": {
            "last_applied_transition_id": None,
            "last_applied_transition_prepared_sha256": None,
        },
        "identity": {
            "job_id": f"JOB-{uuid.uuid4().hex[:12].upper()}",
            "run_id": f"RUN-{uuid.uuid4().hex[:12].upper()}",
            "thread_id": f"THREAD-{uuid.uuid4().hex[:12].upper()}",
            "codex_session_id": None,
        },
        "versions": {
            "agent_plugin_version": plugin_version(),
            "skill_package_version": (skill_root() / "VERSION").read_text(encoding="utf-8").strip(),
            "runtime_schema_version": STATE_SCHEMA,
            "runtime_contract_version": RUNTIME_CONTRACT_VERSION,
            "phase_catalog_version": PHASE_CATALOG_VERSION,
            "obsidian_business_contract_version": "obsidian-copy-first-contract-v1.0",
            "obsidian_schema_bundle_version": "obsidian-schema-bundle-copy-first-v1",
            "obsidian_renderer_version": None,
        },
        "roots": {
            "business_root": str(business),
            "runtime_root": str(runtime_root),
            "obsidian_run_root": str(obsidian_root) if obsidian_root else None,
            "formal_vault_binding": vault_reference,
        },
        "route": {
            key: route[key]
            for key in (
                "route_compiler_version",
                "skip_obsidian_requested",
                "obsidian_enabled",
                "configuration_state",
                "post_release_targets",
                "phase_plan_revision",
                "phase_catalog_version",
                "phase_plan_sha256",
                "previous_phase_plan_sha256",
                "ordered_phase_ids",
            )
        },
        "domain_states": {
            "BUSINESS": {
                "access_state": "READ_WRITE",
                "sealed_by_phase": None,
                "sealed_snapshot_sha256": None,
                "sealed_at": None,
            }
        },
        "workflow": {
            "status": "RUNNING",
            "terminal_result": None,
            "suspension_reason": None,
            "resume_phase": None,
        },
        "cursor": {
            "current_phase": "P00",
            "phase_index": 0,
            "attempt": 1,
            "recovery_epoch": 0,
            "current_role": get_phase("P00").role,
        },
        "publication_release": {
            "verdict": None,
            "integrity_status": "NOT_VALIDATED",
            "release_manifest_sha256": None,
            "validator_result_sha256": None,
            "target_snapshot_sha256": None,
            "publication_final_sha256": None,
        },
        "outputs": {
            "obsidian": {
                "mode": (
                    vault_reference.get("mode", "STAGING_ONLY")
                    if isinstance(vault_reference, dict)
                    else "STAGING_ONLY"
                ),
                "status": "NOT_REQUESTED" if not route["obsidian_enabled"] else "INDEX_PENDING",
                "current_generation": None,
                "active_manifest_sha256": None,
                "resume_phase": None,
                "blockers": [],
            }
        },
        "active": {
            "status": "READY",
            "action_id": None,
            "context_pack_sha256": None,
            "validation_receipt_id": None,
            "input_fingerprint": None,
            "repair_handoff": None,
        },
        "phase_records": records,
        "source": {
            "source_path": str(source),
            "global_goal": goal,
            "source_revision_id": None,
            "source_sha256": None,
        },
        "execution": {
            "run_mode": "source_atomization",
            "committed_phase_ids": [],
            "semantic_completion_evidence": [],
            "repair_counts": {},
        },
        "audit_heads": {
            "journal_head_sha256": None,
            "response_ledger_head_sha256": None,
        },
        "blockers": [],
    }


def cmd_bootstrap(args: argparse.Namespace) -> int:
    runtime_root = Path(args.runtime_root).resolve()
    business = resolve_business_arg(args)
    source = Path(args.source).resolve()
    task_contract_path = Path(args.task_contract).resolve()
    config_raw = getattr(args, "obsidian_config", None)
    skip = bool(getattr(args, "skip_obsidian", False))
    if runtime_root.exists() and any(runtime_root.iterdir()):
        raise ValueError(f"runtime root is not empty: {runtime_root}")
    if not source.is_file() or source.suffix.lower() != ".txt":
        raise ValueError("source must be an existing UTF-8 .txt file")
    source.read_text(encoding="utf-8", errors="strict")
    if not task_contract_path.is_file():
        raise ValueError("--task-contract must name an existing JSON file")
    task_contract = strict_load_json(task_contract_path)
    validate_json_schema(task_contract, "author-task-contract-v1.schema.json")
    goal = str(task_contract["author_request"])
    if getattr(args, "goal", None) and str(args.goal) != goal:
        raise ValueError("--goal conflicts with author_task_contract.json; the contract is authoritative")
    require_disjoint_roots(runtime_root, business)
    route = compile_route(RouteRequest(
        skip_obsidian=skip,
        obsidian_config_binding=str(Path(config_raw).resolve()) if config_raw else None,
    ))
    runtime_root.mkdir(parents=True, exist_ok=True)
    task_binding = runtime_root / "bindings" / "author-task-contract.json"
    atomic_write_text(
        task_binding,
        json.dumps(task_contract, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n",
    )
    atomic_write_text(task_binding.with_suffix(".sha256"), sha256_file(task_binding) + "\n")
    reference = None
    obsidian_root = None
    if route["obsidian_enabled"] and config_raw:
        reference, obsidian_root, _ = prepare_obsidian_binding(
            runtime_root,
            business,
            Path(config_raw),
            authorized_by=str(getattr(args, "authorized_by", None) or "bootstrap-cli"),
            authorization_event_id=str(getattr(args, "authorization_event_id", None) or f"AUTH-{uuid.uuid4().hex.upper()}"),
        )
    state = build_initial_state(
        runtime_root, business, source, goal, route,
        vault_reference=reference, obsidian_root=obsidian_root,
    )
    write_state(runtime_root, state)

    def commit_p00(result: dict[str, Any]) -> None:
        result["phase_records"]["P00"]["status"] = "COMMITTED"
        result["phase_records"]["P00"]["last_validation"] = {"reason": "runtime bootstrap"}
        result["phase_records"]["P01"]["status"] = "ACTIVE"
        result["execution"]["committed_phase_ids"] = ["P00"]
        result["cursor"].update({
            "current_phase": "P01",
            "phase_index": 1,
            "attempt": 1,
            "current_role": get_phase("P01").role,
        })

    final = apply_transition(
        runtime_root,
        state,
        transition_kind="PHASE_COMMIT",
        phase_id="P00",
        mutate=commit_p00,
        validate_state=validate_state_invariants,
        write_state=write_state,
        append_journal=append_journal,
        details={"reason": "runtime bootstrap"},
    )
    emit_json(final)
    return 0


def next_planned_phase(state: dict[str, Any], phase_id: str) -> str:
    plan = state["route"]["ordered_phase_ids"]
    index = plan.index(phase_id)
    return TERMINAL_PHASE if index + 1 >= len(plan) else plan[index + 1]


def commit_phase(
    runtime_root: Path,
    state: dict[str, Any],
    phase_id: str,
    *,
    details: dict[str, Any],
    extra_mutation: Any = None,
    before_state_replace: Any = None,
    lock_held: bool = False,
) -> dict[str, Any]:
    require_phase(state, phase_id)
    next_phase = next_planned_phase(state, phase_id)

    def mutate(result: dict[str, Any]) -> None:
        if extra_mutation:
            extra_mutation(result)
        record = result["phase_records"][phase_id]
        record["status"] = "COMMITTED"
        record["last_validation"] = details
        committed = result["execution"]["committed_phase_ids"]
        if phase_id not in committed:
            committed.append(phase_id)
        result["active"].update({
            "status": "READY",
            "action_id": None,
            "context_pack_sha256": None,
            "validation_receipt_id": None,
            "input_fingerprint": None,
        })
        result["execution"]["semantic_completion_evidence"] = []
        active_handoff = result.get("active", {}).get("repair_handoff")
        if (
            isinstance(active_handoff, dict)
            and active_handoff.get("status") == "IN_PROGRESS"
            and active_handoff.get("recheck_phase") == phase_id
        ):
            # The handoff remains available through every repaired upstream
            # phase, then closes only when the original failed boundary passes.
            result["active"]["repair_handoff"] = None
            result["blockers"] = []
        if next_phase == TERMINAL_PHASE:
            result["cursor"].update({
                "current_phase": TERMINAL_PHASE,
                "phase_index": len(result["route"]["ordered_phase_ids"]),
                "attempt": 1,
                "current_role": "",
            })
            result["workflow"].update({
                "status": "COMPLETED",
                "terminal_result": result["publication_release"]["verdict"] or phase_id,
                "suspension_reason": None,
                "resume_phase": None,
            })
        else:
            result["phase_records"][next_phase]["status"] = "ACTIVE"
            result["cursor"].update({
                "current_phase": next_phase,
                "phase_index": result["route"]["ordered_phase_ids"].index(next_phase),
                "attempt": result["phase_records"][next_phase]["attempt"],
                "current_role": get_phase(next_phase).role,
            })

    return apply_transition(
        runtime_root,
        state,
        transition_kind="PHASE_COMMIT",
        phase_id=phase_id,
        mutate=mutate,
        validate_state=validate_state_invariants,
        write_state=write_state,
        append_journal=append_journal,
        details={**details, "next_phase": next_phase},
        lock_held=lock_held,
    )


def _cmd_source_authority_locked(args: argparse.Namespace) -> int:
    runtime_root = Path(args.runtime_root).resolve()
    state = load_state(runtime_root)
    require_phase(state, "P01")
    business = business_root(state)
    source = Path(state["source"]["source_path"])
    task_contract = runtime_root / "bindings" / "author-task-contract.json"
    task_sidecar = task_contract.with_suffix(".sha256")
    if not task_contract.is_file() or not task_sidecar.is_file():
        raise ValueError("P00 author task contract binding is missing")
    if task_sidecar.read_text(encoding="utf-8").strip() != sha256_file(task_contract):
        raise ValueError("P00 author task contract binding is stale")
    command = [
        sys.executable,
        str(skill_root() / "scripts" / "pipeline.py"),
        "init",
        str(source),
        str(business),
        "--mode",
        "source_atomization",
        "--task-contract",
        str(task_contract),
    ]
    result = command_result(command, cwd=skill_root())
    append_journal(runtime_root, "COMMAND_EXECUTED", phase_id="P01", **result)
    run_or_raise(result)
    revision = strict_load_json(business / "source_revision.json")

    def update_source(current: dict[str, Any]) -> None:
        current["source"]["source_revision_id"] = revision["source_revision_id"]
        current["source"]["source_sha256"] = revision["canonical_source_sha256"]

    final = commit_phase(
        runtime_root,
        state,
        "P01",
        details={"validator": "pipeline init", "exit_code": 0},
        extra_mutation=update_source,
        lock_held=True,
    )
    emit_json(final)
    return 0


def cmd_source_authority(args: argparse.Namespace) -> int:
    runtime_root = Path(args.runtime_root).resolve()
    with exclusive_runtime_lock(runtime_root):
        state = load_state(runtime_root)
        repair_recovery(runtime_root, state)
        return _cmd_source_authority_locked(args)


def _cmd_source_model_locked(args: argparse.Namespace) -> int:
    runtime_root = Path(args.runtime_root).resolve()
    state = load_state(runtime_root)
    require_phase(state, "P02")
    business = business_root(state)
    scripts = skill_root() / "scripts"
    commands = [
        [sys.executable, str(scripts / "pipeline.py"), "prepare-source", str(business)],
        [sys.executable, str(scripts / "pipeline.py"), "validate", str(business), "--mode", "source_atomization"],
    ]
    records = []
    for command in commands:
        result = command_result(command, cwd=skill_root())
        records.append(result)
        append_journal(runtime_root, "COMMAND_EXECUTED", phase_id="P02", **result)
        run_or_raise(result)
    final = commit_phase(
        runtime_root,
        state,
        "P02",
        details={"validator": "source_atomization chain", "exit_code": 0, "commands": [item["command"] for item in records]},
        lock_held=True,
    )
    emit_json(final)
    return 0


def cmd_source_model(args: argparse.Namespace) -> int:
    runtime_root = Path(args.runtime_root).resolve()
    with exclusive_runtime_lock(runtime_root):
        state = load_state(runtime_root)
        repair_recovery(runtime_root, state)
        return _cmd_source_model_locked(args)


def phase_artifact_root(state: dict[str, Any], phase_id: str | None = None) -> Path:
    phase_id = phase_id or current_phase_id(state)
    if phase_id in {"P17", "P18", "P19", "P20", "P21"}:
        raw = state["roots"].get("obsidian_run_root")
        if not raw:
            raise ValueError("Obsidian artifact root is not configured")
        return Path(raw).resolve()
    return business_root(state)


def repository_root() -> Path:
    return Path(__file__).resolve().parents[1]


def repair_handoff_defect_instructions(handoff: dict[str, Any]) -> list[dict[str, Any]]:
    """Return the read-only, model-facing diagnosis carried by a handoff.

    Keep the full handoff as an immutable payload too; this projection makes
    the repair scope and acceptance tests visible in a fresh Context Envelope
    without asking the next worker to infer them from a filename.
    """
    return [
        {
            "defect_id": defect["defect_id"],
            "responsibility": defect["responsibility"],
            "first_loss_phase": defect["first_loss_phase"],
            "classification": defect["classification"],
            "observed_problem": defect["observed_problem"],
            "root_cause": defect["root_cause"],
            "required_repair": defect["required_repair"],
            "forbidden_shortcut": defect["forbidden_shortcut"],
            "acceptance_condition": defect["acceptance_condition"],
            "source_evidence": defect["source_evidence"],
            "target_evidence": defect["target_evidence"],
        }
        for defect in handoff["defects"]
    ]


def repair_handoff_context_payload(
    handoff: dict[str, Any], binding: dict[str, Any]
) -> dict[str, Any]:
    """Build the complete immutable repair diagnosis exposed to the next turn."""
    return {
        "binding": binding,
        "handoff_payload": json.loads(canonical_json_bytes(handoff)),
        "origin_phase": handoff["created_from"]["failed_phase"],
        "return_to_phase": handoff["return_to_phase"],
        "repair_attempt": handoff["repair_attempt"],
        "first_loss_boundary": handoff["first_loss_boundary"],
        "failure_class": handoff["failure_class"],
        "failure_class_note": handoff["failure_class_note"],
        "unresolved_items": list(handoff["unresolved_items"]),
        "defect_instructions": repair_handoff_defect_instructions(handoff),
        "required_action": (
            "Read this exact handoff before writing. Repair only the listed defects, "
            "then recheck the stated acceptance conditions at the origin phase."
        ),
    }


def build_context_envelope(state: dict[str, Any]) -> dict[str, Any]:
    phase = get_phase(current_phase_id(state))
    supported = {f"P{i:02d}" for i in range(3, 12)} | {"P13", "P17", "P18", "P19"}
    if phase.phase_id not in supported:
        raise ValueError(f"context routing is not implemented for {phase.phase_id}")
    artifact_root = phase_artifact_root(state, phase.phase_id)
    domain = "OBSIDIAN_RUNTIME" if phase.phase_id in {"P17", "P18", "P19"} else "BUSINESS"
    bindings: list[dict[str, Any]] = []
    control_bindings: list[dict[str, Any]] = []
    missing: list[str] = []
    input_manifest_binding: dict[str, Any] | None = None
    if phase.phase_id in {"P17", "P18", "P19"}:
        manifest_path, input_manifest, input_sha = ensure_input_manifest(
            state, phase.phase_id, current_phase_attempt(state)
        )
        for entry in input_manifest["artifacts"]:
            if "LLM" not in entry["consumers"] or not entry["exists"]:
                continue
            path = resolve_manifest_artifact(state, entry)
            bindings.append({
                "artifact_id": entry["artifact_id"],
                "domain": entry["domain"],
                "symbolic_root": entry["symbolic_root"],
                "path": str(path),
                "relative_path": entry["relative_path"],
                "sha256": entry["sha256"],
            })
        input_manifest_binding = {
            "schema_version": input_manifest["schema_version"],
            "path": str(manifest_path),
            "relative_path": manifest_path.relative_to(runtime_root_from(state)).as_posix(),
            "sha256": input_sha,
        }
    else:
        seen: set[str] = set()
        for rel in phase.required_reads:
            if rel in seen:
                continue
            seen.add(rel)
            path = safe_relative_target(artifact_root, rel)
            if path.is_file() and not path.is_symlink():
                bindings.append({
                    "domain": domain,
                    "path": str(path),
                    "relative_path": rel,
                    "sha256": sha256_file(path),
                })
            else:
                missing.append(rel)
        # A semantic phase often writes the article first and reviews it in a
        # later action of the same phase. Rebind existing phase outputs so the
        # Codex reviewer can inspect the exact bytes it is about to certify.
        for rel in phase.agent_writes:
            if rel in seen:
                for binding in bindings:
                    if binding.get("relative_path") == rel:
                        binding["binding_role"] = "PHASE_OUTPUT_CANDIDATE"
                        break
                continue
            path = safe_relative_target(artifact_root, rel)
            if path.is_file() and not path.is_symlink():
                seen.add(rel)
                bindings.append({
                    "domain": domain,
                    "path": str(path),
                    "relative_path": rel,
                    "sha256": sha256_file(path),
                    "binding_role": "PHASE_OUTPUT_CANDIDATE",
                })
        if phase.phase_id in {"P06", "P07", "P08", "P10", "P11"}:
            manifest_path = safe_relative_target(artifact_root, "context_pack_manifest.json")
            manifest = strict_load_json(manifest_path)
            if manifest.get("schema_version") != "context-pack-manifest-v2":
                raise ValueError("context_pack_manifest.json has an unsupported schema")
            if manifest.get("prepared_before_writing") is not True:
                raise ValueError("context_pack_manifest.json was not prepared before writing")
            context_rows = manifest.get("context_files")
            if not isinstance(context_rows, list):
                raise ValueError("context_pack_manifest.json context_files must be a list")
            manifest_paths = {
                str(row.get("path") or "")
                for row in context_rows
                if isinstance(row, dict) and row.get("path")
            }
            if phase.phase_id == "P06":
                required_manifest_paths = set(phase.required_reads) - {"context_pack_manifest.json"}
                chunk_root = artifact_root / "chunk_ledger"
                if chunk_root.is_dir():
                    required_manifest_paths.update(
                        path.relative_to(artifact_root).as_posix()
                        for path in chunk_root.iterdir()
                        if path.is_file() and not path.is_symlink()
                    )
                missing_manifest_paths = sorted(required_manifest_paths - manifest_paths)
                if missing_manifest_paths:
                    raise ValueError(
                        "context-pack manifest omits required P06 inputs: "
                        + ", ".join(missing_manifest_paths)
                    )
            for row in context_rows:
                if not isinstance(row, dict):
                    raise ValueError("context_pack_manifest.json contains a non-object row")
                rel = str(row.get("path") or "")
                expected_sha = str(row.get("sha256") or "")
                if not rel:
                    continue
                path = safe_relative_target(artifact_root, rel)
                if not path.is_file() or path.is_symlink():
                    raise ValueError(f"context-pack member is missing or unsafe: {rel}")
                actual_sha = sha256_file(path)
                if actual_sha != expected_sha:
                    raise ValueError(f"context-pack member hash is stale: {rel}")
                if rel in seen:
                    continue
                seen.add(rel)
                bindings.append({
                    "domain": domain,
                    "path": str(path),
                    "relative_path": rel,
                    "sha256": actual_sha,
                    "binding_role": "P05_CONTEXT_PACK_MEMBER",
                })
    if missing:
        raise ValueError(f"cannot route context for {phase.phase_id}; missing: {', '.join(missing)}")
    active_handoff_ref = state.get("active", {}).get("repair_handoff")
    active_handoff: dict[str, Any] | None = None
    if active_handoff_ref is not None:
        active_handoff = load_handoff(runtime_root_from(state), active_handoff_ref)
        if active_handoff.get("job_id") != state["identity"]["job_id"]:
            raise ValueError("repair handoff belongs to another job")
        if active_handoff.get("run_id") != state["identity"]["run_id"]:
            raise ValueError("repair handoff belongs to another run")
        if active_handoff.get("phase_plan_revision") != state["route"]["phase_plan_revision"]:
            raise ValueError("repair handoff belongs to another phase plan")
        created_from = active_handoff.get("created_from") or {}
        if created_from.get("failed_phase") != active_handoff_ref.get("origin_phase"):
            raise ValueError("repair handoff origin pointer does not match its file")
        control_path = handoff_path(runtime_root_from(state), str(active_handoff["handoff_id"]))
        control_bindings.append({
            "binding_role": "REPAIR_HANDOFF",
            "domain": "RUNTIME_CONTROL",
            "path": str(control_path),
            "relative_path": handoff_relative_path(str(active_handoff["handoff_id"])),
            "sha256": sha256_file(control_path),
        })
    rule_bindings = []
    for rel in rules_for_phase(phase.phase_id):
        if rel.startswith("@repo/"):
            path = repository_root() / rel[len("@repo/"):]
            display = rel
        else:
            path = skill_root() / rel
            display = rel
        if not path.is_file():
            raise ValueError(f"cannot route rule for {phase.phase_id}; missing: {rel}")
        rule_bindings.append({
            "path": str(path),
            "rule_relative_path": display,
            "sha256": sha256_file(path),
        })
    supervisor_binding = next(
        (
            binding
            for binding in rule_bindings
            if binding.get("rule_relative_path") == "references/SUPERVISOR_KERNEL.md"
        ),
        None,
    )
    if phase.phase_id in SUPERVISED_SEMANTIC_PHASES and supervisor_binding is None:
        raise ValueError(
            f"{phase.phase_id} context is missing the mandatory Supervisor Kernel binding"
        )
    envelope = {
        "contract_version": (
            "copy-first-obsidian-agent-contract-v1"
            if phase.phase_id in {"P17", "P18", "P19"}
            else "single-thread-agent-contract-v2"
        ),
        "job_id": state["identity"]["job_id"],
        "run_id": state["identity"]["run_id"],
        "thread_id": state["identity"]["thread_id"],
        "global_goal": state["source"]["global_goal"],
        "run_mode": state["execution"]["run_mode"],
        "skill_package_version": state["versions"]["skill_package_version"],
        "source_revision_id": state["source"]["source_revision_id"],
        "source_sha256": state["source"]["source_sha256"],
        "phase_plan_revision": state["route"]["phase_plan_revision"],
        "current_phase": phase.phase_id,
        "current_role": phase.role,
        "phase_attempt": current_phase_attempt(state),
        "state_revision": state["state_revision"],
        "artifact_domain_root": str(artifact_root),
        "required_reads": bindings,
        "required_control_reads": control_bindings,
        "required_rule_reads": rule_bindings,
        "allowed_write_targets": list(phase.agent_writes),
        "deterministic_command": phase.deterministic_command,
        "notes": phase.notes,
        "active_blockers": state["blockers"],
        "response_schema": str(repository_root() / ACTION_SCHEMA_RELATIVE_PATH),
        "completion_claim": (
            "The current Codex task may request validation only after a fresh native read-only "
            "sub-agent review that reopens the bound source and exact phase outputs. Runtime alone commits phases."
        ),
        "supervision": {
            "mode": "NATIVE_SUBAGENT_REVIEW" if phase.phase_id in SUPERVISED_SEMANTIC_PHASES else "DETERMINISTIC_ORCHESTRATED",
            "kernel": supervisor_binding,
            "review_loop": (
                "generate -> reopen current source and exact output -> PASS/PARTIAL/BLOCK -> repair -> recheck"
                if phase.phase_id in SUPERVISED_SEMANTIC_PHASES
                else "runtime validation and phase-specific deterministic checks"
            ),
            "reviewer_must_reopen_source": phase.phase_id in SUPERVISED_SEMANTIC_PHASES,
            "native_subagent_review_required": phase.phase_id in SUPERVISED_SEMANTIC_PHASES,
            "nested_codex_sessions_allowed": False,
            "worker_may_advance_without_review": False if phase.phase_id in SUPERVISED_SEMANTIC_PHASES else True,
        },
    }
    if active_handoff is not None:
        # A path/hash binding is necessary for provenance, but it is not
        # sufficient for a cold-start worker: the worker must receive the
        # actual diagnosis in the Context Envelope it is about to read.  Keep
        # the handoff payload immutable and source-bound while also retaining
        # the control-file binding as the authoritative on-disk copy.
        envelope["active_repair_handoff"] = repair_handoff_context_payload(
            active_handoff, control_bindings[0]
        )
    if input_manifest_binding is not None:
        envelope["input_manifest"] = input_manifest_binding
    phase_brief = phase_brief_for(phase.phase_id)
    if phase_brief is not None:
        envelope["phase_brief"] = phase_brief
    digest = sha256_bytes(canonical_json_bytes(envelope))
    envelope["context_pack_sha256"] = digest
    return envelope


def commit_context_envelope(runtime_root: Path, state: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    envelope = build_context_envelope(state)
    phase_id = current_phase_id(state)
    attempt = current_phase_attempt(state)
    context_path = runtime_root / "context-packs" / f"{phase_id}-attempt-{attempt}.json"
    context_content = canonical_json_bytes(envelope) + b"\n"
    context_sha = sha256_bytes(context_content)
    context_exists = context_path.exists()
    if context_exists and (context_path.is_symlink() or not context_path.is_file()):
        raise ValueError("Context Envelope target is missing, unsafe, or not a regular file")
    context_before_sha = sha256_file(context_path) if context_exists else None

    def mutate(result: dict[str, Any]) -> None:
        result["active"]["context_pack_sha256"] = envelope["context_pack_sha256"]
        result["active"]["status"] = "AWAITING_ACTION"
        result["active"]["validation_receipt_id"] = None
        if "input_manifest" in envelope:
            input_sha = envelope["input_manifest"]["sha256"]
            result["active"]["input_fingerprint"] = input_sha
            result["phase_records"][phase_id]["input_fingerprint"] = input_sha

    final = apply_transition(
        runtime_root,
        state,
        transition_kind="CONTEXT_PACK_COMMIT",
        phase_id=phase_id,
        mutate=mutate,
        validate_state=validate_state_invariants,
        write_state=write_state,
        append_journal=append_journal,
        details={
            "context_pack_sha256": envelope["context_pack_sha256"],
            "context_path": context_path.relative_to(runtime_root).as_posix(),
        },
        artifact_writes=[
            {
                "target_path": str(context_path),
                "target_relative_path": context_path.relative_to(runtime_root).as_posix(),
                "target_precondition": "PATH_MUST_EXIST" if context_exists else "PATH_MUST_NOT_EXIST",
                "expected_absent": not context_exists,
                "expected_before_sha256": context_before_sha,
                "planned_after_sha256": context_sha,
                "content": context_content,
            }
        ],
    )
    return envelope, final


def validate_bound_context(runtime_root: Path, state: dict[str, Any]) -> dict[str, Any]:
    """Re-hash every file bound to the active semantic turn."""
    phase_id = current_phase_id(state)
    attempt = current_phase_attempt(state)
    context_path = runtime_root / "context-packs" / f"{phase_id}-attempt-{attempt}.json"
    envelope = strict_load_json(context_path)
    declared = envelope.get("context_pack_sha256")
    unsigned = dict(envelope)
    unsigned.pop("context_pack_sha256", None)
    actual = sha256_bytes(canonical_json_bytes(unsigned))
    if not isinstance(declared, str) or declared != actual:
        raise ValueError("Context Envelope self-hash is invalid")
    if actual != current_context_hash(state):
        raise ValueError("Context Envelope differs from the active Runtime binding")
    if envelope.get("current_phase") != phase_id or envelope.get("phase_attempt") != attempt:
        raise ValueError("Context Envelope phase identity is stale")
    if envelope.get("job_id") != state["identity"]["job_id"] or envelope.get("run_id") != state["identity"]["run_id"]:
        raise ValueError("Context Envelope belongs to another Runtime job")

    manifest_binding = envelope.get("input_manifest")
    if phase_id in {"P17", "P18", "P19"}:
        if not isinstance(manifest_binding, dict):
            raise ValueError("semantic Context Envelope lacks a Phase I/O input manifest")
        expected_path = phase_manifest_path(state, phase_id, attempt, "input")
        if Path(str(manifest_binding.get("path"))).resolve() != expected_path.resolve():
            raise ValueError("Context Envelope points at an unexpected input manifest")
        input_sha = str(manifest_binding.get("sha256") or "")
        if input_sha != state["active"].get("input_fingerprint"):
            raise ValueError("active input fingerprint differs from the Context Envelope")
        if input_sha != state["phase_records"][phase_id].get("input_fingerprint"):
            raise ValueError("phase input fingerprint differs from the Context Envelope")
        validate_input_manifest_binding(state, phase_id, attempt, input_sha)

    for binding in envelope.get("required_reads", []):
        path = Path(str(binding["path"]))
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"Context required read is missing or unsafe: {path}")
        if sha256_file(path) != binding["sha256"]:
            raise ValueError(f"Context required read changed after binding: {path}")
    for binding in envelope.get("required_rule_reads", []):
        path = Path(str(binding["path"]))
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"Context rule read is missing or unsafe: {path}")
        if sha256_file(path) != binding["sha256"]:
            raise ValueError(f"Context rule changed after binding: {path}")
    for binding in envelope.get("required_control_reads", []):
        path = Path(str(binding["path"]))
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"Context control input is missing or unsafe: {path}")
        if sha256_file(path) != binding["sha256"]:
            raise ValueError(f"Context control input changed after binding: {path}")
    pointer = state.get("active", {}).get("repair_handoff")
    control = envelope.get("active_repair_handoff")
    if pointer is None and control is not None:
        raise ValueError("Context contains a Repair Handoff but State has no active pointer")
    if pointer is not None:
        if not isinstance(control, dict) or not isinstance(control.get("binding"), dict):
            raise ValueError("State has an active Repair Handoff but Context omitted its binding")
        binding = control["binding"]
        if binding.get("relative_path") != pointer.get("path") or binding.get("sha256") != pointer.get("sha256"):
            raise ValueError("Context Repair Handoff binding differs from State")
        loaded_handoff = load_handoff(runtime_root, pointer)
        bound_control = next(
            (
                row
                for row in envelope.get("required_control_reads", [])
                if isinstance(row, dict)
                and row.get("relative_path") == pointer.get("path")
            ),
            None,
        )
        if bound_control is None or binding != bound_control:
            raise ValueError("Context Repair Handoff binding is not the bound control read")
        expected_control = repair_handoff_context_payload(loaded_handoff, bound_control)
        if control != expected_control:
            raise ValueError("Context Repair Handoff payload differs from its immutable control file")
    return envelope


def cmd_emit_turn(args: argparse.Namespace) -> int:
    runtime_root = Path(args.runtime_root).resolve()
    state = load_state(runtime_root)
    # Finish an interrupted transition before deriving a new Context
    # Envelope.  Without this reload, a crash during handoff/context commit
    # can leave the command using the pre-transition state and binding stale
    # files (or refusing to continue because an artifact already exists).
    repair_recovery(runtime_root, state)
    state = load_state(runtime_root)
    require_phase(state, current_phase_id(state))
    if state.get("active", {}).get("status") in {"ACTION_VALIDATED", "VALIDATION_REQUESTED"}:
        raise ValueError(
            "cannot emit a new Context Envelope after validation; execute the active receipt or recover first"
        )
    # ``emit-turn`` is a read boundary, not a new semantic turn.  Re-emitting
    # while the phase is already waiting for the same response used to commit
    # a fresh transition every time.  Because state_revision is itself bound
    # into the envelope, that loop invalidated the response it had just given
    # the worker and could continue indefinitely (the historical P03 runs show
    # this exact same-attempt context commit repeated many times).  Treat a
    # valid active envelope as immutable and idempotently return it.
    if (
        state.get("active", {}).get("status") == "AWAITING_ACTION"
        and state.get("active", {}).get("context_pack_sha256")
    ):
        envelope = validate_bound_context(runtime_root, state)
        emit_json(envelope)
        return 0
    envelope, _ = commit_context_envelope(runtime_root, state)
    emit_json(envelope)
    return 0


def validate_action_semantics(state: dict[str, Any], response: dict[str, Any]) -> None:
    phase = get_phase(current_phase_id(state))
    if response.get("phase_id") != phase.phase_id:
        raise ValueError("action response phase_id does not match Runtime State")
    if response.get("context_pack_sha256") != current_context_hash(state):
        raise ValueError("action response is stale or bound to another context pack")
    actions = response["actions"]
    claim = response.get("phase_completion_claim") or {}
    # A writer may report ordinary in-progress PARTIAL work together with a
    # single artifact action.  A semantic repair handoff is different: it is
    # a terminal review decision and must be committed as its own empty-action
    # transaction, never mixed with a write that could invalidate its evidence.
    if actions and claim.get("ready") is False and claim.get("repair_handoff") is not None:
        raise ValueError(
            "a Repair Handoff cannot be combined with an artifact action; submit an empty action blocker"
        )
    if not actions:
        if claim.get("ready") is True and response.get("status") != "PHASE_READY":
            raise ValueError("a ready completion claim must use status=PHASE_READY")
        if claim.get("ready") is False and response.get("status") != "BLOCKER_FOUND":
            raise ValueError("a non-ready completion claim must use status=BLOCKER_FOUND")
    for action in actions:
        action_type = action["action_type"]
        if action["phase_id"] != phase.phase_id:
            raise ValueError("action phase_id does not match Runtime State")
        target = str(action.get("target") or "")
        if action_type in {"WRITE_PHASE_ARTIFACT", "UPDATE_PHASE_ARTIFACT"}:
            if target not in phase.agent_writes:
                raise ValueError(f"write target is not allowed in {phase.phase_id}: {target!r}")
            if target in MACHINE_EVIDENCE_TARGETS or target.startswith("validator_evidence/"):
                raise ValueError("machine evidence is never a Codex write target")
        if action_type == "UPDATE_PHASE_ARTIFACT":
            payload = action.get("payload") or {}
            if not payload.get("expected_target_sha256"):
                raise ValueError("UPDATE_PHASE_ARTIFACT requires expected_target_sha256")
    if phase.phase_id in {"P17", "P18", "P19"} and actions:
        ordered = list(phase.agent_writes)
        artifact_root = phase_artifact_root(state, phase.phase_id)
        next_missing = next((item for item in ordered if not (artifact_root / item).is_file()), None)
        action = actions[0]
        if next_missing is not None and (
            action["action_type"] != "WRITE_PHASE_ARTIFACT"
            or action["target"] != next_missing
        ):
            raise ValueError(
                f"{phase.phase_id} requires ordered artifact production; next target is {next_missing!r}"
            )
    if phase.phase_id in {"P17", "P18", "P19"} and not actions:
        missing = require_phase_outputs(state, phase.phase_id)
        if response["phase_completion_claim"]["ready"] and missing:
            raise ValueError(
                f"{phase.phase_id} cannot request validation before producing: {', '.join(missing)}"
            )


def require_current_epoch_output_actions(
    state: dict[str, Any], phase_id: str
) -> None:
    phase = get_phase(phase_id)
    record = state.get("phase_records", {}).get(phase_id)
    if not isinstance(record, dict):
        raise ValueError(f"{phase_id} phase record is missing")
    written_targets = set(record.get("written_targets", []))
    unwritten = [rel for rel in phase.agent_writes if rel not in written_targets]
    if unwritten:
        raise ValueError(
            f"{phase_id} outputs lack current-epoch Action provenance: "
            + ", ".join(unwritten)
        )


def validate_serial_completion_claim(
    state: dict[str, Any],
    envelope: dict[str, Any],
    response: dict[str, Any],
    *,
    response_sha256: str | None = None,
) -> dict[str, Any] | None:
    """Validate a native read-only sub-agent review without making it machine-semantic.

    Semantic equivalence remains an AI editorial judgment. Runtime verifies that
    the judgment reopens the exact bound input and every declared phase output,
    cites text that really exists, and becomes stale after any byte change.
    """
    if response["actions"]:
        if response["phase_completion_claim"].get("ready") is False:
            # This is the normal writer loop (an action is still being
            # proposed), not a repair decision.  A real PARTIAL/BLOCK repair
            # is handled below and must contain a complete structured handoff.
            if response["phase_completion_claim"].get("repair_handoff") is not None:
                raise ValueError(
                    "a Repair Handoff requires an empty action list so its evidence remains immutable"
                )
        return
    claim = response["phase_completion_claim"]
    if not claim["ready"]:
        if claim.get("verdict") not in {"PARTIAL", "BLOCK"}:
            raise ValueError("an empty non-ready action must report PARTIAL or BLOCK")
        if response_sha256 is None:
            # Direct callers/tests may not have a response file.  Production
            # validation always supplies the actual response hash.
            response_sha256 = "0" * 64
        return validate_repair_handoff_claim(
            claim,
            state=state,
            envelope=envelope,
            phase_id=current_phase_id(state),
            ordered_phase_ids=state.get("route", {}).get("ordered_phase_ids", routable_phase_ids()),
            phase_outputs=get_phase(current_phase_id(state)).agent_writes,
            response_sha256=response_sha256,
        )
    if claim.get("review_mode") != "NATIVE_SUBAGENT_REVIEW":
        raise ValueError("phase completion requires NATIVE_SUBAGENT_REVIEW")
    if claim.get("verdict") != "PASS" or claim.get("unresolved_items"):
        raise ValueError("phase completion requires PASS with no unresolved items")

    phase = get_phase(current_phase_id(state))
    require_current_epoch_output_actions(state, phase.phase_id)

    source_bindings = {
        str(item.get("relative_path")): item
        for item in envelope.get("required_reads", [])
        if isinstance(item, dict)
        and item.get("relative_path")
        and item.get("binding_role") != "PHASE_OUTPUT_CANDIDATE"
    }
    target_bindings = {
        str(item.get("relative_path")): item
        for item in envelope.get("required_reads", [])
        if isinstance(item, dict)
        and item.get("relative_path")
        and item.get("binding_role") == "PHASE_OUTPUT_CANDIDATE"
    }
    artifact_root = phase_artifact_root(state, phase.phase_id)
    covered_targets: set[str] = set()
    reviewed_sources: set[str] = set()
    reviewed_realizations: dict[str, set[tuple[str, str, str]]] = {}
    reviewed_obligation_ids: dict[tuple[str, str, str, str], set[str]] = {}
    # P04 is the one phase that decides the *complete* responsibility set for
    # each Atom.  A review of only the REQUIRED functions is under-declared by
    # construction: it gives the reviewer no auditable opportunity to say why
    # the other semantic dimensions are absent.  Keep a full decision map for
    # all nine dimensions and compare it with the current blueprint below.
    p04_reviewed_matrix: dict[tuple[str, str], str] = {}
    p04_reviewed_source_evidence: dict[tuple[str, str], str] = {}
    p04_atom_excerpts: dict[str, str] = {}
    if phase.phase_id == "P04":
        atom_ledger_path = safe_relative_target(
            artifact_root, "source_atom_ledger.jsonl"
        )
        if not atom_ledger_path.is_file():
            raise ValueError("P04 semantic review requires source_atom_ledger.jsonl")
        p04_atom_excerpts = {
            str(row.get("atom_id")): str(row.get("raw_excerpt", ""))
            for row in read_jsonl_objects(atom_ledger_path)
        }
    p04_reviewed_obligation_ids: dict[tuple[str, str], set[str]] = {}
    p03_reviewed_obligations: dict[str, str] = {}
    semantic_target_by_phase = {
        "P05": {"section_execution_plan.jsonl"},
        "P06": {"draft.md"},
        "P07": {"final.md"},
        "P08": {"optimized_final.md", "standardized_final.md"},
        "P10": {"revised_final.md"},
        "P11": {"aigc_rewritten_final.md"},
        "P13": {"publication_final.md"},
    }
    semantic_targets = semantic_target_by_phase.get(phase.phase_id, set())
    for index, item in enumerate(claim.get("evidence", []), 1):
        source_rel = str(item.get("source_path") or "")
        target_rel = str(item.get("target_path") or "")
        source_binding = source_bindings.get(source_rel)
        if source_binding is None:
            raise ValueError(
                f"completion evidence {index} source is not a bound phase input: {source_rel!r}"
            )
        source_path = Path(str(source_binding["path"]))
        target_path = safe_relative_target(artifact_root, target_rel)
        if target_rel not in set(phase.agent_writes) | semantic_targets:
            raise ValueError(
                f"completion evidence {index} target is not a declared phase output: {target_rel!r}"
            )
        target_binding = target_bindings.get(target_rel)
        if target_binding is None:
            if target_rel in semantic_targets:
                target_binding = source_bindings.get(target_rel)
            if target_binding is None:
                raise ValueError(
                    f"completion evidence {index} target was not bound as a phase candidate: "
                    f"{target_rel!r}; emit a fresh turn after the last write"
                )
        if not target_path.is_file() or target_path.is_symlink():
            raise ValueError(f"completion evidence target is missing or unsafe: {target_rel}")
        if item.get("source_sha256") != sha256_file(source_path):
            raise ValueError(f"completion evidence source hash is stale: {source_rel}")
        if item.get("target_sha256") != sha256_file(target_path):
            raise ValueError(f"completion evidence target hash is stale: {target_rel}")
        if target_binding.get("sha256") != item.get("target_sha256"):
            raise ValueError(f"completion evidence target differs from the bound candidate: {target_rel}")
        source_excerpt = str(item.get("source_excerpt") or "")
        target_excerpt = str(item.get("target_excerpt") or "")
        if source_excerpt not in source_path.read_text(encoding="utf-8", errors="strict"):
            raise ValueError(f"completion source excerpt is absent from {source_rel}")
        if target_excerpt not in target_path.read_text(encoding="utf-8", errors="strict"):
            raise ValueError(f"completion target excerpt is absent from {target_rel}")
        if target_rel in phase.agent_writes:
            covered_targets.add(target_rel)
        reviewed_sources.add(source_rel)
        atom_id = str(item.get("atom_id") or "")
        function = str(item.get("function") or "")
        realization_id = str(item.get("realization_id") or "")
        if phase.phase_id == "P03" and item.get("source_obligation_ids"):
            obligation_ids = [str(value) for value in item["source_obligation_ids"]]
            if len(obligation_ids) != 1:
                raise ValueError(
                    f"completion evidence {index} must review one P03 source obligation at a time"
                )
            obligation_id = obligation_ids[0]
            if obligation_id in p03_reviewed_obligations:
                raise ValueError(f"duplicate P03 semantic review evidence for {obligation_id}")
            p03_reviewed_obligations[obligation_id] = target_rel
        if atom_id or function or realization_id:
            if phase.phase_id == "P04" and atom_id and function and not realization_id:
                if source_rel != "source_canonical.txt" or target_rel != "publication_blueprint.json":
                    raise ValueError(
                        f"completion evidence {index} P04 Atom/function judgment must compare source_canonical.txt with publication_blueprint.json"
                    )
                pair = (atom_id, function)
                decision = str(item.get("function_decision") or "").strip().upper()
                if decision not in {"REQUIRED", "NOT_REQUIRED"}:
                    raise ValueError(
                        f"completion evidence {index} P04 Atom/function judgment must state function_decision=REQUIRED or NOT_REQUIRED"
                    )
                if pair in p04_reviewed_matrix:
                    raise ValueError(
                        f"duplicate P04 semantic review evidence for {atom_id}/{function}"
                    )
                p04_reviewed_matrix[pair] = decision
                atom_excerpt = p04_atom_excerpts.get(atom_id)
                if atom_excerpt is None:
                    raise ValueError(
                        f"completion evidence {index} cites unknown P04 Atom {atom_id}"
                    )
                if source_excerpt not in atom_excerpt:
                    raise ValueError(
                        f"completion evidence {index} P04 source excerpt is not inside the exact Atom {atom_id}"
                    )
                p04_reviewed_source_evidence[pair] = source_excerpt
                p04_reviewed_obligation_ids[pair] = {
                    str(value) for value in item.get("source_obligation_ids", [])
                }
                continue
            if not (atom_id and function and realization_id):
                raise ValueError(
                    f"completion evidence {index} must supply atom_id, function, and realization_id together"
                )
            if target_rel not in semantic_targets:
                raise ValueError(
                    f"completion evidence {index} Atom/function judgment must target the actual phase article boundary"
                )
            if source_rel != "source_canonical.txt":
                raise ValueError(
                    f"completion evidence {index} Atom/function judgment must reopen source_canonical.txt"
                )
            reviewed_realizations.setdefault(target_rel, set()).add(
                (atom_id, function, realization_id)
            )
            reviewed_obligation_ids[(target_rel, atom_id, function, realization_id)] = {
                str(value) for value in item.get("source_obligation_ids", [])
            }

    missing = sorted(set(phase.agent_writes) - covered_targets)
    if missing:
        raise ValueError(
            "serial completion review does not cover every declared phase output: "
            + ", ".join(missing)
        )
    business_review_phases = {f"P{number:02d}" for number in range(3, 12)} | {"P13"}
    if phase.phase_id in business_review_phases and "source_canonical.txt" not in reviewed_sources:
        raise ValueError("serial completion review must reopen source_canonical.txt")
    if phase.phase_id in {"P06", "P07", "P08", "P09", "P10", "P11", "P13"}:
        if "section_execution_plan.jsonl" not in reviewed_sources:
            raise ValueError(
                "serial completion review must reopen the P05 section_execution_plan.jsonl"
            )
    if phase.phase_id in {"P05", "P06", "P07", "P08", "P10", "P11", "P13"}:
        plan_path = safe_relative_target(artifact_root, "section_execution_plan.jsonl")
        expected_realizations: set[tuple[str, str, str]] = set()
        for row in read_jsonl_objects(plan_path):
            raw = row.get("function_realization_plan_json")
            realizations = json.loads(raw) if isinstance(raw, str) else raw
            if not isinstance(realizations, list):
                raise ValueError("P05 function_realization_plan_json must be a list")
            for realization in realizations:
                if not isinstance(realization, dict):
                    raise ValueError("P05 realization plan contains a non-object")
                expected_realizations.add(
                    (
                        str(realization.get("atom_id") or ""),
                        str(realization.get("function") or ""),
                        str(realization.get("realization_id") or ""),
                    )
                )
        expected_obligation_ids: dict[tuple[str, str, str], set[str]] = {}
        for row in read_jsonl_objects(plan_path):
            raw = row.get("function_realization_plan_json")
            realizations = json.loads(raw) if isinstance(raw, str) else raw
            for realization in realizations:
                raw_ids = realization.get("source_obligation_ids", [])
                values = raw_ids if isinstance(raw_ids, list) else re.split(
                    r"[,;\s]+", str(raw_ids or "")
                )
                key = (
                    str(realization.get("atom_id") or ""),
                    str(realization.get("function") or ""),
                    str(realization.get("realization_id") or ""),
                )
                expected_obligation_ids[key] = {
                    str(value) for value in values if str(value).strip()
                }
        for semantic_target in sorted(semantic_targets):
            actual_for_target = reviewed_realizations.get(semantic_target, set())
            missing_realizations = sorted(expected_realizations - actual_for_target)
            extra_realizations = sorted(actual_for_target - expected_realizations)
            if missing_realizations:
                raise ValueError(
                    f"native sub-agent review of {semantic_target} does not cover every "
                    "P05 Atom/function realization: "
                    + ", ".join(
                        f"{atom_id}/{function}/{realization_id}"
                        for atom_id, function, realization_id in missing_realizations[:16]
                    )
                )
            if extra_realizations:
                raise ValueError(
                    f"native sub-agent review of {semantic_target} cites unknown P05 realizations: "
                    + ", ".join(
                        f"{atom_id}/{function}/{realization_id}"
                        for atom_id, function, realization_id in extra_realizations[:16]
                    )
                )
            for key, obligation_ids in expected_obligation_ids.items():
                actual_ids = reviewed_obligation_ids.get(
                    (semantic_target, *key), set()
                )
                if actual_ids != obligation_ids:
                    raise ValueError(
                        f"native sub-agent review of {semantic_target} has stale source "
                        f"obligation identity for {key[0]}/{key[1]}/{key[2]}"
                    )
        missing_semantic_targets = sorted(
            semantic_targets
            - {
                str(item.get("target_path") or "")
                for item in claim.get("evidence", [])
                if item.get("atom_id")
            }
        )
        if missing_semantic_targets:
            raise ValueError(
                "native sub-agent review lacks Atom/function evidence against article boundary: "
                + ", ".join(missing_semantic_targets)
            )
    if phase.phase_id == "P03":
        expected_p03_targets: dict[str, str] = {}
        ledger_policies = (
            (
                "author_question_obligation_ledger.jsonl",
                "AQ",
                "question_id",
                lambda row: str(row.get("obligation_type", "")).upper()
                not in {
                    "P02_SEMANTIC_CANDIDATE",
                    "SOURCE_WIDE_SEMANTIC_SCAN",
                    "DISMISSED_P02_CANDIDATE",
                    "NO_AUTHOR_QUESTIONS",
                }
                and str(row.get("resolution_status", "")).upper()
                not in {"DISMISSED_NOT_AN_OBLIGATION", "NO_AUTHOR_QUESTIONS"},
            ),
            (
                "source_formula_block_ledger.jsonl",
                "FB",
                "formula_block_id",
                lambda row: str(row.get("canonicalization_status", "")).upper()
                == "CANONICALIZED",
            ),
            (
                "source_math_risk_ledger.jsonl",
                "MR",
                "risk_id",
                lambda row: str(row.get("resolution_status", "")).upper()
                in {
                    "MATH_SEMANTIC_SCAN_COMPLETE",
                    "NO_MATHEMATICAL_RISKS",
                    "RESOLVED_WITH_JUSTIFICATION",
                },
            ),
        )
        for rel, prefix, id_field, include in ledger_policies:
            for row in read_jsonl_objects(safe_relative_target(artifact_root, rel)):
                if include(row):
                    obligation_id = str(row.get(id_field) or "")
                    if not re.fullmatch(rf"{prefix}\d{{3,}}", obligation_id):
                        raise ValueError(f"P03 source obligation has invalid identity: {obligation_id!r}")
                    expected_p03_targets[obligation_id] = rel
        if set(p03_reviewed_obligations) != set(expected_p03_targets):
            missing_ids = sorted(set(expected_p03_targets) - set(p03_reviewed_obligations))
            extra_ids = sorted(set(p03_reviewed_obligations) - set(expected_p03_targets))
            details = []
            if missing_ids:
                details.append("missing=" + ",".join(missing_ids))
            if extra_ids:
                details.append("unknown=" + ",".join(extra_ids))
            raise ValueError(
                "native sub-agent P03 review must cover every actionable source obligation: "
                + " ".join(details)
            )
        for obligation_id, expected_target in expected_p03_targets.items():
            if p03_reviewed_obligations[obligation_id] != expected_target:
                raise ValueError(
                    f"P03 review of {obligation_id} must target its authoritative ledger {expected_target}"
                )
    if phase.phase_id == "P04":
        blueprint = strict_load_json(
            safe_relative_target(artifact_root, "publication_blueprint.json")
        )
        expected_p04_matrix: dict[tuple[str, str], str] = {}
        expected_p04_source_evidence: dict[tuple[str, str], str] = {}
        expected_pair_obligations: dict[tuple[str, str], set[str]] = {}
        function_order = (
            "SUBSTANTIVE_CONTENT",
            "QUESTION_OR_DOUBT",
            "EXPLANATION_CHAIN",
            "METHOD_OBSERVATION",
            "AUTHOR_PERSPECTIVE",
            "INTUITION_OR_ANALOGY",
            "PROOF_DEPENDENCY",
            "FOLLOWUP_REQUEST",
            "WARNING_OR_CONTRAST",
        )
        for contract in blueprint.get("atom_function_contracts", []):
            atom_id = str(contract.get("atom_id") or "")
            matrix = contract.get("function_matrix")
            if not isinstance(matrix, dict):
                raise ValueError(
                    f"P04 contract {atom_id} lacks the complete function_matrix"
                )
            for function in function_order:
                entry = matrix.get(function)
                if not isinstance(entry, dict):
                    raise ValueError(
                        f"P04 contract {atom_id} lacks a function_matrix entry for {function}"
                    )
                decision = str(entry.get("status", entry.get("decision", ""))).strip().upper()
                if decision not in {"REQUIRED", "NOT_REQUIRED"}:
                    raise ValueError(
                        f"P04 contract {atom_id}/{function} has invalid function_matrix status"
                    )
                expected_p04_matrix[(atom_id, function)] = decision
                source_evidence = str(entry.get("source_evidence", ""))
                if not source_evidence:
                    raise ValueError(
                        f"P04 contract {atom_id}/{function} lacks function_matrix source_evidence"
                    )
                expected_p04_source_evidence[(atom_id, function)] = source_evidence
        for obligation in blueprint.get("source_obligation_contracts", []):
            obligation_id = str(obligation.get("obligation_id") or "")
            for binding in obligation.get("function_bindings", []):
                pair = (
                    str(binding.get("atom_id") or ""),
                    str(binding.get("function") or ""),
                )
                expected_pair_obligations.setdefault(pair, set()).add(obligation_id)
        if p04_reviewed_matrix != expected_p04_matrix:
            missing_pairs = sorted(set(expected_p04_matrix) - set(p04_reviewed_matrix))
            extra_pairs = sorted(set(p04_reviewed_matrix) - set(expected_p04_matrix))
            mismatched = sorted(
                pair
                for pair in set(expected_p04_matrix) & set(p04_reviewed_matrix)
                if expected_p04_matrix[pair] != p04_reviewed_matrix[pair]
            )
            details = []
            if missing_pairs:
                details.append(
                    "missing=" + ",".join(f"{atom}/{function}" for atom, function in missing_pairs[:16])
                )
            if extra_pairs:
                details.append(
                    "unknown=" + ",".join(f"{atom}/{function}" for atom, function in extra_pairs[:16])
                )
            if mismatched:
                details.append(
                    "decision-mismatch=" + ",".join(
                        f"{atom}/{function}({p04_reviewed_matrix[(atom, function)]}!={expected_p04_matrix[(atom, function)]})"
                        for atom, function in mismatched[:16]
                    )
                )
            raise ValueError(
                "native sub-agent P04 review must cover every Atom/function decision: "
                + " ".join(details)
            )
        for pair, decision in expected_p04_matrix.items():
            if p04_reviewed_source_evidence.get(pair) != expected_p04_source_evidence[pair]:
                raise ValueError(
                    f"native sub-agent P04 review has source evidence different from the function_matrix for {pair[0]}/{pair[1]}"
                )
            if decision == "NOT_REQUIRED" and p04_reviewed_obligation_ids.get(pair, set()):
                raise ValueError(
                    f"native sub-agent P04 review has source obligations bound to NOT_REQUIRED function {pair[0]}/{pair[1]}"
                )
        for pair, decision in expected_p04_matrix.items():
            if decision != "REQUIRED":
                continue
            if p04_reviewed_obligation_ids.get(pair, set()) != expected_pair_obligations.get(pair, set()):
                raise ValueError(
                    f"native sub-agent P04 review has stale source-obligation identity for {pair[0]}/{pair[1]}"
                )
    return None


def artifact_contract_sha(state: dict[str, Any]) -> str:
    phase = get_phase(current_phase_id(state))
    payload = {
        "phase_id": phase.phase_id,
        "agent_writes": list(phase.agent_writes),
        "machine_evidence_forbidden": sorted(MACHINE_EVIDENCE_TARGETS),
        "business_access_state": state["domain_states"]["BUSINESS"]["access_state"],
    }
    return sha256_bytes(canonical_json_bytes(payload))


def receipt_dir(runtime_root: Path, receipt_id: str) -> Path:
    return runtime_root / "receipts" / receipt_id


def receipt_marker(runtime_root: Path, receipt_id: str, status: str) -> Path:
    return receipt_dir(runtime_root, receipt_id) / f"{status.lower()}.json"


def write_receipt_marker(runtime_root: Path, receipt_id: str, status: str, value: dict[str, Any]) -> str:
    path = receipt_marker(runtime_root, receipt_id, status)
    if path.exists():
        raise ValueError(f"receipt marker already exists: {path}")
    return write_hashed_json(path, value)


def load_valid_receipt(runtime_root: Path, receipt_id: str) -> dict[str, Any]:
    validated = receipt_marker(runtime_root, receipt_id, "VALID")
    if not validated.is_file():
        raise ValueError("validation receipt is missing")
    validate_bare_sha256_sidecar(validated)
    receipt = strict_load_json(validated)
    validate_json_schema(receipt, "action-validation-receipt-v1.schema.json")
    for terminal in ("CONSUMED", "STALE", "REVOKED"):
        if receipt_marker(runtime_root, receipt_id, terminal).exists():
            raise ValueError(f"validation receipt is not executable: {terminal}")
    return receipt


def cmd_validate_action(args: argparse.Namespace) -> int:
    runtime_root = Path(args.runtime_root).resolve()
    state = load_state(runtime_root)
    repair_recovery(runtime_root, state)
    state = load_state(runtime_root)
    require_phase(state, current_phase_id(state))
    if state.get("active", {}).get("status") != "AWAITING_ACTION":
        raise ValueError(
            "action validation requires the current AWAITING_ACTION Context Envelope"
        )
    envelope = validate_bound_context(runtime_root, state)
    response_path = Path(args.response).resolve()
    response = strict_load_json(response_path)
    validate_json_schema(response, "action-response.schema.json")
    validate_action_semantics(state, response)
    validate_action_payload_content(runtime_root, state, response)
    response_sha = sha256_file(response_path)
    validated_handoff = validate_serial_completion_claim(
        state, envelope, response, response_sha256=response_sha
    )
    receipt_id = f"RCT-{uuid.uuid4().hex.upper()}"
    resulting_revision = state["state_revision"] + 1
    receipt = {
        "schema_version": "action-validation-receipt-v1",
        "receipt_id": receipt_id,
        "status": "VALID",
        "response_sha256": response_sha,
        "phase_plan_revision": state["route"]["phase_plan_revision"],
        "phase_id": current_phase_id(state),
        "phase_attempt": current_phase_attempt(state),
        "state_revision": resulting_revision,
        "context_pack_sha256": current_context_hash(state),
        "action_schema_version": "urn:math-longform-agent:schema:action-response:v2",
        "artifact_contract_sha256": artifact_contract_sha(state),
        "repair_handoff_id": (
            validated_handoff.get("handoff_id") if isinstance(validated_handoff, dict) else None
        ),
        "repair_handoff_fingerprint": (
            validated_handoff.get("failure_fingerprint") if isinstance(validated_handoff, dict) else None
        ),
        "validated_at": utc_now(),
    }
    validate_json_schema(receipt, "action-validation-receipt-v1.schema.json")
    receipt_sha = write_receipt_marker(runtime_root, receipt_id, "VALID", receipt)

    def mutate(result: dict[str, Any]) -> None:
        result["active"]["validation_receipt_id"] = receipt_id
        result["active"]["status"] = "ACTION_VALIDATED"

    final = apply_transition(
        runtime_root,
        state,
        transition_kind="ACTION_VALIDATION",
        phase_id=current_phase_id(state),
        mutate=mutate,
        validate_state=validate_state_invariants,
        write_state=write_state,
        append_journal=append_journal,
        details={
            "receipt_id": receipt_id,
            "receipt_sha256": receipt_sha,
            "response_sha256": response_sha,
            "action_count": len(response["actions"]),
            "review_mode": response["phase_completion_claim"].get("review_mode"),
            "review_verdict": response["phase_completion_claim"].get("verdict"),
        },
    )
    if final["state_revision"] != receipt["state_revision"]:
        raise RuntimeError("receipt revision binding failed")
    emit_json({
        "valid": True,
        "phase_id": current_phase_id(final),
        "action_count": len(response["actions"]),
        "executed": False,
        "receipt_id": receipt_id,
        "receipt_path": str(receipt_marker(runtime_root, receipt_id, "VALID")),
    })
    return 0


def business_target(root: Path, relative: str) -> Path:
    if not relative:
        raise ValueError("action target must be nonempty")
    return safe_relative_target(root, relative)


def staged_content(runtime_root: Path, relative: str, expected_sha256: str | None) -> str:
    path = safe_relative_target(runtime_root / "staged-actions", relative)
    if not path.is_file():
        raise ValueError(f"staged action content is missing: {relative}")
    if not expected_sha256 or sha256_file(path) != expected_sha256:
        raise ValueError("staged action content hash is missing or stale")
    return path.read_text(encoding="utf-8", errors="strict")


def validate_content_for_target(
    target: Path,
    content: str,
    declared_format: str,
    *,
    relative_path: str | None = None,
) -> None:
    json_value: Any = None
    if declared_format == "json" or target.suffix.lower() == ".json":
        json_value = strict_json_loads(content)
        if not isinstance(json_value, (dict, list)):
            raise ValueError(f"{target.name} JSON root must be an object or array")
        schema_name = semantic_schema_for(relative_path or "")
        if schema_name:
            validate_json_schema(json_value, schema_name)
    if declared_format == "jsonl" or target.suffix.lower() == ".jsonl":
        rows = 0
        for line_no, line in enumerate(content.splitlines(), 1):
            if not line.strip():
                continue
            value = strict_json_loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"{target.name}:{line_no} must contain one JSON object")
            rows += 1
        if rows == 0:
            raise ValueError(f"{target.name} must contain at least one JSONL row")


def validate_action_payload_content(
    runtime_root: Path,
    state: dict[str, Any],
    response: dict[str, Any],
) -> None:
    actions = response["actions"]
    if not actions or actions[0]["action_type"] not in {
        "WRITE_PHASE_ARTIFACT",
        "UPDATE_PHASE_ARTIFACT",
    }:
        return
    action = actions[0]
    target_rel = str(action["target"])
    target = business_target(
        phase_artifact_root(state, current_phase_id(state)), target_rel
    )
    payload = action.get("payload") or {}
    content = payload.get("content")
    if not isinstance(content, str) and payload.get("content_path"):
        content = staged_content(
            runtime_root,
            str(payload["content_path"]),
            payload.get("content_sha256"),
        )
    if not isinstance(content, str) or not content.strip():
        raise ValueError("write/update action content must be nonempty")
    validate_content_for_target(
        target,
        content,
        str(payload.get("content_format") or "text"),
        relative_path=target_rel,
    )
    # A P04 split declaration is validated before a receipt is issued.  The
    # helper is pure: it reads the authoritative source ledgers and prepares
    # payloads in memory, so malformed spans cannot mutate the business root.
    if current_phase_id(state) == "P04" and target_rel == "publication_blueprint.json":
        blueprint = strict_json_loads(content)
        if not isinstance(blueprint, dict):
            raise ValueError("P04 publication_blueprint.json must be an object")
        prepare_resegmentation(
            phase_artifact_root(state, "P04"),
            blueprint,
        )

def consume_receipt(runtime_root: Path, receipt: dict[str, Any], transition_id: str) -> None:
    write_receipt_marker(runtime_root, receipt["receipt_id"], "CONSUMED", {
        "schema_version": "action-validation-receipt-consumed-v1",
        "receipt_id": receipt["receipt_id"],
        "validated_receipt_sha256": sha256_file(receipt_marker(runtime_root, receipt["receipt_id"], "VALID")),
        "consumed_by_transition_id": transition_id,
        "consumed_at": utc_now(),
    })


def cmd_execute_action(args: argparse.Namespace) -> int:
    runtime_root = Path(args.runtime_root).resolve()
    state = load_state(runtime_root)
    repair_recovery(runtime_root, state)
    state = load_state(runtime_root)
    require_phase(state, current_phase_id(state))
    validate_bound_context(runtime_root, state)
    receipt_id = getattr(args, "receipt_id", None)
    if not receipt_id:
        raise ValueError("validation receipt is required")
    receipt = load_valid_receipt(runtime_root, str(receipt_id))
    response_path = Path(args.response).resolve()
    response = strict_load_json(response_path)
    validate_json_schema(response, "action-response.schema.json")
    validate_action_semantics(state, response)
    response_sha256 = sha256_file(response_path)
    envelope = validate_bound_context(runtime_root, state)
    validate_serial_completion_claim(
        state, envelope, response, response_sha256=response_sha256
    )

    if receipt["response_sha256"] != response_sha256:
        raise ValueError("receipt does not bind this response")
    if receipt["state_revision"] != state["state_revision"]:
        raise ValueError("validation receipt is stale for the current State revision")
    if receipt["phase_plan_revision"] != state["route"]["phase_plan_revision"]:
        raise ValueError("validation receipt belongs to another phase-plan revision")
    if receipt["phase_id"] != current_phase_id(state):
        raise ValueError("validation receipt belongs to another phase")
    if receipt["phase_attempt"] != current_phase_attempt(state):
        raise ValueError("validation receipt belongs to another phase attempt")
    if receipt["context_pack_sha256"] != current_context_hash(state):
        raise ValueError("validation receipt context is stale")
    if receipt["artifact_contract_sha256"] != artifact_contract_sha(state):
        raise ValueError("artifact contract changed after validation")
    if state["active"]["validation_receipt_id"] != receipt["receipt_id"]:
        raise ValueError("receipt is not the active Runtime receipt")

    phase = get_phase(current_phase_id(state))
    actions = response["actions"]
    if not actions:
        claim = response["phase_completion_claim"]
        if not claim["ready"]:
            handoff = validate_repair_handoff_claim(
                claim,
                state=state,
                envelope=envelope,
                phase_id=phase.phase_id,
                ordered_phase_ids=state["route"]["ordered_phase_ids"],
                phase_outputs=phase.agent_writes,
                response_sha256=response_sha256,
            )
            handoff_content = canonical_json_bytes(handoff) + b"\n"
            handoff_sha = sha256_bytes(handoff_content)
            handoff_target = handoff_path(runtime_root, str(handoff["handoff_id"]))
            if handoff_target.exists():
                raise ValueError(f"repair handoff already exists: {handoff_target}")
            handoff_sidecar = handoff_target.with_suffix(".sha256")

            def record_repair_handoff(result: dict[str, Any]) -> None:
                result["active"]["status"] = "REPAIR_REQUIRED"
                result["active"]["validation_receipt_id"] = None
                result["active"]["context_pack_sha256"] = None
                result["active"]["repair_handoff"] = {
                    "handoff_id": handoff["handoff_id"],
                    "path": handoff_relative_path(str(handoff["handoff_id"])),
                    "sha256": handoff_sha,
                    "origin_phase": phase.phase_id,
                    "return_phase": handoff["return_to_phase"],
                    "recheck_phase": phase.phase_id,
                    "status": "ACTIVE",
                    "repair_attempt": handoff["repair_attempt"],
                    "context_pack_sha256": handoff["created_from"]["context_pack_sha256"],
                }
                result["blockers"] = [{
                    "code": "REPAIR_HANDOFF_REQUIRED",
                    "handoff_id": handoff["handoff_id"],
                    "failed_phase": phase.phase_id,
                    "return_to_phase": handoff["return_to_phase"],
                    "failure_class": handoff["failure_class"],
                    "first_loss_boundary": handoff["first_loss_boundary"],
                    "failure_fingerprint": handoff["failure_fingerprint"],
                }]
                result["execution"]["semantic_completion_evidence"] = []

            final = apply_transition(
                runtime_root,
                state,
                transition_kind="REPAIR_HANDOFF_COMMIT",
                phase_id=phase.phase_id,
                mutate=record_repair_handoff,
                validate_state=validate_state_invariants,
                write_state=write_state,
                append_journal=append_journal,
                details={
                    "receipt_id": receipt["receipt_id"],
                    "handoff_id": handoff["handoff_id"],
                    "handoff_sha256": handoff_sha,
                    "failure_fingerprint": handoff["failure_fingerprint"],
                    "return_to_phase": handoff["return_to_phase"],
                },
                artifact_writes=[
                    {
                        "target_path": str(handoff_target),
                        "target_relative_path": handoff_relative_path(str(handoff["handoff_id"])),
                        "target_precondition": "PATH_MUST_NOT_EXIST",
                        "expected_absent": True,
                        "expected_before_sha256": None,
                        "planned_after_sha256": handoff_sha,
                        "content": handoff_content,
                    },
                    {
                        "target_path": str(handoff_sidecar),
                        "target_relative_path": f"{HANDOFF_DIR}/{handoff['handoff_id']}.sha256",
                        "target_precondition": "PATH_MUST_NOT_EXIST",
                        "expected_absent": True,
                        "expected_before_sha256": None,
                        "planned_after_sha256": sha256_bytes((handoff_sha + "\n").encode("utf-8")),
                        "content": handoff_sha + "\n",
                    },
                ],
                receipt=receipt,
            )
            emit_json({
                "executed": True,
                "phase_id": phase.phase_id,
                "repair_handoff_recorded": True,
                "handoff_id": handoff["handoff_id"],
                "handoff_sha256": handoff_sha,
                "return_to_phase": handoff["return_to_phase"],
                "state_revision": final["state_revision"],
            })
            return 0

        def request_validation(result: dict[str, Any]) -> None:
            result["active"]["status"] = "VALIDATION_REQUESTED"
            result["active"]["validation_receipt_id"] = None
            result["execution"]["semantic_completion_evidence"] = list(claim["evidence"])

        final = apply_transition(
            runtime_root,
            state,
            transition_kind="PHASE_VALIDATION_REQUEST",
            phase_id=phase.phase_id,
            mutate=request_validation,
            validate_state=validate_state_invariants,
            write_state=write_state,
            append_journal=append_journal,
            details={"receipt_id": receipt["receipt_id"], "evidence": list(claim["evidence"])},
            receipt=receipt,
        )
        emit_json({
            "executed": True,
            "phase_id": phase.phase_id,
            "validation_requested": True,
            "state_revision": final["state_revision"],
        })
        return 0

    action = actions[0]
    action_type = action["action_type"]
    if action_type not in {"WRITE_PHASE_ARTIFACT", "UPDATE_PHASE_ARTIFACT"}:
        raise ValueError(f"R0 executor does not implement mutation type {action_type}")
    artifact_root = phase_artifact_root(state, phase.phase_id)
    if phase.phase_id not in {"P17", "P18", "P19"}:
        if state["domain_states"]["BUSINESS"]["access_state"] != "READ_WRITE":
            raise ValueError("BUSINESS domain is sealed read-only")

    target_rel = str(action["target"])
    target = business_target(artifact_root, target_rel)
    payload = action.get("payload") or {}
    content = payload.get("content")
    if not isinstance(content, str) and payload.get("content_path"):
        content = staged_content(
            runtime_root,
            str(payload["content_path"]),
            payload.get("content_sha256"),
        )
    if not isinstance(content, str) or not content.strip():
        raise ValueError("write/update action content must be nonempty")
    validate_content_for_target(
        target,
        content,
        str(payload.get("content_format") or "text"),
        relative_path=target_rel,
    )

    resegmentation_outputs: dict[str, str] = {}
    if phase.phase_id == "P04" and target_rel == "publication_blueprint.json":
        blueprint = strict_json_loads(content)
        if not isinstance(blueprint, dict):
            raise ValueError("P04 publication_blueprint.json must be an object")
        resegmentation_outputs = prepare_resegmentation(artifact_root, blueprint)

    old_sha = sha256_file(target) if target.is_file() else None
    if action_type == "WRITE_PHASE_ARTIFACT" and target.exists():
        raise ValueError(f"WRITE requires an absent target: {target_rel}")
    if action_type == "UPDATE_PHASE_ARTIFACT":
        if not target.is_file():
            raise ValueError(f"cannot update missing target: {target_rel}")
        expected = payload.get("expected_target_sha256")
        if not expected or expected != old_sha:
            raise ValueError(f"target hash changed for {target_rel}")

    # When a controlled source resegmentation is declared, the Runtime writes
    # the canonical transformed blueprint returned by the pure helper.  The
    # submitted blueprint is still the semantic request; the transformed
    # bytes are what all later reads must bind.
    if resegmentation_outputs:
        content = resegmentation_outputs["publication_blueprint.json"]
    new_content = content if content.endswith("\n") else content + "\n"
    predicted_sha = sha256_bytes(new_content.encode("utf-8"))
    artifact_writes: list[dict[str, Any]] = [{
        "target_path": str(target),
        "target_relative_path": target_rel,
        "target_precondition": (
            "PATH_MUST_NOT_EXIST"
            if action_type == "WRITE_PHASE_ARTIFACT"
            else "FILE_HASH_MATCH"
        ),
        "expected_absent": action_type == "WRITE_PHASE_ARTIFACT",
        "expected_before_sha256": old_sha,
        "planned_after_sha256": predicted_sha,
        "content": new_content,
    }]

    # Append the deterministic source-ledger rebuild to the same transition.
    # This is intentionally an internal, fixed operation: the Agent can only
    # name publication_blueprint.json, never arbitrary ledger targets.
    generated_targets: list[str] = []
    for generated_rel, generated_content in resegmentation_outputs.items():
        if generated_rel == target_rel:
            continue
        generated_target = safe_relative_target(artifact_root, generated_rel)
        generated_before = sha256_file(generated_target) if generated_target.is_file() else None
        generated_bytes = generated_content.encode("utf-8")
        generated_targets.append(generated_rel)
        artifact_writes.append({
            "target_path": str(generated_target),
            "target_relative_path": generated_rel,
            "target_precondition": (
                "FILE_HASH_MATCH" if generated_before is not None else "PATH_MUST_NOT_EXIST"
            ),
            "expected_absent": generated_before is None,
            "expected_before_sha256": generated_before,
            "planned_after_sha256": sha256_bytes(generated_bytes),
            "content": generated_bytes,
        })
    io_output_manifest_sha: str | None = None
    if phase.phase_id in {"P17", "P18", "P19"}:
        semantic_sidecar = target.with_suffix(".sha256")
        sidecar_before = sha256_file(semantic_sidecar) if semantic_sidecar.is_file() else None
        if action_type == "UPDATE_PHASE_ARTIFACT" and sidecar_before is None:
            raise ValueError(f"semantic artifact sidecar is missing for update: {target_rel}")
        sidecar_content = predicted_sha + "\n"
        artifact_writes.append({
            "target_path": str(semantic_sidecar),
            "target_relative_path": semantic_sidecar.relative_to(artifact_root).as_posix(),
            "target_precondition": (
                "PATH_MUST_NOT_EXIST"
                if sidecar_before is None
                else "FILE_HASH_MATCH"
            ),
            "expected_absent": sidecar_before is None,
            "expected_before_sha256": sidecar_before,
            "planned_after_sha256": sha256_bytes(sidecar_content.encode("utf-8")),
            "content": sidecar_content,
        })
        output_path, output_content, output_sidecar_content, io_output_manifest_sha = (
            output_manifest_transition_payloads(
                state,
                phase.phase_id,
                current_phase_attempt(state),
                {("OBSIDIAN", target_rel): new_content.encode("utf-8")},
                {
                    ("OBSIDIAN", target_rel): (
                        "CREATE"
                        if action_type == "WRITE_PHASE_ARTIFACT"
                        else "UPDATE"
                    )
                },
            )
        )
        output_sidecar = output_path.with_suffix(".sha256")
        for path, payload in (
            (output_path, output_content),
            (output_sidecar, output_sidecar_content),
        ):
            artifact_writes.append({
                "target_path": str(path),
                "target_relative_path": path.relative_to(runtime_root).as_posix(),
                "target_precondition": "PATH_MUST_NOT_EXIST",
                "expected_absent": True,
                "expected_before_sha256": None,
                "planned_after_sha256": sha256_bytes(payload),
                "content": payload,
            })
    mirror_path: Path | None = None
    if target.suffix.lower() == ".jsonl":
        candidate = target.with_suffix(".md")
        if candidate.exists():
            mirror_path = candidate
            mirror_before = sha256_file(candidate)
            mirror_content = render_jsonl_mirror_content(target, new_content)
            artifact_writes.append({
                "target_path": str(candidate),
                "target_relative_path": candidate.relative_to(artifact_root).as_posix(),
                "target_precondition": "FILE_HASH_MATCH",
                "expected_absent": False,
                "expected_before_sha256": mirror_before,
                "planned_after_sha256": sha256_bytes(mirror_content.encode("utf-8")),
                "content": mirror_content,
            })
    if target.name == "active_state.json":
        candidate = target.with_name("active_state.md")
        mirror_before = sha256_file(candidate) if candidate.is_file() else None
        mirror_content = render_active_state_mirror_content(new_content)
        artifact_writes.append({
            "target_path": str(candidate),
            "target_relative_path": candidate.relative_to(artifact_root).as_posix(),
            "target_precondition": "FILE_HASH_MATCH" if mirror_before is not None else "PATH_MUST_NOT_EXIST",
            "expected_absent": mirror_before is None,
            "expected_before_sha256": mirror_before,
            "planned_after_sha256": sha256_bytes(mirror_content.encode("utf-8")),
            "content": mirror_content,
        })

    def mutate(result: dict[str, Any]) -> None:
        record = result["phase_records"][phase.phase_id]
        if target_rel not in record["written_targets"]:
            record["written_targets"].append(target_rel)
        result["active"].update({
            "status": "READY",
            "action_id": None,
            "context_pack_sha256": None,
            "validation_receipt_id": None,
            "input_fingerprint": None,
        })
        result["cursor"]["attempt"] += 1
        result["phase_records"][phase.phase_id]["attempt"] = result["cursor"]["attempt"]
        if io_output_manifest_sha is not None:
            record = result["phase_records"][phase.phase_id]
            record["output_manifest_sha256"] = io_output_manifest_sha
            record["io_output_manifest_sha256"] = io_output_manifest_sha

    final = apply_transition(
        runtime_root,
        state,
        transition_kind="ACTION_COMMIT",
        phase_id=phase.phase_id,
        mutate=mutate,
        validate_state=validate_state_invariants,
        write_state=write_state,
        append_journal=append_journal,
        details={
            "receipt_id": receipt["receipt_id"],
            "action_id": action["action_id"],
            "action_type": action_type,
            "target": target_rel,
            "old_sha256": old_sha,
            "planned_new_sha256": predicted_sha,
            "io_output_manifest_sha256": io_output_manifest_sha,
            "resegmentation_outputs": generated_targets,
        },
        artifact_writes=artifact_writes,
        receipt=receipt,
    )
    emit_json({
        "executed": True,
        "phase_id": phase.phase_id,
        "target": target_rel,
        "sha256": predicted_sha,
        "mirror": str(mirror_path) if mirror_path else None,
        "state_revision": final["state_revision"],
    })
    return 0
def markdown_cell(value: Any) -> str:
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return str(value).replace("\\", "\\\\").replace("|", "\\|").replace("\r", "\\r").replace("\n", "\\n").replace("\t", "\\t")

def markdown_table(rows: list[dict[str, Any]], title: str) -> str:
    if not rows:
        return f"# {title}\n\nNo rows.\n"
    columns: list[str] = []
    for row in rows:
        for key in row:
            if key not in columns:
                columns.append(key)
    header = "| " + " | ".join(columns) + " |"
    divider = "|" + "|".join("---" for _ in columns) + "|"
    body = ["| " + " | ".join(markdown_cell(row.get(column, "")) for column in columns) + " |" for row in rows]
    return f"# {title}\n\n" + "\n".join([header, divider, *body]) + "\n"

def render_jsonl_mirror_content(jsonl_path: Path, content: str) -> str:
    rows: list[dict[str, Any]] = []
    for line_no, line in enumerate(content.splitlines(), 1):
        if not line.strip():
            continue
        value = strict_json_loads(line)
        if not isinstance(value, dict):
            raise ValueError(f"{jsonl_path.name}:{line_no} must contain one JSON object")
        rows.append(value)
    if not rows:
        raise ValueError(f"{jsonl_path.name} must contain at least one JSONL row")
    columns: list[str] = []
    for row in rows:
        for key in row:
            if key not in columns:
                columns.append(key)
    title = jsonl_path.stem.replace("_", " ").title()
    header = "| " + " | ".join(columns) + " |"
    divider = "|" + "|".join("---" for _ in columns) + "|"
    body = [
        "| " + " | ".join(
            markdown_cell(row.get(column, "")) for column in columns
        ) + " |"
        for row in rows
    ]
    return f"# {title}\n\n" + "\n".join([header, divider, *body]) + "\n"


def render_active_state_mirror_content(content: str) -> str:
    """Render active_state.json into its canonical Markdown mirror."""
    value = strict_json_loads(content)
    if not isinstance(value, dict):
        raise ValueError("active_state.json must contain one object")
    required = (
        "run_id", "run_mode", "current_stage", "resume_point",
        "feedback_ledger_sha256", "resume_instruction",
    )
    missing = [key for key in required if key not in value]
    if missing:
        raise ValueError("active_state.json missing mirror fields: " + ", ".join(missing))
    constraints = value.get("hard_constraints", [])
    active_ids = value.get("active_feedback_ids", [])
    if not isinstance(constraints, list) or not isinstance(active_ids, list):
        raise ValueError("active_state.json mirror fields have invalid types")
    lines = [
        "# Active State", "",
        f"RUN_ID: {value['run_id']}",
        f"RUN_MODE: {value['run_mode']}",
        f"CURRENT_STAGE: {value['current_stage']}",
        f"RESUME_POINT: {value['resume_point']}",
        f"FEEDBACK_LEDGER_SHA256: {value['feedback_ledger_sha256']}",
        "ACTIVE_FEEDBACK_IDS: " + (",".join(str(item) for item in active_ids) or "none"),
        "", "## Resume Instruction", "", str(value["resume_instruction"]), "",
        "## Hard Constraints", "",
        *[f"- {item}" for item in constraints], "",
    ]
    return "\n".join(lines)


def regenerate_jsonl_mirror(jsonl_path: Path, *, create: bool = False) -> Path | None:
    mirror = jsonl_path.with_suffix(".md")
    if not mirror.exists() and not create:
        return None
    content = render_jsonl_mirror_content(
        jsonl_path,
        jsonl_path.read_text(encoding="utf-8", errors="strict"),
    )
    atomic_write_text(mirror, content)
    return mirror

def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    atomic_write_text(path, "".join(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n" for row in rows))

def materialize_blueprint_locks(root: Path) -> None:
    blueprint = json.loads((root / "publication_blueprint.json").read_text(encoding="utf-8"))
    mapping = (
        ("voices", "voice_expression_ledger.md", "Voice Expression Ledger"),
        ("symbols", "symbol_ledger.md", "Symbol Ledger"),
        ("chains", "explanation_chain_ledger.md", "Explanation Chain Ledger"),
        ("statements", "math_statement_ledger.md", "Math Statement Ledger"),
        ("proofs", "proof_obligations.md", "Proof Obligations"),
    )
    for key, filename, title in mapping:
        rows = blueprint.get(key)
        if not isinstance(rows, list) or not rows:
            raise ValueError(f"publication blueprint requires nonempty {key}")
        atomic_write_text(root / filename, markdown_table(rows, title))

def require_phase_outputs(state: dict[str, Any], phase_id: str) -> list[str]:
    phase = get_phase(phase_id)
    root = phase_artifact_root(state, phase_id)
    missing: list[str] = []
    for rel in phase.agent_writes:
        path = root / rel
        if not path.is_file() or path.is_symlink() or not path.read_text(encoding="utf-8").strip():
            missing.append(rel)
            continue
        head = path.read_text(encoding="utf-8")[:4000].upper()
        if any(marker in head for marker in ("[TODO", "TODO:", "REPLACE_ME", "REPLACE THIS", "TBD_PLACEHOLDER")):
            missing.append(rel)
    return missing


def run_recorded(runtime_root: Path, phase_id: str, command: list[str]) -> None:
    result = command_result(command, cwd=skill_root())
    append_journal(runtime_root, "COMMAND_EXECUTED", phase_id=phase_id, **result)
    run_or_raise(result)


def commit_p14(
    runtime_root: Path,
    state: dict[str, Any],
    binding: dict[str, Any],
    *,
    lock_held: bool = False,
) -> dict[str, Any]:
    route = state["route"]
    configured = route["configuration_state"] == "AVAILABLE"
    enabled = route["obsidian_enabled"]

    def mutate(result: dict[str, Any]) -> None:
        result["phase_records"]["P14"]["status"] = "COMMITTED"
        result["phase_records"]["P14"]["last_validation"] = {
            "validator": "pipeline release",
            "exit_code": 0,
            "release_manifest_sha256": binding["release_manifest_sha256"],
        }
        if "P14" not in result["execution"]["committed_phase_ids"]:
            result["execution"]["committed_phase_ids"].append("P14")
        result["publication_release"] = dict(binding)
        result["domain_states"]["BUSINESS"] = {
            "access_state": "SEALED_READ_ONLY",
            "sealed_by_phase": "P14",
            "sealed_snapshot_sha256": binding["target_snapshot_sha256"],
            "sealed_at": utc_now(),
        }
        result["active"].update({
            "status": "READY",
            "action_id": None,
            "context_pack_sha256": None,
            "validation_receipt_id": None,
            "input_fingerprint": None,
        })
        result["execution"]["semantic_completion_evidence"] = []
        if not enabled:
            result["cursor"].update({
                "current_phase": TERMINAL_PHASE,
                "phase_index": len(result["route"]["ordered_phase_ids"]),
                "attempt": 1,
                "current_role": "",
            })
            result["workflow"] = {
                "status": "COMPLETED",
                "terminal_result": "PUBLISHABLE",
                "suspension_reason": None,
                "resume_phase": None,
            }
            result["outputs"]["obsidian"].update({
                "status": "NOT_REQUESTED",
                "resume_phase": None,
                "active_manifest_sha256": None,
            })
        else:
            result["phase_records"]["P16"]["status"] = "ACTIVE"
            result["cursor"].update({
                "current_phase": "P16",
                "phase_index": result["route"]["ordered_phase_ids"].index("P16"),
                "attempt": result["phase_records"]["P16"]["attempt"],
                "current_role": get_phase("P16").role,
            })
            if configured:
                result["workflow"] = {
                    "status": "RUNNING",
                    "terminal_result": None,
                    "suspension_reason": None,
                    "resume_phase": None,
                }
                result["outputs"]["obsidian"].update({
                    "status": "INDEX_PENDING",
                    "resume_phase": None,
                    "active_manifest_sha256": None,
                })
            else:
                result["workflow"] = {
                    "status": "SUSPENDED",
                    "terminal_result": None,
                    "suspension_reason": (
                        "OBSIDIAN_VAULT_CONFIGURATION_REQUIRED"
                    ),
                    "resume_phase": "P16",
                }
                result["outputs"]["obsidian"].update({
                    "status": "CONFIGURATION_REQUIRED",
                    "resume_phase": "P16",
                    "active_manifest_sha256": None,
                })

    final = apply_transition(
        runtime_root,
        state,
        transition_kind="P14_RELEASE_COMMIT",
        phase_id="P14",
        mutate=mutate,
        validate_state=validate_state_invariants,
        write_state=write_state,
        append_journal=append_journal,
        details={
            "publication_release": binding,
            "obsidian_enabled": enabled,
            "configuration_state": route["configuration_state"],
        },
        lock_held=lock_held,
    )

    if enabled and configured:
        handoff_path, handoff_content, handoff_sha = build_publication_handoff(final)
        sidecar_path = handoff_path.with_suffix(".sha256")

        def bind_handoff(result: dict[str, Any]) -> None:
            result["outputs"]["obsidian"]["active_manifest_sha256"] = handoff_sha

        final = apply_transition(
            runtime_root,
            final,
            transition_kind="PUBLICATION_HANDOFF_PREPARE",
            phase_id="P16",
            mutate=bind_handoff,
            validate_state=validate_state_invariants,
            write_state=write_state,
            append_journal=append_journal,
            details={
                "handoff_sha256": handoff_sha,
                "handoff_path": str(handoff_path),
            },
            artifact_writes=[
                {
                    "target_path": str(handoff_path),
                    "target_relative_path": handoff_path.relative_to(
                        Path(final["roots"]["obsidian_run_root"])
                    ).as_posix(),
                    "target_precondition": "PATH_MUST_NOT_EXIST",
                    "expected_absent": True,
                    "expected_before_sha256": None,
                    "planned_after_sha256": handoff_sha,
                    "content": handoff_content,
                },
                {
                    "target_path": str(sidecar_path),
                    "target_relative_path": sidecar_path.relative_to(
                        Path(final["roots"]["obsidian_run_root"])
                    ).as_posix(),
                    "target_precondition": "PATH_MUST_NOT_EXIST",
                    "expected_absent": True,
                    "expected_before_sha256": None,
                    "planned_after_sha256": sha256_bytes(
                        (handoff_sha + "\n").encode("utf-8")
                    ),
                    "content": handoff_sha + "\n",
                },
            ],
            lock_held=lock_held,
        )
    return final

def _suspend_for_author_intent(
    runtime_root: Path,
    state: dict[str, Any],
    question_result: dict[str, Any],
) -> dict[str, Any]:
    def mutate(result: dict[str, Any]) -> None:
        result["workflow"] = {
            "status": "SUSPENDED",
            "terminal_result": None,
            "suspension_reason": "AUTHOR_KNOWLEDGE_INTENT_REQUIRED",
            "resume_phase": "P17",
        }
        result["outputs"]["obsidian"].update({
            "status": "AUTHOR_INTENT_REQUIRED",
            "resume_phase": "P17",
            "active_manifest_sha256": question_result["question_sha256"],
        })
        result["active"].update({
            "status": "READY",
            "action_id": None,
            "context_pack_sha256": None,
            "validation_receipt_id": None,
            "input_fingerprint": None,
        })
        io_sha = question_result.get("io_output_manifest_sha256")
        if io_sha:
            record = result["phase_records"]["P17"]
            record["output_manifest_sha256"] = io_sha
            record["io_output_manifest_sha256"] = io_sha

    return apply_transition(
        runtime_root,
        state,
        transition_kind="AUTHOR_INTENT_REQUEST",
        phase_id="P17",
        mutate=mutate,
        validate_state=validate_state_invariants,
        write_state=write_state,
        append_journal=append_journal,
        details=question_result,
        lock_held=True,
    )


def _ensure_obsidian_phase_input(state: dict[str, Any], phase_id: str) -> str:
    _, _, digest = ensure_input_manifest(state, phase_id, current_phase_attempt(state))
    bound = state["phase_records"][phase_id].get("input_fingerprint")
    if bound is not None and bound != digest:
        raise ValueError(f"{phase_id} input manifest differs from the bound phase fingerprint")
    active = state["active"].get("input_fingerprint")
    if active is not None and active != digest:
        raise ValueError(f"{phase_id} input manifest differs from the active turn fingerprint")
    return digest


def _bind_phase_io(
    current: dict[str, Any],
    phase_id: str,
    input_sha: str,
    output_sha: str,
    *,
    preserve_primary_output: bool = False,
) -> None:
    record = current["phase_records"][phase_id]
    record["input_fingerprint"] = input_sha
    record["io_output_manifest_sha256"] = output_sha
    if not preserve_primary_output:
        record["output_manifest_sha256"] = output_sha


def _advance_obsidian_locked(
    runtime_root: Path,
    state: dict[str, Any],
    phase_id: str,
) -> int:
    if phase_id == "P16":
        input_sha = _ensure_obsidian_phase_input(state, phase_id)
        result = index_author_directed_vault(state)
        _, _, output_sha = ensure_output_manifest(
            state, phase_id, current_phase_attempt(state)
        )

        def mutate(current: dict[str, Any]) -> None:
            _bind_phase_io(current, phase_id, input_sha, output_sha)
            current["outputs"]["obsidian"].update({
                "status": "INDEXED",
                "active_manifest_sha256": result["manifest_sha256"],
                "resume_phase": None,
            })
            current["versions"]["obsidian_business_contract_version"] = (
                "obsidian-copy-first-contract-v1.0"
            )
            current["versions"]["obsidian_renderer_version"] = (
                "copy-first-patch-runtime-v1"
            )

        final = commit_phase(
            runtime_root,
            state,
            "P16",
            details=result,
            extra_mutation=mutate,
            lock_held=True,
        )
        emit_json(final)
        return 0

    if phase_id == "P17":
        root = phase_artifact_root(state, phase_id)
        response = root / "author-input" / "AUTHOR_RESPONSE.md"
        if not response.is_file():
            question = root / "author-input" / "AUTHOR_INTENT_QUESTIONS.md"
            if question.is_file():
                question_result = {
                    "question_path": str(question),
                    "question_sha256": sha256_file(question),
                    "questions": [
                        "这篇文章里，哪些内容值得单独拉出来，作为以后继续发展的原子笔记？",
                        "如果选中了某个原子笔记，可以可选地补充以后想继续追问的问题。",
                    ],
                }
            else:
                question_result = write_author_intent_question(state)
            _, _, question_output_sha = ensure_output_manifest(
                state, phase_id, current_phase_attempt(state)
            )
            question_result["io_output_manifest_sha256"] = question_output_sha
            final = _suspend_for_author_intent(runtime_root, state, question_result)
            emit_json({
                "state": final,
                "author_input_required": True,
                **question_result,
            })
            return 0
        if state["workflow"]["status"] == "SUSPENDED":
            raise RuntimeCliError(
                "AUTHOR_INTENT_NOT_RESUMED",
                "Bind the author response with submit-author-intent before semantic compilation.",
                exit_code=64,
            )
        if state["active"]["status"] != "VALIDATION_REQUESTED":
            raise ValueError("P17 requires a current-task serial phase-validation request")
        input_sha = _ensure_obsidian_phase_input(state, phase_id)
        missing = require_phase_outputs(state, phase_id)
        if missing:
            raise ValueError(f"P17 outputs are missing: {', '.join(missing)}")
        result = validate_bound_author_intent(state)
        _, _, output_sha = ensure_output_manifest(
            state, phase_id, current_phase_attempt(state)
        )

        def mutate(current: dict[str, Any]) -> None:
            _bind_phase_io(current, phase_id, input_sha, output_sha)
            current["outputs"]["obsidian"].update({
                "status": "AUTHOR_INTENT_BOUND",
                "active_manifest_sha256": result["intent_sha256"],
                "resume_phase": None,
            })

        final = commit_phase(
            runtime_root,
            state,
            "P17",
            details=result,
            extra_mutation=mutate,
            lock_held=True,
        )
        emit_json(final)
        return 0

    if phase_id == "P18":
        if state["active"]["status"] != "VALIDATION_REQUESTED":
            raise ValueError("P18 requires a current-task serial phase-validation request")
        input_sha = _ensure_obsidian_phase_input(state, phase_id)
        missing = require_phase_outputs(state, phase_id)
        if missing:
            raise ValueError(f"P18 outputs are missing: {', '.join(missing)}")
        result = materialize_page_seeds(state)
        _, _, output_sha = ensure_output_manifest(
            state, phase_id, current_phase_attempt(state)
        )

        def mutate(current: dict[str, Any]) -> None:
            _bind_phase_io(current, phase_id, input_sha, output_sha)
            current["outputs"]["obsidian"].update({
                "status": "SEEDS_MATERIALIZED",
                "active_manifest_sha256": result["seed_manifest_sha256"],
            })

        final = commit_phase(
            runtime_root,
            state,
            "P18",
            details=result,
            extra_mutation=mutate,
            lock_held=True,
        )
        emit_json(final)
        return 0

    if phase_id == "P19":
        if state["active"]["status"] != "VALIDATION_REQUESTED":
            raise ValueError("P19 requires a current-task serial phase-validation request")
        input_sha = _ensure_obsidian_phase_input(state, phase_id)
        missing = require_phase_outputs(state, phase_id)
        if missing:
            raise ValueError(f"P19 outputs are missing: {', '.join(missing)}")
        result = apply_page_patch_bundle(state)
        _, _, output_sha = ensure_output_manifest(
            state, phase_id, current_phase_attempt(state)
        )

        def mutate(current: dict[str, Any]) -> None:
            _bind_phase_io(current, phase_id, input_sha, output_sha)
            current["outputs"]["obsidian"].update({
                "status": "PATCHED",
                "active_manifest_sha256": result["patch_application_sha256"],
            })

        final = commit_phase(
            runtime_root,
            state,
            "P19",
            details=result,
            extra_mutation=mutate,
            lock_held=True,
        )
        emit_json(final)
        return 0

    if phase_id == "P20":
        input_sha = _ensure_obsidian_phase_input(state, phase_id)
        result = build_staging_and_delivery(state)
        _, _, output_sha = ensure_output_manifest(
            state, phase_id, current_phase_attempt(state)
        )

        def mutate(current: dict[str, Any]) -> None:
            _bind_phase_io(current, phase_id, input_sha, output_sha)
            current["outputs"]["obsidian"].update({
                "status": "STAGED",
                "current_generation": result["generation_id"],
                "active_manifest_sha256": result["manifest_sha256"],
            })

        final = commit_phase(
            runtime_root,
            state,
            "P20",
            details=result,
            extra_mutation=mutate,
            lock_held=True,
        )
        emit_json(final)
        return 0

    if phase_id == "P21":
        input_sha = _ensure_obsidian_phase_input(state, phase_id)
        result = validate_author_directed_staging(state)
        ready_for_import = result["outcome"] == "READY_FOR_IMPORT"
        _, _, output_sha = ensure_output_manifest(
            state, phase_id, current_phase_attempt(state)
        )

        def mutate(current: dict[str, Any]) -> None:
            _bind_phase_io(
                current,
                phase_id,
                input_sha,
                output_sha,
                preserve_primary_output=True,
            )
            current["outputs"]["obsidian"].update({
                "status": result["outcome"],
                "active_manifest_sha256": result["p21_import_commit_sha256"],
                "resume_phase": None,
            })
            current["phase_records"]["P21"]["output_manifest_sha256"] = (
                result["p21_import_commit_sha256"]
            )

        final = commit_phase(
            runtime_root,
            state,
            "P21",
            details=result,
            extra_mutation=mutate,
            lock_held=True,
        )
        emit_json({
            "state": final,
            "ready_for_import": ready_for_import,
            "ready_for_export": not ready_for_import,
            **result,
        })
        return 0

    raise ValueError(f"unsupported Obsidian phase: {phase_id}")


def cmd_submit_author_intent(args: argparse.Namespace) -> int:
    runtime_root = Path(args.runtime_root).resolve()
    with exclusive_runtime_lock(runtime_root):
        state = load_state(runtime_root)
        repair_recovery(runtime_root, state)
        state = load_state(runtime_root)
        if current_phase_id(state) != "P17":
            raise ValueError(f"expected current phase P17, found {current_phase_id(state)}")
        if state["phase_records"]["P17"]["status"] != "ACTIVE":
            raise ValueError("P17 is not active")
        if state["workflow"]["status"] != "SUSPENDED":
            raise ValueError("Runtime is not waiting for author knowledge intent")
        if state["workflow"]["suspension_reason"] != "AUTHOR_KNOWLEDGE_INTENT_REQUIRED":
            raise ValueError("Runtime suspension is not an author-intent request")
        result = bind_author_response(state, Path(args.response_file))

        def mutate(current: dict[str, Any]) -> None:
            current["workflow"] = {
                "status": "RUNNING",
                "terminal_result": None,
                "suspension_reason": None,
                "resume_phase": None,
            }
            current["outputs"]["obsidian"].update({
                "status": "EXTRACTING",
                "resume_phase": None,
                "active_manifest_sha256": result["receipt_sha256"],
            })
            current["active"].update({
                "status": "READY",
                "action_id": None,
                "context_pack_sha256": None,
                "validation_receipt_id": None,
                "input_fingerprint": None,
            })
            current["cursor"]["attempt"] += 1
            current["phase_records"]["P17"]["attempt"] = current["cursor"]["attempt"]

        final = apply_transition(
            runtime_root,
            state,
            transition_kind="AUTHOR_INTENT_BIND",
            phase_id="P17",
            mutate=mutate,
            validate_state=validate_state_invariants,
            write_state=write_state,
            append_journal=append_journal,
            details=result,
            lock_held=True,
        )
        emit_json({"state": final, "author_response_bound": True, **result})
        return 0


def cmd_apply_obsidian(args: argparse.Namespace) -> int:
    runtime_root = Path(args.runtime_root).resolve()
    with exclusive_runtime_lock(runtime_root):
        state = load_state(runtime_root)
        if state["outputs"]["obsidian"]["mode"] == "STAGING_ONLY":
            raise ValueError("staging-only Vault snapshot can be exported but never applied by this Runtime")
        repair_recovery(runtime_root, state)
        state = load_state(runtime_root)
        if "P21" not in state["execution"]["committed_phase_ids"]:
            raise ValueError("P21 must be committed before Obsidian application")
        if state["outputs"]["obsidian"]["status"] not in {"READY_FOR_IMPORT", "IMPORTED"}:
            raise ValueError("Obsidian package is not ready for import")
        result = apply_author_directed_import(
            state, str(args.approval_manifest_sha256)
        )

        def mutate(current: dict[str, Any]) -> None:
            current["outputs"]["obsidian"].update({
                "status": "IMPORTED",
                "active_manifest_sha256": result["receipt_sha256"],
            })

        final = apply_transition(
            runtime_root,
            state,
            transition_kind="OBSIDIAN_REVIEWED_IMPORT",
            phase_id="P21",
            mutate=mutate,
            validate_state=validate_state_invariants,
            write_state=write_state,
            append_journal=append_journal,
            details=result,
            lock_held=True,
        )
        emit_json({"state": final, **result})
        return 0


def _cmd_advance_locked(args: argparse.Namespace) -> int:
    runtime_root = Path(args.runtime_root).resolve()
    state = load_state(runtime_root)
    phase_id = current_phase_id(state)
    require_phase(state, phase_id)
    if phase_id in OBSIDIAN_PHASES:
        return _advance_obsidian_locked(runtime_root, state, phase_id)
    phase = get_phase(phase_id)
    business = business_root(state)
    scripts = skill_root() / "scripts"
    semantic_phases = {f"P{number:02d}" for number in range(3, 12)} | {"P13"}
    if phase_id in semantic_phases and state["active"]["status"] != "VALIDATION_REQUESTED":
        raise ValueError(f"{phase_id} requires a current-task serial phase-validation request")
    if phase_id in semantic_phases:
        # The completion review binds exact bytes. Nothing may change between that
        # review transaction and the deterministic phase gate.
        validate_bound_context(runtime_root, state)
        require_current_epoch_output_actions(state, phase_id)
        missing = require_phase_outputs(state, phase_id)
        if missing:
            raise ValueError(f"{phase_id} outputs are missing, empty, or placeholders: {', '.join(missing)}")

    if phase_id == "P04":
        run_recorded(
            runtime_root,
            phase_id,
            [
                sys.executable,
                str(scripts / "materialize_atom_function_contracts.py"),
                str(business),
            ],
        )
        # Markdown ledgers are mechanical views of the Agent-reviewed blueprint.
        materialize_blueprint_locks(business)
        for rel in phase.runtime_writes:
            if not (business / rel).is_file():
                raise ValueError(f"P04 mirror compiler did not create {rel}")

    extra_mutation = None
    if phase_id == "P03":
        for name in (
            "validate_author_task_contract.py",
            "validate_formula_block_canonicalization.py",
            "validate_author_question_obligations.py",
            "validate_source_math_risks.py",
            "validate_source_review_resolution.py",
        ):
            run_recorded(runtime_root, phase_id, [sys.executable, str(scripts / name), str(business)])
        run_recorded(runtime_root, phase_id, [sys.executable, str(scripts / "pipeline.py"), "set-mode", str(business), "--mode", "full_publication"])
        extra_mutation = lambda current: current["execution"].update({"run_mode": "full_publication"})
    elif phase_id == "P04":
        for name, extra in (
            ("validate_content_function_preservation.py", ["--contracts-only"]),
            ("validate_source_obligation_contracts.py", []),
            ("validate_atom_semantics.py", []),
            ("validate_surface_decisions.py", []),
        ):
            run_recorded(
                runtime_root,
                phase_id,
                [sys.executable, str(scripts / name), str(business), *extra],
            )
    elif phase_id in {"P06", "P07", "P08", "P10", "P11"}:
        if phase_id == "P06":
            run_recorded(
                runtime_root,
                phase_id,
                [sys.executable, str(scripts / "validate_section_execution_plan.py"), str(business)],
            )
        targets = {
            "P06": [("P06_DRAFT", "draft.md", True)],
            "P07": [("P07_FINAL", "final.md", True)],
            "P08": [
                ("P08_OPTIMIZED", "optimized_final.md", True),
                ("P08_STANDARDIZED", "standardized_final.md", True),
            ],
            "P10": [("P10_REVISED", "revised_final.md", True)],
            "P11": [("P11_AIGC", "aigc_rewritten_final.md", True)],
        }[phase_id]
        for stage_id, target, all_atoms in targets:
            command = [
                sys.executable,
                str(scripts / "validate_content_function_preservation.py"),
                str(business),
                "--stage",
                stage_id,
                "--target",
                target,
            ]
            if all_atoms:
                command.append("--all-atoms")
            run_recorded(runtime_root, phase_id, command)
            run_recorded(
                runtime_root,
                phase_id,
                [
                    sys.executable,
                    str(scripts / "validate_quality_gate.py"),
                    str(business),
                    "--stage",
                    stage_id,
                    "--target",
                    target,
                ],
            )
    elif phase_id == "P05":
        for stem in (
            "cross_chunk_dependency_map",
            "section_context_prefetch_plan",
            "section_execution_plan",
        ):
            regenerate_jsonl_mirror(business / f"{stem}.jsonl", create=True)
        run_recorded(
            runtime_root,
            phase_id,
            [sys.executable, str(scripts / "validate_section_execution_plan.py"), str(business)],
        )
        run_recorded(
            runtime_root,
            phase_id,
            [sys.executable, str(scripts / "compile_quality_contract.py"), str(business)],
        )
        run_recorded(
            runtime_root,
            phase_id,
            [sys.executable, str(scripts / "context_pack.py"), str(business)],
        )
        run_recorded(
            runtime_root,
            phase_id,
            [sys.executable, str(scripts / "validate_cross_chunk_dependencies.py"), str(business)],
        )
        for rel in phase.runtime_writes:
            if not (business / rel).is_file():
                raise ValueError(f"P05 deterministic compiler did not create {rel}")
    elif phase_id == "P09":
        regenerate_jsonl_mirror(business / "final_claim_ledger.jsonl", create=True)
        for name in (
            "validate_trace_lock.py",
            "validate_claim_source_obligation.py",
            "validate_symbol_lock.py",
            "validate_integration.py",
        ):
            command = [sys.executable, str(scripts / name)]
            if name == "validate_symbol_lock.py":
                command.extend(
                    [str(business / "symbol_ledger.md"), str(business / "standardized_final.md")]
                )
            elif name == "validate_integration.py":
                command.append(str(business / "integration_report.md"))
            else:
                command.append(str(business))
            run_recorded(runtime_root, phase_id, command)
    elif phase_id == "P12":
        run_recorded(runtime_root, phase_id, [
            sys.executable,
            str(scripts / "pipeline.py"),
            "prepare-publication",
            str(business),
            str(business / "aigc_rewritten_final.md"),
            str(business / "publication_blueprint.json"),
            "--overwrite",
        ])
        for rel in phase.runtime_writes:
            if not (business / rel).is_file():
                raise ValueError(f"P12 compiler did not create {rel}")
    elif phase_id == "P13":
        run_recorded(runtime_root, phase_id, [
            sys.executable,
            str(scripts / "validate_content_function_preservation.py"),
            str(business),
            "--stage",
            "P13_PUBLICATION",
            "--target",
            "publication_final.md",
            "--all-atoms",
        ])
        run_recorded(runtime_root, phase_id, [
            sys.executable,
            str(scripts / "validate_quality_gate.py"),
            str(business),
            "--stage",
            "P13_PUBLICATION",
            "--target",
            "publication_final.md",
        ])
        run_recorded(runtime_root, phase_id, [
            sys.executable,
            str(scripts / "finalize_atom_consumption.py"),
            str(business),
        ])
        run_recorded(runtime_root, phase_id, [sys.executable, str(scripts / "pipeline.py"), "validate", str(business), "--mode", "full_publication"])
    elif phase_id == "P14":
        run_recorded(runtime_root, phase_id, [sys.executable, str(scripts / "pipeline.py"), "release", str(business), "--mode", "full_publication"])
        binding = verify_publication_release_binding(None, business)
        final = commit_p14(runtime_root, state, binding, lock_held=True)
        emit_json(final)
        return 0
    else:
        raise ValueError(f"advance is not valid for {phase_id}")

    details = {
        "validator": phase.deterministic_command or "runtime phase gate",
        "exit_code": 0,
        "semantic_evidence": state["execution"]["semantic_completion_evidence"],
    }
    final = commit_phase(
        runtime_root,
        state,
        phase_id,
        details=details,
        extra_mutation=extra_mutation,
        lock_held=True,
    )
    emit_json(final)
    return 0


def cmd_advance(args: argparse.Namespace) -> int:
    runtime_root = Path(args.runtime_root).resolve()
    with exclusive_runtime_lock(runtime_root):
        state = load_state(runtime_root)
        repair_recovery(runtime_root, state)
        return _cmd_advance_locked(args)


def _cmd_configure_obsidian_locked(args: argparse.Namespace) -> int:
    runtime_root = Path(args.runtime_root).resolve()
    state = load_state(runtime_root)
    if not state["route"]["obsidian_enabled"]:
        raise RuntimeCliError(
            "OBSIDIAN_DISABLED",
            "This run explicitly skipped Obsidian and cannot be configured in the active phase-plan revision.",
            exit_code=64,
        )
    if current_phase_id(state) != "P16":
        raise ValueError("Obsidian configuration can resume only at P16")
    if state["workflow"]["status"] != "SUSPENDED" or state["outputs"]["obsidian"]["status"] != "CONFIGURATION_REQUIRED":
        raise ValueError("Runtime is not suspended for Obsidian Vault configuration")
    verify_publication_release_binding(state, business_root(state))
    reference, obsidian_root, _ = prepare_obsidian_binding(
        runtime_root,
        business_root(state),
        Path(args.obsidian_config),
        authorized_by=str(args.authorized_by),
        authorization_event_id=str(args.authorization_event_id),
    )
    prospective = json.loads(canonical_json_bytes(state))
    prospective["roots"]["formal_vault_binding"] = reference
    prospective["roots"]["obsidian_run_root"] = str(obsidian_root)
    prospective["route"]["configuration_state"] = "AVAILABLE"
    handoff_path, handoff_content, handoff_sha = build_publication_handoff(
        prospective
    )
    handoff_sidecar = handoff_path.with_suffix(".sha256")

    def mutate(result: dict[str, Any]) -> None:
        result["roots"]["formal_vault_binding"] = reference
        result["roots"]["obsidian_run_root"] = str(obsidian_root)
        result["route"]["configuration_state"] = "AVAILABLE"
        result["workflow"] = {
            "status": "RUNNING",
            "terminal_result": None,
            "suspension_reason": None,
            "resume_phase": None,
        }
        result["outputs"]["obsidian"].update({
            "mode": reference.get("mode", "STAGING_ONLY"),
            "status": "INDEX_PENDING",
            "resume_phase": None,
            "active_manifest_sha256": handoff_sha,
        })
        result["active"]["status"] = "READY"

    final = apply_transition(
        runtime_root,
        state,
        transition_kind="OBSIDIAN_CONFIGURATION_BIND",
        phase_id="P16",
        mutate=mutate,
        validate_state=validate_state_invariants,
        write_state=write_state,
        append_journal=append_journal,
        details={
            "binding_id": reference["binding_id"],
            "handoff_sha256": handoff_sha,
            "handoff_path": str(handoff_path),
            "authorized_by": str(args.authorized_by),
            "authorization_event_id": str(args.authorization_event_id),
        },
        artifact_writes=[
            {
                "target_path": str(handoff_path),
                "target_relative_path": handoff_path.relative_to(
                    obsidian_root
                ).as_posix(),
                "target_precondition": "PATH_MUST_NOT_EXIST",
                "expected_absent": True,
                "expected_before_sha256": None,
                "planned_after_sha256": handoff_sha,
                "content": handoff_content,
            },
            {
                "target_path": str(handoff_sidecar),
                "target_relative_path": handoff_sidecar.relative_to(
                    obsidian_root
                ).as_posix(),
                "target_precondition": "PATH_MUST_NOT_EXIST",
                "expected_absent": True,
                "expected_before_sha256": None,
                "planned_after_sha256": sha256_bytes(
                    (handoff_sha + "\n").encode("utf-8")
                ),
                "content": handoff_sha + "\n",
            },
        ],
        lock_held=True,
    )
    emit_json(final)
    return 0


def cmd_configure_obsidian(args: argparse.Namespace) -> int:
    runtime_root = Path(args.runtime_root).resolve()
    with exclusive_runtime_lock(runtime_root):
        state = load_state(runtime_root)
        repair_recovery(runtime_root, state)
        return _cmd_configure_obsidian_locked(args)


def _cmd_recover_locked(args: argparse.Namespace) -> int:
    runtime_root = Path(args.runtime_root).resolve()
    state = load_state(runtime_root)
    # Recovery itself must first finish any interrupted lower-level
    # transition.  Otherwise a crash during REPAIR_HANDOFF_COMMIT can leave
    # this command looking at the pre-transition state and incorrectly report
    # that no handoff exists.  The lock is held by cmd_recover, so this is
    # safe and does not introduce a nested lock.
    repair_recovery(runtime_root, state)
    state = load_state(runtime_root)
    pointer = state.get("active", {}).get("repair_handoff")
    if not isinstance(pointer, dict):
        raise ValueError(
            "semantic recovery requires an active Repair Handoff; a free-form reason is not sufficient"
        )
    if state.get("active", {}).get("status") != "REPAIR_REQUIRED":
        raise ValueError("semantic recovery requires active.status=REPAIR_REQUIRED")
    handoff = load_handoff(runtime_root, pointer)
    if args.handoff_id and str(args.handoff_id) != str(handoff.get("handoff_id")):
        raise ValueError("the requested handoff ID is not the active Repair Handoff")
    if handoff.get("job_id") != state["identity"]["job_id"] or handoff.get("run_id") != state["identity"]["run_id"]:
        raise ValueError("Repair Handoff belongs to another Runtime job")
    if handoff.get("phase_plan_revision") != state["route"]["phase_plan_revision"]:
        raise ValueError("Repair Handoff belongs to another phase plan")
    plan = list(state["route"]["ordered_phase_ids"])
    current = current_phase_id(state)
    created_from = handoff["created_from"]
    if created_from["failed_phase"] != current:
        raise ValueError("active Repair Handoff failed_phase does not match the current phase")
    target = str(args.to_phase or handoff["return_to_phase"])
    if target not in plan:
        raise ValueError("recovery target is not in the active phase plan")
    current_index = len(plan) if current == TERMINAL_PHASE else plan.index(current)
    target_index = plan.index(target)
    if target != handoff["return_to_phase"]:
        raise ValueError("recovery target must equal Repair Handoff.return_to_phase")
    if target_index > current_index:
        raise ValueError("recovery target cannot be later than the failed responsibility")
    if target == "P00":
        raise ValueError("recovery cannot return to P00")
    active_receipt = state["active"]["validation_receipt_id"]

    def mutate(result: dict[str, Any]) -> None:
        for index, phase_id in enumerate(plan):
            record = result["phase_records"][phase_id]
            if index < target_index:
                continue
            if phase_id == target:
                record["status"] = "ACTIVE"
                record["attempt"] += 1
                record["recovery_epoch"] += 1
            elif record["status"] not in {"PENDING"}:
                record["status"] = "STALE"
            record["written_targets"] = []
        result["execution"]["committed_phase_ids"] = [
            phase_id for phase_id in result["execution"]["committed_phase_ids"]
            if plan.index(phase_id) < target_index
        ]
        result["execution"]["repair_counts"][target] = (
            int(result["execution"]["repair_counts"].get(target, 0)) + 1
        )
        result["cursor"] = {
            "current_phase": target,
            "phase_index": target_index,
            "attempt": result["phase_records"][target]["attempt"],
            "recovery_epoch": result["phase_records"][target]["recovery_epoch"],
            "current_role": get_phase(target).role,
        }
        result["active"] = {
            "status": "RECOVERY_READY",
            "action_id": None,
            "context_pack_sha256": None,
            "validation_receipt_id": None,
            "input_fingerprint": None,
            "repair_handoff": {
                **pointer,
                "status": "IN_PROGRESS",
            },
        }
        result["execution"]["semantic_completion_evidence"] = []
        result["blockers"] = [{
            "code": "REPAIR_IN_PROGRESS",
            "handoff_id": handoff["handoff_id"],
            "failed_phase": handoff["created_from"]["failed_phase"],
            "return_to_phase": target,
            "repair_attempt": handoff["repair_attempt"],
            "first_loss_boundary": handoff["first_loss_boundary"],
            "failure_fingerprint": handoff["failure_fingerprint"],
            "repair_instruction": "Read the exact Repair Handoff and satisfy every defect acceptance_condition before rechecking the failed phase.",
        }]
        result["workflow"] = {
            "status": "RUNNING",
            "terminal_result": None,
            "suspension_reason": None,
            "resume_phase": None,
        }
        if target_index <= plan.index("P14"):
            result["domain_states"]["BUSINESS"] = {
                "access_state": "READ_WRITE",
                "sealed_by_phase": None,
                "sealed_snapshot_sha256": None,
                "sealed_at": None,
            }
            if result["publication_release"]["verdict"] == "PUBLISHABLE":
                result["publication_release"]["integrity_status"] = "STALE"
            if result["route"]["obsidian_enabled"]:
                result["outputs"]["obsidian"].update({
                    "status": "INDEX_PENDING",
                    "active_manifest_sha256": None,
                    "resume_phase": None,
                })

    def revoke(transition_id: str) -> None:
        if active_receipt:
            try:
                write_receipt_marker(runtime_root, active_receipt, "REVOKED", {
                    "schema_version": "action-validation-receipt-revoked-v1",
                    "receipt_id": active_receipt,
                    "revoked_by_transition_id": transition_id,
                    "reason": str(args.reason),
                    "revoked_at": utc_now(),
                })
            except ValueError:
                pass

    final = apply_transition(
        runtime_root,
        state,
        transition_kind="PHASE_RECOVERY",
        phase_id=target,
        mutate=mutate,
        validate_state=validate_state_invariants,
        write_state=write_state,
        append_journal=append_journal,
        details={
            "from_phase": current,
            "to_phase": target,
            "handoff_id": handoff["handoff_id"],
            "handoff_sha256": pointer["sha256"],
            "failure_fingerprint": handoff["failure_fingerprint"],
            "repair_attempt": handoff["repair_attempt"],
            "reason": str(args.reason or ""),
        },
        after_commit=revoke,
        lock_held=True,
    )
    emit_json(final)
    return 0


def cmd_recover(args: argparse.Namespace) -> int:
    runtime_root = Path(args.runtime_root).resolve()
    with exclusive_runtime_lock(runtime_root):
        return _cmd_recover_locked(args)


def cmd_status(args: argparse.Namespace) -> int:
    runtime_root = Path(args.runtime_root).resolve()
    state = load_state(runtime_root)
    emit_json({
        "state": state,
        "recovery_inspection": inspect_recovery(runtime_root, state),
    })
    return 0


def cmd_inspect_recovery(args: argparse.Namespace) -> int:
    runtime_root = Path(args.runtime_root).resolve()
    state = load_state(runtime_root)
    report = inspect_recovery(runtime_root, state)
    emit_json(report)
    return 0 if report["status"] in {"CLEAN", "REPAIRABLE"} else 75


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    bootstrap = sub.add_parser("bootstrap", help="create Runtime State v2 and commit P00")
    bootstrap.add_argument("--runtime-root", required=True)
    bootstrap.add_argument("--business-root")
    bootstrap.add_argument("--business-output", help="deprecated alias for --business-root")
    bootstrap.add_argument("--source", required=True)
    bootstrap.add_argument("--task-contract", required=True)
    bootstrap.add_argument("--goal", help="deprecated display alias; must exactly match author_request")
    bootstrap.add_argument("--skip-obsidian", action="store_true")
    bootstrap.add_argument("--obsidian-config")
    bootstrap.add_argument("--authorized-by")
    bootstrap.add_argument("--authorization-event-id")
    bootstrap.set_defaults(func=cmd_bootstrap)

    source_authority = sub.add_parser("source-authority", help="run P01")
    source_authority.add_argument("--runtime-root", required=True)
    source_authority.set_defaults(func=cmd_source_authority)

    source_model = sub.add_parser("source-model", help="run P02")
    source_model.add_argument("--runtime-root", required=True)
    source_model.set_defaults(func=cmd_source_model)

    context = sub.add_parser("emit-turn", help="build and commit the current semantic context")
    context.add_argument("--runtime-root", required=True)
    context.set_defaults(func=cmd_emit_turn)

    validate_action = sub.add_parser("validate-action", help="strictly validate a Codex response and create a receipt")
    validate_action.add_argument("--runtime-root", required=True)
    validate_action.add_argument("--response", required=True)
    validate_action.set_defaults(func=cmd_validate_action)

    execute_action = sub.add_parser("execute-action", help="execute one action bound to a validation receipt")
    execute_action.add_argument("--runtime-root", required=True)
    execute_action.add_argument("--response", required=True)
    execute_action.add_argument("--receipt-id", required=True)
    execute_action.set_defaults(func=cmd_execute_action)

    advance = sub.add_parser("advance", help="run the active phase gate and commit on success")
    advance.add_argument("--runtime-root", required=True)
    advance.set_defaults(func=cmd_advance)

    configure = sub.add_parser("configure-obsidian", help="bind a trusted read-only Vault and resume P16")
    configure.add_argument("--runtime-root", required=True)
    configure.add_argument("--obsidian-config", required=True)
    configure.add_argument("--authorized-by", required=True)
    configure.add_argument("--authorization-event-id", required=True)
    configure.set_defaults(func=cmd_configure_obsidian)

    submit_intent = sub.add_parser(
        "submit-author-intent",
        help="bind the author's natural-language response to the adaptive P17 atomic-note focus question",
    )
    submit_intent.add_argument("--runtime-root", required=True)
    submit_intent.add_argument("--response-file", required=True)
    submit_intent.set_defaults(func=cmd_submit_author_intent)

    apply_obsidian = sub.add_parser(
        "apply-obsidian",
        help="apply the exact P21 manifest after human review and SHA-256 approval",
    )
    apply_obsidian.add_argument("--runtime-root", required=True)
    apply_obsidian.add_argument("--approval-manifest-sha256", required=True)
    apply_obsidian.set_defaults(func=cmd_apply_obsidian)

    status = sub.add_parser("status", help="show State v2 and recovery inspection")
    status.add_argument("--runtime-root", required=True)
    status.set_defaults(func=cmd_status)

    inspect = sub.add_parser("inspect-recovery", help="inspect immutable transition markers")
    inspect.add_argument("--runtime-root", required=True)
    inspect.set_defaults(func=cmd_inspect_recovery)

    recover = sub.add_parser("recover", help="explicitly recover to an earlier phase in the active plan")
    recover.add_argument("--runtime-root", required=True)
    recover.add_argument("--to-phase", required=False, choices=routable_phase_ids())
    recover.add_argument("--handoff-id", required=False)
    recover.add_argument("--reason", required=False, default="")
    recover.set_defaults(func=cmd_recover)
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        return int(args.func(args))
    except RuntimeCliError as exc:
        emit_json(emit_cli_error(exc, str(args.command)))
        return int(exc.exit_code)
    except Exception as exc:
        error = RuntimeCliError(
            "RUNTIME_COMMAND_FAILED",
            str(exc),
            exit_code=1,
            details={"exception_type": type(exc).__name__},
        )
        emit_json(emit_cli_error(error, str(args.command)))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
