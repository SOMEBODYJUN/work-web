"""Stable phase metadata for the single-thread Math Longform runtime.

This registry controls execution only.  It deliberately does not redefine any
mathematical, provenance, or publication rule from the bundled skill.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping


TERMINAL_PHASE = "TERMINAL"


@dataclass(frozen=True)
class PhaseContract:
    phase_id: str
    name: str
    role: str
    next_phase: str
    required_reads: tuple[str, ...]
    agent_writes: tuple[str, ...] = ()
    runtime_writes: tuple[str, ...] = ()
    deterministic_command: str | None = None
    notes: str = ""
    execution_kind: str = "HYBRID"
    handler_key: str | None = None
    routable: bool = True
    implementation_status: str = "LEGACY_COMPATIBLE"
    allowed_outcomes: tuple[str, ...] = ()


@dataclass(frozen=True)
class AgentPhaseBrief:
    """The task contract placed directly in an Obsidian semantic turn."""

    phase_id: str
    mission: str
    objective: str
    success_conditions: tuple[str, ...]
    prohibitions: tuple[str, ...]
    handoff: str


_PHASES = (
    PhaseContract(
        "P00",
        "THREAD_BOOTSTRAP",
        "RUNTIME_BOOTSTRAPPER",
        "P01",
        ("VERSION", "AGENTS.md", "SKILL.md"),
        runtime_writes=("runtime_state.json", "runtime_journal.jsonl"),
        notes="Creates only runtime-owned state outside the business output directory.",
    ),
    PhaseContract(
        "P01",
        "SOURCE_AUTHORITY",
        "SOURCE_AUTHORITY_MANAGER",
        "P02",
        ("references/CANONICAL_SOURCE_PROTOCOL.md", "references/SECURITY_BOUNDARY.md"),
        deterministic_command="pipeline.py init",
        notes="Uses the bundled pipeline entry point; it owns the initial business state files.",
    ),
    PhaseContract(
        "P02",
        "SOURCE_MODEL",
        "SOURCE_MODEL_BUILDER",
        "P03",
        (
            "source_canonical.txt",
            "source_revision.json",
            "source_atom_ledger.jsonl",
            "source_formula_block_ledger.jsonl",
            "author_question_obligation_ledger.jsonl",
            "source_math_risk_ledger.jsonl",
        ),
        deterministic_command="pipeline.py prepare-source + validate --mode source_atomization",
        notes="Deterministic intake creates obligations; it never resolves their semantics.",
    ),
    PhaseContract(
        "P03",
        "SOURCE_REVIEW",
        "SOURCE_REVIEWER",
        "P04",
        (
            "source_canonical.txt",
            "source_revision.json",
            "source_atom_ledger.jsonl",
            "source_formula_block_ledger.jsonl",
            "author_question_obligation_ledger.jsonl",
            "source_math_risk_ledger.jsonl",
            "active_state.json",
            "user_feedback_ledger.jsonl",
            "author_task_contract.json",
        ),
        agent_writes=(
            "source_formula_block_ledger.jsonl",
            "author_question_obligation_ledger.jsonl",
            "source_math_risk_ledger.jsonl",
            "active_state.json",
        ),
        notes="Reread the whole canonical source. Confirm, dismiss, or reclassify every P02 question candidate; add missed obligations; complete the source-wide author-intent and mathematical semantic scans. Mathematical risks come from full-context AI review, never keyword detectors. The three P03 ledgers are the sole source-obligation identity authority; active_state.json carries only resume and actual-user-feedback state and must not transcribe AQ/FB/MR IDs. A source patch is proposed here but applied only by the canonical patch command.",
    ),
    PhaseContract("P04", "MATH_LOCKS", "MATH_LOCK_BUILDER", "P05", ("author_task_contract.json", "source_canonical.txt", "source_atom_ledger.jsonl", "source_formula_block_ledger.jsonl", "author_question_obligation_ledger.jsonl", "source_math_risk_ledger.jsonl"), agent_writes=("publication_blueprint.json",), runtime_writes=("source_atom_ledger.jsonl", "source_atom_ledger.md", "surface_decision_review.jsonl", "voice_expression_ledger.md", "symbol_ledger.md", "explanation_chain_ledger.md", "math_statement_ledger.md", "proof_obligations.md"), notes="The Agent-reviewed blueprint is the single semantic authority. It binds every P03 AQ/FB/MR obligation to overlapping Atom/functions, then Runtime materializes atom functions, surface locks, and five Markdown ledgers. P02's SUBSTANTIVE_CONTENT floor is never a complete review. If P04 declares a source_atom_resegmentation, Runtime losslessly rebuilds the source Atom/sentence/chunk and P03 overlap mirrors in the same transaction; inherited child contracts remain pending until explicitly re-reviewed."),
    PhaseContract("P05", "DEPENDENCY_AND_PLAN", "STRUCTURE_PLANNER", "P06", ("author_task_contract.json", "source_canonical.txt", "source_revision.json", "source_atom_ledger.jsonl", "source_chunk_index.jsonl", "publication_blueprint.json", "source_formula_block_ledger.jsonl", "author_question_obligation_ledger.jsonl", "source_math_risk_ledger.jsonl", "active_state.json", "user_feedback_ledger.jsonl", "math_statement_ledger.md", "proof_obligations.md", "voice_expression_ledger.md", "explanation_chain_ledger.md"), agent_writes=("cross_chunk_dependency_map.jsonl", "section_context_prefetch_plan.jsonl", "section_execution_plan.jsonl", "section_plan.md", "merge_plan.md", "pre_final_plan.md", "heading_voice_gate.md", "source_destination_ledger.md"), runtime_writes=("cross_chunk_dependency_map.md", "section_context_prefetch_plan.md", "section_execution_plan.md", "quality_contract.json", "context_pack_manifest.json"), notes="Compile every P04 Atom/function responsibility into one realization obligation carrying the complete exact Atom. Route each author expansion directive once. Runtime compiles the one whole-article, section, Atom, and expansion quality contract; a section, destination, or common topic is not realization."),
    PhaseContract("P06", "DRAFT", "ARTICLE_BUILDER", "P07", ("context_pack_manifest.json", "author_task_contract.json", "quality_contract.json", "source_canonical.txt", "source_identity.json", "source_provenance.json", "source_revision.json", "source_normalization_map.jsonl", "source.txt", "source_chunk_index.jsonl", "source_sentence_index.jsonl", "source_atom_ledger.jsonl", "source_atom_ledger.md", "publication_blueprint.json", "cross_chunk_dependency_map.jsonl", "section_context_prefetch_plan.jsonl", "section_execution_plan.jsonl", "section_execution_plan.md", "section_plan.md", "merge_plan.md", "pre_final_plan.md", "heading_voice_gate.md", "source_destination_ledger.md", "source_formula_block_ledger.jsonl", "author_question_obligation_ledger.jsonl", "source_math_risk_ledger.jsonl", "math_statement_ledger.md", "proof_obligations.md", "voice_expression_ledger.md", "symbol_ledger.md", "explanation_chain_ledger.md", "active_state.json", "user_feedback_ledger.jsonl"), agent_writes=("draft.md", "publication_blueprint.json"), notes="Execute the complete P05 context pack, realization obligations, section budgets, and author expansion directives. Every Atom/function cites a complete unique non-heading output unit; expansion evidence is separately identifiable and cannot substitute for source realization."),
    PhaseContract("P07", "REVIEW_AND_FINAL", "SERIAL_CONTENT_REVIEWER", "P08", ("context_pack_manifest.json", "author_task_contract.json", "quality_contract.json", "source_canonical.txt", "draft.md", "source_atom_ledger.jsonl", "section_execution_plan.jsonl", "publication_blueprint.json", "math_statement_ledger.md", "proof_obligations.md", "voice_expression_ledger.md", "explanation_chain_ledger.md"), agent_writes=("independent_review.md", "final.md", "publication_blueprint.json"), notes="A fresh native read-only reviewer must recheck every Atom/function, section budget, and author task directive against draft.md. A topic sentence, destination, or worker-authored PASS is not semantic evidence."),
    PhaseContract("P08", "OPTIMIZE_AND_STANDARDIZE", "FORMAT_STANDARDIZER", "P09", ("context_pack_manifest.json", "author_task_contract.json", "quality_contract.json", "source_canonical.txt", "source_atom_ledger.jsonl", "section_execution_plan.jsonl", "final.md", "publication_blueprint.json", "voice_expression_ledger.md", "symbol_ledger.md", "math_statement_ledger.md", "proof_obligations.md", "explanation_chain_ledger.md"), agent_writes=("post_final_structure_review.md", "optimized_final.md", "standardized_final.md", "publication_blueprint.json"), notes="Review optimized_final.md and standardized_final.md separately for every Atom/function, author directive, and quality budget; stop at the first loss instead of copying one file over the other."),
    PhaseContract("P09", "VERIFICATION_LOCKS", "TRACE_BUILDER", "P10", ("author_task_contract.json", "quality_contract.json", "source_canonical.txt", "standardized_final.md", "source_atom_ledger.jsonl", "publication_blueprint.json", "section_execution_plan.jsonl", "math_statement_ledger.md", "proof_obligations.md", "voice_expression_ledger.md", "symbol_ledger.md", "explanation_chain_ledger.md"), agent_writes=("final_paragraph_index.md", "final_trace_map.md", "final_claim_ledger.jsonl", "symbol_lock_report.md", "integration_report.md", "coverage_check.md", "ledger_integrity_check.md", "statement_completeness_check.md", "formula_compatibility_report.md"), runtime_writes=("final_claim_ledger.md",), notes="Build exact standardized-final trace and claim locks. JSONL is authoritative for claims; Runtime creates its Markdown mirror. P12 must not overwrite these reviewed P09 artifacts."),
    PhaseContract("P10", "ATTACK_AND_REVISION", "SERIAL_ATTACKER_REVISER", "P11", ("context_pack_manifest.json", "author_task_contract.json", "quality_contract.json", "source_canonical.txt", "source_atom_ledger.jsonl", "section_execution_plan.jsonl", "standardized_final.md", "publication_blueprint.json", "math_statement_ledger.md", "proof_obligations.md", "voice_expression_ledger.md", "explanation_chain_ledger.md"), agent_writes=("attack_report.md", "revision_tasks.md", "revised_final.md", "revision_changelog.md", "regression_check.md", "revised_trace_map.md", "publication_blueprint.json"), notes="Perform the semantic attack before revision. Recheck every Atom/function, section budget, and author directive after the bounded revision; accepted evidence changes must be synchronized into the blueprint."),
    PhaseContract("P11", "AIGC_REWRITE", "AIGC_REWRITER", "P12", ("context_pack_manifest.json", "author_task_contract.json", "quality_contract.json", "source_canonical.txt", "source_atom_ledger.jsonl", "section_execution_plan.jsonl", "revised_final.md", "voice_expression_ledger.md", "publication_blueprint.json", "revised_trace_map.md", "math_statement_ledger.md", "proof_obligations.md", "explanation_chain_ledger.md"), agent_writes=("aigc_source_type_ledger.md", "aigc_rewrite_tasks.md", "aigc_rewritten_final.md", "aigc_rewrite_changelog.md", "post_aigc_regression_check.md", "post_aigc_trace_check.md", "post_aigc_formula_check.md", "post_aigc_clean_gate.md", "clean_final_gate.md", "publication_blueprint.json"), notes="P11 reviews every Atom/function and task directive, supplies exact target evidence used by P12, and meets the current quality contract; unsupported positional or topic-only mapping is forbidden."),
    PhaseContract("P12", "PUBLICATION_ASSEMBLY", "PUBLICATION_ASSEMBLER", "P13", ("aigc_rewritten_final.md", "publication_blueprint.json", "author_task_contract.json", "quality_contract.json", "source_canonical.txt", "source_atom_ledger.jsonl"), runtime_writes=("publication_final.md", "atom_consumption_candidates.jsonl", "publication_sentence_trace.jsonl", "publication_sentence_trace.md", "publication_paragraph_index.md", "publication_trace_map.md", "publication_claim_ledger.jsonl", "publication_claim_ledger.md", "heading_authorization.jsonl", "publication_fragment_authorization.jsonl"), deterministic_command="pipeline.py prepare-publication", notes="Pure mechanical assembly. All authorization and consumption outputs remain pending until full P13 semantic review; this phase writes no PASS reports."),
    PhaseContract("P13", "CONTENT_ACCEPTANCE", "SERIAL_FINAL_REVIEWER", "P14", ("publication_final.md", "publication_sentence_trace.jsonl", "publication_fragment_authorization.jsonl", "heading_authorization.jsonl", "publication_claim_ledger.jsonl", "atom_consumption_candidates.jsonl", "author_task_contract.json", "quality_contract.json", "source_canonical.txt", "source_atom_ledger.jsonl", "section_execution_plan.jsonl", "publication_blueprint.json", "math_statement_ledger.md", "proof_obligations.md", "source_formula_block_ledger.jsonl", "author_question_obligation_ledger.jsonl", "source_math_risk_ledger.jsonl"), agent_writes=("publication_fragment_authorization.jsonl", "heading_authorization.jsonl", "publication_content_review.json", "mathematical_review.json", "omission_ledger.md", "failure_recovery_log.md", "PUBLICATION_AUDIT_REPORT.md", "publication_blueprint.json"), notes="Reopen every exact atom span, P03 AQ/FB/MR obligation, P05 realization obligation, author task directive, section budget, and mapped output unit. P13 writes the semantic audit body; P14 alone replaces its machine-evidence fields. Only the deterministic P13 finalizer may write final obligation states and CONSUMED."),
    PhaseContract("P14", "RELEASE_EVIDENCE", "DETERMINISTIC_RELEASE_RUNNER", TERMINAL_PHASE, ("publication_final.md", "publication_content_review.json", "mathematical_review.json"), deterministic_command="pipeline.py release", notes="Codex has no write permission to release evidence."),
    PhaseContract(
        "P15",
        "WECHAT_OPTIONAL",
        "WECHAT_FORMATTER",
        TERMINAL_PHASE,
        ("publication_final.md",),
        agent_writes=("wechat_publication_final.md", "wechat_publish_plan.md"),
        handler_key=None,
        routable=False,
        implementation_status="DEFERRED",
    ),
    PhaseContract(
        "P16",
        "OBSIDIAN_VAULT_LEARNING",
        "VAULT_STYLE_AND_GRAPH_INDEXER",
        "P17",
        ("handoff/publication_handoff_manifest.json",),
        execution_kind="PYTHON_DETERMINISTIC",
        handler_key="obsidian.index_vault",
        implementation_status="IMPLEMENTED_COPY_FIRST_V1",
        allowed_outcomes=("INDEXED", "CONFIGURATION_REQUIRED", "BLOCKED"),
        notes="Read-only Vault learning plus a clean copy of P00-P15 authorial evidence. It does not choose notes.",
    ),
    PhaseContract(
        "P17",
        "AUTHOR_KNOWLEDGE_INTENT",
        "AUTHOR_INTENT_COMPILER",
        "P18",
        (
            "author-input/AUTHOR_INTENT_QUESTIONS.md",
            "author-input/AUTHOR_RESPONSE.md",
            "evidence/publication_final.md",
            "index/vault_profile.json",
        ),
        agent_writes=("semantic/author_intent_contract.json",),
        execution_kind="LLM_SEMANTIC",
        handler_key="obsidian.compile_author_focus",
        implementation_status="IMPLEMENTED_COPY_FIRST_V1",
        allowed_outcomes=("AUTHOR_INTENT_REQUIRED", "AUTHOR_INTENT_BOUND", "BLOCKED"),
        notes="Ask one required author-focus question and at most two conditional follow-ups. The complete Article remains required. Never ask for tags, folders, existing notes, links, or MOC choices.",
    ),
    PhaseContract(
        "P18",
        "COPY_FIRST_PAGE_PLANNING",
        "COPY_FIRST_SEED_PLANNER",
        "P19",
        (
            "semantic/author_intent_contract.json",
            "evidence/publication_final.md",
            "index/vault_profile.json",
            "index/vault_note_index.json",
        ),
        agent_writes=("semantic/copy_first_page_plan.json",),
        runtime_writes=("page-seeds/", "page_seed_manifest.json"),
        execution_kind="LLM_SEMANTIC",
        handler_key="obsidian.materialize_copy_first_seeds",
        implementation_status="IMPLEMENTED_COPY_FIRST_V1",
        notes="The Agent writes one body-free plan. Runtime copies the complete Article, exact publication slices, and inspected Vault preimages into immutable page seeds.",
    ),
    PhaseContract(
        "P19",
        "BOUNDED_PAGE_PATCHING",
        "OBSIDIAN_PAGE_PATCHER",
        "P20",
        ("semantic/copy_first_page_plan.json", "page_seed_manifest.json", "page-seeds/"),
        agent_writes=("semantic/page_patch_bundle.json",),
        runtime_writes=("page-candidates/", "diffs/", "page_patch_application.json"),
        execution_kind="LLM_SEMANTIC",
        handler_key="obsidian.apply_bounded_page_patches",
        implementation_status="IMPLEMENTED_COPY_FIRST_V1",
        allowed_outcomes=("PATCHES_APPLIED", "BLOCKED"),
        notes="The Agent may only submit exact local patches bound to seed hashes. Blank-page generation and whole-page rewrites are forbidden.",
    ),
    PhaseContract(
        "P20",
        "OBSIDIAN_PREVIEW_AND_DELIVERY",
        "OBSIDIAN_DETERMINISTIC_PREVIEWER",
        "P21",
        ("page_patch_application.json", "page-candidates/", "diffs/"),
        runtime_writes=("staging/", "delivery/"),
        execution_kind="PYTHON_DETERMINISTIC",
        handler_key="obsidian.preview_and_export",
        implementation_status="IMPLEMENTED_COPY_FIRST_V1",
        allowed_outcomes=("STAGED", "BLOCKED"),
        notes="Checks only mechanical safety, formula delimiters, link closure, paths, hashes, and clean export. It never judges or rewrites mathematics.",
    ),
    PhaseContract(
        "P21",
        "OBSIDIAN_IMPORT_VALIDATION",
        "OBSIDIAN_DETERMINISTIC_VALIDATOR",
        TERMINAL_PHASE,
        ("staging/staging_manifest.json", "page_patch_application.json"),
        execution_kind="PYTHON_DETERMINISTIC",
        handler_key="obsidian.validate_import",
        implementation_status="IMPLEMENTED_COPY_FIRST_V1",
        allowed_outcomes=("READY_FOR_IMPORT", "READY_FOR_EXPORT", "SNAPSHOT_CONFLICT", "BLOCKED"),
        notes="Validates exact candidate hashes, current Vault preconditions, reciprocal closure, and the new-tag approval delta. Application remains separately approval-bound.",
    ),
)

PHASES: Mapping[str, PhaseContract] = {phase.phase_id: phase for phase in _PHASES}


PUBLICATION_AGENT_PHASE_BRIEFS: Mapping[str, AgentPhaseBrief] = {
    "P03": AgentPhaseBrief(
        phase_id="P03",
        mission="Resolve source-intake obligations before article planning begins.",
        objective="Reread the whole canonical source, resolve or block every formula, author-question, mathematical-risk, active-state, and feedback obligation, and add any obligations missed by deterministic intake.",
        success_conditions=(
            "Every formula block is source-supported and resolved, or remains explicitly blocked for author review.",
            "Every P02 author-question candidate is confirmed, dismissed with a source-grounded reason, or reclassified, and missed questions are added.",
            "The whole-source mathematical semantic scan is complete; every material risk has a source-bound disposition, or one explicit no-risk conclusion records the reviewed result.",
            "The current P03 ledgers are the only source-obligation identity list; active state contains no handwritten AQ/FB/MR inventory.",
            "No unresolved source-review item is hidden by switching to full-publication mode.",
        ),
        prohibitions=(
            "Do not guess damaged formulas or silently repair source bytes.",
            "Do not treat P02 keyword candidates as semantic truth or their absence as proof that no obligation exists.",
            "Do not infer mathematical safety or risk from formula tokens, topic keywords, or historical manuscript patterns.",
            "Do not copy, summarize, or range-compress AQ/FB/MR identities into active_state.json; P04 and Runtime enumerate the authoritative ledgers directly.",
            "Do not write the article, section plan, or P04 Atom-function contracts in P03.",
            "Do not bypass the canonical source-patch path when a source change is genuinely required.",
        ),
        handoff="P04 receives a source-wide reviewed obligation set and rereads every Atom to build the complete semantic and surface contract.",
    ),
    "P04": AgentPhaseBrief(
        phase_id="P04",
        mission="Turn the deterministic source floor into a complete semantic contract.",
        objective="Reread every exact Atom in local and whole-source context, assign every independent function, and decide the final surface lock without inferring roles from keywords.",
        success_conditions=(
            "Every current non-duplicate Atom has one reviewed contract.",
            "Every Atom contract contains a nine-dimension function_matrix; each function is explicitly REQUIRED or NOT_REQUIRED with exact source evidence and a concrete semantic reason.",
            "The reviewed required_functions set preserves or explicitly extends the P02 floor; SUBSTANTIVE_CONTENT alone is allowed only after an actual all-Atom semantic decision, never because it was the P02 default.",
            "Every question, explanation chain, method, proof dependency, perspective, intuition, follow-up, warning, and voice responsibility is decided from source evidence.",
            "Every actionable P03 AQ/FB/MR row has one source_obligation_contract bound to every overlapping Atom and the exact required functions.",
            "Every P02 surface prelock is confirmed, downgraded only with a demonstrated false-positive reason, or extended by the semantic reviewer.",
            "When one source span contains independent surface or semantic responsibilities that cannot share one contract, declare a lossless P04 source_atom_resegmentation and complete a fresh contract for every child before validation.",
        ),
        prohibitions=(
            "Do not classify functions by keyword presence or absence.",
            "Do not import old ledgers or CONSUMED states into the current source revision.",
            "Do not collapse a proof route, construction, question, or method observation into a topic summary.",
            "Do not leave a P03 obligation merely routed to a destination; bind its ID and complete source span into the Atom/function contract.",
            "Do not downgrade a BYTE_EXACT prelock because a paraphrase has similar meaning or emotional strength.",
            "Do not pass an inherited resegmented child contract; the child must receive an explicit source-grounded semantic and surface decision.",
        ),
        handoff="P05 receives the complete multi-function contracts and must compile one source-grounded realization obligation per function.",
    ),
    "P05": AgentPhaseBrief(
        phase_id="P05",
        mission="Compile the reviewed source model into a lossless article-construction plan.",
        objective="Give every Atom/function pair one exact-source realization obligation, route each Atom and each author expansion directive to one real section, and make the section plan compile into the one quantitative quality contract before prose is written.",
        success_conditions=(
            "Every non-duplicate Atom occurs in exactly one section execution row.",
            "Every required function has one realization_id, the complete exact Atom as source evidence, and a concrete writing instruction.",
            "Every realization carries exactly the P03 source_obligation_ids bound to that Atom/function, including an explicit empty list when none apply.",
            "Only functions of one Atom may share a realization group, with one concrete shared merge justification.",
            "A multi-chunk source has a real multi-section route and the section prefetch plan reopens its dependencies.",
            "Section order and titles are explicit; every author expansion directive is assigned exactly once and remains separate from source-preservation credit.",
            "The Runtime-compiled quality contract binds the author request, source, Atom contracts, section plan, CJK source budgets, and expansion budgets.",
        ),
        prohibitions=(
            "Do not treat a destination, heading, theorem name, or related topic as realization.",
            "Do not merge responsibilities merely because they discuss the same mathematical object.",
            "Do not merge different Atoms into one realization unit, even when they belong in one paragraph.",
            "Do not replace an author-selected proof or construction with a standard alternative.",
            "Do not write the article in P05.",
            "Do not choose a smaller budget to make a planned short article pass; numeric policy comes only from author_task_contract.json.",
        ),
        handoff="P06 receives a hash-bound context pack and executes the realization obligations section by section.",
    ),
    "P06": AgentPhaseBrief(
        phase_id="P06",
        mission="Write the first complete article without flattening the source into a summary.",
        objective="Execute every P05 realization obligation and author expansion directive in draft.md, record exact P06_DRAFT evidence, and meet the whole-article, section, Atom, and expansion budgets without using formulas as prose credit.",
        success_conditions=(
            "Every planned section is substantively written from its bound Atom contracts and dependency pack.",
            "Every Atom/function pair has one matching realization_id and one complete, unique non-heading output unit as target evidence.",
            "Every bound P03 obligation has its own source_obligation_result proving its required action and fulfillment mode in that output unit.",
            "Questions, explanation chains, methods, proof directions, author perspective, intuition, and follow-up requests survive as independent responsibilities.",
            "Any shared target unit belongs to functions of the same explicitly justified P05 realization group.",
            "Every required expansion directive has separate complete-unit evidence and criterion-by-criterion acceptance results in task_requirement_reviews.",
            "The P06 quality gate passes for the full article, every section, every measured substantive Atom, and every expansion directive.",
        ),
        prohibitions=(
            "Do not summarize a cluster of Atoms into their common conclusion.",
            "Do not use one generic sentence as evidence for unrelated responsibilities.",
            "Do not select a few words from a generic sentence as target evidence.",
            "Do not replace the source's method with an easier textbook proof.",
            "Do not certify a missing responsibility in publication_blueprint.json; repair draft.md first.",
            "Do not count headings, LaTeX, or expansion prose as replacement for source explanation.",
        ),
        handoff="P07 reopens the source and completed draft, and its final native reviewer may not trust P06's drafting rationale.",
    ),
    "P07": AgentPhaseBrief(
        phase_id="P07",
        mission="Review the draft against the source and produce the first accepted final article.",
        objective="Reopen the canonical source, P05 realization plan, P04 contracts, and draft.md; identify concrete content or mathematical defects, repair them in final.md, and record P07_FINAL evidence for every Atom/function pair.",
        success_conditions=(
            "independent_review.md cites exact source and draft locations for every defect or explicitly records that no defect remains.",
            "final.md preserves every P05 Atom/function realization and repairs the first loss boundary rather than compensating later.",
            "Every P07_FINAL function result is bound to the current final.md hash and a complete target output unit.",
            "A fresh native reviewer can verify the final without relying on P06's rationale or self-authored PASS language.",
            "Every task directive and every quantitative budget is rechecked against final.md rather than inherited from the draft.",
        ),
        prohibitions=(
            "Do not trust P06 destinations, topic coverage, or blueprint verdicts as proof of consumption.",
            "Do not replace an author-selected proof, construction, question, explanation chain, or method with a standard alternative.",
            "Do not neutralize author perspective or exact-surface material while calling the change stylistic cleanup.",
            "Do not postpone a known P06 loss to optimization, standardization, or publication review.",
            "Do not let newly added expansion prose hide a reduction in source-derived explanation.",
        ),
        handoff="P08 receives a source-accepted final.md and must prove preservation separately across optimization and standardization.",
    ),
    "P08": AgentPhaseBrief(
        phase_id="P08",
        mission="Optimize and standardize the accepted article without cumulative semantic loss.",
        objective="Transform final.md into optimized_final.md and then standardized_final.md as two distinct rewrite boundaries, reviewing every Atom/function after each transformation.",
        success_conditions=(
            "post_final_structure_review.md identifies the exact bounded changes authorized at this stage.",
            "Every Atom/function has a current P08_OPTIMIZED result against optimized_final.md.",
            "Every Atom/function is reviewed again under P08_STANDARDIZED against standardized_final.md rather than inheriting the optimized verdict.",
            "Formula, Markdown, and platform normalization leave proof routes, questions, explanations, methods, voice, and exact locks intact.",
            "Both P08 boundaries independently pass the same whole-article, section, Atom, and expansion quality contract.",
        ),
        prohibitions=(
            "Do not copy one preservation review across both P08 targets.",
            "Do not compress a long explanation into its conclusion or turn a question into a declarative sentence.",
            "Do not rewrite BYTE_EXACT spans or use formula formatting as permission to change mathematical content.",
            "Do not introduce unsupported headings, bridges, summaries, or editorial stance.",
            "Do not treat shorter standardized prose as automatically better when it violates a source or section budget.",
        ),
        handoff="P09 receives the exact standardized_final.md bytes and builds trace and claim locks without rewriting the article.",
    ),
    "P09": AgentPhaseBrief(
        phase_id="P09",
        mission="Build source-grounded reverse traces and claim locks for the standardized article.",
        objective="Map the exact standardized_final.md paragraphs, claims, symbols, and integration responsibilities back to current source Atoms, statements, proofs, and P08 preservation evidence.",
        success_conditions=(
            "Every declared P09 trace, claim, symbol, coverage, integrity, completeness, formula, and integration artifact is current and mutually consistent.",
            "Every substantive claim has source ownership, support type, transformation scope, and a non-blocking verdict.",
            "Trace and claim locations bind the exact standardized_final.md bytes and current source revision.",
            "The native reviewer verifies the evidence artifacts against source and article rather than accepting report prose as self-proof.",
        ),
        prohibitions=(
            "Do not edit standardized_final.md in a trace-building phase.",
            "Do not invent source ownership, proof IDs, or claim support to make reports complete.",
            "Do not use a paragraph-level topic link as proof for every claim or Atom function inside it.",
            "Do not treat a structurally complete report or validator-shaped PASS as semantic repair.",
        ),
        handoff="P10 receives an exact attack surface: standardized article, source contracts, and independently checked reverse evidence.",
    ),
    "P10": AgentPhaseBrief(
        phase_id="P10",
        mission="Attack the standardized article first, then apply only bounded source-grounded repairs.",
        objective="Reopen the source and P09 evidence, write a defect-only attack report and exact revision tasks, produce revised_final.md from those tasks, and recheck every Atom/function under P10_REVISED.",
        success_conditions=(
            "attack_report.md identifies defects before revision and cites exact source and article evidence.",
            "revision_tasks.md authorizes finite changes, and revision_changelog.md accounts for every applied change.",
            "revised_trace_map.md binds the current revised_final.md and every P10_REVISED Atom/function result passes.",
            "Regression review confirms that each repair fixed its defect without creating a new loss elsewhere.",
            "The revised article still passes every source, section, Atom, and author-expansion budget.",
        ),
        prohibitions=(
            "Do not let the attacker silently rewrite the article or let the reviser change unlisted material.",
            "Do not perform broad style improvement, proof substitution, or content expansion under a repair task.",
            "Do not repair a broken upstream contract by patching only the visible final prose.",
            "Do not carry unresolved PARTIAL or LOST functions into P11.",
        ),
        handoff="P11 receives a semantically complete revised_final.md and may perform only the bounded AIGC rewrite layer.",
    ),
    "P11": AgentPhaseBrief(
        phase_id="P11",
        mission="Remove unsupported AIGC surface while preserving every accepted source responsibility.",
        objective="Classify the current prose surface, define bounded rewrite tasks, produce aigc_rewritten_final.md, and bind every Atom/function and every non-heading output unit to current P11_AIGC evidence.",
        success_conditions=(
            "aigc_source_type_ledger.md and aigc_rewrite_tasks.md distinguish supported source expression from unsupported model-authored surface.",
            "aigc_rewritten_final.md applies only authorized rewrites and the changelog accounts for each change.",
            "Every Atom/function has current P11_AIGC evidence, and every non-heading output unit has a source-grounded mapping for P12.",
            "Task-authorized expansion units have separate current P11 evidence and are not misreported as source-Atom realization.",
            "P11 passes the same quality contract; removing model-like surface cannot reduce explanatory volume below any budget.",
            "All post-AIGC regression, trace, formula, clean-surface, and final gates agree on the exact output bytes.",
        ),
        prohibitions=(
            "Do not use an AI-detection score or generic style preference as rewrite authority.",
            "Do not compress explanations, questions, proof routes, methods, or author perspective while removing model-like prose.",
            "Do not invent replacement headings, transitions, reassurance, summaries, metaphors, or claims.",
            "Do not pre-author P13 review rows or declare any Atom CONSUMED.",
        ),
        handoff="P12 mechanically copies the exact P11 article bytes and builds only pending publication mappings; it performs no semantic review.",
    ),
    "P13": AgentPhaseBrief(
        phase_id="P13",
        mission="Perform final semantic and mathematical acceptance on the actual compiled publication.",
        objective="Reopen every exact source Atom, P05 realization obligation, mathematical risk, and mapped publication output unit; write current-hash P13 decisions for every function and authorize release only when the compiled bytes retain them all.",
        success_conditions=(
            "Every publication fragment and heading has a current source-grounded authorization rather than a pending or inherited verdict.",
            "publication_content_review.json and mathematical_review.json examine the actual publication_final.md bytes and contain no unresolved blocker.",
            "Every Atom/function has a current P13_PUBLICATION result with complete source and target evidence.",
            "Every P03 AQ/FB/MR obligation has a current P13 source_obligation_result; only then may the finalizer write the AQ final status.",
            "Omission, recovery, and audit records are honest; only after their acceptance may the deterministic finalizer write CONSUMED.",
            "The final reviewer checks the complete author task and every section, while the machine gate separately confirms CJK prose, Atom, and expansion budgets on publication_final.md.",
        ),
        prohibitions=(
            "Do not trust P11 PASS rows, P12 mappings, destinations, or related topic sentences as final consumption evidence.",
            "Do not review representative samples or merge several independent Atom responsibilities into one generic judgment.",
            "Do not reuse stale P13 files after recovery or write review files without current-epoch Action provenance.",
            "Do not hand-edit validator_result, release manifests, or P14 machine evidence.",
            "Do not use formula volume, headings, omission-row count, or unrelated expansion to conceal source compression.",
        ),
        handoff="P14 receives only a fully accepted publication and runs the deterministic release and evidence chain without changing prose.",
    ),
}


# P00-P15 retain their phase order and artifact contracts.  These briefs make
# every publication semantic turn self-describing without changing that path.
OBSIDIAN_AGENT_PHASE_BRIEFS: Mapping[str, AgentPhaseBrief] = {
    "P17": AgentPhaseBrief(
        phase_id="P17",
        mission="Bind the author's atomic-note focus without changing the released Article.",
        objective="Compile the required Article output and only the author-selected atomic-note directives into author_intent_contract.json v2.",
        success_conditions=(
            "The Article output is required and uses FULL_COPY.",
            "Every atomic-note directive carries an exact author-response quote.",
            "Source evidence locators point only into publication_final.md.",
        ),
        prohibitions=(
            "Do not ask the author for tags, folders, existing notes, links, or MOC decisions.",
            "Do not infer extra atomic notes from headings or importance.",
            "Do not omit the complete Article when the author says only one topic should be extracted.",
        ),
        handoff="P18 receives a small author-focus contract and builds one body-free Copy-first page plan.",
    ),
    "P18": AgentPhaseBrief(
        phase_id="P18",
        mission="Plan exact Copy-first seeds for one Article and the author-selected atomic notes.",
        objective="Write copy_first_page_plan.json without any rendered page body.",
        success_conditions=(
            "Exactly one Article uses FULL_ARTICLE_COPY.",
            "Each atomic note uses exact publication line slices and an author directive.",
            "Destinations follow the inspected Vault and tags are classified for approval.",
            "Every connection has two natural reciprocal sentences.",
            "The normal one-Article/one-atomic-note case explicitly chooses no MOC.",
        ),
        prohibitions=(
            "Do not put rendered_markdown, body, content, or prose payloads in the plan.",
            "Do not create atomic notes outside the author's directives.",
            "Do not invent a universal taxonomy or force an MOC.",
        ),
        handoff="Runtime materializes exact page seeds; P19 reopens those real files for bounded patching.",
    ),
    "P19": AgentPhaseBrief(
        phase_id="P19",
        mission="Adapt actual copied page seeds using only visible, local, hash-bound patches.",
        objective="Write one page_patch_bundle.json against the current page_seed_manifest.json.",
        success_conditions=(
            "Every patched page binds its exact seed SHA-256.",
            "Formula, heading, context, and link repairs are exact local operations.",
            "An empty operations array is used when a copied seed already needs no repair.",
        ),
        prohibitions=(
            "Do not regenerate a page from blank or replace the whole page.",
            "Do not hide deletions inside an unstructured rewrite.",
            "Do not write the formal Vault or place engineering artifacts in delivery.",
        ),
        handoff="Runtime applies exact patches and P20 produces diffs, preview, and the clean delivery package. This contract is also the future note-management Agent handoff.",
    ),
}


COMMON_RULE_READS = (
    "AGENTS.md",
    "SKILL.md",
    "references/SUPERVISOR_KERNEL.md",
    "references/CANONICAL_SOURCE_PROTOCOL.md",
    "references/CONTENT_AUTHORITY_PROTOCOL.md",
    "references/ACTIVE_STATE_AND_USER_FEEDBACK_PROTOCOL.md",
    "references/SECURITY_BOUNDARY.md",
    "references/SINGLE_THREAD_RUNTIME_PROTOCOL.md",
)


PHASE_RULE_READS: Mapping[str, tuple[str, ...]] = {
    "P03": (
        "references/FORMULA_BLOCK_CANONICALIZATION_PROTOCOL.md",
        "references/AUTHOR_QUESTION_OBLIGATION_PROTOCOL.md",
        "references/MATHEMATICAL_RISK_REVIEW_PROTOCOL.md",
        "references/SURFACE_DECISION_PROTOCOL.md",
        "references/FAILURE_RECOVERY_PROTOCOL.md",
    ),
    "P04": (
        "references/PUBLICATION_BLUEPRINT_PROTOCOL.md",
        "references/SOURCE_MICRO_ATOMIZATION_PROTOCOL.md",
        "references/CONTENT_FUNCTION_PRESERVATION_PROTOCOL.md",
        "references/DETAILED_WORKFLOW_PROTOCOL.md",
        "references/writing_expression_guide.md",
        "references/style_calibration.md",
    ),
    "P05": (
        "references/CROSS_CHUNK_DEPENDENCY_PROTOCOL.md",
        "references/LEDGER_CONTEXT_LOCK.md",
        "references/STRUCTURED_LEDGER_PROTOCOL.md",
        "references/DETAILED_WORKFLOW_PROTOCOL.md",
    ),
    "P06": ("references/DETAILED_WORKFLOW_PROTOCOL.md", "references/CONTENT_FUNCTION_PRESERVATION_PROTOCOL.md", "references/writing_expression_guide.md", "references/style_calibration.md", "references/mdnice_formula_rules.md"),
    "P07": ("references/DETAILED_WORKFLOW_PROTOCOL.md", "references/CONTENT_FUNCTION_PRESERVATION_PROTOCOL.md", "references/PUBLICATION_CONTENT_ACCEPTANCE_PROTOCOL.md"),
    "P08": ("references/DETAILED_WORKFLOW_PROTOCOL.md", "references/CONTENT_FUNCTION_PRESERVATION_PROTOCOL.md", "references/writing_expression_guide.md", "references/mdnice_formula_rules.md"),
    "P09": ("references/CLAIM_SOURCE_OBLIGATION_MODEL.md", "references/OUTPUT_FRAGMENT_AUTHORIZATION_PROTOCOL.md"),
    "P10": ("references/DETAILED_WORKFLOW_PROTOCOL.md", "references/CONTENT_FUNCTION_PRESERVATION_PROTOCOL.md", "references/FAILURE_RECOVERY_PROTOCOL.md", "references/PUBLICATION_CONTENT_ACCEPTANCE_PROTOCOL.md"),
    "P11": ("rubrics/aigc_rewrite_rubric.md", "checklists/aigc_rewrite_checklist.md", "references/CONTENT_FUNCTION_PRESERVATION_PROTOCOL.md", "references/FORBIDDEN_PHRASE_LOCK_PROTOCOL.md"),
    "P12": ("references/PUBLICATION_BLUEPRINT_PROTOCOL.md", "references/OUTPUT_FRAGMENT_AUTHORIZATION_PROTOCOL.md", "references/HEADING_AUTHORIZATION_PROTOCOL.md"),
    "P13": ("references/PUBLICATION_CONTENT_ACCEPTANCE_PROTOCOL.md", "references/CONTENT_FUNCTION_PRESERVATION_PROTOCOL.md", "references/FAILURE_RECOVERY_PROTOCOL.md"),
    "P14": ("references/VALIDATOR_EVIDENCE_LOCK_PROTOCOL.md", "references/PUBLICATION_AUDIT_REPORT_SPEC.md", "references/RUN_MODE_PROTOCOL.md"),
}


OBSIDIAN_PHASE_RULE_READS: Mapping[str, tuple[str, ...]] = {
    "P17": (
        "@repo/obsidian/protocols/AUTHOR_DIRECTED_RESPONSIBILITY_CONTRACT.md",
        "@repo/obsidian/protocols/P17_AUTHOR_INTENT_COMPILATION.md",
        "@repo/obsidian/protocols/READER_SURFACE_CLEANLINESS.md",
    ),
    "P18": (
        "@repo/obsidian/protocols/AUTHOR_DIRECTED_RESPONSIBILITY_CONTRACT.md",
        "@repo/obsidian/protocols/P18_COPY_FIRST_PAGE_PLAN.md",
        "@repo/obsidian/protocols/BIDIRECTIONAL_GRAPH_PROTOCOL.md",
        "@repo/obsidian/protocols/MOC_ROUTE_DECISION_PROTOCOL.md",
        "@repo/obsidian/protocols/READER_SURFACE_CLEANLINESS.md",
    ),
    "P19": (
        "@repo/obsidian/protocols/P19_BOUNDED_PAGE_PATCH.md",
        "@repo/obsidian/protocols/BIDIRECTIONAL_GRAPH_PROTOCOL.md",
        "@repo/obsidian/protocols/READER_SURFACE_CLEANLINESS.md",
    ),
}


def get_phase(phase_id: str) -> PhaseContract:
    try:
        return PHASES[phase_id]
    except KeyError as exc:
        raise ValueError(f"unknown phase: {phase_id}") from exc


def next_phase(phase_id: str) -> str:
    return get_phase(phase_id).next_phase


def rules_for_phase(phase_id: str) -> tuple[str, ...]:
    if phase_id in OBSIDIAN_PHASE_RULE_READS:
        return COMMON_RULE_READS + OBSIDIAN_PHASE_RULE_READS[phase_id]
    return COMMON_RULE_READS + PHASE_RULE_READS.get(phase_id, ())


def phase_brief_for(phase_id: str) -> dict[str, object] | None:
    """Return an explicit model-facing contract for a semantic phase."""
    brief = PUBLICATION_AGENT_PHASE_BRIEFS.get(phase_id)
    if brief is None:
        brief = OBSIDIAN_AGENT_PHASE_BRIEFS.get(phase_id)
    if brief is None:
        return None
    return {
        "phase_id": brief.phase_id,
        "mission": brief.mission,
        "objective": brief.objective,
        "success_conditions": list(brief.success_conditions),
        "prohibitions": list(brief.prohibitions),
        "handoff": brief.handoff,
    }


PHASE_CATALOG_VERSION = "phase-catalog-copy-first-v1"


def routable_phase_ids() -> tuple[str, ...]:
    return tuple(phase_id for phase_id, phase in PHASES.items() if phase.routable)


def phase_catalog_manifest() -> dict[str, object]:
    return {
        "catalog_version": PHASE_CATALOG_VERSION,
        "phases": [
            {
                "phase_id": phase.phase_id,
                "phase_name": phase.name,
                "execution_kind": phase.execution_kind,
                "handler_key": phase.handler_key,
                "routable": phase.routable,
                "implementation_status": phase.implementation_status,
                "allowed_outcomes": list(phase.allowed_outcomes),
            }
            for phase in PHASES.values()
        ],
    }
