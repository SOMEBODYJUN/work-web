"""Machine-readable handler registry for Runtime v2.

P00-P15 remain frozen. P16-P21 implement the author-directed Obsidian
compilation route in the same single-thread Runtime.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True)
class HandlerSpec:
    phase_id: str
    handler_key: str
    cli_command: str
    implementation_status: str
    mutates_business: bool
    mutates_formal_vault: bool = False


HANDLERS: Mapping[str, HandlerSpec] = {
    "P00": HandlerSpec("P00", "runtime.bootstrap", "bootstrap", "IMPLEMENTED", False),
    "P01": HandlerSpec("P01", "legacy.source_authority", "source-authority", "IMPLEMENTED", True),
    "P02": HandlerSpec("P02", "legacy.source_model", "source-model", "IMPLEMENTED", True),
    **{
        f"P{number:02d}": HandlerSpec(
            f"P{number:02d}",
            f"legacy.advance.p{number:02d}",
            "advance",
            "IMPLEMENTED",
            True,
        )
        for number in range(3, 15)
    },
    "P16": HandlerSpec("P16", "obsidian.index_vault", "advance", "IMPLEMENTED_COPY_FIRST_V1", False),
    "P17": HandlerSpec("P17", "obsidian.compile_author_focus", "advance", "IMPLEMENTED_COPY_FIRST_V1", False),
    "P18": HandlerSpec("P18", "obsidian.materialize_copy_first_seeds", "advance", "IMPLEMENTED_COPY_FIRST_V1", False),
    "P19": HandlerSpec("P19", "obsidian.apply_bounded_page_patches", "advance", "IMPLEMENTED_COPY_FIRST_V1", False),
    "P20": HandlerSpec("P20", "obsidian.preview_and_export", "advance", "IMPLEMENTED_COPY_FIRST_V1", False),
    "P21": HandlerSpec("P21", "obsidian.validate_import", "advance", "IMPLEMENTED_COPY_FIRST_V1", False),
}


def handler_manifest() -> dict[str, object]:
    return {
        "registry_version": "handler-registry-copy-first-v1",
        "handlers": [
            {
                "phase_id": item.phase_id,
                "handler_key": item.handler_key,
                "cli_command": item.cli_command,
                "implementation_status": item.implementation_status,
                "mutates_business": item.mutates_business,
                "mutates_formal_vault": item.mutates_formal_vault,
            }
            for item in HANDLERS.values()
        ],
    }
