"""Copy-first Obsidian extension for P16--P21.

P00--P15 remain owned by the publication skill.  This module deliberately
keeps semantic decisions in the Agent-authored JSON contracts and keeps all
byte movement, hashing, exact patching, preview, and import safety in the
Runtime.
"""
from __future__ import annotations

from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import re
from typing import Any

import obsidian_author_directed as legacy
from runtime_support import (
    atomic_write_bytes,
    atomic_write_text,
    canonical_json_bytes,
    safe_relative_target,
    sha256_bytes,
    sha256_file,
    strict_load_json,
    validate_bare_sha256_sidecar,
    validate_json_schema,
    write_hashed_json,
)


INTENT_PATH = "semantic/author_intent_contract.json"
PLAN_PATH = "semantic/copy_first_page_plan.json"
SEED_MANIFEST_PATH = "page_seed_manifest.json"
PATCH_PATH = "semantic/page_patch_bundle.json"
PATCH_APPLICATION_PATH = "page_patch_application.json"
STAGING_PATH = "staging/staging_manifest.json"
IMPORT_PATH = "validation/import_manifest.json"
COMMIT_PATH = "validation/p21_import_commit.json"
ARTICLE_SOURCE = "evidence/publication_final.md"
SHA_RE = re.compile(r"^[0-9a-f]{64}$")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _root(state: dict[str, Any]) -> Path:
    return legacy.obsidian_root_from(state)


def _read(path: Path) -> str:
    return legacy._read_text(path)


def _write(path: Path, text: str) -> str:
    if not text.endswith("\n"):
        text += "\n"
    atomic_write_text(path, text)
    digest = sha256_file(path)
    atomic_write_text(path.with_suffix(".sha256"), digest + "\n")
    return digest


def _write_plain(path: Path, text: str) -> None:
    if not text.endswith("\n"):
        text += "\n"
    atomic_write_text(path, text)


def _json(path: Path) -> dict[str, Any]:
    value = strict_load_json(path)
    if not isinstance(value, dict):
        raise ValueError(f"JSON object required: {path}")
    return value


def _schema(value: dict[str, Any], name: str) -> None:
    validate_json_schema(value, name)


def _profile(root: Path) -> dict[str, Any]:
    return _json(root / "index" / "vault_profile.json")


def _intent(root: Path) -> tuple[dict[str, Any], str]:
    path = root / INTENT_PATH
    value = _json(path)
    _schema(value, "author-intent-contract-v2.schema.json")
    digest = sha256_file(path)
    response = root / "author-input" / "AUTHOR_RESPONSE.md"
    article = root / ARTICLE_SOURCE
    if value["author_response_sha256"] != sha256_file(response):
        raise ValueError("author intent contract is stale relative to AUTHOR_RESPONSE.md")
    if value["publication_final_sha256"] != sha256_file(article):
        raise ValueError("author intent contract is stale relative to publication_final.md")
    response_text = _read(response)
    for directive in value["atomic_note_directives"]:
        if directive["author_quote"] not in response_text:
            raise ValueError(f"directive {directive['directive_id']} lacks an exact author anchor")
    return value, digest


def write_author_intent_question(state: dict[str, Any]) -> dict[str, Any]:
    """P17 asks one required adaptive question, with optional guidance only."""
    root = _root(state)
    article = _read(root / ARTICLE_SOURCE)
    match = re.search(r"^#\s+(.+?)\s*$", article, re.M)
    title = match.group(1).strip() if match else "当前文章"
    questions = [
        "这篇文章里，哪些内容值得单独拉出来，作为以后继续发展的原子笔记？",
        "如果你选中了某个原子笔记，可以顺带写一句你以后想继续追问的问题；没有也可以不写。",
    ]
    content = "\n".join([
        "# Obsidian 沉淀取舍", "", f"文章：**{title}**", "",
        "请先回答第 1 个问题。第 2 个只是缺少未来用途时的可选补充；你不需要指定文件夹、标签、旧笔记、链接或 MOC。", "",
        f"1. {questions[0]}", f"2. （可选）{questions[1]}", "",
    ])
    path = root / "author-input" / "AUTHOR_INTENT_QUESTIONS.md"
    digest = _write(path, content)
    return {"question_path": str(path), "question_sha256": digest, "questions": questions}


def submit_author_response(state: dict[str, Any], response_path: Path) -> dict[str, Any]:
    return legacy.submit_author_response(state, response_path)


def validate_author_intent_contract(state: dict[str, Any]) -> dict[str, Any]:
    value, digest = _intent(_root(state))
    if not value["article_output"]["required"] or value["article_output"]["copy_mode"] != "FULL_COPY":
        raise ValueError("the complete Article is always required and must use FULL_COPY")
    ids = [item["directive_id"] for item in value["atomic_note_directives"]]
    if len(ids) != len(set(ids)):
        raise ValueError("atomic directive ids must be unique")
    return {"outcome": "AUTHOR_INTENT_BOUND", "intent_sha256": digest, "atomic_note_count": len(ids)}


def _safe_rel(value: str, *, suffix: str = ".md") -> str:
    path = legacy.safe_relative_target(Path("."), value) if False else Path(value.replace("\\", "/"))
    if path.is_absolute() or any(part in {"", ".", ".."} or ":" in part for part in path.parts) or not value.endswith(suffix):
        raise ValueError(f"unsafe relative path: {value}")
    return path.as_posix()


def _frontmatter(title: str, aliases: list[str], tags: list[str]) -> str:
    lines = ["---", f"title: {json.dumps(title, ensure_ascii=False)}"]
    if aliases:
        lines.append("aliases:")
        lines.extend(f"  - {json.dumps(item, ensure_ascii=False)}" for item in aliases)
    if tags:
        lines.append("tags:")
        lines.extend(f"  - {item}" for item in tags)
    lines.extend(["---", ""])
    return "\n".join(lines)


def _line_slice(article: str, slices: list[dict[str, Any]]) -> str:
    lines = article.splitlines(keepends=True)
    chunks: list[str] = []
    for item in slices:
        start, end = int(item["start_line"]), int(item["end_line"])
        if start > end or start < 1 or end > len(lines):
            raise ValueError(f"source slice out of range: {start}-{end}")
        chunks.extend(lines[start - 1 : end])
    text = "".join(chunks)
    if not text.strip():
        raise ValueError("source slices select no content")
    return text


def _tag_classes(tags: list[str], profile: dict[str, Any], binding: dict[str, Any]) -> list[dict[str, str]]:
    policy = legacy.normalize_tag_policy((binding.get("config") or {}).get("tag_policy"))
    learned = {str(x).casefold() for x in legacy._learned_tag_values(profile)}
    approved = {str(x).casefold() for x in policy["approved_tags"]}
    result: list[dict[str, str]] = []
    for tag in tags:
        legacy._canonical_tag(tag, max_depth=policy["max_depth"], context="page tag")
        key = tag.casefold()
        status = "REUSED" if key in learned else "PREAPPROVED" if key in approved else "NEW_PROPOSAL"
        result.append({"tag": tag, "status": status})
    return result


def _connection_sentences(plan: dict[str, Any], page_id: str) -> list[str]:
    result: list[str] = []
    for connection in plan.get("connections", []):
        if connection["page_a_id"] == page_id:
            result.append(connection["sentence_for_a"])
        elif connection["page_b_id"] == page_id:
            result.append(connection["sentence_for_b"])
    return result


def materialize_page_seeds(state: dict[str, Any]) -> dict[str, Any]:
    root = _root(state)
    intent, intent_sha = _intent(root)
    plan_path = root / PLAN_PATH
    plan = _json(plan_path)
    _schema(plan, "copy-first-page-plan-v1.schema.json")
    plan_sha = sha256_file(plan_path)
    article_path = root / ARTICLE_SOURCE
    article = _read(article_path)
    article_sha = sha256_file(article_path)
    profile_path = root / "index" / "vault_profile.json"
    profile = _json(profile_path)
    vault_index = _json(root / "index" / "vault_note_index.json")
    indexed_notes = {str(item["path"]): item for item in vault_index.get("notes", [])}
    profile_sha = sha256_file(profile_path)
    binding, vault = legacy.load_binding(state)
    if plan["author_intent_contract_sha256"] != intent_sha or plan["publication_final_sha256"] != article_sha or plan["vault_profile_sha256"] != profile_sha:
        raise ValueError("copy-first plan is not bound to current intent, article, and Vault profile")
    pages = plan["pages"]
    known_folders = set(profile.get("known_folders") or [item["path"] for item in profile.get("observed_folders", [])])
    fallback_folder = legacy.normalize_destination_policy((binding.get("config") or {}).get("destination_policy"))["fallback_folder"]
    for field in ("page_id", "operation_id", "target_path"):
        values = [str(page[field]).casefold() for page in pages]
        if len(values) != len(set(values)):
            raise ValueError(f"copy-first plan contains duplicate {field}")
    article_pages = [p for p in pages if p["artifact_role"] == "ARTICLE"]
    if len(article_pages) != 1 or article_pages[0]["seed_mode"] != "FULL_ARTICLE_COPY":
        raise ValueError("plan must contain exactly one FULL_ARTICLE_COPY Article page")
    directive_ids = {d["directive_id"] for d in intent["atomic_note_directives"]}
    atomic_pages = [p for p in pages if p["artifact_role"] == "ATOMIC_NOTE"]
    covered_directives: set[str] = set()
    for page in atomic_pages:
        selected = set(page.get("author_directive_ids", []))
        if not selected or not selected <= directive_ids:
            raise ValueError(f"atomic page {page['page_id']} must bind author-selected directives")
        if page["seed_mode"] != "PUBLICATION_LINE_SLICES" or not page.get("source_slices"):
            raise ValueError(f"atomic page {page['page_id']} must start from publication line slices")
        covered_directives.update(selected)
    if covered_directives != directive_ids:
        raise ValueError("atomic pages must cover exactly the author's atomic-note directives")
    moc_pages = [p for p in pages if p["artifact_role"] == "MOC"]
    moc = plan["moc_decision"]
    if moc["decision"] == "NONE" and moc_pages:
        raise ValueError("MOC NONE cannot include an MOC page")
    if moc["decision"] in {"CREATE", "UPDATE"} and (len(moc_pages) != 1 or moc_pages[0]["page_id"] != moc["page_id"]):
        raise ValueError("MOC decision does not match the planned MOC page")
    page_ids = {p["page_id"] for p in pages}
    for connection in plan.get("connections", []):
        if connection["page_a_id"] not in page_ids or connection["page_b_id"] not in page_ids:
            raise ValueError(f"connection references an unknown page: {connection['connection_id']}")
    seed_dir = root / "page-seeds"
    seed_dir.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, Any]] = []
    for page in pages:
        target_rel = _safe_rel(page["target_path"])
        parent = Path(target_rel).parent.as_posix()
        parent = "" if parent == "." else parent
        if page["operation_kind"] == "CREATE" and parent not in known_folders and parent != fallback_folder:
            raise ValueError(f"destination invents an unlearned folder taxonomy: {target_rel}")
        target = safe_relative_target(vault, target_rel)
        current_sha = sha256_file(target) if target.is_file() else None
        if page["operation_kind"] == "CREATE" and current_sha is not None:
            raise ValueError(f"CREATE target already exists: {target_rel}")
        if page["operation_kind"] == "UPDATE" and current_sha != page["expected_target_sha256"]:
            raise ValueError(f"UPDATE preimage changed: {target_rel}")
        if page["artifact_role"] == "ARTICLE":
            source_payload = article
            source_artifact, source_sha, copied_bytes = ARTICLE_SOURCE, article_sha, len(article.encode("utf-8"))
        elif page["seed_mode"] == "PUBLICATION_LINE_SLICES":
            if not set(page.get("author_directive_ids", [])) <= directive_ids:
                raise ValueError(f"page {page['page_id']} contains an unknown directive id")
            source_payload = _line_slice(article, page.get("source_slices", []))
            source_artifact, source_sha, copied_bytes = ARTICLE_SOURCE, article_sha, len(source_payload.encode("utf-8"))
        elif page["seed_mode"] == "INSPECTED_VAULT_COPY":
            if not page.get("source_note"):
                raise ValueError(f"page {page['page_id']} needs source_note for Vault copy")
            source_target = safe_relative_target(vault, str(page["source_note"]))
            if not source_target.is_file() or source_target.is_symlink():
                raise ValueError(f"inspected Vault source is missing: {page['source_note']}")
            indexed = indexed_notes.get(str(page["source_note"]))
            if not indexed or indexed.get("sha256") != sha256_file(source_target):
                raise ValueError(f"Vault copy is not bound to the inspected P16 index: {page['source_note']}")
            source_payload = _read(source_target)
            source_artifact, source_sha, copied_bytes = str(page["source_note"]), sha256_file(source_target), len(source_payload.encode("utf-8"))
        else:
            raise ValueError(f"unsupported seed mode: {page['seed_mode']}")
        tags = [str(x) for x in page.get("tags", [])]
        tag_classes = _tag_classes(tags, profile, binding)
        # Frontmatter is controlled metadata; the body remains copied source material.
        content = _frontmatter(str(page["title"]), [str(x) for x in page.get("aliases", [])], tags) + source_payload
        if not content.endswith("\n"):
            content += "\n"
        sentences = _connection_sentences(plan, page["page_id"])
        if sentences:
            content += "\n" + "\n\n".join(sentences).strip() + "\n"
        seed_rel = f"page-seeds/{page['page_id']}.md"
        seed_path = safe_relative_target(root, seed_rel)
        seed_sha = _write(seed_path, content)
        records.append({
            "page_id": page["page_id"], "operation_id": page["operation_id"], "operation_kind": page["operation_kind"],
            "artifact_role": page["artifact_role"], "seed_mode": page["seed_mode"], "target_path": target_rel,
            "expected_target_sha256": page["expected_target_sha256"], "title": page["title"], "seed_relative_path": seed_rel,
            "seed_sha256": seed_sha, "source_artifact": source_artifact, "source_sha256": source_sha,
            "source_slices": page.get("source_slices", []), "copied_bytes": copied_bytes, "seed_bytes": len(content.encode("utf-8")),
            "tag_classification": tag_classes, "connection_ids": [c["connection_id"] for c in plan.get("connections", []) if page["page_id"] in {c["page_a_id"], c["page_b_id"]}],
            "author_directive_ids": page.get("author_directive_ids", []), "patchable": True,
        })
    manifest = {"schema_version": "page-seed-manifest-v1", "author_intent_contract_sha256": intent_sha, "page_plan_sha256": plan_sha, "publication_final_sha256": article_sha, "vault_profile_sha256": profile_sha, "pages": records, "created_at": _now()}
    _schema(manifest, "page-seed-manifest-v1.schema.json")
    path = root / SEED_MANIFEST_PATH
    digest = write_hashed_json(path, manifest)
    return {"outcome": "SEEDS_MATERIALIZED", "seed_manifest_sha256": digest, "page_count": len(records)}


def _apply_one(text: str, op: dict[str, Any]) -> tuple[str, dict[str, int]]:
    kind, old, new = op["kind"], op.get("old_text", ""), op.get("new_text", "")
    if kind == "PREPEND":
        if old: raise ValueError(f"{op['patch_id']} PREPEND old_text must be empty")
        return new + text, {"added": len(new.encode()), "deleted": 0, "replaced": 0}
    if kind == "APPEND":
        if old: raise ValueError(f"{op['patch_id']} APPEND old_text must be empty")
        return text + new, {"added": len(new.encode()), "deleted": 0, "replaced": 0}
    count = text.count(old) if old else 0
    if count != 1:
        raise ValueError(f"{op['patch_id']} exact preimage occurs {count} times; expected exactly one")
    if len(old) >= max(1, int(len(text) * 0.95)) and kind in {"REPLACE_EXACT", "DELETE_EXACT"}:
        raise ValueError(f"{op['patch_id']} would rewrite the whole page")
    replacement = "" if kind == "DELETE_EXACT" else new
    if kind == "INSERT_BEFORE_EXACT": replacement = new + old
    if kind == "INSERT_AFTER_EXACT": replacement = old + new
    result = text.replace(old, replacement, 1)
    old_b, new_b = len(old.encode()), len(replacement.encode())
    return result, {"added": max(0, new_b - old_b), "deleted": max(0, old_b - new_b), "replaced": old_b if kind == "REPLACE_EXACT" else 0}


def apply_page_patch_bundle(state: dict[str, Any]) -> dict[str, Any]:
    root = _root(state)
    seed_path = root / SEED_MANIFEST_PATH
    seeds = _json(seed_path)
    _schema(seeds, "page-seed-manifest-v1.schema.json")
    seed_sha = sha256_file(seed_path)
    plan_sha = str(seeds["page_plan_sha256"])
    patch_path = root / PATCH_PATH
    bundle = _json(patch_path)
    _schema(bundle, "page-patch-bundle-v1.schema.json")
    if bundle["seed_manifest_sha256"] != seed_sha or bundle["page_plan_sha256"] != plan_sha:
        raise ValueError("patch bundle is not bound to the current seed manifest and page plan")
    by_id = {p["page_id"]: p for p in seeds["pages"]}
    patch_by_id = {p["page_id"]: p for p in bundle["patches"]}
    if set(patch_by_id) - set(by_id):
        raise ValueError("patch bundle contains an unknown page")
    candidate_dir, diff_dir = root / "page-candidates", root / "diffs"
    candidate_dir.mkdir(parents=True, exist_ok=True); diff_dir.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, Any]] = []
    for page_id, seed in by_id.items():
        seed_file = safe_relative_target(root, seed["seed_relative_path"])
        text = _read(seed_file)
        if sha256_file(seed_file) != seed["seed_sha256"]:
            raise ValueError(f"seed changed before patching: {page_id}")
        patch_page = patch_by_id.get(page_id, {"page_id": page_id, "seed_sha256": seed["seed_sha256"], "operations": []})
        if patch_page["seed_sha256"] != seed["seed_sha256"]:
            raise ValueError(f"patch seed binding mismatch: {page_id}")
        original = text
        added = deleted = replaced = 0
        for op in patch_page["operations"]:
            text, stats = _apply_one(text, op)
            added += stats["added"]; deleted += stats["deleted"]; replaced += stats["replaced"]
        if seed["artifact_role"] == "ARTICLE" and deleted + replaced > int(len(original.encode("utf-8")) * 0.20):
            raise ValueError(f"patch bundle changes too much of the complete Article: {page_id}")
        if seed["artifact_role"] != "ARTICLE" and deleted + replaced > int(len(original.encode("utf-8")) * 0.40):
            raise ValueError(f"patch bundle changes too much copied material: {page_id}")
        if added > int(len(original.encode("utf-8")) * 0.50):
            raise ValueError(f"patch bundle appends too much new material to a copied seed: {page_id}")
        if not text.endswith("\n"): text += "\n"
        candidate_rel = f"page-candidates/{page_id}.md"
        diff_rel = f"diffs/{page_id}.diff"
        candidate_sha = _write(safe_relative_target(root, candidate_rel), text)
        diff = "".join(difflib.unified_diff(original.splitlines(True), text.splitlines(True), fromfile=seed["seed_relative_path"], tofile=candidate_rel))
        _write(safe_relative_target(root, diff_rel), diff or "(no semantic patch; seed copied unchanged)\n")
        records.append({"page_id": page_id, "seed_sha256": seed["seed_sha256"], "candidate_sha256": candidate_sha, "operation_count": len(patch_page["operations"]), "copied_bytes": len(original.encode()), "added_bytes": added, "deleted_bytes": deleted, "replaced_bytes": replaced})
    application = {"schema_version": "page-patch-application-v1", "seed_manifest_sha256": seed_sha, "patch_bundle_sha256": sha256_file(patch_path), "pages": records}
    _schema(application, "page-patch-application-v1.schema.json")
    digest = write_hashed_json(root / PATCH_APPLICATION_PATH, application)
    return {"outcome": "PATCHES_APPLIED", "patch_application_sha256": digest, "page_count": len(records)}


def _candidate_lint(root: Path, seeds: dict[str, Any]) -> list[str]:
    """Mechanical P20 checks only; never judge or rewrite mathematics."""
    errors: list[str] = []
    seed_by = {item["page_id"]: item for item in seeds["pages"]}
    plan = _json(root / PLAN_PATH)
    profile_index = _json(root / "index" / "vault_note_index.json")
    resolvable: set[str] = set()
    for page in plan["pages"]:
        resolvable.update({str(page["title"]).casefold(), Path(page["target_path"]).stem.casefold()})
        resolvable.update(str(alias).casefold() for alias in page.get("aliases", []))
    for note in profile_index.get("notes", []):
        resolvable.update({str(note.get("title", "")).casefold(), Path(str(note.get("path", ""))).stem.casefold()})
        resolvable.update(str(alias).casefold() for alias in note.get("aliases", []))
    contents: dict[str, str] = {}
    plan_by = {item["page_id"]: item for item in plan["pages"]}
    for page_id, seed in seed_by.items():
        path = root / "page-candidates" / f"{page_id}.md"
        text = _read(path); contents[page_id] = text
        if text.startswith("---\n") and text.find("\n---\n", 4) < 0:
            errors.append(f"frontmatter is not closed: {page_id}")
        frontmatter, raw_frontmatter, _ = legacy._split_frontmatter(text)
        expected_page = plan_by[page_id]
        if not raw_frontmatter or str(frontmatter.get("title", "")) != str(expected_page["title"]):
            errors.append(f"controlled title frontmatter changed or is invalid: {page_id}")
        if legacy._as_list(frontmatter.get("tags")) != [str(item) for item in expected_page.get("tags", [])]:
            errors.append(f"controlled tags frontmatter changed or is invalid: {page_id}")
        seed_text = _read(safe_relative_target(root, seed["seed_relative_path"]))
        new_inline_tags = {tag.casefold() for tag in legacy._tags_from_markdown(text)} - {tag.casefold() for tag in legacy._tags_from_markdown(seed_text)}
        if new_inline_tags:
            errors.append(f"P19 introduced undeclared tags: {page_id}: {sorted(new_inline_tags)}")
        new_links = legacy._wikilinks(text) - legacy._wikilinks(seed_text)
        if new_links:
            errors.append(f"P19 introduced links outside the P18 graph plan: {page_id}: {sorted(new_links)}")
        math_surface = legacy.FENCED_CODE_RE.sub("", text)
        display_count = len(re.findall(r"(?<!\\)\$\$", math_surface))
        inline_surface = re.sub(r"(?<!\\)\$\$", "", math_surface)
        inline_count = len(re.findall(r"(?<!\\)\$", inline_surface))
        if display_count % 2 or inline_count % 2:
            errors.append(f"obvious formula delimiter imbalance: {page_id}")
    for connection in plan.get("connections", []):
        a, b = connection["page_a_id"], connection["page_b_id"]
        if connection["sentence_for_a"] not in contents.get(a, ""):
            errors.append(f"reciprocal sentence missing from {a}: {connection['connection_id']}")
        if connection["sentence_for_b"] not in contents.get(b, ""):
            errors.append(f"reciprocal sentence missing from {b}: {connection['connection_id']}")
        for sentence in (connection["sentence_for_a"], connection["sentence_for_b"]):
            for link in legacy._wikilinks(sentence):
                if link.casefold() not in resolvable:
                    errors.append(f"planned WikiLink does not resolve: [[{link}]]")
    article = _read(root / ARTICLE_SOURCE)
    article_pages = [item for item in seeds["pages"] if item["artifact_role"] == "ARTICLE"]
    if len(article_pages) != 1 or article not in _read(safe_relative_target(root, article_pages[0]["seed_relative_path"])):
        errors.append("the P18 Article seed does not contain the complete released article")
    return errors


def build_staging_and_delivery(state: dict[str, Any]) -> dict[str, Any]:
    root = _root(state)
    seeds = _json(root / SEED_MANIFEST_PATH); application = _json(root / PATCH_APPLICATION_PATH)
    _schema(seeds, "page-seed-manifest-v1.schema.json"); _schema(application, "page-patch-application-v1.schema.json")
    binding, vault = legacy.load_binding(state)
    lint_errors = _candidate_lint(root, seeds)
    if lint_errors:
        raise ValueError("P20 mechanical preview failed: " + "; ".join(lint_errors[:8]))
    generation = "GEN-" + hashlib.sha256((sha256_file(root / PATCH_APPLICATION_PATH) + _now()).encode()).hexdigest()[:16]
    operations: list[dict[str, Any]] = []; new_tags: dict[str, list[str]] = {}
    app_by = {x["page_id"]: x for x in application["pages"]}
    for page in seeds["pages"]:
        target = safe_relative_target(vault, page["target_path"])
        before = sha256_file(target) if target.is_file() else None
        app = app_by[page["page_id"]]
        for tag in page["tag_classification"]:
            if tag["status"] == "NEW_PROPOSAL": new_tags.setdefault(tag["tag"], []).append(page["page_id"])
        operations.append({"operation_id": page["operation_id"], "operation_kind": page["operation_kind"], "artifact_role": page["artifact_role"], "target_path": page["target_path"], "expected_target_sha256": page["expected_target_sha256"], "candidate_relative_path": f"page-candidates/{page['page_id']}.md", "before_sha256": before, "after_sha256": app["candidate_sha256"], "diff_relative_path": f"diffs/{page['page_id']}.diff", "tag_classification": page["tag_classification"]})
    staging = {"manifest_schema_version": "obsidian-staging-manifest-v2", "generation_id": generation, "vault_binding_id": binding["binding_id"], "vault_root_fingerprint": binding["root_fingerprint"], "page_seed_manifest_sha256": sha256_file(root / SEED_MANIFEST_PATH), "patch_application_sha256": sha256_file(root / PATCH_APPLICATION_PATH), "operations": operations, "new_tag_proposals": [{"tag": tag, "pages": pages} for tag, pages in sorted(new_tags.items())], "created_at": _now()}
    _schema(staging, "obsidian-staging-manifest-v2.schema.json")
    staging_sha = write_hashed_json(root / STAGING_PATH, staging)
    review_lines = ["# Obsidian 预览", "", f"生成批次：`{generation}`", "", f"页面数：{len(operations)}", "", "## 文件", ""]
    review_lines.extend(f"- `{op['target_path']}`（{op['operation_kind']}）" for op in operations)
    if new_tags: review_lines += ["", "## 待作者确认的新标签", ""] + [f"- `{tag}`" for tag in sorted(new_tags)]
    _write(root / "staging" / "STAGING_REVIEW.md", "\n".join(review_lines) + "\n")
    delivery = root / "delivery"
    if delivery.exists():
        for child in delivery.iterdir():
            if child.is_dir():
                import shutil; shutil.rmtree(child)
            else: child.unlink()
    (delivery / "01-微信公众号").mkdir(parents=True, exist_ok=True); (delivery / "02-Obsidian导入包").mkdir(parents=True, exist_ok=True)
    source_article = root / ARTICLE_SOURCE
    _write_plain(delivery / "01-微信公众号" / "微信公众号最终发布稿.md", _read(source_article))
    for op in operations:
        candidate = safe_relative_target(root, op["candidate_relative_path"])
        target = safe_relative_target(delivery / "02-Obsidian导入包", op["target_path"])
        target.parent.mkdir(parents=True, exist_ok=True); _write_plain(target, _read(candidate))
    _write_plain(delivery / "交付说明.md", "本目录只包含微信公众号发布稿、Obsidian Article 和作者选定的原子笔记；工程证据留在运行目录。\n")
    return {"outcome": "STAGED", "generation_id": generation, "manifest_sha256": staging_sha, "operation_count": len(operations), "delivery_root": str(delivery)}


def _staging(root: Path) -> tuple[Path, dict[str, Any]]:
    path = root / STAGING_PATH; value = _json(path); _schema(value, "obsidian-staging-manifest-v2.schema.json"); return path, value


def validate_staging(state: dict[str, Any]) -> dict[str, Any]:
    root = _root(state); path, manifest = _staging(root); binding, vault = legacy.load_binding(state)
    if manifest["vault_binding_id"] != binding["binding_id"] or manifest["vault_root_fingerprint"] != binding["root_fingerprint"]:
        raise ValueError("staging manifest belongs to another Vault binding")
    errors: list[str] = []
    seeds = _json(root / SEED_MANIFEST_PATH); application = _json(root / PATCH_APPLICATION_PATH)
    if manifest["page_seed_manifest_sha256"] != sha256_file(root / SEED_MANIFEST_PATH):
        errors.append("staging seed-manifest binding changed")
    if manifest["patch_application_sha256"] != sha256_file(root / PATCH_APPLICATION_PATH):
        errors.append("staging patch-application binding changed")
    seed_by_operation = {item["operation_id"]: item for item in seeds["pages"]}
    app_by_page = {item["page_id"]: item for item in application["pages"]}
    expected_new_tags: dict[str, list[str]] = {}
    for op in manifest["operations"]:
        candidate = safe_relative_target(root, op["candidate_relative_path"]); target = safe_relative_target(vault, op["target_path"])
        if not candidate.is_file() or sha256_file(candidate) != op["after_sha256"]: errors.append(f"candidate hash mismatch: {op['target_path']}")
        current = sha256_file(target) if target.is_file() else None
        if current != op["before_sha256"]: errors.append(f"Vault precondition changed: {op['target_path']}")
        seed = seed_by_operation.get(op["operation_id"])
        if not seed or seed["target_path"] != op["target_path"] or seed["operation_kind"] != op["operation_kind"]:
            errors.append(f"staging operation differs from seed plan: {op['operation_id']}")
            continue
        app = app_by_page.get(seed["page_id"])
        if not app or app["candidate_sha256"] != op["after_sha256"]:
            errors.append(f"staging candidate differs from patch application: {op['operation_id']}")
        if op["tag_classification"] != seed["tag_classification"]:
            errors.append(f"tag classification changed after seed planning: {op['operation_id']}")
        for item in seed["tag_classification"]:
            if item["status"] == "NEW_PROPOSAL":
                expected_new_tags.setdefault(item["tag"], []).append(seed["page_id"])
    expected_tag_delta = [{"tag": tag, "pages": pages} for tag, pages in sorted(expected_new_tags.items())]
    if manifest["new_tag_proposals"] != expected_tag_delta:
        errors.append("new-tag approval delta differs from the classified page tags")
    package = root / "delivery" / "02-Obsidian导入包"
    if not package.is_dir() or any(item.is_file() and item.suffix.lower() != ".md" for item in package.rglob("*")):
        errors.append("clean delivery contains a non-Markdown engineering artifact")
    else:
        delivered = [item for item in package.rglob("*.md")]
        if len(delivered) != len(manifest["operations"]):
            errors.append("clean delivery page count differs from staging")
    export_only = (binding.get("config") or {}).get("mode") == "STAGING_ONLY"
    outcome = "READY_FOR_EXPORT" if export_only else "READY_FOR_IMPORT"
    report = {"report_schema_version": "obsidian-validation-report-v2", "verdict": outcome if not errors else "BLOCKED", "staging_manifest_sha256": sha256_file(path), "errors": errors, "new_tag_proposals": manifest["new_tag_proposals"], "created_at": _now()}
    report_sha = write_hashed_json(root / "validation" / "obsidian_validation_report.json", report)
    if errors: raise ValueError("P21 staging validation failed: " + "; ".join(errors[:8]))
    import_manifest = {"manifest_schema_version": "reviewed-obsidian-import-manifest-v2", "generation_id": manifest["generation_id"], "vault_binding_id": binding["binding_id"], "vault_root_fingerprint": binding["root_fingerprint"], "staging_manifest_sha256": sha256_file(path), "patch_application_sha256": manifest["patch_application_sha256"], "validation_report_sha256": report_sha, "operations": manifest["operations"], "new_tag_proposals": manifest["new_tag_proposals"], "approval_contract": "Human approval binds the exact SHA-256 of this manifest, including its new-tag delta.", "created_at": _now()}
    _schema(import_manifest, "obsidian-import-manifest-v2.schema.json")
    import_sha = write_hashed_json(root / IMPORT_PATH, import_manifest)
    commit = {"commit_schema_version": "obsidian-import-commit-v2", "import_manifest_sha256": import_sha, "staging_manifest_sha256": sha256_file(path), "patch_application_sha256": manifest["patch_application_sha256"], "vault_binding_id": binding["binding_id"], "vault_root_fingerprint": binding["root_fingerprint"], "operations": manifest["operations"], "created_at": _now()}
    _schema(commit, "obsidian-import-commit-v2.schema.json")
    commit_sha = write_hashed_json(root / COMMIT_PATH, commit)
    return {"outcome": outcome, "validation_sha256": report_sha, "import_manifest_sha256": import_sha, "p21_import_commit_sha256": commit_sha, "operation_count": len(manifest["operations"]), "new_tag_proposals": manifest["new_tag_proposals"]}


def apply_import(state: dict[str, Any], approval_manifest_sha256: str) -> dict[str, Any]:
    """Use the proven legacy transaction engine against the v2 manifest."""
    root = _root(state); binding, vault = legacy.load_binding(state)
    config = binding.get("config") or {}
    if (config.get("human_review") or {}).get("vault_commit") is not True:
        raise ValueError("Vault commit is disabled by configuration")
    import_path = root / IMPORT_PATH; commit_path = root / COMMIT_PATH
    manifest = _json(import_path); commit = _json(commit_path)
    _schema(manifest, "obsidian-import-manifest-v2.schema.json"); _schema(commit, "obsidian-import-commit-v2.schema.json")
    actual = sha256_file(import_path)
    if approval_manifest_sha256 != actual or commit["import_manifest_sha256"] != actual:
        raise ValueError("approval hash does not bind the current v2 import manifest")
    if sha256_file(commit_path) != legacy._bound_p21_import_commit_sha(state):
        raise ValueError("P21 import commit marker changed after Runtime commit")
    if manifest.get("vault_binding_id") != binding["binding_id"] or commit.get("vault_binding_id") != binding["binding_id"]:
        raise ValueError("import manifest belongs to another Vault binding")
    staging_path = root / STAGING_PATH
    if manifest["staging_manifest_sha256"] != sha256_file(staging_path) or commit["staging_manifest_sha256"] != sha256_file(staging_path):
        raise ValueError("staging manifest differs from the exact P21 approval")
    if manifest["patch_application_sha256"] != sha256_file(root / PATCH_APPLICATION_PATH) or commit["patch_application_sha256"] != sha256_file(root / PATCH_APPLICATION_PATH):
        raise ValueError("patch application differs from the exact P21 approval")
    if manifest["validation_report_sha256"] != sha256_file(root / "validation" / "obsidian_validation_report.json"):
        raise ValueError("validation report differs from the exact P21 approval")
    if commit["operations"] != manifest["operations"]:
        raise ValueError("P21 commit operations differ from the approved import manifest")
    recovered = legacy._recover_interrupted_imports(root, binding, vault)
    # Reuse the durable, recoverable transaction implementation with the v2
    # candidate path field.
    import uuid
    import_id = f"IMP-{uuid.uuid4().hex[:16].upper()}"; import_dir = root / "imports" / import_id; backup_root = import_dir / "backups"; import_dir.mkdir(parents=True, exist_ok=False)
    operations = manifest["operations"]; transaction_path = import_dir / legacy.IMPORT_TRANSACTION_FILENAME
    tx_ops: list[dict[str, Any]] = []; applied: list[dict[str, Any]] = []
    try:
        for op in operations:
            target = safe_relative_target(vault, op["target_path"]); current = legacy._target_sha256_or_none(target)
            if current == op["after_sha256"]:
                applied.append({"operation_id": op["operation_id"], "target_path": op["target_path"], "status": "IDEMPOTENT_ALREADY_APPLIED", "after_sha256": current}); continue
            if op["operation_kind"] == "CREATE" and current is not None: raise ValueError(f"CREATE target appeared: {op['target_path']}")
            if op["operation_kind"] == "UPDATE" and current != op["expected_target_sha256"]: raise ValueError(f"UPDATE target changed: {op['target_path']}")
            backup_rel = None
            if current is not None:
                backup = safe_relative_target(backup_root, op["target_path"]); atomic_write_bytes(backup, target.read_bytes()); backup_rel = backup.relative_to(import_dir).as_posix()
            tx_ops.append({"operation_id": op["operation_id"], "operation_kind": op["operation_kind"], "target_path": op["target_path"], "before_sha256": current, "after_sha256": op["after_sha256"], "backup_relative_path": backup_rel})
        tx: dict[str, Any] | None = None
        if tx_ops:
            tx = {"transaction_schema_version": "obsidian-import-transaction-v1", "import_id": import_id, "status": "PREPARED", "p21_import_commit_sha256": sha256_file(commit_path), "approved_manifest_sha256": actual, "vault_binding_id": binding["binding_id"], "vault_root_fingerprint": binding["root_fingerprint"], "operations": tx_ops, "applied_operation_ids": [], "created_at": _now(), "updated_at": _now()}
            legacy._write_import_transaction(transaction_path, tx)
        for op in operations:
            target = safe_relative_target(vault, op["target_path"])
            if legacy._target_sha256_or_none(target) == op["after_sha256"]: continue
            candidate = safe_relative_target(root, op["candidate_relative_path"])
            if not candidate.is_file() or candidate.is_symlink() or sha256_file(candidate) != op["after_sha256"]:
                raise ValueError(f"candidate changed after P21 approval: {op['operation_id']}")
            atomic_write_bytes(target, candidate.read_bytes())
            if sha256_file(target) != op["after_sha256"]: raise RuntimeError(f"post-write hash mismatch: {op['target_path']}")
            applied.append({"operation_id": op["operation_id"], "target_path": op["target_path"], "status": "APPLIED", "after_sha256": op["after_sha256"]})
            if tx is not None:
                tx["status"] = "APPLYING"; tx["applied_operation_ids"].append(op["operation_id"]); legacy._write_import_transaction(transaction_path, tx)
        if tx is not None:
            tx["status"] = "COMMITTED"; tx["committed_at"] = _now(); legacy._write_import_transaction(transaction_path, tx)
    except Exception as error:
        if transaction_path.is_file():
            transaction = strict_load_json(transaction_path)
            validate_json_schema(transaction, "obsidian-import-transaction-v1.schema.json")
            legacy._rollback_import_transaction(transaction_path, transaction, vault, recovery_reason="APPLY_FAILED")
        elif tx_ops:
            raise RuntimeError("import preparation failed after backup creation") from error
        raise
    receipt = {"receipt_schema_version": "reviewed-obsidian-import-receipt-v2", "import_id": import_id, "approved_manifest_sha256": actual, "p21_import_commit_sha256": sha256_file(commit_path), "vault_binding_id": binding["binding_id"], "operations": applied, "status": "IMPORTED", "applied_at": _now()}
    receipt_sha = write_hashed_json(import_dir / "import_receipt.json", receipt)
    return {"outcome": "IMPORTED", "import_id": import_id, "receipt_sha256": receipt_sha, "applied": applied, "recovered_import_ids": recovered}
