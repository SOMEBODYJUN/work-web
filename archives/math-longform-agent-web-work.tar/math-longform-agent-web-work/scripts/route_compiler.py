"""Trusted Route Compiler for the serial single-thread Runtime."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
from typing import Any

from runtime_support import RuntimeCliError, canonical_json_bytes

CORE_PHASES = tuple(f"P{i:02d}" for i in range(15))
OBSIDIAN_PHASES = tuple(f"P{i:02d}" for i in range(16, 22))
SUPPORTED_ADDITIONAL_TARGETS: tuple[str, ...] = ()
PHASE_CATALOG_VERSION = "phase-catalog-copy-first-v1"
ROUTE_COMPILER_VERSION = "route-compiler-copy-first-v1"


@dataclass(frozen=True)
class RouteRequest:
    skip_obsidian: bool = False
    obsidian_config_binding: str | None = None
    requested_additional_targets: tuple[str, ...] = ()


def compile_route(request: RouteRequest, *, revision: int = 1, previous_sha256: str | None = None) -> dict[str, Any]:
    if request.skip_obsidian and request.obsidian_config_binding:
        raise RuntimeCliError(
            "CONFLICTING_CLI_OPTIONS",
            "--skip-obsidian cannot be combined with --obsidian-config.",
            exit_code=64,
        )
    if len(set(request.requested_additional_targets)) != len(request.requested_additional_targets):
        raise RuntimeCliError(
            "DUPLICATE_POST_RELEASE_TARGET",
            "A post-release target was requested more than once.",
            exit_code=64,
        )
    unsupported = [
        target for target in request.requested_additional_targets
        if target not in SUPPORTED_ADDITIONAL_TARGETS
    ]
    if unsupported:
        raise RuntimeCliError(
            "UNSUPPORTED_POST_RELEASE_TARGET",
            "Requested post-release target is not supported by this Runtime version.",
            exit_code=64,
            details={"requested_targets": unsupported, "supported_targets": ["obsidian"]},
        )

    obsidian_enabled = not request.skip_obsidian
    ordered = list(CORE_PHASES + (OBSIDIAN_PHASES if obsidian_enabled else ()))
    configuration_state = (
        "NOT_REQUIRED"
        if not obsidian_enabled
        else ("AVAILABLE" if request.obsidian_config_binding else "REQUIRED")
    )
    canonical = {
        "route_compiler_version": ROUTE_COMPILER_VERSION,
        "phase_catalog_version": PHASE_CATALOG_VERSION,
        "phase_plan_revision": revision,
        "previous_phase_plan_sha256": previous_sha256,
        "post_release_targets": ["obsidian"] if obsidian_enabled else [],
        "ordered_phase_ids": ordered,
        "configuration_state": configuration_state,
    }
    digest = hashlib.sha256(canonical_json_bytes(canonical)).hexdigest()
    return {
        **canonical,
        "phase_plan_sha256": digest,
        "skip_obsidian_requested": request.skip_obsidian,
        "obsidian_enabled": obsidian_enabled,
    }
