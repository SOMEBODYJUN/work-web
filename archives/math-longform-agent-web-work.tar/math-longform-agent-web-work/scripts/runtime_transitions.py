"""Runtime transition protocol r0.2 with recoverable artifact and finalization stages."""
from __future__ import annotations

import base64
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import uuid
from typing import Any, Callable

from runtime_lock import exclusive_runtime_lock
from runtime_support import (
    RuntimeCliError,
    atomic_write_bytes,
    atomic_write_json,
    canonical_json_bytes,
    sha256_bytes,
    sha256_file,
    strict_json_loads,
    strict_load_json,
    validate_bare_sha256_sidecar,
    validate_json_schema,
    write_hashed_json,
)

TRANSITION_PROTOCOL_VERSION = "transition-protocol-r0.2"
STAGE_KINDS = (
    "prepared",
    "artifact_applied",
    "state_applied",
    "committed",
    "finalized",
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def state_digest(state: dict[str, Any]) -> str:
    return hashlib.sha256(canonical_json_bytes(state)).hexdigest()


def state_payload_digest(state: dict[str, Any]) -> str:
    """Hash State while excluding the prepared-marker hash binding."""
    copy = json.loads(canonical_json_bytes(state))
    copy.setdefault("transition_head", {})[
        "last_applied_transition_prepared_sha256"
    ] = None
    return hashlib.sha256(canonical_json_bytes(copy)).hexdigest()


def marker_dir(runtime_root: Path, transition_id: str) -> Path:
    return runtime_root / "transitions" / transition_id


def marker_path(runtime_root: Path, transition_id: str, kind: str) -> Path:
    return marker_dir(runtime_root, transition_id) / f"{kind}.json"


def marker_valid(path: Path) -> bool:
    try:
        validate_bare_sha256_sidecar(path)
    except Exception:
        return False
    return True


def write_marker(
    runtime_root: Path,
    transition_id: str,
    kind: str,
    value: dict[str, Any],
) -> str:
    path = marker_path(runtime_root, transition_id, kind)
    if path.exists():
        raise ValueError(f"transition marker already exists: {path}")
    return write_hashed_json(path, value)


def load_marker(runtime_root: Path, transition_id: str, kind: str) -> dict[str, Any]:
    path = marker_path(runtime_root, transition_id, kind)
    validate_bare_sha256_sidecar(path)
    value = strict_load_json(path)
    if value.get("transition_id") != transition_id:
        raise ValueError(f"transition marker ID mismatch: {path}")
    return value


def _journal_rows(runtime_root: Path) -> list[dict[str, Any]]:
    path = runtime_root / "runtime_journal.jsonl"
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line_no, line in enumerate(
        path.read_text(encoding="utf-8", errors="strict").splitlines(), 1
    ):
        if not line.strip():
            continue
        value = strict_json_loads(line)
        if not isinstance(value, dict):
            raise ValueError(f"runtime journal row {line_no} is not an object")
        rows.append(value)
    return rows


def _journal_matches(runtime_root: Path, journal_event_id: str) -> list[dict[str, Any]]:
    return [
        row for row in _journal_rows(runtime_root)
        if row.get("journal_event_id") == journal_event_id
    ]


def _append_journal_recovery(
    runtime_root: Path,
    prepared: dict[str, Any],
) -> str:
    """Idempotently reconstruct the transition journal event."""
    journal_event_id = prepared["journal_event_id"]
    existing = _journal_matches(runtime_root, journal_event_id)
    if len(existing) > 1:
        raise RuntimeCliError(
            "RUNTIME_JOURNAL_EVENT_DUPLICATE",
            "Transition journal event ID appears more than once.",
            exit_code=75,
            details={"journal_event_id": journal_event_id},
        )
    if existing:
        row = existing[0]
        if (
            row.get("event") != "STATE_TRANSITION_COMMITTED"
            or row.get("transition_id") != prepared["transition_id"]
        ):
            raise RuntimeCliError(
                "RUNTIME_JOURNAL_EVENT_CONFLICT",
                "Existing journal event does not match the transition.",
                exit_code=75,
                details={"journal_event_id": journal_event_id},
            )
        return str(row["event_sha256"])

    path = runtime_root / "runtime_journal.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = _journal_rows(runtime_root)
    previous = rows[-1].get("event_sha256") if rows else None
    payload = {
        "event": "STATE_TRANSITION_COMMITTED",
        "journal_event_id": journal_event_id,
        "at": prepared["journal_event_at"],
        "previous_event_sha256": previous,
        "transition_id": prepared["transition_id"],
        "transition_kind": prepared["transition_kind"],
        "phase_id": prepared["phase_id"],
        "resulting_state_revision": prepared["resulting_state_revision"],
        "details": prepared.get("details") or {},
    }
    digest = sha256_bytes(canonical_json_bytes(payload))
    row = {**payload, "event_sha256": digest}
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(
            json.dumps(row, ensure_ascii=False, sort_keys=True, allow_nan=False)
            + "\n"
        )
        handle.flush()
        import os
        os.fsync(handle.fileno())
    return digest


def _receipt_marker(runtime_root: Path, receipt_id: str, status: str) -> Path:
    return runtime_root / "receipts" / receipt_id / f"{status.lower()}.json"


def _consume_receipt_recovery(
    runtime_root: Path,
    prepared: dict[str, Any],
) -> str | None:
    receipt_id = prepared.get("receipt_id")
    if not receipt_id:
        return None
    valid_path = _receipt_marker(runtime_root, receipt_id, "VALID")
    if not valid_path.is_file():
        raise RuntimeCliError(
            "RUNTIME_RECEIPT_VALID_MARKER_MISSING",
            "The transition receipt VALID marker is missing.",
            exit_code=75,
            details={"receipt_id": receipt_id},
        )
    valid_sha = validate_bare_sha256_sidecar(valid_path)
    if valid_sha != prepared.get("receipt_valid_sha256"):
        raise RuntimeCliError(
            "RUNTIME_RECEIPT_BINDING_CONFLICT",
            "The transition receipt binding changed.",
            exit_code=75,
            details={"receipt_id": receipt_id},
        )
    consumed_path = _receipt_marker(runtime_root, receipt_id, "CONSUMED")
    if consumed_path.exists():
        validate_bare_sha256_sidecar(consumed_path)
        consumed = strict_load_json(consumed_path)
        if consumed.get("consumed_by_transition_id") != prepared["transition_id"]:
            raise RuntimeCliError(
                "RUNTIME_RECEIPT_CONSUMPTION_CONFLICT",
                "Receipt was consumed by another transition.",
                exit_code=75,
                details={"receipt_id": receipt_id},
            )
        return sha256_file(consumed_path)

    digest = write_hashed_json(consumed_path, {
        "schema_version": "action-validation-receipt-consumed-v1",
        "receipt_id": receipt_id,
        "validated_receipt_sha256": valid_sha,
        "consumed_by_transition_id": prepared["transition_id"],
        "consumed_at": utc_now(),
    })
    return digest


def _artifact_observation(entry: dict[str, Any]) -> str:
    target = Path(entry["target_path"])
    planned = entry["planned_after_sha256"]
    if target.is_file() and not target.is_symlink():
        current = sha256_file(target)
        if current == planned:
            return "AFTER"
        expected = entry.get("expected_before_sha256")
        if expected and current == expected:
            return "BEFORE"
        return "NEITHER"
    if target.exists():
        return "NEITHER"
    return "BEFORE" if entry.get("expected_absent") else "NEITHER"


def _apply_artifacts(prepared: dict[str, Any]) -> list[dict[str, Any]]:
    entries = list(prepared.get("artifact_writes") or [])
    # Preflight every target before touching any target.  A multi-file P04
    # source-ledger rebuild must fail as a unit when one precondition is stale;
    # otherwise an early ledger could be replaced before a later conflict is
    # discovered.  Recovery still accepts a mixture of BEFORE/AFTER states
    # after an interrupted process, but ordinary execution never starts with
    # a known conflict.
    preflight: list[tuple[dict[str, Any], str]] = []
    for entry in entries:
        observation = _artifact_observation(entry)
        preflight.append((entry, observation))
        if observation == "NEITHER":
            raise RuntimeCliError(
                "RUNTIME_ARTIFACT_RECOVERY_CONFLICT",
                "Artifact is neither at the expected before state nor planned after state.",
                exit_code=75,
                details={
                    "transition_id": prepared["transition_id"],
                    "target_path": entry["target_path"],
                },
            )
    applied: list[dict[str, Any]] = []
    for entry, _initial_observation in preflight:
        target = Path(entry["target_path"])
        observation = _artifact_observation(entry)
        if observation == "NEITHER":
            raise RuntimeCliError(
                "RUNTIME_ARTIFACT_RECOVERY_CONFLICT",
                "Artifact is neither at the expected before state nor planned after state.",
                exit_code=75,
                details={
                    "transition_id": prepared["transition_id"],
                    "target_path": entry["target_path"],
                },
            )
        if observation == "BEFORE":
            payload = base64.b64decode(entry["payload_base64"], validate=True)
            if sha256_bytes(payload) != entry["planned_after_sha256"]:
                raise RuntimeCliError(
                    "RUNTIME_ARTIFACT_PAYLOAD_CORRUPT",
                    "Prepared artifact payload does not match its planned hash.",
                    exit_code=75,
                    details={"target_path": entry["target_path"]},
                )
            atomic_write_bytes(target, payload)
        actual = sha256_file(target)
        if actual != entry["planned_after_sha256"]:
            raise RuntimeCliError(
                "RUNTIME_ARTIFACT_APPLY_FAILED",
                "Artifact did not reach the planned after hash.",
                exit_code=75,
                details={"target_path": entry["target_path"]},
            )
        applied.append({
            "target_path": entry["target_path"],
            "artifact_after_sha256": actual,
        })
    return applied


def _planned_state(prepared: dict[str, Any], prepared_sha: str) -> dict[str, Any]:
    state = json.loads(canonical_json_bytes(prepared["planned_resulting_state_payload"]))
    state["transition_head"]["last_applied_transition_prepared_sha256"] = prepared_sha
    if state_payload_digest(state) != prepared["planned_resulting_state_payload_sha256"]:
        raise RuntimeCliError(
            "RUNTIME_PLANNED_STATE_HASH_MISMATCH",
            "Prepared resulting State payload hash is invalid.",
            exit_code=75,
            details={"transition_id": prepared["transition_id"]},
        )
    validate_json_schema(state, "runtime-state-v2.schema.json")
    return state


def _state_is_planned(
    state: dict[str, Any],
    prepared: dict[str, Any],
    prepared_sha: str,
) -> bool:
    return (
        state.get("transition_head", {}).get("last_applied_transition_id")
        == prepared["transition_id"]
        and state.get("transition_head", {}).get(
            "last_applied_transition_prepared_sha256"
        ) == prepared_sha
        and int(state.get("state_revision", -1))
        == int(prepared["resulting_state_revision"])
        and state_payload_digest(state)
        == prepared["planned_resulting_state_payload_sha256"]
    )


def _complete_transition(
    runtime_root: Path,
    prepared: dict[str, Any],
    *,
    write_state: Callable[[Path, dict[str, Any]], None] | None = None,
    append_journal: Callable[..., str | None] | None = None,
) -> dict[str, Any]:
    tid = prepared["transition_id"]
    prepared_path = marker_path(runtime_root, tid, "prepared")
    prepared_sha = validate_bare_sha256_sidecar(prepared_path)

    artifacts = _apply_artifacts(prepared)
    artifact_marker_path = marker_path(runtime_root, tid, "artifact_applied")
    if not artifact_marker_path.exists():
        write_marker(runtime_root, tid, "artifact_applied", {
            "schema_version": "transition-artifact-applied-v1",
            "transition_id": tid,
            "prepared_sha256": prepared_sha,
            "artifact_required": bool(prepared.get("artifact_writes")),
            "artifacts": artifacts,
            "applied_at": utc_now(),
        })
    else:
        load_marker(runtime_root, tid, "artifact_applied")

    current = strict_load_json(runtime_root / "runtime_state.json")
    if _state_is_planned(current, prepared, prepared_sha):
        resulting = current
    elif int(current.get("state_revision", -1)) == int(
        prepared["expected_state_revision"]
    ):
        resulting = _planned_state(prepared, prepared_sha)
        if write_state is None:
            atomic_write_json(runtime_root / "runtime_state.json", resulting)
        else:
            write_state(runtime_root, resulting)
    else:
        raise RuntimeCliError(
            "RUNTIME_STATE_RECOVERY_CONFLICT",
            "Runtime State is neither before nor after the prepared transition.",
            exit_code=75,
            details={
                "transition_id": tid,
                "current_state_revision": current.get("state_revision"),
                "expected_state_revision": prepared["expected_state_revision"],
                "resulting_state_revision": prepared["resulting_state_revision"],
            },
        )

    state_marker_path = marker_path(runtime_root, tid, "state_applied")
    resulting_sha = state_digest(resulting)
    if not state_marker_path.exists():
        write_marker(runtime_root, tid, "state_applied", {
            "schema_version": "transition-state-applied-v1",
            "transition_id": tid,
            "prepared_sha256": prepared_sha,
            "resulting_state_sha256": resulting_sha,
            "resulting_state_revision": resulting["state_revision"],
            "applied_at": utc_now(),
        })
    else:
        state_marker = load_marker(runtime_root, tid, "state_applied")
        if state_marker.get("resulting_state_sha256") != resulting_sha:
            raise RuntimeCliError(
                "RUNTIME_STATE_APPLIED_MARKER_CONFLICT",
                "State-applied marker does not match Runtime State.",
                exit_code=75,
                details={"transition_id": tid},
            )

    primary_after = artifacts[0]["artifact_after_sha256"] if artifacts else None
    committed_path = marker_path(runtime_root, tid, "committed")
    if not committed_path.exists():
        write_marker(runtime_root, tid, "committed", {
            "schema_version": "transition-committed-v2",
            "transition_id": tid,
            "prepared_sha256": prepared_sha,
            "journal_event_id": prepared["journal_event_id"],
            "receipt_id": prepared.get("receipt_id"),
            "artifact_after_sha256": primary_after,
            "resulting_state_sha256": resulting_sha,
            "committed_at": utc_now(),
        })
    else:
        committed = load_marker(runtime_root, tid, "committed")
        for key, expected in {
            "journal_event_id": prepared["journal_event_id"],
            "receipt_id": prepared.get("receipt_id"),
            "artifact_after_sha256": primary_after,
            "resulting_state_sha256": resulting_sha,
        }.items():
            if committed.get(key) != expected:
                raise RuntimeCliError(
                    "RUNTIME_COMMITTED_MARKER_CONFLICT",
                    f"Committed marker field changed: {key}",
                    exit_code=75,
                    details={"transition_id": tid},
                )

    if append_journal is None:
        journal_sha = _append_journal_recovery(runtime_root, prepared)
    else:
        journal_sha = append_journal(
            runtime_root,
            "STATE_TRANSITION_COMMITTED",
            journal_event_id=prepared["journal_event_id"],
            event_at=prepared["journal_event_at"],
            transition_id=tid,
            transition_kind=prepared["transition_kind"],
            phase_id=prepared["phase_id"],
            resulting_state_revision=prepared["resulting_state_revision"],
            details=prepared.get("details") or {},
        )
    receipt_consumed_sha = _consume_receipt_recovery(runtime_root, prepared)

    finalized_path = marker_path(runtime_root, tid, "finalized")
    if not finalized_path.exists():
        write_marker(runtime_root, tid, "finalized", {
            "schema_version": "transition-finalized-v1",
            "transition_id": tid,
            "prepared_sha256": prepared_sha,
            "committed_sha256": sha256_file(committed_path),
            "journal_event_id": prepared["journal_event_id"],
            "journal_event_sha256": journal_sha,
            "receipt_id": prepared.get("receipt_id"),
            "receipt_consumed_sha256": receipt_consumed_sha,
            "artifact_after_sha256": primary_after,
            "resulting_state_sha256": resulting_sha,
            "finalized_at": utc_now(),
        })
    else:
        load_marker(runtime_root, tid, "finalized")
    return resulting


def inspect_recovery(
    runtime_root: Path,
    state: dict[str, Any],
) -> dict[str, Any]:
    transitions_root = runtime_root / "transitions"
    findings: list[dict[str, Any]] = []
    repairs: list[dict[str, Any]] = []
    if not transitions_root.exists():
        return {
            "schema_version": "transition-inspection-v2",
            "status": "CLEAN",
            "findings": [],
            "repairs": [],
        }

    for directory in sorted(
        (item for item in transitions_root.iterdir() if item.is_dir()),
        key=lambda item: item.name,
    ):
        tid = directory.name
        prepared_path = directory / "prepared.json"
        if not prepared_path.exists():
            findings.append({
                "code": "TRANSITION_PREPARED_MISSING",
                "transition_id": tid,
            })
            continue
        try:
            prepared = load_marker(runtime_root, tid, "prepared")
            prepared_sha = sha256_file(prepared_path)
        except Exception as exc:
            findings.append({
                "code": "TRANSITION_PREPARED_INVALID",
                "transition_id": tid,
                "cause": str(exc),
            })
            continue

        # Every present stage marker must be valid.
        stage_invalid = False
        for kind in STAGE_KINDS[1:]:
            path = marker_path(runtime_root, tid, kind)
            if path.exists() and not marker_valid(path):
                findings.append({
                    "code": f"TRANSITION_{kind.upper()}_INVALID",
                    "transition_id": tid,
                })
                stage_invalid = True
        if stage_invalid:
            continue

        finalized_path = marker_path(runtime_root, tid, "finalized")
        committed_path = marker_path(runtime_root, tid, "committed")
        artifact_path = marker_path(runtime_root, tid, "artifact_applied")
        state_path = marker_path(runtime_root, tid, "state_applied")

        journal_matches = _journal_matches(
            runtime_root, prepared["journal_event_id"]
        )
        if len(journal_matches) > 1:
            findings.append({
                "code": "JOURNAL_EVENT_DUPLICATE",
                "transition_id": tid,
                "journal_event_id": prepared["journal_event_id"],
            })
            continue
        journal_ok = (
            len(journal_matches) == 1
            and journal_matches[0].get("transition_id") == tid
            and journal_matches[0].get("event")
            == "STATE_TRANSITION_COMMITTED"
        )

        receipt_id = prepared.get("receipt_id")
        receipt_ok = True
        if receipt_id:
            consumed = _receipt_marker(runtime_root, receipt_id, "CONSUMED")
            receipt_ok = False
            if consumed.exists() and marker_valid(consumed):
                value = strict_load_json(consumed)
                receipt_ok = value.get("consumed_by_transition_id") == tid

        if finalized_path.exists():
            if not (
                artifact_path.exists()
                and state_path.exists()
                and committed_path.exists()
                and journal_ok
                and receipt_ok
            ):
                repairs.append({
                    "code": "FINALIZATION_SIDE_EFFECTS_CAN_BE_REBUILT",
                    "transition_id": tid,
                })
                continue
            # For the current head, the primary artifact must still be at
            # the committed hash. Historical finalized transitions may have
            # been superseded by later actions.
            if (
                state.get("transition_head", {}).get(
                    "last_applied_transition_id"
                ) == tid
                and prepared.get("artifact_writes")
            ):
                if _artifact_observation(
                    prepared["artifact_writes"][0]
                ) != "AFTER":
                    findings.append({
                        "code": "CURRENT_ARTIFACT_HASH_MISMATCH",
                        "transition_id": tid,
                    })
            continue

        # Incomplete transitions are repairable only when artifact and State
        # are exactly at a recognized before/after state.
        observations = [
            _artifact_observation(entry)
            for entry in prepared.get("artifact_writes") or []
        ]
        if "NEITHER" in observations:
            findings.append({
                "code": "ACTION_ARTIFACT_RECOVERY_CONFLICT",
                "transition_id": tid,
            })
            continue
        current_revision = int(state.get("state_revision", -1))
        expected_revision = int(prepared["expected_state_revision"])
        resulting_revision = int(prepared["resulting_state_revision"])
        state_recognized = (
            current_revision == expected_revision
            or _state_is_planned(state, prepared, prepared_sha)
        )
        if not state_recognized:
            findings.append({
                "code": "STATE_RECOVERY_CONFLICT",
                "transition_id": tid,
                "current_revision": current_revision,
                "expected_revision": expected_revision,
                "resulting_revision": resulting_revision,
            })
            continue
        repairs.append({
            "code": "TRANSITION_CAN_BE_COMPLETED",
            "transition_id": tid,
            "artifact_observations": observations,
            "journal_present": journal_ok,
            "receipt_consumed": receipt_ok,
        })

    corrupt_codes = {
        "TRANSITION_PREPARED_MISSING",
        "TRANSITION_PREPARED_INVALID",
        "JOURNAL_EVENT_DUPLICATE",
        "ACTION_ARTIFACT_RECOVERY_CONFLICT",
        "STATE_RECOVERY_CONFLICT",
        "CURRENT_ARTIFACT_HASH_MISMATCH",
    }
    if any(
        item["code"] in corrupt_codes
        or item["code"].endswith("_INVALID")
        for item in findings
    ):
        status = "CORRUPT"
    elif findings:
        status = "RECOVERY_REQUIRED"
    elif repairs:
        status = "REPAIRABLE"
    else:
        status = "CLEAN"
    return {
        "schema_version": "transition-inspection-v2",
        "status": status,
        "findings": findings,
        "repairs": repairs,
    }


def repair_recovery(
    runtime_root: Path,
    state: dict[str, Any],
) -> dict[str, Any]:
    report = inspect_recovery(runtime_root, state)
    if report["status"] == "CLEAN":
        return report
    if report["status"] != "REPAIRABLE":
        raise RuntimeCliError(
            (
                "RUNTIME_RECOVERY_REQUIRED"
                if report["status"] == "RECOVERY_REQUIRED"
                else "RUNTIME_TRANSITION_CORRUPT"
            ),
            "Runtime transition recovery requires explicit inspection.",
            exit_code=75,
            details=report,
        )
    for repair in sorted(
        report["repairs"],
        key=lambda item: int(
            load_marker(
                runtime_root, item["transition_id"], "prepared"
            )["resulting_state_revision"]
        ),
    ):
        tid = repair["transition_id"]
        prepared = load_marker(runtime_root, tid, "prepared")
        _complete_transition(runtime_root, prepared)
    current = strict_load_json(runtime_root / "runtime_state.json")
    return inspect_recovery(runtime_root, current)


def apply_transition(
    runtime_root: Path,
    state: dict[str, Any],
    *,
    transition_kind: str,
    phase_id: str,
    mutate: Callable[[dict[str, Any]], None],
    validate_state: Callable[[dict[str, Any]], None],
    write_state: Callable[[Path, dict[str, Any]], None],
    append_journal: Callable[..., str | None],
    details: dict[str, Any] | None = None,
    artifact_writes: list[dict[str, Any]] | None = None,
    receipt: dict[str, Any] | None = None,
    after_commit: Callable[[str], None] | None = None,
    lock_held: bool = False,
) -> dict[str, Any]:
    """Apply a transition through PREPARED→ARTIFACT→STATE→COMMITTED→FINALIZED."""

    def perform() -> dict[str, Any]:
        current = strict_load_json(runtime_root / "runtime_state.json")
        if int(current.get("state_revision", -1)) != int(
            state.get("state_revision", -2)
        ):
            raise RuntimeCliError(
                "RUNTIME_STATE_REVISION_CONFLICT",
                "Runtime state changed since it was loaded.",
                exit_code=75,
                details={
                    "expected": state.get("state_revision"),
                    "actual": current.get("state_revision"),
                },
            )

        resulting = json.loads(canonical_json_bytes(current))
        mutate(resulting)
        resulting["state_revision"] = int(current["state_revision"]) + 1
        resulting["updated_at"] = utc_now()
        transition_id = f"TX-{uuid.uuid4().hex.upper()}"
        journal_event_id = f"JE-{uuid.uuid4().hex.upper()}"
        journal_event_at = utc_now()
        resulting.setdefault("transition_head", {})[
            "last_applied_transition_id"
        ] = transition_id
        resulting["transition_head"][
            "last_applied_transition_prepared_sha256"
        ] = None
        validate_state(resulting)

        normalized_writes: list[dict[str, Any]] = []
        for index, raw in enumerate(artifact_writes or []):
            payload = raw["content"]
            if isinstance(payload, str):
                payload = payload.encode("utf-8")
            if not isinstance(payload, bytes):
                raise TypeError("artifact transition content must be bytes or text")
            target = Path(raw["target_path"])
            planned = sha256_bytes(payload)
            if raw.get("planned_after_sha256") not in {None, planned}:
                raise ValueError("artifact payload does not match planned after hash")
            normalized_writes.append({
                "artifact_index": index,
                "target_path": str(target),
                "target_relative_path": raw.get("target_relative_path"),
                "target_precondition": raw["target_precondition"],
                "expected_absent": bool(raw.get("expected_absent", False)),
                "expected_before_sha256": raw.get("expected_before_sha256"),
                "planned_after_sha256": planned,
                "payload_base64": base64.b64encode(payload).decode("ascii"),
            })

        receipt_id = receipt.get("receipt_id") if receipt else None
        receipt_valid_sha = None
        if receipt_id:
            valid_path = _receipt_marker(runtime_root, receipt_id, "VALID")
            receipt_valid_sha = validate_bare_sha256_sidecar(valid_path)

        prepared = {
            "schema_version": "transition-prepared-v2",
            "protocol_version": TRANSITION_PROTOCOL_VERSION,
            "transition_id": transition_id,
            "transition_kind": transition_kind,
            "expected_state_revision": int(current["state_revision"]),
            "resulting_state_revision": int(current["state_revision"]) + 1,
            "previous_state_sha256": state_digest(current),
            "planned_resulting_state_payload_sha256": state_payload_digest(
                resulting
            ),
            "planned_resulting_state_payload": resulting,
            "phase_plan_revision": current["route"]["phase_plan_revision"],
            "phase_id": phase_id,
            "phase_attempt": current["cursor"]["attempt"],
            "recovery_epoch": current["cursor"]["recovery_epoch"],
            "receipt_id": receipt_id,
            "receipt_valid_sha256": receipt_valid_sha,
            "action_id": (details or {}).get("action_id"),
            "target_path": (
                normalized_writes[0]["target_path"]
                if normalized_writes else None
            ),
            "target_precondition": (
                normalized_writes[0]["target_precondition"]
                if normalized_writes else None
            ),
            "expected_before_sha256": (
                normalized_writes[0]["expected_before_sha256"]
                if normalized_writes else None
            ),
            "expected_absent": (
                normalized_writes[0]["expected_absent"]
                if normalized_writes else False
            ),
            "planned_after_sha256": (
                normalized_writes[0]["planned_after_sha256"]
                if normalized_writes else None
            ),
            "artifact_writes": normalized_writes,
            "journal_event_id": journal_event_id,
            "journal_event_at": journal_event_at,
            "prepared_at": utc_now(),
            "details": details or {},
        }
        write_marker(
            runtime_root, transition_id, "prepared", prepared
        )
        # Completion is idempotent. A crash after any stage can call the same
        # function again through repair_recovery().
        final = _complete_transition(
            runtime_root,
            prepared,
            write_state=write_state,
            append_journal=append_journal,
        )
        if after_commit:
            after_commit(transition_id)
        return final

    if lock_held:
        return perform()
    with exclusive_runtime_lock(runtime_root):
        current = strict_load_json(runtime_root / "runtime_state.json")
        repair_recovery(runtime_root, current)
        return perform()
