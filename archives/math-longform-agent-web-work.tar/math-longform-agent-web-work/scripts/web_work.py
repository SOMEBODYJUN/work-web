#!/usr/bin/env python3
"""Upload-first launcher for ChatGPT Work's cloud filesystem.

This adapter prepares inputs only.  All phase transitions remain owned by
agent_runtime.py; it cannot approve a semantic phase or write a formal Vault.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import sys
import uuid
import zipfile


ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / "scripts" / "agent_runtime.py"
CONTRACT = ROOT / "config" / "author-task-contract.preserve-reorganize.json"
MAX_FILES = 20_000
MAX_FILE_BYTES = 100_000_000
MAX_TOTAL_BYTES = 256_000_000
DEFAULT_REQUEST = "保留原稿的数学事实、证明路线和作者声音，按流程整理并完成发布验收。"
_runtime_env: dict[str, str] | None = None


def _sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _safe_zip_members(archive: zipfile.ZipFile) -> list[tuple[zipfile.ZipInfo, PurePosixPath]]:
    members: list[tuple[zipfile.ZipInfo, PurePosixPath]] = []
    seen: set[str] = set()
    directory_keys: set[str] = set()
    total = 0
    for item in archive.infolist():
        name = item.filename.rstrip("/")
        if not name or "\\" in name or name.startswith("/") or any(
            part in {"", ".", ".."} or ":" in part for part in name.split("/")
        ):
            raise ValueError(f"unsafe Vault ZIP entry: {item.filename!r}")
        path = PurePosixPath(name)
        key = path.as_posix().casefold()
        if key in seen:
            raise ValueError(f"duplicate or case-colliding Vault ZIP path: {name}")
        seen.add(key)
        if item.is_dir():
            directory_keys.add(key)
        mode = (item.external_attr >> 16) & 0xFFFF
        kind = stat.S_IFMT(mode)
        if kind not in {0, stat.S_IFDIR if item.is_dir() else stat.S_IFREG}:
            raise ValueError(f"Vault ZIP contains a link or special file: {name}")
        if not item.is_dir():
            total += item.file_size
            if item.file_size > MAX_FILE_BYTES or total > MAX_TOTAL_BYTES:
                raise ValueError("Vault ZIP exceeds the extraction size limit")
        members.append((item, path))
        if len(members) > MAX_FILES:
            raise ValueError("Vault ZIP exceeds the entry count limit")
    for _, path in members:
        for parent in path.parents:
            if parent == PurePosixPath("."):
                break
            if parent.as_posix().casefold() in seen - directory_keys:
                raise ValueError(f"Vault ZIP file shadows a directory: {parent}")
    return members


def extract_vault_snapshot(source: Path, target: Path) -> dict:
    if target.exists():
        raise ValueError(f"snapshot target already exists: {target}")
    if not zipfile.is_zipfile(source):
        raise ValueError("Vault snapshot must be a ZIP archive")
    try:
        with zipfile.ZipFile(source) as archive:
            members = _safe_zip_members(archive)
            target.mkdir(parents=True)
            files = []
            for entry, relative in members:
                path = target.joinpath(*relative.parts)
                if entry.is_dir():
                    path.mkdir(parents=True, exist_ok=True)
                    continue
                path.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(entry) as input_handle, path.open("xb") as output_handle:
                    size = 0
                    while block := input_handle.read(1024 * 1024):
                        size += len(block)
                        if size > entry.file_size or size > MAX_FILE_BYTES:
                            raise ValueError(f"Vault ZIP entry inflated beyond limit: {relative}")
                        output_handle.write(block)
                if size != entry.file_size:
                    raise ValueError(f"Vault ZIP entry size changed: {relative}")
                files.append({"path": relative.as_posix(), "size": size, "sha256": _sha(path)})
    except Exception:
        if target.exists():
            shutil.rmtree(target)
        raise
    return {"kind": "UPLOADED_VAULT_SNAPSHOT", "archive_sha256": _sha(source), "files": files}


def _verify_snapshot(workspace: Path) -> None:
    manifest_path = workspace / "inputs" / "vault-snapshot-manifest.json"
    if not manifest_path.is_file():
        return
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    root = workspace / "vault-snapshot"
    expected = {item["path"]: item for item in manifest["files"]}
    actual = {}
    for path in root.rglob("*"):
        if path.is_symlink():
            raise ValueError("Vault snapshot contains a symlink after binding")
        if path.is_file():
            relative = path.relative_to(root).as_posix()
            actual[relative] = {"path": relative, "size": path.stat().st_size, "sha256": _sha(path)}
    if actual != expected:
        raise ValueError("Vault snapshot changed after upload; stop and restart from a current snapshot")


def _prepare_vault(workspace: Path, zip_path: Path) -> Path:
    snapshot = extract_vault_snapshot(zip_path.resolve(strict=True), workspace / "vault-snapshot")
    inputs = workspace / "inputs"
    _write_json(inputs / "vault-snapshot-manifest.json", snapshot)
    config = {
        "config_schema_version": "obsidian-target-config-v1.0",
        "mode": "STAGING_ONLY",
        "authorized_vault_root": str(workspace / "vault-snapshot"),
        "obsidian_run_root": None,
        "indexing": {"exclude_paths": [".trash", "Templates", ".codex-agent"], "max_notes": 20000, "max_note_bytes": 2000000},
        "destination_policy": {"learn_from_vault": True, "fallback_folder": "Agent Inbox", "allow_invented_taxonomy": False},
        "tag_policy": {"approved_tags": [], "max_depth": 2},
        "attachments": {"mode": "TEXT_REFERENCES_ONLY", "copy_binary_files": False, "validate_binary_targets": False},
        "human_review": {"mode": "ACTUAL_PAGES_AND_DIFFS", "vault_commit": False, "approval_hash_required": True},
    }
    path = inputs / "obsidian-target-config.json"
    _write_json(path, config)
    return path


def _run_runtime(*args: str) -> dict:
    command = [sys.executable, str(RUNTIME), *args]
    result = subprocess.run(command, cwd=ROOT, env=_runtime_env, text=True, capture_output=True, check=False)
    if result.returncode:
        raise RuntimeError(f"Runtime command {args[0]} failed ({result.returncode}):\n{result.stderr or result.stdout}")
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError:
        return {"output": result.stdout.strip()}


def _ensure_dependencies(workspace: Path) -> None:
    """Install only declared Runtime dependencies in this cloud task if absent."""
    global _runtime_env
    target = workspace / "python-deps"
    probe = subprocess.run(
        [sys.executable, "-c", "import jsonschema, yaml"],
        text=True, capture_output=True, check=False,
    )
    if probe.returncode and not (target / "jsonschema" / "__init__.py").is_file():
        base = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "--target", str(target), "-r", str(ROOT / "requirements-web-lock.txt")]
        result = subprocess.run(
            [*base, "--no-index", "--find-links", str(ROOT / "vendor" / "wheels")],
            text=True, capture_output=True, check=False,
        )
        if result.returncode:
            result = subprocess.run(base, text=True, capture_output=True, check=False)
        if result.returncode:
            raise RuntimeError("required Python packages are unavailable; install requirements-web-lock.txt in the Work environment before continuing: " + result.stderr[-1200:])
    env = os.environ.copy()
    env["PYTHONPATH"] = str(target) + os.pathsep + env.get("PYTHONPATH", "")
    _runtime_env = env
    check = subprocess.run([sys.executable, "-c", "import jsonschema, yaml"], env=env, capture_output=True, check=False)
    if check.returncode:
        raise RuntimeError("Runtime dependencies could not be loaded")


def _summary(workspace: Path, result: dict) -> dict:
    state = result["state"]
    return {
        "workspace_root": str(workspace),
        "runtime_root": str(workspace / "runtime"),
        "business_root": str(workspace / "business"),
        "run_id": state["identity"]["run_id"],
        "current_phase": state["cursor"]["current_phase"],
        "workflow_status": state["workflow"]["status"],
        "obsidian_status": state["outputs"]["obsidian"]["status"],
        "committed_phases": state["execution"]["committed_phase_ids"],
    }


def init(args: argparse.Namespace) -> None:
    workspace = Path(args.workspace_root).resolve()
    if workspace == ROOT or ROOT in workspace.parents:
        raise ValueError("run workspace must be outside the uploaded Agent folder")
    source = Path(args.source).resolve(strict=True)
    if not source.is_file():
        raise ValueError("the manuscript upload must be a regular file")
    # Work's attachment staging can drop the original filename extension
    # (for example, an uploaded `*.txt` may arrive as `01-txt`).  Validate the
    # bytes rather than trusting the staging name, while still rejecting
    # binary uploads before they enter the canonical source pipeline.
    manuscript = source.read_text(encoding="utf-8", errors="strict")
    if "\x00" in manuscript:
        raise ValueError("the manuscript upload must be UTF-8 text")
    if workspace.exists() and any(workspace.iterdir()):
        raise ValueError("--workspace-root must be new or empty")
    request_file = getattr(args, "request_file", None)
    request = Path(request_file).read_text(encoding="utf-8", errors="strict") if request_file else (args.request or DEFAULT_REQUEST)
    if not request.strip():
        raise ValueError("the author request must not be empty")
    if args.vault_zip and not args.obsidian:
        raise ValueError("--vault-zip requires the author's explicit --obsidian request")
    workspace.mkdir(parents=True, exist_ok=True)
    _ensure_dependencies(workspace)
    inputs = workspace / "inputs"
    inputs.mkdir()
    copied_source = inputs / "source.txt"
    shutil.copyfile(source, copied_source)
    contract = deepcopy(json.loads(CONTRACT.read_text(encoding="utf-8")))
    contract["task_id"] = f"TASK-{uuid.uuid4().hex.upper()}"
    contract["author_request"] = request
    contract["author_confirmation"]["evidence"] = request
    if args.task_contract:
        contract = json.loads(Path(args.task_contract).read_text(encoding="utf-8"))
        if contract.get("author_request") != request:
            raise ValueError("supplied author task contract must quote the current request exactly")
    if "REPLACE_WITH" in json.dumps(contract) or "TASK-REPLACE" in json.dumps(contract):
        raise ValueError("author task contract still contains placeholders")
    contract_path = inputs / "author-task-contract.json"
    _write_json(contract_path, contract)
    runtime_args = [
        "bootstrap", "--runtime-root", str(workspace / "runtime"),
        "--business-root", str(workspace / "business"),
        "--source", str(copied_source), "--task-contract", str(contract_path),
    ]
    if not args.obsidian:
        runtime_args.append("--skip-obsidian")
    elif args.vault_zip:
        config_path = _prepare_vault(workspace, Path(args.vault_zip))
        runtime_args.extend(["--obsidian-config", str(config_path)])
    _run_runtime(*runtime_args)
    _run_runtime("source-authority", "--runtime-root", str(workspace / "runtime"))
    _run_runtime("source-model", "--runtime-root", str(workspace / "runtime"))
    state = _run_runtime("status", "--runtime-root", str(workspace / "runtime"))
    print(json.dumps({**_summary(workspace, state), "source_sha256": _sha(copied_source)}, ensure_ascii=False, indent=2))


def status(args: argparse.Namespace) -> None:
    workspace = Path(args.workspace_root).resolve()
    _ensure_dependencies(workspace)
    _verify_snapshot(workspace)
    print(json.dumps(_summary(workspace, _run_runtime("status", "--runtime-root", str(workspace / "runtime"))), ensure_ascii=False, indent=2))


def runtime(args: argparse.Namespace) -> None:
    """Use the original CLI with the run's isolated Python dependencies."""
    workspace = Path(args.workspace_root).resolve()
    _ensure_dependencies(workspace)
    _verify_snapshot(workspace)
    rest = args.runtime_args
    if rest and rest[0] == "--":
        rest = rest[1:]
    allowed = {
        "emit-turn", "validate-action", "execute-action", "advance", "status",
        "recover", "submit-author-intent",
    }
    if not rest or rest[0] not in allowed:
        raise ValueError("unsupported Web Work Runtime action")
    if "--runtime-root" in rest:
        raise ValueError("Runtime root is bound by --workspace-root")
    result = _run_runtime(rest[0], "--runtime-root", str(workspace / "runtime"), *rest[1:])
    print(json.dumps(result, ensure_ascii=False, indent=2))


def attach_vault(args: argparse.Namespace) -> None:
    workspace = Path(args.workspace_root).resolve()
    _ensure_dependencies(workspace)
    state = _run_runtime("status", "--runtime-root", str(workspace / "runtime"))["state"]
    if not (state["route"]["obsidian_enabled"] and state["cursor"]["current_phase"] == "P16"
            and state["workflow"]["status"] == "SUSPENDED"
            and state["outputs"]["obsidian"]["status"] == "CONFIGURATION_REQUIRED"):
        raise ValueError("Vault snapshot may only be attached at the suspended P16 configuration gate")
    config = _prepare_vault(workspace, Path(args.vault_zip))
    _verify_snapshot(workspace)
    _run_runtime(
        "configure-obsidian", "--runtime-root", str(workspace / "runtime"),
        "--obsidian-config", str(config), "--authorized-by", "author-uploaded-snapshot",
        "--authorization-event-id", f"UPLOAD-{uuid.uuid4().hex.upper()}",
    )
    print(json.dumps(_summary(workspace, _run_runtime("status", "--runtime-root", str(workspace / "runtime"))), ensure_ascii=False, indent=2))


def checkpoint(args: argparse.Namespace) -> None:
    """Archive the entire run without claiming cross-path Runtime relocation."""
    workspace = Path(args.workspace_root).resolve()
    output = Path(args.output).resolve()
    if output == workspace or workspace in output.parents:
        raise ValueError("checkpoint output must be outside the run workspace")
    _ensure_dependencies(workspace)
    _verify_snapshot(workspace)
    summary = _summary(workspace, _run_runtime("status", "--runtime-root", str(workspace / "runtime")))
    files = sorted(path for path in workspace.rglob("*") if path.is_file())
    if any(path.is_symlink() for path in workspace.rglob("*")):
        raise ValueError("checkpoint cannot contain symlinks")
    manifest = {
        "schema_version": "web-work-checkpoint-v1",
        "origin_root": str(workspace),
        "run_id": summary["run_id"],
        "current_phase": summary["current_phase"],
        "skill_version": (ROOT / "skills" / "math-longform-publisher" / "VERSION").read_text(encoding="utf-8").strip(),
        "runtime_sha256": _sha(RUNTIME),
        "files": [{"path": path.relative_to(workspace).as_posix(), "size": path.stat().st_size, "sha256": _sha(path)} for path in files],
        "relocation_supported": False,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise ValueError("checkpoint output already exists")
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in files:
            archive.write(path, path.relative_to(workspace).as_posix())
        archive.writestr("checkpoint-manifest.json", json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n")
    if any(_sha(path) != item["sha256"] for path, item in zip(files, manifest["files"])):
        output.unlink(missing_ok=True)
        raise ValueError("run changed while checkpoint was being written")
    print(json.dumps({"checkpoint": str(output), "sha256": _sha(output), "run_id": summary["run_id"], "current_phase": summary["current_phase"], "relocation_supported": False}, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    start = sub.add_parser("init", help="freeze uploads, bootstrap, and run P01-P02")
    start.add_argument("--workspace-root", required=True)
    start.add_argument("--source", required=True)
    author = start.add_mutually_exclusive_group(required=False)
    author.add_argument("--request", help="exact current author request; quote safely in the shell")
    author.add_argument("--request-file", help="UTF-8 file containing the exact current author request")
    start.add_argument("--task-contract", help="current-run contract with explicit expansion directives")
    start.add_argument("--obsidian", action="store_true", help="author explicitly requested P16-P21")
    start.add_argument("--vault-zip", help="uploaded read-only Vault snapshot; implies staging-only export")
    start.set_defaults(func=init)
    inspect = sub.add_parser("status")
    inspect.add_argument("--workspace-root", required=True)
    inspect.set_defaults(func=status)
    dispatch = sub.add_parser("runtime", help="call the original Runtime with this run's dependencies")
    dispatch.add_argument("--workspace-root", required=True)
    dispatch.add_argument("runtime_args", nargs=argparse.REMAINDER)
    dispatch.set_defaults(func=runtime)
    attach = sub.add_parser("attach-vault", help="bind a late uploaded Vault ZIP at suspended P16")
    attach.add_argument("--workspace-root", required=True)
    attach.add_argument("--vault-zip", required=True)
    attach.set_defaults(func=attach_vault)
    backup = sub.add_parser("checkpoint", help="archive the full run and its hash inventory")
    backup.add_argument("--workspace-root", required=True)
    backup.add_argument("--output", required=True)
    backup.set_defaults(func=checkpoint)
    args = parser.parse_args()
    try:
        args.func(args)
    except (ValueError, OSError, RuntimeError, zipfile.BadZipFile) as exc:
        parser.exit(1, f"web-work: {exc}\n")


if __name__ == "__main__":
    main()
