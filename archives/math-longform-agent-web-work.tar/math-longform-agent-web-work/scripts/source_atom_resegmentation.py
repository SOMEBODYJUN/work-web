#!/usr/bin/env python3
"""Prepare a lossless, source-bound P04 Atom resegmentation transaction.

P04 may decide that an existing intake Atom contains several independent
responsibilities.  The declaration below is deliberately about byte spans
only; it is not a topic router and it never invents source text::

    "source_atom_resegmentation": [
      {"source_atom_id": "A0001", "children": [
        {"atom_id": "A0101", "source_byte_start": 0,
         "source_byte_end": 42},
        {"atom_id": "A0102", "source_byte_start": 42,
         "source_byte_end": 91}
      ]}
    ]

The function computes every changed file in memory and returns text payloads.
The Runtime adds those payloads to the same ACTION_COMMIT transaction as the
blueprint, so a malformed split cannot leave partially rebuilt ledgers.
"""
from __future__ import annotations

from collections import defaultdict
import copy
import hashlib
import json
from pathlib import Path
import re
import sys
from typing import Any

# The Runtime imports this helper from the repository root, while the source
# skill imports its helpers with the skill's ``scripts`` directory on
# ``sys.path``.  Make the latter resolution explicit so the helper has one
# deterministic import path in both callers.
_SKILL_SCRIPTS = Path(__file__).resolve().parents[1] / "skills" / "math-longform-publisher" / "scripts"
if str(_SKILL_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SKILL_SCRIPTS))
from safe_io import read_bytes_strict, read_jsonl_strict


DECLARATION_KEYS = (
    "source_atom_resegmentation",
    "atom_resegmentation",
    "source_atom_splits",
)
SPAN_RE = re.compile(r"^\s*(\d+)\s*[-:]\s*(\d+)\s*$")
ATOM_ID_RE = re.compile(r"^A\d{4,}$")


def _jsonl(rows: list[dict[str, Any]]) -> str:
    return "".join(
        json.dumps(row, ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n"
        for row in rows
    )


def _markdown(rows: list[dict[str, Any]], title: str) -> str:
    if not rows:
        return f"# {title}\n\n_No rows._\n"
    keys: list[str] = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)

    def cell(value: Any) -> str:
        if isinstance(value, (dict, list)):
            value = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
        return (
            str(value if value is not None else "")
            .replace("\\", "\\\\")
            .replace("|", "\\|")
            .replace("\r", "\\r")
            .replace("\n", "\\n")
            .replace("\t", "\\t")
        )

    lines = [f"# {title}", "", "| " + " | ".join(keys) + " |",
             "|" + "|".join("---" for _ in keys) + "|"]
    lines.extend("| " + " | ".join(cell(row.get(key, "")) for key in keys) + " |" for row in rows)
    return "\n".join(lines) + "\n"


def _parse_span(value: Any) -> tuple[int, int] | None:
    match = SPAN_RE.fullmatch(str(value or ""))
    if not match:
        return None
    start, end = int(match.group(1)), int(match.group(2))
    return (start, end) if start < end else None


def _span(item: dict[str, Any]) -> tuple[int, int]:
    span = _parse_span(item.get("source_span"))
    if span is not None:
        return span
    try:
        start = int(item["source_byte_start"])
        end = int(item["source_byte_end"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError("resegmentation child requires source_span or byte start/end") from exc
    if start >= end:
        raise ValueError("resegmentation child span must be non-empty")
    return start, end


def _declaration(blueprint: dict[str, Any]) -> tuple[str | None, list[dict[str, Any]]]:
    present = [key for key in DECLARATION_KEYS if key in blueprint]
    if not present:
        return None, []
    if len(present) != 1:
        raise ValueError("P04 may declare only one Atom resegmentation field")
    key = present[0]
    raw = blueprint[key]
    if isinstance(raw, dict):
        # A committed P04 blueprint is immutable with respect to its split
        # operation.  Later P04 updates may carry the audit record forward;
        # they must not apply the same split a second time.
        if str(raw.get("status", "")).upper() == "APPLIED":
            return key, []
        raw = raw.get("operations", raw.get("splits"))
    if not isinstance(raw, list) or not raw:
        raise ValueError(f"{key} must be a non-empty list of split operations")
    if not all(isinstance(item, dict) for item in raw):
        raise ValueError(f"{key} entries must be objects")
    return key, raw


def _validate_applied_history(root: Path, blueprint: dict[str, Any], key: str) -> None:
    """Ensure a prior split cannot be silently erased by a later P04 update."""
    raw = blueprint.get(key)
    if not isinstance(raw, dict) or str(raw.get("status", "")).upper() != "APPLIED":
        raise ValueError(
            "source Atom ledger contains resegmented children but the P04 blueprint lacks its APPLIED audit record"
        )
    operations = raw.get("operations")
    if not isinstance(operations, list) or not operations:
        raise ValueError("APPLIED source_atom_resegmentation must retain nonempty operations")
    atoms = _read_rows(root / "source_atom_ledger.jsonl")
    children_by_parent: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for atom in atoms:
        parent = str(atom.get("parent_atom_id", ""))
        if parent:
            children_by_parent[parent].append(atom)
    seen_parents: set[str] = set()
    for operation in operations:
        if not isinstance(operation, dict):
            raise ValueError("APPLIED resegmentation operation must be an object")
        parent = str(operation.get("source_atom_id") or operation.get("parent_atom_id") or "")
        if not parent or parent in seen_parents:
            raise ValueError("APPLIED resegmentation has an invalid or duplicate parent")
        seen_parents.add(parent)
        declared_children = operation.get("children")
        actual_children = sorted(
            children_by_parent.get(parent, []),
            key=lambda row: int(row["source_byte_start"]),
        )
        if not isinstance(declared_children, list) or len(declared_children) != len(actual_children):
            raise ValueError(f"APPLIED resegmentation child audit does not match ledger for {parent}")
        for declared, actual in zip(declared_children, actual_children):
            if not isinstance(declared, dict):
                raise ValueError("APPLIED resegmentation child must be an object")
            start, end = _span(declared)
            if (
                str(declared.get("atom_id")) != str(actual.get("atom_id"))
                or start != int(actual["source_byte_start"])
                or end != int(actual["source_byte_end"])
            ):
                raise ValueError(f"APPLIED resegmentation child audit is stale for {parent}")
    if set(children_by_parent) != seen_parents:
        raise ValueError("APPLIED resegmentation audit omits a ledger parent")


def _read_rows(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        raise ValueError(f"missing authoritative ledger: {path.name}")
    rows = read_jsonl_strict(path)
    if not rows or not all(isinstance(row, dict) for row in rows):
        raise ValueError(f"{path.name} must contain nonempty JSON objects")
    return [dict(row) for row in rows]


def _overlap_ids(rows: list[dict[str, Any]], start: int, end: int) -> list[str]:
    return [
        str(row["atom_id"])
        for row in rows
        if max(start, int(row["source_byte_start"])) < min(end, int(row["source_byte_end"]))
        and str(row.get("content_type", "")) != "DUPLICATE"
    ]


def _replace_atom_ids(value: Any, mapping: dict[str, list[str]]) -> Any:
    if isinstance(value, list):
        out: list[str] = []
        for item in value:
            for replacement in mapping.get(str(item), [str(item)]):
                if replacement not in out:
                    out.append(replacement)
        return out
    tokens = [token for token in re.split(r"[,;\s]+", str(value or "")) if token]
    out: list[str] = []
    for token in tokens:
        for replacement in mapping.get(token, [token]):
            if replacement not in out:
                out.append(replacement)
    return ",".join(out)


def _expand_atom_token(
    token: str,
    mapping: dict[str, list[str]],
    ordered_old_ids: list[str],
) -> list[str]:
    """Expand one Atom ID or bounded Atom range without topic heuristics."""
    if token in mapping:
        return list(mapping[token])
    range_match = re.fullmatch(r"A(\d{4,})-A(\d{4,})", token)
    if range_match:
        left, right = (int(range_match.group(1)), int(range_match.group(2)))
        if left > right:
            raise ValueError(f"invalid Atom range: {token}")
        selected = []
        for atom_id in ordered_old_ids:
            number_match = re.fullmatch(r"A(\d{4,})", atom_id)
            if number_match and left <= int(number_match.group(1)) <= right:
                selected.extend(mapping.get(atom_id, [atom_id]))
        if not selected:
            raise ValueError(f"Atom range does not reference the source ledger: {token}")
        return selected
    return [token]


def _rebind_atom_reference_value(
    value: Any,
    mapping: dict[str, list[str]],
    ordered_old_ids: list[str],
) -> Any:
    if isinstance(value, list):
        out: list[Any] = []
        for item in value:
            for replacement in _expand_atom_token(str(item), mapping, ordered_old_ids):
                if replacement not in out:
                    out.append(replacement)
        return out
    if isinstance(value, str):
        tokens = [token for token in re.split(r"[,;\s]+", value) if token]
        if not tokens:
            return value
        out: list[str] = []
        for token in tokens:
            for replacement in _expand_atom_token(token, mapping, ordered_old_ids):
                if replacement not in out:
                    out.append(replacement)
        return ",".join(out)
    return value


def _rebind_obligation_rows(rows: list[dict[str, Any]], atoms: list[dict[str, Any]], span_field: str) -> list[dict[str, Any]]:
    rebound: list[dict[str, Any]] = []
    for row in rows:
        updated = dict(row)
        span = _parse_span(row.get(span_field))
        if span is not None:
            updated["atom_ids"] = ",".join(_overlap_ids(atoms, *span)) or "none"
        rebound.append(updated)
    return rebound


def _contract_functions(contract: dict[str, Any]) -> set[str]:
    raw = contract.get("required_functions", [])
    values = raw if isinstance(raw, list) else re.split(r"[,;\s]+", str(raw or ""))
    return {str(value).strip() for value in values if str(value).strip()}


def _obligation_spans(root: Path) -> dict[str, tuple[int, int]]:
    result: dict[str, tuple[int, int]] = {}
    for filename, id_field in (
        ("author_question_obligation_ledger.jsonl", "question_id"),
        ("source_formula_block_ledger.jsonl", "formula_block_id"),
        ("source_math_risk_ledger.jsonl", "risk_id"),
    ):
        path = root / filename
        if not path.is_file():
            continue
        for row in _read_rows(path):
            span = _parse_span(row.get("source_span"))
            if span is not None:
                result[str(row.get(id_field, ""))] = span
    return result


def _chunk_rows(source: bytes, atoms: list[dict[str, Any]], old_chunks: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, list[dict[str, Any]]]]:
    if not old_chunks:
        raise ValueError("source_atom_resegmentation requires source_chunk_index.jsonl")
    boundaries: list[tuple[str, int, int]] = []
    seen_chunk_ids: set[str] = set()
    for row in old_chunks:
        span = _parse_span(row.get("char_span"))
        if span is None:
            raise ValueError(f"{row.get('chunk_id', '<chunk>')}: invalid chunk char_span")
        chunk_id = str(row.get("chunk_id", ""))
        if not re.fullmatch(r"C\d{3,}", chunk_id):
            raise ValueError(f"invalid source chunk ID: {chunk_id!r}")
        if chunk_id in seen_chunk_ids:
            raise ValueError(f"duplicate source chunk ID: {chunk_id}")
        seen_chunk_ids.add(chunk_id)
        if not (0 <= span[0] < span[1] <= len(source)):
            raise ValueError(f"{chunk_id}: chunk span is outside source bytes")
        try:
            source[span[0]:span[1]].decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError(f"{chunk_id}: chunk span splits UTF-8") from exc
        boundaries.append((chunk_id, *span))
    boundaries.sort(key=lambda item: item[1])
    if boundaries[0][1] != 0 or boundaries[-1][2] != len(source):
        raise ValueError("chunk boundaries do not cover source exactly")
    for previous, current in zip(boundaries, boundaries[1:]):
        if previous[2] != current[1]:
            raise ValueError("chunk boundaries are not contiguous")

    members: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for atom in atoms:
        start = int(atom["source_byte_start"])
        end = int(atom["source_byte_end"])
        matches = [cid for cid, left, right in boundaries if left <= start and end <= right]
        if len(matches) != 1:
            raise ValueError(f"{atom['atom_id']}: child atom crosses a chunk boundary")
        atom["chunk_id"] = matches[0]
        members[matches[0]].append(atom)

    out: list[dict[str, Any]] = []
    by_id = {str(row.get("chunk_id")): row for row in old_chunks}
    for cid, left, right in boundaries:
        chunk_atoms = members.get(cid, [])
        if not chunk_atoms:
            raise ValueError(f"{cid}: resegmentation would leave an empty chunk")
        first, last = chunk_atoms[0], chunk_atoms[-1]
        updated = dict(by_id[cid])
        updated.update({
            "char_span": f"{left}-{right}",
            "source_excerpt": source[left:right].decode("utf-8"),
            "start_sentence_id": first["sentence_id"],
            "end_sentence_id": last["sentence_id"],
            "semantic_unit_hint": str(len(chunk_atoms)),
            "status": "complete",
        })
        out.append(updated)
    return out, members


def prepare_resegmentation(root: Path, blueprint: dict[str, Any]) -> dict[str, str]:
    """Validate and prepare all P04 split outputs; return ``relative -> text``."""
    key, operations = _declaration(blueprint)
    if key is None:
        ledger = root / "source_atom_ledger.jsonl"
        if ledger.is_file() and any(
            str(row.get("parent_atom_id", ""))
            for row in _read_rows(ledger)
        ):
            raise ValueError(
                "source Atom ledger contains resegmented children but blueprint has no audit declaration"
            )
        return {}
    if not operations:
        _validate_applied_history(root, blueprint, key)
        return {}
    source_path = root / "source_canonical.txt"
    source = read_bytes_strict(source_path, root=root)
    atoms = _read_rows(root / "source_atom_ledger.jsonl")
    old_atoms = {str(row.get("atom_id")): row for row in atoms}
    if len(old_atoms) != len(atoms):
        raise ValueError("source_atom_ledger.jsonl contains duplicate Atom IDs")
    for atom_id, atom in old_atoms.items():
        try:
            start = int(atom["source_byte_start"])
            end = int(atom["source_byte_end"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"{atom_id}: authoritative Atom span is malformed") from exc
        if not (0 <= start < end <= len(source)):
            raise ValueError(f"{atom_id}: authoritative Atom span is outside source bytes")
        try:
            excerpt = source[start:end].decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError(f"{atom_id}: authoritative Atom span splits UTF-8") from exc
        recorded_excerpt = str(atom.get("source_excerpt", atom.get("raw_excerpt", "")))
        status_blob = " ".join(
            str(atom.get(field, ""))
            for field in ("atom_type", "ocr_state", "needed_action", "math_role")
        )
        if (
            recorded_excerpt
            and recorded_excerpt != excerpt
            and not re.search(r"canonicalized|restored|ocr", status_blob, re.I)
        ):
            raise ValueError(f"{atom_id}: authoritative Atom excerpt does not match source bytes")
    mapping: dict[str, list[str]] = {}
    child_rows: dict[str, dict[str, Any]] = {}
    operated: set[str] = set()
    for operation in operations:
        parent_id = str(operation.get("source_atom_id") or operation.get("parent_atom_id") or "")
        if parent_id not in old_atoms:
            raise ValueError(f"resegmentation parent does not exist: {parent_id!r}")
        if parent_id in operated:
            raise ValueError(f"resegmentation parent declared more than once: {parent_id}")
        operated.add(parent_id)
        children = operation.get("children")
        if not isinstance(children, list) or len(children) < 2:
            raise ValueError(f"{parent_id}: split must declare at least two children")
        parent_start = int(old_atoms[parent_id]["source_byte_start"])
        parent_end = int(old_atoms[parent_id]["source_byte_end"])
        cursor = parent_start
        ids: list[str] = []
        for child in children:
            if not isinstance(child, dict):
                raise ValueError(f"{parent_id}: child declaration must be an object")
            child_id = str(child.get("atom_id") or "")
            if not ATOM_ID_RE.fullmatch(child_id):
                raise ValueError(f"invalid resegmented child Atom ID: {child_id!r}")
            if child_id in old_atoms or child_id in child_rows:
                raise ValueError(f"resegmented child Atom ID already exists: {child_id}")
            start, end = _span(child)
            if start != cursor:
                raise ValueError(f"{parent_id}: child spans must be contiguous and ordered")
            if not (parent_start <= start < end <= parent_end):
                raise ValueError(f"{parent_id}: child span is outside its parent span")
            try:
                source[start:end].decode("utf-8")
            except UnicodeDecodeError as exc:
                raise ValueError(f"{child_id}: span splits a UTF-8 sequence") from exc
            inherited = copy.deepcopy(old_atoms[parent_id])
            excerpt = source[start:end].decode("utf-8")
            inherited.update({
                "atom_id": child_id,
                "source_byte_start": str(start),
                "source_byte_end": str(end),
                "source_excerpt_sha256": hashlib.sha256(source[start:end]).hexdigest(),
                "raw_excerpt": excerpt,
                "source_excerpt": excerpt,
                "char_span": f"{start}-{end}",
                "parent_atom_id": parent_id,
                "consumption_status": "PLANNED",
            })
            try:
                invariant = json.loads(str(inherited.get("content_invariant_json", "{}")))
            except (TypeError, json.JSONDecodeError):
                invariant = {}
            if isinstance(invariant, dict):
                invariant["summary"] = excerpt
                inherited["content_invariant_json"] = json.dumps(
                    invariant, ensure_ascii=False, sort_keys=True, separators=(",", ":")
                )
            inherited["local_context_role"] = (
                f"P04 受控重分段 {parent_id} 的子单元 {child_id}；"
                "须在新边界上重新完成语义审查"
            )
            inherited["global_context_role"] = (
                f"来源字节 {start}-{end} 的独立受控单元（由 {parent_id} 重分段产生）"
            )
            child_rows[child_id] = inherited
            ids.append(child_id)
            cursor = end
        if cursor != parent_end:
            raise ValueError(f"{parent_id}: child spans do not cover the complete parent")
        mapping[parent_id] = ids

    replacements: dict[str, dict[str, Any]] = {}
    for row in atoms:
        replacements[str(row["atom_id"])] = row
    for parent_id, children in mapping.items():
        replacements.pop(parent_id)
        replacements.update({child_id: child_rows[child_id] for child_id in children})
    atoms = sorted(replacements.values(), key=lambda row: int(row["source_byte_start"]))

    old_sentences = _read_rows(root / "source_sentence_index.jsonl")
    old_sentence_by_atom: dict[str, dict[str, Any]] = {}
    old_sentence_ids: set[str] = set()
    for row in old_sentences:
        sentence_id = str(row.get("sentence_id", ""))
        if sentence_id:
            if sentence_id in old_sentence_ids:
                raise ValueError(f"source_sentence_index.jsonl contains duplicate sentence ID: {sentence_id}")
            old_sentence_ids.add(sentence_id)
        for atom_id in re.findall(r"\bA\d{4,}\b", str(row.get("atom_ids", ""))):
            old_sentence_by_atom[atom_id] = row
    next_sentence_number = max(
        [int(match.group(1)) for value in old_sentence_ids
         if (match := re.fullmatch(r"T(\d+)", value))] or [0]
    ) + 1
    sentences: list[dict[str, Any]] = []
    for atom in atoms:
        parent = str(atom.get("parent_atom_id") or atom["atom_id"])
        prior = old_sentence_by_atom.get(parent, {})
        # Preserve unaffected sentence identities.  Only children of a split
        # parent receive fresh IDs, avoiding needless invalidation of later
        # traces and human review references.
        if parent == atom["atom_id"] and atom["atom_id"] in old_sentence_by_atom:
            sentence_id = str(prior.get("sentence_id"))
        else:
            sentence_id = f"T{next_sentence_number:04d}"
            next_sentence_number += 1
        atom["sentence_id"] = sentence_id
        sentences.append({
            "sentence_id": sentence_id,
            "chunk_id": "",
            "char_span": atom["char_span"],
            "exact_sentence_or_line": atom["raw_excerpt"],
            "sentence_role": prior.get("sentence_role", str(atom.get("content_type", "")).lower()),
            "atom_ids": atom["atom_id"],
            "coverage_status": prior.get("coverage_status", "covered"),
            "notes": prior.get("notes", "one semantic intake unit; may contain internal punctuation"),
        })
    chunks_old = _read_rows(root / "source_chunk_index.jsonl")
    chunks, members = _chunk_rows(source, atoms, chunks_old)
    for sentence, atom in zip(sentences, atoms):
        sentence["chunk_id"] = atom["chunk_id"]

    # P03 ledgers are source-span authorities. Their identities do not change;
    # only their mechanical Atom overlap mirrors are rebound.
    ledger_updates: dict[str, list[dict[str, Any]]] = {}
    for filename, span_field in (
        ("author_question_obligation_ledger.jsonl", "source_span"),
        ("source_formula_block_ledger.jsonl", "source_span"),
        ("source_math_risk_ledger.jsonl", "source_span"),
    ):
        path = root / filename
        if path.is_file():
            ledger_updates[filename] = _rebind_obligation_rows(_read_rows(path), atoms, span_field)

    updated_blueprint = copy.deepcopy(blueprint)
    ordered_old_ids = [str(row["atom_id"]) for row in sorted(
        old_atoms.values(), key=lambda row: int(row["source_byte_start"])
    )]

    # Replace each parent contract by child contracts.  The runtime may carry
    # the parent's reviewed contract forward for the first transaction, but it
    # marks that copy as inherited so P04 must explicitly re-review the new
    # boundaries before the phase can complete.  A child may provide a
    # ``contract`` object (or the contract fields directly) when the Agent has
    # already supplied the semantic split in the same response.
    original_contracts = {
        str(item.get("atom_id")): item
        for item in blueprint.get("atom_function_contracts", [])
        if isinstance(item, dict)
    }
    new_contracts: list[dict[str, Any]] = []
    for atom_id in ordered_old_ids:
        if atom_id not in mapping:
            contract = copy.deepcopy(original_contracts.get(atom_id))
            if contract is not None:
                new_contracts.append(contract)
            continue
        parent_contract = original_contracts.get(atom_id)
        if parent_contract is None:
            raise ValueError(f"resegmentation parent lacks a P04 contract: {atom_id}")
        operation = next(item for item in operations
                         if str(item.get("source_atom_id") or item.get("parent_atom_id")) == atom_id)
        children = operation["children"]
        for child in children:
            child_id = str(child["atom_id"])
            contract_override = child.get("contract")
            if contract_override is None:
                # Accept the semantic fields directly as a convenience, while
                # keeping the declaration explicit and auditable.
                direct_keys = {
                    "required_functions", "content_type", "reason",
                    "local_context_role", "global_context_role",
                    "content_invariant", "surface_contract",
                }
                contract_override = {
                    key: child[key] for key in direct_keys if key in child
                }
            if contract_override is not None and not isinstance(contract_override, dict):
                raise ValueError(f"{child_id}: contract must be an object")
            contract = copy.deepcopy(parent_contract)
            if contract_override:
                contract.update(copy.deepcopy(contract_override))
            contract["atom_id"] = child_id
            child_row = child_rows[child_id]
            contract["source_evidence"] = child_row["raw_excerpt"]
            if not contract_override:
                contract["resegmentation_inherited"] = True
            new_contracts.append(contract)
    if new_contracts:
        updated_blueprint["atom_function_contracts"] = new_contracts

    # Rebind all semantic blueprint references before processing obligation
    # contracts.  Ranges such as A0010-A0018 are expanded against the original
    # ordered ledger, so a split parent cannot remain as a stale hidden link.
    for top_key, top_value in list(updated_blueprint.items()):
        if top_key in {"atom_function_contracts", "source_obligation_contracts", "source_atom_resegmentation"}:
            continue
        if isinstance(top_value, list):
            for index, row in enumerate(top_value):
                if isinstance(row, dict):
                    for field in ("source_atoms", "source_atom_ids", "atom_ids"):
                        if field in row:
                            row[field] = _rebind_atom_reference_value(
                                row[field], mapping, ordered_old_ids
                            )
    contracts = updated_blueprint.get("source_obligation_contracts")
    if isinstance(contracts, list):
        obligation_spans = _obligation_spans(root)
        atom_contracts = {
            str(item.get("atom_id")): item
            for item in updated_blueprint.get("atom_function_contracts", [])
            if isinstance(item, dict)
        }
        for contract in contracts:
            if not isinstance(contract, dict):
                continue
            span = _parse_span(contract.get("source_span"))
            if span is None:
                span = obligation_spans.get(str(contract.get("obligation_id", "")))
            if span is not None:
                contract["source_atom_ids"] = _overlap_ids(atoms, *span)
            bindings = contract.get("function_bindings")
            if not isinstance(bindings, list):
                continue
            rebound_bindings: list[dict[str, str]] = []
            for binding in bindings:
                if not isinstance(binding, dict):
                    continue
                old_id = str(binding.get("atom_id", ""))
                function = str(binding.get("function", ""))
                candidates = mapping.get(old_id, [old_id])
                selected = [
                    atom_id for atom_id in candidates
                    if function in _contract_functions(atom_contracts.get(atom_id, {}))
                ]
                if not selected:
                    raise ValueError(
                        f"{contract.get('obligation_id', '<obligation>')}: no child P04 contract retains {old_id}/{function}"
                    )
                rebound_bindings.extend({"atom_id": atom_id, "function": function} for atom_id in selected)
            contract["function_bindings"] = rebound_bindings
            contract["required_functions"] = sorted({str(item["function"]) for item in rebound_bindings})

    # Keep the declaration as an auditable P04 decision, but remove aliases so
    # a subsequent run cannot apply the same transaction twice.
    for alias in DECLARATION_KEYS:
        if alias != key:
            updated_blueprint.pop(alias, None)
    updated_blueprint["source_atom_resegmentation"] = {
        "schema_version": "source-atom-resegmentation-v1",
        "status": "APPLIED",
        "operations": operations,
    }

    outputs: dict[str, str] = {
        "source_atom_ledger.jsonl": _jsonl(atoms),
        "source_atom_ledger.md": _markdown(atoms, "Source Atom Ledger"),
        "source_sentence_index.jsonl": _jsonl(sentences),
        "source_sentence_index.md": _markdown(sentences, "Source Sentence Index"),
        "source_chunk_index.jsonl": _jsonl(chunks),
        "source_chunk_index.md": _markdown(chunks, "Source Chunk Index"),
        "publication_blueprint.json": json.dumps(updated_blueprint, ensure_ascii=False, indent=2) + "\n",
    }
    for filename, rows in ledger_updates.items():
        outputs[filename] = _jsonl(rows)
        outputs[Path(filename).with_suffix(".md").as_posix()] = _markdown(
            rows, Path(filename).stem.replace("_", " ").title()
        )
    for cid, rows in members.items():
        outputs[f"chunk_ledger/chunk_{cid}_atom_ledger.jsonl"] = _jsonl(rows)
        outputs[f"chunk_ledger/chunk_{cid}_atom_ledger.md"] = _markdown(rows, f"{cid} Atom Ledger")
    return outputs


__all__ = ["prepare_resegmentation"]
