#!/usr/bin/env python3
"""Validate Runtime v2 plus the reviewed-apply Obsidian extension."""
from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

from handler_registry import HANDLERS  # noqa: E402
from phase_registry import routable_phase_ids, rules_for_phase  # noqa: E402
from route_compiler import RouteRequest, compile_route  # noqa: E402
from runtime_transitions import TRANSITION_PROTOCOL_VERSION  # noqa: E402


def fail(message: str) -> None:
    raise ValueError(message)


def main() -> int:
    action_schema = json.loads((ROOT / "schemas" / "action-response.schema.json").read_text(encoding="utf-8"))
    schema_phases = set(action_schema["properties"]["phase_id"]["enum"])
    catalog_phases = set(routable_phase_ids())
    if schema_phases != catalog_phases:
        fail(f"Action Schema phases differ from routable catalog: {schema_phases ^ catalog_phases}")

    for request in (RouteRequest(skip_obsidian=True), RouteRequest(skip_obsidian=False)):
        route = compile_route(request)
        missing = set(route["ordered_phase_ids"]) - set(HANDLERS)
        if missing:
            fail(f"Route contains phases without handler specs: {sorted(missing)}")

    default = compile_route(RouteRequest())
    if default["post_release_targets"] != ["obsidian"]:
        fail("Obsidian must be enabled by default")
    skipped = compile_route(RouteRequest(skip_obsidian=True))
    if skipped["post_release_targets"]:
        fail("skip route must be publication-only")

    if "P22" in catalog_phases or "P22" in HANDLERS:
        fail("P22 must not be registered in R0")
    if any(spec.mutates_formal_vault for spec in HANDLERS.values()):
        fail("Phase handlers must not mutate the formal Vault")
    implemented = "IMPLEMENTED_COPY_FIRST_V1"
    for phase_id in ("P16", "P17", "P18", "P19", "P20", "P21"):
        if HANDLERS[phase_id].implementation_status != implemented:
            fail(f"{phase_id} is not bound to the Copy-first implementation")

    plugin = json.loads((ROOT / ".codex-plugin" / "plugin.json").read_text(encoding="utf-8"))
    if plugin["version"] != "1.0.0":
        fail("Web Work upload package version must be 1.0.0")
    runtime_text = (SCRIPTS / "agent_runtime.py").read_text(encoding="utf-8")
    for required in ("submit-author-intent", "apply-obsidian", "approval-manifest-sha256"):
        if required not in runtime_text:
            fail(f"Author-directed runtime surface missing: {required}")
    for forbidden in ("codex exec", "codex-propose", "dual_agent_scheduler"):
        if forbidden in runtime_text:
            fail(f"Web Work Runtime must not launch nested Codex sessions: {forbidden}")
    if "validate_serial_completion_claim" not in runtime_text:
        fail("Runtime does not validate current-task serial completion evidence")

    kernel = ROOT / "skills" / "math-longform-publisher" / "references" / "SUPERVISOR_KERNEL.md"
    if not kernel.is_file() or not kernel.read_text(encoding="utf-8").strip():
        fail("Supervisor Kernel is missing or empty")
    for phase_id in ("P03", "P07", "P13", "P17", "P19"):
        if "references/SUPERVISOR_KERNEL.md" not in rules_for_phase(phase_id):
            fail(f"{phase_id} does not bind the Supervisor Kernel")
    if '"review_loop"' not in runtime_text or "NATIVE_SUBAGENT_REVIEW" not in runtime_text:
        fail("Runtime context envelope does not expose the native sub-agent review loop")
    skill_prompt = (ROOT / "skills" / "math-longform-publisher" / "agents" / "openai.yaml").read_text(encoding="utf-8")
    plugin_prompt = (ROOT / ".codex-plugin" / "plugin.json").read_text(encoding="utf-8")
    for prompt_name, prompt_text in (("Skill", skill_prompt), ("Plugin", plugin_prompt)):
        if "references/SUPERVISOR_KERNEL.md" not in prompt_text:
            fail(f"{prompt_name} startup prompt does not require the Supervisor Kernel")

    obsidian_text = (SCRIPTS / "obsidian_copy_first.py").read_text(encoding="utf-8")
    for required in (
        "p21_import_commit.json",
        "_recover_interrupted_imports",
        "page_patch_bundle.json",
        "FULL_ARTICLE_COPY",
    ):
        if required not in obsidian_text:
            fail(f"Reviewed apply safety surface missing: {required}")
    transaction_schema = ROOT / "schemas" / "obsidian-import-transaction-v1.schema.json"
    if not transaction_schema.is_file():
        fail("Reviewed apply transaction schema is missing")

    state_schema = json.loads((ROOT / "schemas" / "runtime-state-v2.schema.json").read_text(encoding="utf-8"))
    if state_schema.get("$id") != "urn:math-longform-agent:schema:runtime-state:v2":
        fail("Runtime State v2 Schema ID mismatch")
    if state_schema["properties"]["runtime_contract_version"].get("const") != "r0.2":
        fail("Runtime State v2 must bind runtime contract r0.2")
    action_evidence = action_schema["properties"]["phase_completion_claim"]["properties"]["evidence"]["items"]
    state_evidence = state_schema["properties"]["execution"]["properties"]["semantic_completion_evidence"]["items"]
    if action_evidence["properties"] != state_evidence["properties"]:
        fail("Runtime State semantic evidence fields differ from accepted action evidence")
    if action_evidence["required"] != state_evidence["required"]:
        fail("Runtime State semantic evidence requirements differ from accepted action evidence")
    if TRANSITION_PROTOCOL_VERSION != "transition-protocol-r0.2":
        fail("Runtime transition protocol must be r0.2")

    support_text = (SCRIPTS / "runtime_support.py").read_text(encoding="utf-8")
    for required in (
        "validate_named_sha256_sidecar",
        "validate_bare_sha256_sidecar",
    ):
        if required not in support_text:
            fail(f"Runtime sidecar interface missing: {required}")

    transition_text = (SCRIPTS / "runtime_transitions.py").read_text(encoding="utf-8")
    for stage in (
        "artifact_applied",
        "state_applied",
        "committed",
        "finalized",
    ):
        if stage not in transition_text:
            fail(f"Runtime transition stage missing: {stage}")

    print("OK")
    print(f"routable_phases={len(catalog_phases)} default_route={len(default['ordered_phase_ids'])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
