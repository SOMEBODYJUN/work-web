# Bidirectional Knowledge Graph Protocol

A WikiLink is not a connection by itself. A valid connection is a readable judgment whose two directions are useful in their own contexts.

Example shape:

- New note side: “[[A]] explains the local mechanism used here, while this note records the broader reusable strategy.”
- Existing note side: “When the strategy must be applied under these boundary conditions, see [[B]] for the full argument.”

Do not use bare link lists or relation tokens such as `supports`, `contrasts-with`, `computed-with`, `related-to`.

Every planned connection must be closed in one of two ways:
1. both endpoints are staged operations, each containing its natural sentence; or
2. the target already contains the reciprocal judgment, cited by exact inspected evidence.

A reciprocal update to a human note is prepared as a full preview and diff with the original SHA-256 precondition. It is never silently written.

Reject links based only on shared terms, category membership, or graph-density goals. An unforced sparse graph is better than a dense meaningless graph.
