# Author-Directed Obsidian Responsibility Contract

## Product rule

P00-P15 already discovered and protected the author's own reasoning, voice, questions, explanatory route, and mathematical responsibilities. P16-P21 must inherit that evidence. Never ask the author to identify authorial understanding again.

The complete released Article is always preserved. The author alone chooses
which ideas, if any, deserve independent atomic notes and may optionally state
the future question or research group those notes should serve.

The Agent alone performs:
- exact evidence location and contextual completion;
- Vault learning and retrieval;
- CREATE / UPDATE / LINK / EMBED / SKIP judgment;
- destination and naming choice learned from the Vault;
- meaningful explained outbound links;
- reciprocal backlink design and update proposals;
- MOC creation, update, reuse, or rejection;
- problem route or learning route design;
- duplication, orphan, and forced-link attacks;
- copy-first seed planning, bounded local adaptation, staging, deterministic
  validation, and reviewed application.

The Agent must not ask the author which old note to link, which folder to use, whether to create a MOC, or how to implement the graph.

## Autonomy boundary

Autonomous discoveries outside the author's atomic-note choices must not become
atomic notes. The ARTICLE operation is required. MOC and existing-note backlink
operations are knowledge infrastructure, not extra content choices, and are
allowed only when justified.

## Zero-candidate rule

The author may choose no atomic note. This is valid. Preserve the complete
Article and perform only justified links or route work. Never manufacture cards
to satisfy a quantity expectation.
