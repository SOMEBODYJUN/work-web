# P17 Author Intent Compilation

Ask one required question:

> 这篇文章里，哪些内容值得单独拉出来，作为以后继续发展的原子笔记？

Ask at most two conditional follow-ups, and only when the missing answer changes
the extraction boundary. A future question or group intention is useful but
optional. Never ask the author to choose tags, folders, existing notes, links,
or a MOC.

Compile the natural-language response into `semantic/author_intent_contract.json`.

The complete Article is always required with `FULL_COPY`. Every atomic-note
directive must include an exact quote copied from `AUTHOR_RESPONSE.md`. Do not
infer an additional atomic note from article headings, terminology,
mathematical importance, or retrieval results.

Use P00-P15 evidence to locate authorial reasoning. `source_evidence` must point
to the released `publication_final.md` and explain why the evidence fulfills the
author's chosen future use.

Set the five autonomous-scope fields to true. Those fields are not permissions
for extra atomic notes; they assign all downstream knowledge engineering to the
Agent.
