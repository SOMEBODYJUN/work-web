# MOC and Knowledge Route Decision Protocol

The Agent, not the author, decides whether knowledge navigation needs:
- a new MOC;
- an update to an existing MOC;
- reuse of an existing route without modification;
- no MOC.

A valid MOC reveals a route: a problem decomposition, learning dependency, method family, comparison structure, or writing path. It must not repeat folder contents.

Choose NONE when:
- the new material is already reachable from an existing route;
- only one or two isolated notes exist without a durable organizing problem;
- a new MOC would merely list files.

Choose UPDATE or REUSE when the Vault already has a genuine entry point. Choose CREATE only when the selected notes and existing Vault form a stable route with a clear purpose.

The decision must cite inspected Vault evidence and explain route value.
