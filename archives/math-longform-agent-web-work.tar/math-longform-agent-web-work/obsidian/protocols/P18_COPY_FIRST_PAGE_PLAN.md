# P18 Copy-first Page Planning

Write exactly one `semantic/copy_first_page_plan.json`. The plan contains no
page body and no `rendered_markdown`, `content`, or blank-page generation field.

Plan exactly one `FULL_ARTICLE_COPY` Article. For each author-selected atomic
note, select complete line slices from `evidence/publication_final.md`; include
enough local context to remain understandable, but do not rewrite the excerpt.
An inspected existing Vault note may use `INSPECTED_VAULT_COPY` only when a
reciprocal update is genuinely necessary.

Choose destinations from `vault_profile.json` and `vault_note_index.json`.
Reuse observed or pre-approved tags where they fit. A truly new tag is a
`NEW_PROPOSAL` that P20 must expose and the exact P21 approval must bind.

Every graph connection declares two readable reciprocal sentences. A WikiLink
alone is not a connection. One Article plus one atomic note normally needs their
mutual link and an explicit `MOC` decision of `NONE`.

The Runtime, not the Agent, materializes the page seeds from authoritative
source bytes. Do not manually reproduce publication prose in the plan.
