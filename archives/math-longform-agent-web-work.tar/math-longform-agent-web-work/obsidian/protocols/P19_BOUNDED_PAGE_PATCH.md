# P19 Bounded Page Patch

Open `page_seed_manifest.json` and every real file in `page-seeds/`. Write one
`semantic/page_patch_bundle.json` bound to the current plan and seed-manifest
SHA-256 values.

Allowed operations are `PREPEND`, `APPEND`, `INSERT_BEFORE_EXACT`,
`INSERT_AFTER_EXACT`, `REPLACE_EXACT`, and `DELETE_EXACT`. Except for prepend
and append, every operation carries one exact preimage that occurs exactly once.

Use local patches for formula-delimiter repair, heading adaptation, missing
local context, and natural link placement. Use an empty operation array when a
seed is already good. Never regenerate from blank, replace a complete page, or
hide broad deletions inside a new rendering.

This file contract is also the stable handoff for a future note-management
Agent. Its consumer must not depend on the identity of the Agent that wrote it.
