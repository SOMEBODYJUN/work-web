# Reader Surface Cleanliness

Final Vault pages may contain only information useful for reading, retrieval, writing, or navigation.

Allowed examples:
- title;
- restrained aliases and tags learned from the Vault;
- source note or bibliographic source;
- natural prose, definitions, derivations, examples, warnings, and explained links.

Forbidden:
- runtime hashes;
- operation ids or object ids;
- ownership and managed-contract fields;
- HTML management markers;
- database relation labels;
- staging instructions;
- validator evidence.

All machine evidence belongs under the Runtime Obsidian directory outside the Vault.
